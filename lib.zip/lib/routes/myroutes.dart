import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

class AppState {
  static GlobalKey<NavigatorState> navigatorKey =
      new GlobalKey<NavigatorState>();
  static String updateNotification = "";

  static GlobalKey<NavigatorState> getNavigator() {
    return navigatorKey;
  }
}