import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/CallScreen.dart';
import 'package:naksaa_services/UI/Home/ChatScreen.dart';
import 'package:naksaa_services/UI/Home/HistoryScreen.dart';
import 'package:naksaa_services/UI/Home/MainUtility/Terms_and_conditions.dart';
import 'package:naksaa_services/UI/Home/MainUtility/pricing_policy.dart';
import 'package:naksaa_services/UI/Home/Partner/AllLiveVendor.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/InteriorDesgin.dart';
import 'package:naksaa_services/UI/Home/our_services.dart';
import 'package:naksaa_services/UI/REgister/splashScreen.dart';
import 'package:naksaa_services/aboutus/aboutus.dart';
import 'package:naksaa_services/routes/myroutes.dart';
import 'package:url_strategy/url_strategy.dart';
import 'UI/Home/HomeScreen.dart';
import 'UI/Home/MainUtility/blog_page.dart';
import 'UI/Home/MainUtility/disclaimer.dart';
import 'UI/Home/MainUtility/privacy_policy.dart';
import 'UI/Home/MainUtility/refund_and_cancellation_policy.dart';
import 'UI/REgister/project Assets/constants.dart';

const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'High Importance Notifications', // title
  description:
      'This channel is used for important notifications.', // description
  importance: Importance.high,
  playSound: true,
);

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<void> _fireBaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  RemoteNotification? notification = message.notification;
  AndroidNotification? android = message.notification?.android;
  if (notification != null && android != null) {
    flutterLocalNotificationsPlugin.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          channel.id,
          channel.name,
          channelDescription: channel.description,
          color: themeColor,
          playSound: true,
          icon: '@mipmap/ic_launcher',
        ),
      ),
    );
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp(
  //   options: DefaultFirebaseOptions.currentPlatform,
  // );
  if (!kIsWeb) {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(_fireBaseMessagingBackgroundHandler);
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
            alert: true, badge: true, sound: true);
  } else {
    print("this is on web");

    await Firebase.initializeApp(
      options: const FirebaseOptions(
          apiKey: "AIzaSyD7CDZC5gfCsiVVCeqNfM75o9U45OJzWJk",
          authDomain: "naksa-60265.firebaseapp.com",
          projectId: "naksa-60265",
          storageBucket: "naksa-60265.appspot.com",
          messagingSenderId: "1053971998858",
          appId: "1:1053971998858:web:53fecee674690d67d86573",
          measurementId: "G-0N6MZ9FEG9"),
    );
    FirebaseMessaging.onBackgroundMessage(
      _fireBaseMessagingBackgroundHandler,
    );
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
            alert: true, badge: true, sound: true);
  }
  setPathUrlStrategy();

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  MyApp({
    super.key,
  });

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // final navigatorKey = GlobalKey<NavigatorState>();
  @override
  void intState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return Desktopmyapp();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return Desktopmyapp();
      } else {
        return Mobilemyapp();
      }
    });
  }

  @override
  Widget Desktopmyapp() {
    return MaterialApp(
      // navigatorKey: navigatorKey,
      title:
          'Naksa || Best Interior Desginer, Architecture, vastu Provider Platform',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      navigatorObservers: [FlutterSmartDialog.observer],
      builder: FlutterSmartDialog.init(),
      initialRoute: "/",

      routes: {
        // "/splashscreen": (context) => const SplashScreen(),
        // "/ChooseLanguage": (context) => const ChooseLanguage(),
        // "/Login": (context) => const PhoneRegister(),
        "/about_us": (context) => const Aboutus(),
        "/": (context) => const HomeScreen(),
        "/chat_with_us": (context) => const ChatMainScreen(),
        "/our_Services": (context) => const OurServices(),
        "/call_with_us": (context) => const CallMainScreen(),
        "/our_live_vendor": (context) => const AllLiveVendor(),
        "/history": (context) => const HistoryScreen(),
        "/pricing_policy": (context) => const PricingPolicy(),
        "/privacy_policy": (context) => const PrivacyPolicy(),
        "/terms_and_conditions": (context) => const TermsAndConditions(),
        "/refund_and_cancellaton_policy": (context) =>
            const RefundAndCancellationPolicy(),
        "/pricingpolicy": (context) => const PricingPolicy(),
        "/our_disclaimer": (context) => const OurDisclaimer(),
        "/call": (context) => const CallMainScreen(),
        "/AllLive": (context) => const AllLiveVendor(),
        "/blogPage": (context) => const BlogPage(),
        "/inetrior_desginer": (context) => const InteriorDesginDescription(),
        // "/": (context) => const SplashScreen(),
        // "/": (context) => const SplashScreen(),
        // "/": (context) => const SplashScreen(),
        // "/": (context) => const SplashScreen(),
      },
    );
  }

  @override
  Widget Mobilemyapp() {
    return kIsWeb
        ? MaterialApp(
            // navigatorKey: navigatorKey,
            title: 'Naksa',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            // onGenerateRoute: MyRoutes.generateroute,
            // home: const SplashScreen(),
            navigatorObservers: [FlutterSmartDialog.observer],
            builder: FlutterSmartDialog.init(),
            home: BottomNavigationBarScreen(
              pageIndex: 0,
            ),
          )
        : MaterialApp(
            navigatorKey: AppState.getNavigator(),
            title: 'Naksa',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            // onGenerateRoute: MyRoutes.generateroute,
            // home: const SplashScreen(),
            navigatorObservers: [FlutterSmartDialog.observer],
            builder: FlutterSmartDialog.init(),
            home: const SplashScreen(),
          );
  }
}
