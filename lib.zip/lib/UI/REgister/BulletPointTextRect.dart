import 'package:flutter/material.dart';

class BulletPointTextRect extends StatefulWidget {
  final String bulTxtRect;
  const BulletPointTextRect({Key? key, required this.bulTxtRect})
      : super(key: key);

  @override
  State<BulletPointTextRect> createState() => _BulletPointTextRectState();
}

class _BulletPointTextRectState extends State<BulletPointTextRect> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 40),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8243,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 3,
              width: 3,
              color: Colors.black,
            ),
            SizedBox(
              width: 10,
            ),
            BulletPointText(widget.bulTxtRect, context),
          ],
        ),
      ),
    );
  }
}

Widget BulletPointText(String bulTxtRect, BuildContext context) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.8243,
    child: Text(
      bulTxtRect,
      maxLines: 5,
      overflow: TextOverflow.fade,
      textAlign: TextAlign.justify,
    ),
  );
}
