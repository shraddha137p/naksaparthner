import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/REgister/OTPVarification.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class PhoneRegister extends StatefulWidget {
  const PhoneRegister({super.key});

  @override
  State<PhoneRegister> createState() => _PhoneRegisterState();
}

class _PhoneRegisterState extends State<PhoneRegister> {
  var networkHandler = NetworkHandler();
  final TextEditingController _phone = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String? ftoken;
  var isloading = false;

  @override
  void initState() {
    super.initState();
    gettoken();
  }

  Future<void> gettoken() async {
    final fcmToken = await FirebaseMessaging.instance.getToken();
    print(fcmToken);
    print("aryaman");
    setState(() {
      ftoken = fcmToken.toString();
      print("fcm  $ftoken" "  aryamans");
    });
  }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopPhoneRegister();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopPhoneRegister();
      } else {
        return MobilePhoneregister();
      }
    });
  }

  Widget DesktopPhoneRegister() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            height: screenSize.height/1.28,
            width: screenSize.width/2.74,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin:  EdgeInsets.only(top: screenSize.height/24.02, left: screenSize.width/91.4),
                  height: screenSize.height/14.7,
                  width: screenSize.width/12.8,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: screenSize.height/27.4,
                        // width: 198,
                        child: Image.asset(
                          "assets/logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                       SizedBox(
                        height: screenSize.height/192.2,
                      ),
                      Text(
                        "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width/213.3,
                          color: const Color.fromRGBO(112, 112, 112, 1),
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin:  EdgeInsets.only(top: screenSize.height/14.1),
                  height: screenSize.height/2.40,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        "assets/SVG/back.png",
                      ),
                    ),
                  ),
                  child: Container(
                    height: screenSize.height/2.46,
                    width: screenSize.width/5.64,
                    margin:  EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/96),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(screenSize.width/192),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.12),
                          offset: const Offset(
                            3.0,
                            3.0,
                          ),
                          blurRadius: 8.0,
                          spreadRadius: 2.0,
                        ), //BoxShadow
                        const BoxShadow(
                          color: Colors.white,
                          offset: Offset(
                            0.0,
                            0.0,
                          ),
                          blurRadius: 0.0,
                          spreadRadius: 0.0,
                        ), //BoxShadow
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          Container(
                            width: screenSize.width/4.8,
                            margin:  EdgeInsets.symmetric(
                              vertical: screenSize.height/27.4,
                              horizontal: screenSize.width/48,
                            ),
                            child: Text(
                              "Log In",
                              textAlign: TextAlign.center,
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/73.84,
                                color:  Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Container(
                            height: screenSize.height/17.1,
                            width: screenSize.width/4.8,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                screenSize.width/76.8,
                              ),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(
                                    0.12,
                                  ),
                                  offset: const Offset(
                                    3.0,
                                    3.0,
                                  ),
                                  blurRadius: 8.0,
                                  spreadRadius: 2.0,
                                ),
                                const BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(
                                    0.0,
                                    0.0,
                                  ),
                                  blurRadius: 0.0,
                                  spreadRadius: 0.0,
                                ), //BoxShadow
                              ],
                            ),
                            child: Row(
                              children: [
                                 SizedBox(
                                  width: screenSize.width/320,
                                ),
                                Container(
                                  height: screenSize.height/19.2,
                                  width: screenSize.width/38.4,
                                  decoration: const BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(
                                        "assets/SVG/flag-2x.png",
                                      ),
                                    ),
                                  ),
                                ),
                                 SizedBox(
                                  width: screenSize.width/96,
                                ),
                                Container(
                                  child: Center(
                                    child: Text(
                                      "INDIA +91",
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width/120,
                                        color: const Color.fromRGBO(
                                            164, 164, 164, 1),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                           SizedBox(
                            height: screenSize.height/48.05,
                          ),
                          Container(
                            height: screenSize.height/17.1,
                            width: screenSize.width/4.8,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                screenSize.width/76.8,
                              ),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(
                                    0.12,
                                  ),
                                  offset: const Offset(
                                    3.0,
                                    3.0,
                                  ),
                                  blurRadius: 8.0,
                                  spreadRadius: 2.0,
                                ), //BoxShadow
                                const BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(
                                    0.0,
                                    0.0,
                                  ),
                                  blurRadius: 0.0,
                                  spreadRadius: 0.0,
                                ), //BoxShadow
                              ],
                            ),
                            child: Center(
                                child: TextFormField(
                              controller: _phone,
                              textAlign: TextAlign.center,
                              keyboardType: TextInputType.phone,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Enter Mobile Number',
                                hintStyle: GoogleFonts.merriweather(
                                  fontSize: screenSize.width/120,
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Enter your mobile';
                                } else if (value.length < 10) {
                                  return 'Enter 10 digit mobile number';
                                } else if (value.length > 10) {
                                  return 'Enter 10 digit mobile number';
                                }
                                return null;
                              },
                              style: GoogleFonts.merriweather(
                                fontSize: 15,
                                color: const Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                          ),
                           SizedBox(
                            height: screenSize.height/24.02,
                          ),
                          GestureDetector(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                setState(
                                  () {
                                    isloading = true;
                                  },
                                );
                                Map<String, String> data = {
                                  'phone': _phone.text,
                                  'mob_notification': ftoken.toString()
                                };
                                var response = await networkHandler.post(
                                    'customer-reg', data);

                                if (response.statusCode == 200) {
                                  Map jsonResponse = jsonDecode(response.body);
                                  if (jsonResponse['status'] == true) {
                                    setState(
                                      () {
                                        isloading = false;
                                      },
                                    );
                                    Fluttertoast.showToast(
                                      msg: jsonResponse['otp'],
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: themeColor,
                                      textColor: Colors.white,
                                      fontSize: 16.0,
                                    );
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => OTPVarification(
                                          mobile: _phone.text,
                                        ),
                                      ),
                                    );
                                  } else {
                                    setState(
                                      () {
                                        isloading = false;
                                      },
                                    );
                                    Fluttertoast.showToast(
                                      msg:
                                          "Something went wrong!, please try again..",
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: themeColor,
                                      textColor: Colors.white,
                                      fontSize: screenSize.width/120,
                                    );
                                  }
                                }
                              }
                            },
                            child: isloading == false
                                ? Container(
                                    width: screenSize.width/7.77,
                                    height: screenSize.height/17.1,
                                    decoration: BoxDecoration(
                                      color: Colors.yellow,
                                      borderRadius: BorderRadius.circular(
                                        screenSize.width/76.8,
                                      ),
                                      border: Border.all(
                                        width: screenSize.width/180,
                                        color: Colors.yellow,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        "GET OTP",
                                        style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width/120,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  )
                                : Container(
                                    width: screenSize.width/7.77,
                                    height: screenSize.height/17.1,
                                    decoration: BoxDecoration(
                                      color: Colors.yellow,
                                      borderRadius: BorderRadius.circular(
                                        25,
                                      ),
                                      border: Border.all(
                                        width: screenSize.width/76.8,
                                        color: Colors.yellow,
                                      ),
                                    ),
                                    child: const Center(
                                      child: CircularProgressIndicator(
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Container(
                    margin:  EdgeInsets.only(
                      top: screenSize.height/19.2,
                    ),
                    width: screenSize.width/9.79,
                    child: Text(
                      "Welcome To Naksa Discover the Best Solution Easy & Simple",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/120,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget MobilePhoneregister() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin:  EdgeInsets.only(top: screenSize.height/8.04, left: screenSize.width/17.1),
              height: screenSize.height/9,
              width: double.infinity,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: screenSize.height/11.6,
                      // width: 198,
                      child: Image.asset(
                        "assets/naksa_logo.png",
                        fit: BoxFit.fill,
                      ),
                    ),
                     SizedBox(
                      height:  screenSize.height/151.2,
                    ),
                    Text(
                      "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/40,
                        color: const Color.fromRGBO(112, 112, 112, 1),
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ]),
            ),
            Container(
              margin:  EdgeInsets.only(top: screenSize.height/11.1),
              height: screenSize.height/2.16,
              width: double.infinity,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/SVG/back.png"))),
              child: Container(
                height: screenSize.width/1.93,
                width: screenSize.width/1.05,
                margin:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(screenSize.width/36),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.12),
                      offset: const Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 8.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                    const BoxShadow(
                      color: Colors.white,
                      offset: Offset(0.0, 0.0),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ), //BoxShadow
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(children: [
                    Container(
                      width: screenSize.width/0.9,
                      margin:  EdgeInsets.symmetric(
                          vertical: screenSize.height/21.6, horizontal: screenSize.width/9),
                      child: Text(
                        "Log In",
                        textAlign: TextAlign.left,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width/22.5,
                          color: const Color.fromRGBO(2, 44, 67, 1),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      height: screenSize.height/13.5,
                      width: screenSize.width/1.45,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/14.4),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.12),
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 8.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          const BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ), //BoxShadow
                        ],
                      ),
                      child: Row(children: [
                         SizedBox(
                          width: screenSize.width/60,
                        ),
                        Container(
                          height: screenSize.height/15.12,
                          width: screenSize.width/7.2,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage("assets/SVG/flag-2x.png"))),
                        ),
                         SizedBox(
                          width: screenSize.width/18,
                        ),
                        Container(
                          child:  Center(
                              child: Text(
                            "INDIA +91",
                            style: TextStyle(
                                fontFamily: "Merriweather-LightItalic",
                                fontSize: screenSize.width/30,
                                color: Color.fromRGBO(164, 164, 164, 1)),
                          )),
                        ),
                      ]),
                    ),
                     SizedBox(
                      height: screenSize.height/37.8,
                    ),
                    Container(
                      height: screenSize.height/13.5,
                      width: screenSize.width/1.45,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/14.4),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.12),
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 8.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          const BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ), //BoxShadow
                        ],
                      ),
                      child: Center(
                          child: TextFormField(
                        maxLength: 10,
                        controller: _phone,
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                          counterText: "",
                          border: InputBorder.none,
                          hintText: 'Enter Mobile Number',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Enter your mobile';
                          } else if (value.length < 10) {
                            return 'Enter 10 digit mobile number';
                          } else if (value.length > 10) {
                            return 'Enter 10 digit mobile number';
                          }
                          return null;
                        },
                        style:  TextStyle(
                            fontFamily: "Merriweather-LightItalic",
                            fontSize: screenSize.width/24,
                            color: Color.fromRGBO(164, 164, 164, 1)),
                      )),
                    ),
                     SizedBox(
                      height: screenSize.height/18.9,
                    ),
                    GestureDetector(
                      onTap: () async {
                        if (_formKey.currentState!.validate()) {
                          setState(() {
                            isloading = true;
                          });
                          Map<String, String> data = {
                            'phone': _phone.text,
                            'mob_notification': ftoken.toString()
                          };
                          var response =
                              await networkHandler.post('customer-reg', data);

                          if (response.statusCode == 200) {
                            Map jsonResponse = jsonDecode(response.body);
                            if (jsonResponse['status'] == true) {
                              Fluttertoast.showToast(
                                  msg: jsonResponse['otp'],
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: screenSize.width/22.5);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => OTPVarification(
                                    mobile: _phone.text,
                                  ),
                                ),
                              );
                            } else {
                              Fluttertoast.showToast(
                                  msg:
                                      "Something went wrong!, please try again..",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: screenSize.width/22.5);
                            }
                          }
                        }
                      },
                      child: isloading == false
                          ? Container(
                              width: screenSize.width/1.45,
                              height: screenSize.height/13.5,
                              decoration: BoxDecoration(
                                  color: Colors.yellow,
                                  borderRadius: BorderRadius.circular(screenSize.width/14.4),
                                  border: Border.all(
                                      width: screenSize.width/180, color: Colors.yellow)),
                              child:  Center(
                                child: Text(
                                  "GET OTP",
                                  style: TextStyle(
                                      fontFamily: "Merriweather-LightItalic",
                                      fontSize: screenSize.width/21.1,
                                      color: Colors.white),
                                ),
                              ),
                            )
                          : Container(
                              width: screenSize.width/1.45,
                              height: screenSize.height/13.5,
                              decoration: BoxDecoration(
                                  color: Colors.yellow,
                                  borderRadius: BorderRadius.circular(screenSize.width/14.4),
                                  border: Border.all(
                                      width: screenSize.width/180, color: Colors.yellow)),
                              child: const Center(
                                  child: CircularProgressIndicator(
                                color: Colors.white,
                              )),
                            ),
                    )
                  ]),
                ),
              ),
            ),
            Center(
              child: Container(
                margin:  EdgeInsets.only(
                  top: screenSize.height/15.12,
                ),
                width: screenSize.width/1.83,
                child:  Text(
                  "Welcome To Naksa Discover the Best Solution Easy & Simple",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontFamily: "Merriweather-LightItalic",
                      fontSize: screenSize.width/22.5,
                      color: Colors.black),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
