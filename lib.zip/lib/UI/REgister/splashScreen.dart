import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/REgister/Langauage.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../MainAsset/LoadingIndicator.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const ChooseLanguage(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Center(
          child: SizedBox(
        width: screenSize.width/0.45,
        height: screenSize.height/0.94,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: screenSize.height/5.04,
              width: screenSize.width/2.33,
              child: Image.asset(
                "assets/logo.png",
                fit: BoxFit.fill,
              ),
            ),
             SizedBox(
              height: screenSize.height/25.2,
            ),
            const LoadingIndicator()
          ],
        ),
      )),
    );
  }
}
