// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
// import 'package:permission_handler/permission_handler.dart';

// import '../../API/FirebaseMethods.dart';
// import '../../MainAsset/LoadingIndicator.dart';

// class BroadCastingScreen extends StatefulWidget {
//   final int uid;
//   final bool isRole;
//   final String channelId;
//   const BroadCastingScreen(
//       {super.key,
//       required this.isRole,
//       required this.channelId,
//       required this.uid});

//   @override
//   State<BroadCastingScreen> createState() => _BroadCastingScreenState();
// }

// class _BroadCastingScreenState extends State<BroadCastingScreen> {
//   String channelName = "naks";
//   String token =
//       "007eJxTYFi9oem+ivUpleZbM1v0RZV3PHnx7Uft6583gqIWbFF8dapegSHJzDDZzMTA0sTQONkkxSgtKck8zcTIwiLVxDwx0SLFbPrRG8kNgYwMp1ekMjMyQCCIz8KQl5hdzMAAAGdvI7o=";
//   // uid of the local user

//   int? _remoteUid; // uid of the remote user
//   bool _isJoined = false; // Indicates if the local user has joined the channeRl
//   late RtcEngine agoraEngine; // Agora engine instance

//   final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
//       GlobalKey<ScaffoldMessengerState>(); // Global key to access the scaffold

//   showMessage(String message) {
//     scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
//       content: Text(message),
//     ));
//   }

//   final TextEditingController _chatController = TextEditingController();
//   final _formKey = GlobalKey<FormState>();

//   @override
//   void initState() {
//     super.initState();
//     // Set up an instance of Agora engine
//     setupVideoSDKEngine();
//   }

//   @override
//   void dispose() async {
//     await agoraEngine.leaveChannel();
//     _chatController.dispose();
//     super.dispose();
//   }

//   Future<void> setupVideoSDKEngine() async {
//     // retrieve or request camera and microphone permissions
//     await [Permission.microphone, Permission.camera].request();

//     //create an instance of the Agora engine
//     agoraEngine = createAgoraRtcEngine();
//     await agoraEngine.initialize(
//         const RtcEngineContext(appId: 'b61c6409413c4d2fbb7f4288e47aa8d6'));

//     await agoraEngine.enableVideo();

//     // Register the event handler
//     agoraEngine.registerEventHandler(
//       RtcEngineEventHandler(
//         onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
//           showMessage(
//               "Local user uid:${connection.localUid} joined the channel");
//           setState(() {
//             _isJoined = true;
//           });
//         },
//         onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
//           showMessage("Remote user uid:$remoteUid joined the channel");
//           setState(() {
//             _remoteUid = remoteUid;
//           });
//         },
//         onUserOffline: (RtcConnection connection, int remoteUid,
//             UserOfflineReasonType reason) {
//           showMessage("Remote user uid:$remoteUid left the channel");
//           setState(() {
//             _remoteUid = null;
//           });
//         },
//       ),
//     );
//   }

//   void join() async {
//     // await agoraEngine.startPreview();

//     // // Set channel options including the client role and channel profile
//     ChannelMediaOptions options = const ChannelMediaOptions(
//       clientRoleType: ClientRoleType.clientRoleAudience,
//       channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
//     );
//     // await agoraEngine.startPreview();
//     // await agoraEngine
//     //     .setChannelProfile(ChannelProfileType.channelProfileLiveBroadcasting);
//     // if (widget.isRole) {
//     //   await agoraEngine.setClientRole(
//     //       role: ClientRoleType.clientRoleBroadcaster);
//     // } else {
//     //   await agoraEngine.setClientRole(role: ClientRoleType.clientRoleAudience);
//     // }

//     await agoraEngine.joinChannel(
//       token: token, channelId: channelName, uid: widget.uid,
//       options: options,
//       // uid: uid,
//     );
//     await updateViewCount(widget.uid.toString(), true);
//   }

//   void leave() async {
//     setState(() {
//       _isJoined = false;
//       _remoteUid = null;
//     });
//     await agoraEngine.leaveChannel();
//   }

//   bool isSwitched = false;
//   bool isVideomute = false;
//   bool mutecall = false;
//   void _onVideoMute(bool newval) {
//     agoraEngine.muteLocalVideoStream(newval);
//   }

//   _leaveChannel() async {
//     await agoraEngine.leaveChannel();
//     await updateViewCount(widget.uid.toString(), false);
//     //   if(widget.channelId == '123vjkv jk'){

//     //   }
//     // }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return WillPopScope(
//       onWillPop: () async {
//         _leaveChannel();
//         return Future.value(true);
//       },
//       child: Scaffold(
//         appBar: AppBar(
//           backgroundColor: darkBlue,
//           elevation: 0,
//           title: SizedBox(
//             height: 50,
//             child: Row(
//               children: [
//                 Image.asset("assets/logo.png"),
//                 SizedBox(
//                   width: 50,
//                 ),
//                 Text("Go Live")
//               ],
//             ),
//           ),
//           // centerTitle: true,
//           automaticallyImplyLeading: false,
//         ),
//         body: SingleChildScrollView(
//           child: Column(children: [
//             Container(
//               margin: const EdgeInsets.only(top: 5),
//               child: Container(
//                 height: 200,
//                 width: MediaQuery.of(context).size.width,
//                 color: textColor,
//                 child: _remoteVideo(),
//               ),
//             ),
//             GestureDetector(
//               onTap: (() {
//                 join();
//               }),
//               child: Container(
//                 height: 50,
//                 margin: const EdgeInsets.only(left: 15, right: 15),
//                 decoration: BoxDecoration(
//                     color: darkBlue, borderRadius: BorderRadius.circular(20)),
//                 width: double.infinity,
//                 child: const Center(
//                     child: Text(
//                   "Start Stream",
//                   style: TextStyle(fontSize: 18, color: Colors.white),
//                 )),
//               ),
//             ),
//             Container(
//               height: 240,
//               decoration: BoxDecoration(border: Border.all()),
//               child: Center(child: _remoteVideo()),
//             ),
//             // SizedBox(
//             //   height: 330,
//             //   child: StreamBuilder<dynamic>(
//             //       stream: FirebaseFirestore.instance
//             //           .collection('livestream')
//             //           .doc(widget.channelId)
//             //           .collection('comments')
//             //           .orderBy('createdAt', descending: true)
//             //           .snapshots(),
//             //       builder: (context, snapshot) {
//             //         if (snapshot.connectionState == ConnectionState.waiting) {
//             //           return const LoadingIndicator();
//             //         }
//             //         return ListView.builder(
//             //             itemCount: snapshot.data.docs.length,
//             //             itemBuilder: (context, index) {
//             //               return ListTile(
//             //                 title: Text(
//             //                   snapshot.data.docs[index]['username'],
//             //                   style: TextStyle(
//             //                       color: snapshot.data.docs[index]['uid'] ==
//             //                               widget.uid
//             //                           ? darkBlue
//             //                           : Colors.black),
//             //                 ),
//             //                 subtitle:
//             //                     Text(snapshot.data.docs[index]['message']),
//             //               );
//             //             });
//             //       }),
//             // ),
//             // const SizedBox(
//             //   height: 10,
//             // ),
//             // _ChatNowSection()
//           ]),
//         ),
//         // body: Stack(
//         //   children: [

//         //     Positioned(
//         //         bottom: 100,
//         //         right: 10,
//         //         child: Container(
//         //           width: 130,
//         //           height: 200,
//         //           decoration: BoxDecoration(
//         //             borderRadius: BorderRadius.circular(20),
//         //             color: Colors.yellow,
//         //           ),
//         //           child: _screenSharePreview(),
//         //         )),
//         //   ],
//         // ),
//         //  ListView(
//         //   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
//         //   children: [
//         //     // Container for the local video
//         //     Container(
//         //       height: 240,
//         //       decoration: BoxDecoration(border: Border.all()),
//         //       child: Center(child: _localPreview()),
//         //     ),
//         //     const SizedBox(height: 10),
//         //     //Container for the Remote video
//         //
//         // Button Row

//         // Button Row ends
//         //   ],
//         // )
//         bottomNavigationBar: Container(
//           padding: EdgeInsets.all(10),
//           height: 85,
//           width: MediaQuery.of(context).size.width,
//           decoration: BoxDecoration(
//               color: Color.fromRGBO(56, 56, 56, 1),
//               borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(15), topRight: Radius.circular(15))),
//           child:
//               Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
//             GestureDetector(
//               onTap: () {
//                 leave();
//               },
//               child: Container(
//                 height: 50,
//                 width: 50,
//                 decoration:
//                     BoxDecoration(color: Colors.red, shape: BoxShape.circle),
//                 child: Center(
//                     child: Icon(
//                   Icons.call,
//                   size: 25,
//                   color: Colors.white,
//                 )),
//               ),
//             ),
//             GestureDetector(
//               onTap: () {
//                 _switchCamera();
//                 // _onHandsFree(isSwitched);
//               },
//               child: Container(
//                 height: 50,
//                 width: 50,
//                 decoration: BoxDecoration(
//                     color: isSwitched != true ? themeColor : Colors.red,
//                     shape: BoxShape.circle),
//                 child: Center(
//                     child: Icon(
//                   Icons.switch_camera,
//                   size: 25,
//                   color: isSwitched != true ? Colors.black : Colors.white,
//                 )),
//               ),
//             ),
//             GestureDetector(
//               onTap: () {
//                 setState(() {
//                   isVideomute = !isVideomute;
//                 });
//                 _onVideoMute(isVideomute);
//               },
//               child: Container(
//                 height: 50,
//                 width: 50,
//                 decoration: BoxDecoration(
//                     color: isVideomute != true ? themeColor : Colors.red,
//                     shape: BoxShape.circle),
//                 child: Center(
//                     child: Icon(
//                   Icons.videocam_off,
//                   size: 25,
//                   color: isVideomute != true ? Colors.black : Colors.white,
//                 )),
//               ),
//             ),
//             GestureDetector(
//               onTap: () {
//                 setState(() {
//                   mutecall = !mutecall;
//                 });
//                 _onmute(mutecall);
//               },
//               child: Container(
//                 height: 50,
//                 width: 50,
//                 decoration: BoxDecoration(
//                   color: mutecall != true ? themeColor : Colors.red,
//                   shape: BoxShape.circle,
//                 ),
//                 child: Center(
//                     child: Icon(
//                   Icons.mic,
//                   size: 25,
//                   color: mutecall != true ? Colors.black : Colors.white,
//                 )),
//               ),
//             ),
//             GestureDetector(
//               onTap: () {
//                 _shareScreen();
//               },
//               child: Container(
//                 height: 50,
//                 width: 50,
//                 decoration: BoxDecoration(
//                   color: themeColor,
//                   shape: BoxShape.circle,
//                 ),
//                 child: Center(
//                     child: SvgPicture.asset(
//                   "assets/SVG/share.svg",
//                   // color: Colors.white,
//                 )),
//               ),
//             ),
//           ]),
//         ),
//       ),
//     );
//   }

//   void _onmute(bool sts) {
//     agoraEngine.muteLocalAudioStream(sts);
//   }

//   Future<void> _switchCamera() {
//     return agoraEngine.switchCamera();
//   }

//   bool _isScreenShared = false;

//   Future<void> _shareScreen() async {
//     setState(() {
//       _isScreenShared = !_isScreenShared;
//     });

//     if (_isScreenShared) {
//       agoraEngine.startScreenCapture(const ScreenCaptureParameters2(
//           captureAudio: true,
//           audioParams: ScreenAudioParameters(
//               sampleRate: 16000, channels: 2, captureSignalVolume: 100),
//           captureVideo: true,
//           videoParams: ScreenVideoParameters(
//               dimensions: VideoDimensions(height: 1280, width: 720),
//               frameRate: 15,
//               bitrate: 600)));
//       // Start screen sharing

//     } else {
//       await agoraEngine.stopScreenCapture();
//     }

//     // Update channel media options to publish camera or screen capture streams
//     ChannelMediaOptions options = ChannelMediaOptions(
//       publishCameraTrack: !_isScreenShared,
//       publishMicrophoneTrack: !_isScreenShared,
//       publishScreenTrack: _isScreenShared,
//       publishScreenCaptureAudio: _isScreenShared,
//       publishScreenCaptureVideo: _isScreenShared,
//     );

//     agoraEngine.updateChannelMediaOptions(options);
//   }

//   // Future<void> _shareScreen() async {
//   //   setState(() {
//   //     _isScreenShared = !_isScreenShared;
//   //   });

//   //   if (_isScreenShared) {
//   //     if(Platform.isAndroid || Platform.isWindows || Platform.isMacOS){
//   //       final windows = agoraEngine.enumerateDisplays();
//   //       await agoraEngine.startScreenCaptureByWindowId(windowId: windowId, regionRect: regionRect, captureParams: captureParams)
//   //     }

//   //   } else {
//   //     await agoraEngine.stopScreenCapture();
//   //   }

//   //   // Set and update channel media options
//   //   ChannelMediaOptions options = ChannelMediaOptions(
//   //     publishScreenTrack: _isScreenShared,
//   //     publishCameraTrack: !_isScreenShared,
//   //   );

//   //   agoraEngine.updateChannelMediaOptions(options);
//   // }

//   Widget _screenSharePreview() {
//     // Display local video or screen sharing preview
//     if (_isJoined) {
//       if (!_isScreenShared) {
//         return AgoraVideoView(
//           controller: VideoViewController(
//             rtcEngine: agoraEngine,
//             canvas: const VideoCanvas(uid: 0),
//           ),
//         );
//       } else {
//         return AgoraVideoView(
//             controller: VideoViewController(
//           rtcEngine: agoraEngine,
//           canvas: const VideoCanvas(
//             uid: 0,
//             sourceType: VideoSourceType.videoSourceScreen,
//           ),
//         ));
//       }
//     } else {
//       return const Center(
//         child: Text(
//           'Live Preview',
//           style: TextStyle(fontSize: 18, color: Colors.white),
//           textAlign: TextAlign.center,
//         ),
//       );
//     }
//   }

//   Widget _ChatNowSection() {
//     if (_isJoined) {
//       return Container(
//           height: 50,
//           margin: const EdgeInsets.only(left: 15, right: 15, bottom: 10),
//           decoration: BoxDecoration(
//               border: Border.all(color: darkBlue, width: 1),
//               borderRadius: BorderRadius.circular(20)),
//           child: Row(children: [
//             Container(
//               height: 50,
//               width: 280,
//               child: Form(
//                 key: _formKey,
//                 child: TextFormField(
//                   controller: _chatController,
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return 'Please enter message';
//                     }
//                     return null;
//                   },
//                   cursorColor: Colors.black,
//                   // keyboardType: inputType,
//                   decoration: const InputDecoration(
//                       border: InputBorder.none,
//                       focusedBorder: InputBorder.none,
//                       enabledBorder: InputBorder.none,
//                       errorBorder: InputBorder.none,
//                       disabledBorder: InputBorder.none,
//                       contentPadding: EdgeInsets.only(
//                           left: 15, bottom: 11, top: 11, right: 15),
//                       hintText: "Chat Now"),
//                 ),
//               ),
//             ),
//             const SizedBox(
//               width: 10,
//             ),
//             GestureDetector(
//               onTap: () {
//                 if (_formKey.currentState!.validate()) {
//                   chatFirebase(_chatController.text, widget.channelId, context,
//                       'Rohit Kushwaha', widget.uid.toString());
//                   _chatController.clear();
//                 }
//               },
//               child: Container(
//                 height: 21,
//                 width: 25,
//                 decoration: const BoxDecoration(
//                     // shape: BoxShape.circle,
//                     image: DecorationImage(
//                         image: AssetImage("assets/SVG/Group.png"),
//                         fit: BoxFit.fill)),
//               ),
//             )
//           ]));
//     } else {
//       return GestureDetector(
//         onTap: (() {
//           join();
//         }),
//         child: Container(
//           height: 50,
//           margin: const EdgeInsets.only(left: 15, right: 15),
//           decoration: BoxDecoration(
//               color: darkBlue, borderRadius: BorderRadius.circular(20)),
//           width: double.infinity,
//           child: const Center(
//               child: Text(
//             "Start Stream",
//             style: TextStyle(fontSize: 18, color: Colors.white),
//           )),
//         ),
//       );
//     }
//   }

//   // Future<void> _showMyDialog() async {
//   //   return showDialog<void>(
//   //     context: context,
//   //     barrierDismissible: true, // user must tap button!
//   //     builder: (BuildContext context) {
//   //       return SimpleDialog(
//   //           backgroundColor: Colors.white,
//   //           insetPadding: EdgeInsets.only(top: 500),
//   //           shape:
//   //               RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
//   //           children: [
//   //             Container(
//   //               width: 150,
//   //               child: Row(
//   //                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//   //                   crossAxisAlignment: CrossAxisAlignment.center,
//   //                   children: [
//   //                     GestureDetector(
//   //                       onTap: () {
//   //                         leave();
//   //                       },
//   //                       child: Container(
//   //                         child: Column(children: [
//   //                           Container(
//   //                             height: 40,
//   //                             width: 40,
//   //                             decoration: BoxDecoration(shape: BoxShape.circle),
//   //                             child: Center(
//   //                                 child: SvgPicture.asset(
//   //                               "assets/SVG/chatsvg.svg",
//   //                               // color: Colors.white,
//   //                             )),
//   //                           ),
//   //                           SizedBox(
//   //                             height: 7,
//   //                           ),
//   //                           Text(
//   //                             "Chat Now",
//   //                             style: TextStyle(
//   //                                 fontSize: 12,
//   //                                 fontWeight: FontWeight.bold,
//   //                                 color: blueColor),
//   //                           )
//   //                         ]),
//   //                       ),
//   //                     ),
//   //                     GestureDetector(
//   //                       onTap: () {
//   //                         Navigator.pop(context);
//   //                         _shareScreen();
//   //                       },
//   //                       child: Container(
//   //                         child: Column(
//   //                             crossAxisAlignment: CrossAxisAlignment.center,
//   //                             children: [
//   //                               Container(
//   //                                 height: 40,
//   //                                 width: 40,
//   //                                 decoration:
//   //                                     BoxDecoration(shape: BoxShape.circle),
//   //                                 child: Center(
//   //                                     child: SvgPicture.asset(
//   //                                   "assets/SVG/share.svg",
//   //                                   // color: Colors.white,
//   //                                 )),
//   //                               ),
//   //                               SizedBox(
//   //                                 height: 7,
//   //                               ),
//   //                               _isScreenShared
//   //                                   ? Text(
//   //                                       "Stop Screen Share",
//   //                                       style: TextStyle(
//   //                                           fontSize: 12,
//   //                                           fontWeight: FontWeight.bold,
//   //                                           color: blueColor),
//   //                                     )
//   //                                   : Text(
//   //                                       "Start Screen Share",
//   //                                       style: TextStyle(
//   //                                           fontSize: 12,
//   //                                           fontWeight: FontWeight.bold,
//   //                                           color: blueColor),
//   //                                     )
//   //                             ]),
//   //                       ),
//   //                     ),
//   //                   ]),
//   //             ),
//   //           ]);
//   //     },
//   //   );
//   // }

// // Display local video preview
//   Widget _localPreview() {
//     if (_isJoined) {
//       return AgoraVideoView(
//           controller: VideoViewController(
//         rtcEngine: agoraEngine,
//         canvas: VideoCanvas(
//           uid: widget.uid,
//           sourceType: VideoSourceType.videoSourceScreen,
//         ),
//       ));
//     } else {
//       return const Center(
//         child: Text(
//           'Live Preview',
//           style: TextStyle(fontSize: 18, color: Colors.white),
//           textAlign: TextAlign.center,
//         ),
//       );
//     }
//   }

// // Display remote user's video
//   Widget _remoteVideo() {
//     if (_remoteUid != null) {
//       // return Container();
//       return AgoraVideoView(
//         controller: VideoViewController.remote(
//           rtcEngine: agoraEngine,
//           canvas: VideoCanvas(uid: _remoteUid),
//           connection: RtcConnection(channelId: channelName),
//         ),
//       );
//     } else {
//       String msg = '';
//       if (_isJoined) msg = 'Waiting for a remote user to join';
//       return Text(
//         msg,
//         textAlign: TextAlign.center,
//       );
//     }
//   }
// }
