import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/Service/CustomerFollowingService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/customerFollowingModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../MainAsset/URL.dart';
import '../Home/Partner/VendorProfile.dart';

class CustomerFollowingScreen extends StatefulWidget {
  const CustomerFollowingScreen({super.key});

  @override
  State<CustomerFollowingScreen> createState() =>
      _CustomerFollowingScreenState();
}

class _CustomerFollowingScreenState extends State<CustomerFollowingScreen> {
  var customerFollowingService = CustomerFollowingService();
  List<CustomerFollowingData> results = [];
  Future<List<CustomerFollowingData>> getdata() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    results = (await customerFollowingService.viewVendorFollower(uid!))!;
    if (results != null) {
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    Color themeColor = const Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = const Color.fromRGBO(56, 56, 56, 1);

    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopCusomerfollowing();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopCusomerfollowing();
      } else {
        return MobileCusomerfollowing();
      }
    });
  }

  Widget DesktopCusomerfollowing() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Following"),
        elevation: 0,
        backgroundColor: themeColor,
      ),
      body: Container(
        color: const Color.fromRGBO(242, 244, 243, 1),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                  margin: const EdgeInsets.only(top: 15, bottom: 15),
                  child: FutureBuilder(
                    future: getdata(),
                    builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                        item.hasData
                            ? item.data!.isNotEmpty
                                ? ListView.builder(
                                    itemCount: results.length,
                                    physics:
                                        const AlwaysScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    itemBuilder: ((context, index) {
                                      return GestureDetector(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  VendorProfileScreen(
                                                vid: results[index]
                                                    .id
                                                    .toString(),
                                              ),
                                            ),
                                          );
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(
                                            10,
                                          ),
                                          height: 134,
                                          margin: const EdgeInsets.only(
                                            bottom: 15,
                                            left: 14,
                                            right: 14,
                                          ),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: Colors.white,
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color.fromRGBO(
                                                  0,
                                                  0,
                                                  0,
                                                  0.16,
                                                ),
                                                offset: Offset(
                                                  3.0,
                                                  3.0,
                                                ),
                                                blurRadius: 6.0,
                                                spreadRadius: 2.0,
                                              ), //BoxShadow
                                              BoxShadow(
                                                color: Colors.white,
                                                offset: Offset(
                                                  0.0,
                                                  0.0,
                                                ),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                SizedBox(
                                                  width: 65,
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Container(
                                                        height: 60,
                                                        width: 60,
                                                        decoration:
                                                            BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          border: Border.all(
                                                              width: 1,
                                                              color:
                                                                  themeColor),
                                                          image:
                                                              DecorationImage(
                                                            image: NetworkImage(
                                                                '${MainUrl}vendor-image/${results[index].photo}'),
                                                            fit: BoxFit.cover,
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        height: 12,
                                                      ),
                                                      Container(
                                                        child:
                                                            RatingBarIndicator(
                                                          rating: 4.5,
                                                          itemBuilder: (
                                                            context,
                                                            index,
                                                          ) =>
                                                              const Icon(
                                                            Icons.star,
                                                            color: Colors.amber,
                                                          ),
                                                          itemCount: 5,
                                                          itemSize: 13.0,
                                                          direction:
                                                              Axis.horizontal,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      Container(
                                                        child: const Center(
                                                          child: Text(
                                                            "734 Votes",
                                                            style: TextStyle(
                                                              fontSize: 9,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(
                                                  width: 24,
                                                ),
                                                Container(
                                                  child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          results[index].name,
                                                          style:
                                                              const TextStyle(
                                                                  fontSize: 16,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Colors
                                                                      .black),
                                                        ),
                                                        const SizedBox(
                                                          height: 10,
                                                        ),
                                                        SizedBox(
                                                          width: 150,
                                                          child: Text(
                                                            results[index]
                                                                .primaryskills,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                                fontSize: 13,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.53)),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          height: 5,
                                                        ),
                                                        SizedBox(
                                                          width: 150,
                                                          child: Text(
                                                            results[index]
                                                                .language,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                                fontSize: 13,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.53)),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                          "${(results[index].enddate.difference(results[index].startdate).inDays)} Days",
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              color: Colors
                                                                  .black
                                                                  .withOpacity(
                                                                      0.53)),
                                                        ),
                                                        const SizedBox(
                                                          height: 6,
                                                        ),
                                                        // Text(
                                                        //   "₹ ${results![index].audicallprice}/min",
                                                        //   style: TextStyle(
                                                        //       fontSize: 14,
                                                        //       fontWeight:
                                                        //           FontWeight
                                                        //               .bold,
                                                        //       color: Colors
                                                        //           .black
                                                        //           .withOpacity(
                                                        //               1)),
                                                        // )
                                                      ]),
                                                ),
                                                Container(
                                                  child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: [
                                                        Container(
                                                          height: 40,
                                                          width: 40,
                                                          decoration: const BoxDecoration(
                                                              image: DecorationImage(
                                                                  image: AssetImage(
                                                                      "assets/SVG/star2-2x.png"))),
                                                          child: const Center(
                                                              child: Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                                    bottom: 5),
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                              size: 16,
                                                            ),
                                                          )),
                                                        ),
                                                        results[index].follow ==
                                                                "true"
                                                            ? GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  showDialog(
                                                                      context:
                                                                          context,
                                                                      builder: (BuildContext
                                                                              context) =>
                                                                          AlertDeleteModal(
                                                                            cid:
                                                                                results[index].customerid.toString(),
                                                                            vid:
                                                                                results[index].vendorid.toString(),
                                                                            name:
                                                                                results[index].name,
                                                                          ));
                                                                },
                                                                child:
                                                                    Container(
                                                                  height: 25,
                                                                  width: 65,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      color:
                                                                          themeColor),
                                                                  child:
                                                                      const Center(
                                                                          child:
                                                                              Text(
                                                                    "UnFollow",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            12,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .bold,
                                                                        color: Color.fromRGBO(
                                                                            2,
                                                                            44,
                                                                            67,
                                                                            1)),
                                                                  )),
                                                                ),
                                                              )
                                                            : GestureDetector(
                                                                onTap:
                                                                    () async {},
                                                                child:
                                                                    Container(
                                                                  height: 25,
                                                                  width: 65,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      color:
                                                                          themeColor),
                                                                  child:
                                                                      const Center(
                                                                          child:
                                                                              Text(
                                                                    "Follow",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            12,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .bold,
                                                                        color: Color.fromRGBO(
                                                                            2,
                                                                            44,
                                                                            67,
                                                                            1)),
                                                                  )),
                                                                ),
                                                              )
                                                      ]),
                                                )
                                              ]),
                                        ),
                                      );
                                    }))
                                : const Center(
                                    child: Text("No Data Found"),
                                  )
                            : const Center(
                                child: CircularProgressIndicator(),
                              ),
                  ))
            ]),
      ),
    );
  }

  Widget MobileCusomerfollowing() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Following"),
        elevation: 0,
        backgroundColor: themeColor,
      ),
      body: Container(
        color: const Color.fromRGBO(242, 244, 243, 1),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                  margin:  EdgeInsets.only(top: screenSize.height/50.4, bottom: screenSize.height/50.4),
                  child: FutureBuilder(
                    future: getdata(),
                    builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                        item.hasData
                            ? item.data!.isNotEmpty
                                ? ListView.builder(
                                    itemCount: results.length,
                                    physics:
                                        const AlwaysScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    itemBuilder: ((context, index) {
                                      return GestureDetector(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      VendorProfileScreen(
                                                          vid: results[index]
                                                              .id
                                                              .toString())));
                                        },
                                        child: Container(
                                          padding:  EdgeInsets.all(screenSize.width/36),
                                          height: screenSize.height/5.64,
                                          margin:  EdgeInsets.only(
                                              bottom: screenSize.height/50.4, left: screenSize.width/25.7, right: screenSize.width/25.7),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(screenSize.width/36),
                                            color: Colors.white,
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color.fromRGBO(
                                                    0, 0, 0, 0.16),
                                                offset: Offset(
                                                  3.0,
                                                  3.0,
                                                ),
                                                blurRadius: 6.0,
                                                spreadRadius: 2.0,
                                              ), //BoxShadow
                                              BoxShadow(
                                                color: Colors.white,
                                                offset: Offset(0.0, 0.0),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                SizedBox(
                                                  width: screenSize.width/5.53,
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Container(
                                                        height: screenSize.height/12.6,
                                                        width: screenSize.width/6,
                                                        decoration: BoxDecoration(
                                                            shape:
                                                                BoxShape.circle,
                                                            border: Border.all(
                                                                width: screenSize.width/1,
                                                                color:
                                                                    themeColor),
                                                            image: DecorationImage(
                                                                image: NetworkImage(
                                                                    '${MainUrl}vendor-image/${results[index].photo}'),
                                                                fit: BoxFit
                                                                    .cover)),
                                                      ),
                                                       SizedBox(
                                                        height: screenSize.height/63,
                                                      ),
                                                      Container(
                                                        child:
                                                            RatingBarIndicator(
                                                          rating: 4.5,
                                                          itemBuilder: (context,
                                                                  index) =>
                                                              const Icon(
                                                            Icons.star,
                                                            color: Colors.amber,
                                                          ),
                                                          itemCount: 5,
                                                          itemSize: 13.0,
                                                          direction:
                                                              Axis.horizontal,
                                                        ),
                                                      ),
                                                       SizedBox(
                                                        height: screenSize.height/75.6,
                                                      ),
                                                      Container(
                                                        child:  Center(
                                                            child: Text(
                                                          "734 Votes",
                                                          style: TextStyle(
                                                              fontSize: screenSize.width/40,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600),
                                                        )),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                 SizedBox(
                                                  width: screenSize.width/15,
                                                ),
                                                Container(
                                                  child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          results[index].name,
                                                          style:
                                                               TextStyle(
                                                                  fontSize: screenSize.width/22.5,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Colors
                                                                      .black),
                                                        ),
                                                         SizedBox(
                                                          height: screenSize.height/75.6,
                                                        ),
                                                        SizedBox(
                                                          width: screenSize.width/2.4,
                                                          child: Text(
                                                            results[index]
                                                                .primaryskills,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                                fontSize: screenSize.width/27.6,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.53)),
                                                          ),
                                                        ),
                                                         SizedBox(
                                                          height: screenSize.height/151.2,
                                                        ),
                                                        SizedBox(
                                                          width: screenSize.width/6.4,
                                                          child: Text(
                                                            results[index]
                                                                .language,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                                fontSize: screenSize.width/36,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.53)),
                                                          ),
                                                        ),
                                                         SizedBox(
                                                          height: screenSize.height/151.2,
                                                        ),
                                                        Text(
                                                          "${(results[index].enddate.difference(results[index].startdate).inDays)} Days",
                                                          style: TextStyle(
                                                              fontSize: screenSize.width/27.6,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              color: Colors
                                                                  .black
                                                                  .withOpacity(
                                                                      0.53)),
                                                        ),
                                                         SizedBox(
                                                          height: screenSize.height/126,
                                                        ),
                                                        
                                                      ]),
                                                ),
                                                Container(
                                                  child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: [
                                                        Container(
                                                          height: screenSize.height/18.9,
                                                          width: screenSize.width/9,
                                                          decoration: const BoxDecoration(
                                                              image: DecorationImage(
                                                                  image: AssetImage(
                                                                      "assets/SVG/star2-2x.png"))),
                                                          child:  Center(
                                                              child: Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                                    bottom: screenSize.height/151.2),
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                              size: screenSize.width/22.5,
                                                            ),
                                                          )),
                                                        ),
                                                        results[index].follow ==
                                                                "true"
                                                            ? GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  showDialog(
                                                                      context:
                                                                          context,
                                                                      builder: (BuildContext
                                                                              context) =>
                                                                          AlertDeleteModal(
                                                                            cid:
                                                                                results[index].customerid.toString(),
                                                                            vid:
                                                                                results[index].vendorid.toString(),
                                                                            name:
                                                                                results[index].name,
                                                                          ));
                                                                },
                                                                child:
                                                                    Container(
                                                                  height: screenSize.height/30.2,
                                                                  width: screenSize.width/5.53,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              screenSize.width/36),
                                                                      color:
                                                                          themeColor),
                                                                  child:
                                                                       Center(
                                                                          child:
                                                                              Text(
                                                                    "UnFollow",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            screenSize.width/30,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .bold,
                                                                        color: Color.fromRGBO(
                                                                            2,
                                                                            44,
                                                                            67,
                                                                            1)),
                                                                  )),
                                                                ),
                                                              )
                                                            : GestureDetector(
                                                                onTap:
                                                                    () async {},
                                                                child:
                                                                    Container(
                                                                  
                                                                  height: screenSize.height/30.2,
                                                                  width: screenSize.width/5.53,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              screenSize.width/36),
                                                                      color:
                                                                          themeColor),
                                                                  child:
                                                                       Center(
                                                                          child:
                                                                              Text(
                                                                    "Follow",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            screenSize.width/30,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .bold,
                                                                        color: Color.fromRGBO(
                                                                            2,
                                                                            44,
                                                                            67,
                                                                            1)),
                                                                  )),
                                                                ),
                                                              )
                                                      ]),
                                                )
                                              ]),
                                        ),
                                      );
                                    }))
                                : const Center(
                                    child: Text("No Data Found"),
                                  )
                            : const Center(
                                child: CircularProgressIndicator(),
                              ),
                  ))
            ]),
      ),
    );
  }
}

class AlertDeleteModal extends StatelessWidget {
  String name;
  String cid;
  String vid;
  AlertDeleteModal(
      {super.key, required this.name, required this.cid, required this.vid});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      elevation: 0.6,
      contentPadding:
          const EdgeInsets.only(left: 20, right: 10, top: 5, bottom: 5),
      titlePadding:
          const EdgeInsets.only(left: 20, right: 10, top: 5, bottom: 5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "Unfollow",
            style: TextStyle(
                fontSize: 17, fontWeight: FontWeight.bold, color: darkBlue),
          ),
          IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                color: Colors.black,
              ))
        ],
      ),
      content: SizedBox(
        height: 80,
        width: 300,
        child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "Are you sure you want to unfollow $name",
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
              ),
              const SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {
                  followVendor(cid, vid, true, context);
                },
                child: Container(
                  height: 30,
                  width: 80,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10), color: darkBlue),
                  child: const Center(
                      child: Text(
                    "Unfollow",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600),
                  )),
                ),
              )
            ]),
      ),
    );
  }

  var networkhandler = NetworkHandler();
  void followVendor(
      String cid, String vid, bool follow, BuildContext context) async {
    Map<String, dynamic> data = {
      'customerid': cid,
      'vendorid': vid,
      'follow': follow,
    };

    var response = await networkhandler.post('vendor-follower', data);
    print(response.body);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse['data'] == 'inserted' ||
          jsonResponse['data'] == 'updated') {
        if (follow == true) {
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                  builder: (context) => const CustomerFollowingScreen()),
              (route) => false);
          Fluttertoast.showToast(
              msg: "Sorry for inconvenience with  $name",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: darkBlue,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      }
    }
  }
}
