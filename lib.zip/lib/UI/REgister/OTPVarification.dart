import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Service/CustomerProfileService.dart';
import '../../model/CustomerProfileModel.dart';
import '../Home/CompleteProfileScreen.dart';

class OTPVarification extends StatefulWidget {
  String mobile;
  OTPVarification({super.key, required this.mobile});

  @override
  State<OTPVarification> createState() => _OTPVarificationState();
}

class _OTPVarificationState extends State<OTPVarification>
    with SingleTickerProviderStateMixin {
  var networkHandler = NetworkHandler();
  bool isloading = false;
  final TextEditingController _otp1 = TextEditingController();
  final TextEditingController _otp2 = TextEditingController();
  final TextEditingController _otp3 = TextEditingController();
  final TextEditingController _otp4 = TextEditingController();
  AnimationController? _animationController;
  int levelClock = 60;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
        vsync: this, duration: Duration(seconds: levelClock));

    _animationController!.forward();
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopOTPVarification();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopOTPVarification();
      } else {
        return MobileOTPVarification();
      }
    });
  }

  Widget DesktopOTPVarification() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: Center(
        child: SizedBox(
          height: screenSize.height/0.961,
          width: screenSize.width/2.74,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin:  EdgeInsets.only(top: screenSize.height/24.02, left: screenSize.width/91.42),
                height: screenSize.height/6.86,
                width: screenSize.width/12.8,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: screenSize.height/10.67,
                        child: Image.asset(
                          "assets/naksa_logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                       SizedBox(
                        height: screenSize.height/192.2,
                      ),
                      Text(
                        "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width/160,
                          color: const Color.fromRGBO(112, 112, 112, 1),
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ]),
              ),
              Container(
                margin:  EdgeInsets.only(top: screenSize.height/19.22),
                height: screenSize.height/2.40,
                padding:  EdgeInsets.only(left: screenSize.width/64, right: screenSize.width/64),
                width: double.infinity,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/SVG/back.png"))),
                child: Container(
                  height: screenSize.height/3.41,
                  width: screenSize.width/8.45,
                  margin:  EdgeInsets.only(left: screenSize.width/29.5, right: screenSize.width/29.5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(screenSize.width/192),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      const BoxShadow(
                        color: Colors.white,
                        offset: Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Column(children: [
                    SizedBox(
                      height: screenSize.height/9.61,
                      child: Stack(
                        children: [
                          Container(
                            margin:  EdgeInsets.only(top: screenSize.height/21.35),
                            height: screenSize.height/12.64,
                            width: screenSize.width/2.51,
                            padding:  EdgeInsets.all(screenSize.width/192),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  width: screenSize.width/240,
                                  color:
                                      const Color.fromRGBO(240, 240, 240, 1)),
                            ),
                            child: const Image(
                              image: AssetImage("assets/SVG/ic-contact-2x.png"),
                              fit: BoxFit.contain,
                            ),
                          ),
                          Positioned(
                              top: screenSize.height/25.97,
                              // left: 150,
                              right: 0,
                              child: Container(
                                height: screenSize.height/41.78,
                                width: screenSize.width/83.47,
                                decoration: const BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                      "assets/SVG/message-2x.png",
                                    ),
                                  ),
                                ),
                              ))
                        ],
                      ),
                    ),
                     SizedBox(
                      height: screenSize.height/60.06,
                    ),
                    Container(
                        child: Text(
                      "Enter 4 Digits code",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/192,
                        color: const Color.fromRGBO(164, 164, 164, 1),
                        fontWeight: FontWeight.bold,
                      ),
                    )),
                   
                    Container(
                      margin:  EdgeInsets.all(screenSize.width/192),
                      child: Form(
                        key: _formKey,
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                height: screenSize.height/16.01,
                                width: screenSize.width/32,
                                child: TextFormField(
                                  controller: _otp1,
                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: darkBlue, width: screenSize.width/960),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: themeColor, width: screenSize.width/1920),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: screenSize.height/16.01,
                                width: screenSize.width/32,
                                child: TextFormField(
                                  controller: _otp2,

                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: darkBlue, width:screenSize.width/960),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: themeColor, width: screenSize.width/1920),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: screenSize.height/16.01,
                                width: screenSize.width/32,
                                child: TextFormField(
                                  controller: _otp3,
                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: darkBlue, width: screenSize.width/960),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: themeColor, width: screenSize.width/1920),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: screenSize.height/16.01,
                                width: screenSize.width/32.66,
                                child: TextFormField(
                                  controller: _otp4,
                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: darkBlue, width: screenSize.width/960),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/128),
                                      borderSide:  BorderSide(
                                          color: themeColor, width: screenSize.width/1920),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              )
                            ]),
                      ),
                    ),
                    Container(
                      margin:  EdgeInsets.only(left: screenSize.width/192, right: screenSize.width/192),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Countdown(
                              animation: StepTween(
                                begin:
                                    levelClock, // THIS IS A USER ENTERED NUMBER
                                end: 0,
                              ).animate(_animationController!),
                            ),
                            GestureDetector(
                              onTap: () async {
                                _animationController!.reset();
                                _animationController!.forward();
                              },
                              child: Container(
                                child: Row(
                                  children: [
                                    Text(
                                      "Resend >",
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width/137.1,
                                        color:
                                            const Color.fromRGBO(2, 44, 67, 1),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ]),
                    ),
                     SizedBox(
                      height: screenSize.height/38.44,
                    ),
                    GestureDetector(
                      onTap: () async {
                        String otpnumber =
                            '${_otp1.text}${_otp2.text}${_otp3.text}${_otp4.text}';

                        if (_formKey.currentState!.validate()) {
                          setState(() {
                            isloading = true;
                          });
                          Map<String, String> data = {
                            'phone': widget.mobile,
                            'otp': otpnumber
                          };
                          var response = await networkHandler.post(
                              'customer-verify_otp', data);

                          if (response.statusCode == 200) {
                            setState(() {
                              isloading = false;
                            });
                            Map jsonResponse = jsonDecode(response.body);
                            if (jsonResponse['status'] == true) {
                              Fluttertoast.showToast(
                                  msg: "OTP Verified Succesfully",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: screenSize.height/120);

                              getProfileDetails(widget.mobile);

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const CustomerProfileScreen()));
                            } else {
                              Fluttertoast.showToast(
                                  msg: "Please enter correct OTP",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: screenSize.height/120);
                            }
                          }
                        }
                      },
                      child: Container(
                        margin:  EdgeInsets.only(left: screenSize.width/192, right: screenSize.width/192),
                        width: screenSize.width/7.77,
                        height: screenSize.height/18.8,
                        decoration: BoxDecoration(
                            color: Colors.yellow,
                            borderRadius: BorderRadius.circular(screenSize.width/76.8),
                            border: Border.all(width: screenSize.width/960, color: Colors.yellow)),
                        child: Center(
                          child: isloading == false
                              ? Text(
                                  "CONFIRM",
                                  style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/112.9,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                )
                              : const CircularProgressIndicator(
                                  color: Colors.white,
                                ),
                        ),
                      ),
                    )
                  ]),
                ),
              ),
              Center(
                child: Container(
                  margin:  EdgeInsets.only(
                    top: screenSize.height/19.2,
                  ),
                  width: 196,
                  child:  Text(
                    "Welcome To Naksa Discover the Best Solution Easy & Simple",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: screenSize.width/120, color: Colors.black),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget MobileOTPVarification() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin:  EdgeInsets.only(top: screenSize.height/8.04, left: screenSize.width/17.1),
              height: screenSize.height/9,
              width: double.infinity,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: screenSize.height/11.8,
                      child: Image.asset(
                        "assets/logo.png",
                        fit: BoxFit.fill,
                      ),
                    ),
                     SizedBox(
                      height:  screenSize.height/153.96,
                    ),
                    Text(
                      "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/30,
                        color: const Color.fromRGBO(112, 112, 112, 1),
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ]),
            ),
            Container(
              margin:  EdgeInsets.only(top: screenSize.height/12.6),
              height: screenSize.height/2.52,
              width: double.infinity,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/SVG/back.png"))),
              child: Container(
                height: screenSize.height/2.69,
                width: screenSize.width/1.58,
                margin:  EdgeInsets.only(left: screenSize.width/7.2, right: screenSize.width/7.2),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(screenSize.width/36),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.12),
                      offset: const Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 8.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                    const BoxShadow(
                      color: Colors.white,
                      offset: Offset(0.0, 0.0),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ), //BoxShadow
                  ],
                ),
                child: Column(children: [
                  SizedBox(
                    height: screenSize.height/6.8,
                    child: Stack(
                      children: [
                        Container(
                          margin:  EdgeInsets.only(top: screenSize.height/16.8),
                          height: screenSize.height/9.94,
                          width: screenSize.width/4.73,
                          padding:  EdgeInsets.all(screenSize.width/36),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                width: screenSize.width/45,
                                color: const Color.fromRGBO(240, 240, 240, 1)),
                          ),
                          child: const Image(
                            image: AssetImage("assets/SVG/ic-contact-2x.png"),
                            fit: BoxFit.contain,
                          ),
                        ),
                        Positioned(
                            top: screenSize.height/20.4,
                            // left: 150,
                            right: 0,
                            child: Container(
                              height: screenSize.height/32.8,
                              width: screenSize.width/15.6,
                              decoration: const BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage(
                                          "assets/SVG/message-2x.png"))),
                            ))
                      ],
                    ),
                  ),
                   SizedBox(
                    height: screenSize.height/47.25,
                  ),
                  Container(
                      child: Text(
                    "Enter 4 Digits code",
                    style: GoogleFonts.merriweather(
                      fontSize: screenSize.width/30,
                      color: const Color.fromRGBO(164, 164, 164, 1),
                      fontWeight: FontWeight.bold,
                    ),
                  )),
                  Container(
                    margin:  EdgeInsets.all(screenSize.width/36),
                    child: Form(
                      key: _formKey,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              height: screenSize.height/12.6,
                              width: screenSize.width/6,
                              child: TextFormField(
                                controller: _otp1,
                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: darkBlue, width: screenSize.width/180),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: themeColor, width: screenSize.width/360),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            ),
                            SizedBox(
                              height: screenSize.height/12.6,
                              width: screenSize.width/6,
                              child: TextFormField(
                                controller: _otp2,

                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: darkBlue, width: screenSize.width/180),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: themeColor, width: screenSize.width/360),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            ),
                            SizedBox(
                              height: screenSize.height/12.6,
                              width: screenSize.width/6,
                              child: TextFormField(
                                controller: _otp3,
                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: darkBlue, width: screenSize.width/180),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: themeColor, width: screenSize.width/360),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            ),
                            SizedBox(
                              height: screenSize.height/12.6,
                              width: screenSize.width/6,
                              child: TextFormField(
                                controller: _otp4,
                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                        color: darkBlue, width: screenSize.width/180),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width/24),
                                    borderSide:  BorderSide(
                                      color: themeColor,
                                      width: screenSize.width/360,
                                    ),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            )
                          ]),
                    ),
                  ),
                  Container(
                    margin:  EdgeInsets.only(left: screenSize.width/36, right: screenSize.width/36),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Countdown(
                            animation: StepTween(
                              begin:
                                  levelClock, // THIS IS A USER ENTERED NUMBER
                              end: 0,
                            ).animate(_animationController!),
                          ),
                          GestureDetector(
                            onTap: () async {
                              _animationController!.reset();
                              _animationController!.forward();
                            },
                            child: Row(
                              children: [
                                Text("Resend >",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width/30,
                                      color: const Color.fromRGBO(2, 44, 67, 1),
                                      fontWeight: FontWeight.bold,
                                    ))
                              ],
                            ),
                          )
                        ]),
                  ),
                   SizedBox(
                    height: screenSize.height/75.6,
                  ),
                  GestureDetector(
                    onTap: () async {
                      String otpnumber =
                          '${_otp1.text}${_otp2.text}${_otp3.text}${_otp4.text}';

                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          isloading = true;
                        });
                        Map<String, String> data = {
                          'phone': widget.mobile,
                          'otp': otpnumber
                        };
                        var response = await networkHandler.post(
                            'customer-verify_otp', data);

                        if (response.statusCode == 200) {
                          setState(() {
                            isloading = false;
                          });
                          Map jsonResponse = jsonDecode(response.body);
                          if (jsonResponse['status'] == true) {
                            Fluttertoast.showToast(
                                msg: "OTP Verified Succesfully",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                timeInSecForIosWeb: 1,
                                backgroundColor: themeColor,
                                textColor: Colors.white,
                                fontSize: screenSize.width/22.5);

                            getProfileDetails(widget.mobile);

                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) =>
                            //             const CustomerProfileScreen()));
                          } else {
                            Fluttertoast.showToast(
                                msg: "Please enter correct OTP",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                timeInSecForIosWeb: 1,
                                backgroundColor: themeColor,
                                textColor: Colors.white,
                                fontSize: screenSize.width/22.5);
                          }
                        }
                      }
                    },
                    child: Container(
                      margin:  EdgeInsets.only(left: screenSize.width/36, right: screenSize.width/36),
                      width: screenSize.width/1.45,
                      height: screenSize.height/21,
                      decoration: BoxDecoration(
                          color: Colors.yellow,
                          borderRadius: BorderRadius.circular(screenSize.width/14.4),
                          border: Border.all(width: screenSize.width/180, color: Colors.yellow)),
                      child: Center(
                        child: isloading == false
                            ? Text(
                                "CONFIRM",
                                style: GoogleFonts.merriweather(
                                  fontSize: screenSize.width/21.1,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            : const CircularProgressIndicator(
                                color: Colors.white,
                              ),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
            Center(
              child: Container(
                margin:  EdgeInsets.only(
                  top: screenSize.height/15.12,
                ),
                width: screenSize.width/1.838,
                child: Text(
                  "Welcome To Naksa Discover the Best Solution Easy & Simple",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.merriweather(
                    fontSize: screenSize.width/25.7,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  List<CustomerP> _customerList = [];
  var customerService = CustomerProfileService();
  Future<void> getProfileDetails(String phone) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await customerService.viewCustomerProfile(phone);
    print(response);
    if (response != null) {
      _customerList = response;
      SharedPreferences pref = await SharedPreferences.getInstance();
      pref.setBool("islogin", true);
      pref.setString("phone", _customerList[0].phone!);
      pref.setString("uid", _customerList[0].id.toString());
      if (_customerList[0].name != null) {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => BottomNavigationBarScreen(pageIndex: 0)));
      } else {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const CustomerProfileScreen(),
          ),
        );
      }
    } else {
      throw Exception("Failed to load data");
    }
  }
}

class Countdown extends AnimatedWidget {
  
  Countdown({Key? key, required this.animation})
      : super(key: key, listenable: animation);
  Animation<int> animation;

  @override
  build(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    String value = '';
    Duration clockTimer = Duration(seconds: animation.value);
    print(animation.value);

    String timerText =
        '${clockTimer.inMinutes.remainder(60).toString()}:${clockTimer.inSeconds.remainder(60).toString().padLeft(2, '0')}';
    return Text(timerText,
        style: GoogleFonts.merriweather(
          fontSize: screenSize.width/25.7,
          color: const Color.fromRGBO(2, 44, 67, 1),
          fontWeight: FontWeight.bold,
        ));
  }
}
