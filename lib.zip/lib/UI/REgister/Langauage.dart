import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/HomeScreen.dart';
import 'package:naksaa_services/UI/Home/Partner/CallRequest.dart';
import 'package:naksaa_services/UI/Home/Partner/ChatRequest.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/IncomingVideoCallScreen.dart';
import 'package:naksaa_services/UI/REgister/PhoneRegister.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../main.dart';
import '../../routes/myroutes.dart';

class ChooseLanguage extends StatefulWidget {
  const ChooseLanguage({super.key});

  @override
  State<ChooseLanguage> createState() => _ChooseLanguageState();
}

class _ChooseLanguageState extends State<ChooseLanguage> {
  late StreamSubscription subscription;
  var isDeviceConnected = false;

  bool isAlertSet = false;
  @override
  void initState() {
    getConnectivity();

    getToken();
    // TODO: implement initState
    super.initState();
    // showNotifications();

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print(message.notification);
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      print(notification!.title.toString());
     
        print("Inside function${message.data["vtoken"]}");
        if (message.data["notificationtype"] == "chat") {
          AppState.getNavigator().currentState?.pushAndRemoveUntil(  
              MaterialPageRoute(
                  builder: (context) => IncomingChatRequest(
                        vendorid: message.data["vendorimage"],
                        orderid: message.data["orderid"],
                      )),(route) => false);
        }
        if (message.data["notificationtype"] == "call") {
         AppState.getNavigator().currentState?.pushAndRemoveUntil(  
              MaterialPageRoute(
                  builder: (context) => IncomingCallRequest(
                      channelname:message.data["channelid"],
                      token:
                          "006b61c6409413c4d2fbb7f4288e47aa8d6IABhZRmvK4gsR32qEnZqUbPDm7RyAxXoQ9rIebwl+bgRhqNtxrANvtUaEAAtSaF3NaeJZAEAAQDFY4hk",
                      vendorid: message.data["vendorimage"])), (route) => false);
        }
        if (message.data["notificationtype"] == "video-call") {
          AppState.getNavigator().currentState?.pushAndRemoveUntil(  
              MaterialPageRoute(
                  builder: (context) => IncomingVideoCallRequest(
                      channelname: message.data["channelid"],
                      token: "message.data[vtokken]",
                      vendorid: message.data["vendorimage"])), (route) => false);
        }
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
                android: AndroidNotificationDetails(channel.id, channel.name,
                    channelDescription: channel.description,
                    color: themeColor,
                    playSound: true,
                    icon: '@mipmap/ic_launcher')));
      

      // }
    });
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print("A new onmessageopenedapp is published");
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification!.body != null && android != null) {
        print("inside this");
        print("Inside function${message.data["vtoken"]}");
        if (message.data["notificationtype"] == "chat") {
         AppState.getNavigator().currentState?.pushAndRemoveUntil(  
              MaterialPageRoute(
                  builder: (context) => IncomingChatRequest(
                        vendorid: message.data["vendorimage"],
                        orderid: message.data["orderid"],
                      )), (route) => false);
        }
        if (message.data["notificationtype"] == "call") {
         AppState.getNavigator().currentState?.pushAndRemoveUntil(  
              MaterialPageRoute(
                  builder: (context) => IncomingCallRequest(
                      channelname: message.data["channelid"],
                      token: "message.data[vtokken]",
                      vendorid: message.data["vendorimage"])),  (route) => false);
        }
        if (message.data["notificationtype"] == "video-call") {
          AppState.getNavigator().currentState?.pushAndRemoveUntil(  
              MaterialPageRoute(
                  builder: (context) => IncomingVideoCallRequest(
                      channelname: message.data["channelid"],
                      token: "message.data[vtokken]",
                      vendorid: message.data["vendorimage"])), (route) => false);
        }
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
                android: AndroidNotificationDetails(channel.id, channel.name,
                    channelDescription: channel.description,
                    color: themeColor,
                    playSound: true,
                    icon: '@mipmap/ic_launcher')));
      }
    }).onError((error) {
      print(error);
      print("hiii");
    });
  }

  getConnectivity() => subscription = Connectivity()
          .onConnectivityChanged
          .listen((ConnectivityResult result) async {
        isDeviceConnected = await InternetConnectionChecker().hasConnection;
        if (!isDeviceConnected && isAlertSet == false) {
          showDialogBox();
          setState(() => isAlertSet = true);
        }
      });

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  getToken() async {
    String? ftoken = await FirebaseMessaging.instance.getToken();
    print("token");
    print(ftoken.toString());
  }

  void showNotifications() {
    flutterLocalNotificationsPlugin.show(
        0,
        "Testing message",
        "How to check it",
        NotificationDetails(
            android: AndroidNotificationDetails(channel.id, channel.name,
                channelDescription: channel.description,
                importance: Importance.high,
                color: Colors.blue,
                playSound: true,
                icon: '@mipmap/ic_launcher')));
  }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopLanguage();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopLanguage();
      } else {
        return MobileLanguage();
      }
    });
  }

  Widget DesktopLanguage() {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    bool amIHovering = false;

    // store the position where your mouse pointer left the widget
    Offset exitFrom = const Offset(0, 0);
    return Scaffold(
      body: Center(
        child: SizedBox(
          height: screenHeight/1.37,
          width: screenWidth/3.84,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin:  EdgeInsets.only(top: screenHeight/32.0, left: screenWidth/91.4),
                height: screenHeight/6.86,
                width: screenWidth/12.8,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: screenHeight/9.61,
                        // width: 198,
                        child: Image.asset(
                          "assets/logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                       SizedBox(
                        height: screenHeight/192.2,
                      ),
                      Text(
                        "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenWidth/192,
                          color: const Color.fromRGBO(112, 112, 112, 1),
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ]),
              ),
              Container(
                margin:  EdgeInsets.only(top: screenHeight/27.4),
                height: screenHeight/2.82,
                width: double.infinity,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/SVG/back.png"))),
                child: Container(
                  height: screenHeight/2.46,
                  width: screenWidth/5.64,
                  margin:  EdgeInsets.only(left: screenWidth/96, right: screenWidth/96),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(screenWidth/192),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      const BoxShadow(
                        color: Colors.white,
                        offset: Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Column(children: [
                    Container(
                      margin:  EdgeInsets.symmetric(
                          vertical: screenHeight/22.3, horizontal: 62.10),
                      child: Text(
                        "Select Your Language",
                        style: GoogleFonts.merriweather(
                          fontSize: screenWidth/96,
                          color: const Color.fromRGBO(78, 78, 78, 1),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                        child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onHover: (val) {
                            setState(() {
                              amIHovering = val;
                              print(amIHovering);
                            });
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            height: screenHeight/8.73,
                            width: screenWidth/17.4,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: amIHovering ? Colors.white : themeColor,
                                boxShadow: [
                                  BoxShadow(
                                    color:
                                        const Color.fromRGBO(153, 167, 223, 1)
                                            .withOpacity(1),
                                    spreadRadius: 5,
                                    blurRadius: 6,
                                    offset: const Offset(
                                        0, 6), // changes position of shadow
                                  ),
                                ]),
                            child: Column(
                                // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                                children: [
                                  SizedBox(
                                    height: screenHeight / 26.26,
                                  ),
                                  Container(
                                    height: screenHeight/19.2,
                                    width: screenWidth/38.4,
                                    decoration: const BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                                "assets/SVG/अ2x.png"),
                                            fit: BoxFit.cover)),
                                  ),
                                  Text(
                                    "Hindi",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenWidth/137.1,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ]),
                          ),
                        ),
                        Container(
                          margin:  EdgeInsets.all(screenWidth/192),
                          height: screenHeight/240.2,
                          width: screenWidth/80,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(screenWidth/192),
                              color: const Color.fromRGBO(154, 154, 154, 1)),
                        ),
                        Container(
                          height: screenHeight/8.7,
                          width: screenWidth/17.4,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              // borderRadius: BorderRadius.circular(100),
                              color: const Color.fromRGBO(250, 215, 0, 1),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color.fromRGBO(153, 167, 223, 1)
                                      .withOpacity(1),
                                  spreadRadius: 5,
                                  blurRadius: 6,
                                  offset: const Offset(
                                      0, 6), // changes position of shadow
                                ),
                              ]),
                          child: Column(
                              // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                              children: [
                                SizedBox(
                                  height: screenHeight / 26.26,
                                ),
                                Container(
                                  height: screenHeight/19.2,
                                  width: screenWidth/38.4,
                                  decoration: const BoxDecoration(
                                      image: DecorationImage(
                                          image:
                                              AssetImage("assets/SVG/A2x.png"),
                                          fit: BoxFit.cover)),
                                ),
                                Text(
                                  "English",
                                  style: GoogleFonts.merriweather(
                                    fontSize: screenWidth/112.9,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                )
                              ]),
                        )
                      ],
                    )),
                    GestureDetector(
                      onTap: () async {
                        if (kIsWeb) {
                        } else {
                          final fcmToken =
                              await FirebaseMessaging.instance.getToken();
                          print(fcmToken);
                        }
                        SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        //
                        var phone = prefs.getBool("islogin");
                        if (phone == true) {
                          Navigator.pushNamed(
                              context, "/bottomNavigationBarScreen");
                        } else {
                          Navigator.pushNamed(context, "/Login");
                        }
                      },
                      child: Container(
                        margin:  EdgeInsets.only(top: screenHeight/20.8),
                        width: screenWidth/7.77,
                        height: screenHeight/17.4,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(screenWidth/76.8),
                            border: Border.all(
                                width: screenWidth/960,
                                color: const Color.fromRGBO(2, 44, 67, 1))),
                        child: Center(
                          child: Text(
                            "GET STARTED",
                            style: GoogleFonts.merriweather(
                              fontSize: screenWidth/112.9,
                              color: const Color.fromRGBO(2, 44, 67, 1),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    )
                  ]),
                ),
              ),
              Center(
                child: Container(
                  margin:  EdgeInsets.only(
                    top: screenHeight/19.2,
                  ),
                  width: screenWidth/9.79,
                  child: Text(
                    "Welcome To Naksa Discover the Best Solution Easy & Simple",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.merriweather(
                      fontSize: screenWidth/120,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget MobileLanguage() {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
              top: screenHeight/15.12,
              right: screenWidth/18,
              child: InkWell(
                onTap: () {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (context) => BottomNavigationBarScreen(
                            pageIndex: 0,
                          )));
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => IncomingVideoCallRequest(
                  //             channelname:
                  //                 "4bbe1bca-44f0-4d6d-a00d-57bdd8ff70a3",
                  //             token: "message.data[vtokken]",
                  //             vendorid: "1")));
                },
                child: Container(
                    height: screenHeight/21.6,
                    width: screenWidth/4.5,
                    decoration: BoxDecoration(
                      color: Colors.yellow,
                      borderRadius: BorderRadius.circular(screenWidth/18),
                      boxShadow: [
                        BoxShadow(
                          color: const Color.fromRGBO(
                            153,
                            167,
                            223,
                            1,
                          ).withOpacity(
                            1,
                          ),
                          spreadRadius: 1,
                          blurRadius: 1,
                          offset: const Offset(0, 1),
                        ),
                      ],
                    ),
                    child: Center(
                        child: Text(
                      "Skip",
                      style:  GoogleFonts.merriweather(
                          fontSize: screenWidth/21.1,
                          color: darkBlue,
                          fontWeight: FontWeight.bold),
                    ))),
              )),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin:  EdgeInsets.only(top: screenHeight/10.08, left: screenWidth/17.1),
                height: screenHeight/9,
                width: double.infinity,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: screenHeight/15.12,
                        // width: 198,
                        child: Image.asset(
                          "assets/logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                       SizedBox(
                        height: screenHeight/151.2,
                      ),
                       Text(
                        "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                        style:  GoogleFonts.merriweather(
                            fontSize: screenWidth/36,
                            color: Color.fromRGBO(112, 112, 112, 1)),
                      )
                    ]),
              ),
              Container(
                margin:  EdgeInsets.only(top: screenHeight/11.1),
                height: screenHeight/2.04,
                width: double.infinity,
                decoration:  BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/SVG/back.png"))),
                child: Container(
                  height: screenHeight/1.93,
                  width: screenWidth/1.05,
                  margin:  EdgeInsets.only(left: screenWidth/18, right: screenWidth/18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(screenWidth/36),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      const BoxShadow(
                        color: Colors.white,
                        offset: Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Column(
                    children: [
                      Container(
                        margin:  EdgeInsets.symmetric(
                            vertical: screenHeight/50.4, horizontal: screenWidth/36),
                        child:  Text(
                          "Select Your Language",
                          style:  GoogleFonts.merriweather(
                              fontSize: screenWidth/18,
                              color: Color.fromRGBO(78, 78, 78, 1)),
                        ),
                      ),
                      Container(
                          child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          GestureDetector(
                            child: Container(
                              height: screenHeight / 6.73,
                              width: screenWidth / 3.0763,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(screenWidth/3.6),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color:
                                          const Color.fromRGBO(153, 167, 223, 1)
                                              .withOpacity(1),
                                      spreadRadius: 5,
                                      blurRadius: 6,
                                      offset: const Offset(
                                          0, 6), // changes position of shadow
                                    ),
                                  ]),
                              child: Column(
                                // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                                children: [
                                  SizedBox(
                                    height: screenHeight / 26.26,
                                  ),
                                  Container(
                                    height: screenHeight / 16.08,
                                    width: screenWidth / 7.2,
                                    decoration: const BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                                "assets/SVG/अ2x.png"),
                                            fit: BoxFit.cover)),
                                  ),
                                   Text(
                                    "Hindi",
                                    style:  GoogleFonts.merriweather(
                                      fontSize: screenWidth/25.7,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin:  EdgeInsets.all(
                              screenWidth/25.7,
                            ),
                            height: screenHeight/189,
                            width: screenWidth/15,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                screenWidth/36,
                              ),
                              color: const Color.fromRGBO(
                                154,
                                154,
                                154,
                                1,
                              ),
                            ),
                          ),
                          Container(
                            height: screenHeight / 6.73,
                            width: screenWidth / 3.0763,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(screenWidth/3.6),
                              color: const Color.fromRGBO(250, 215, 0, 1),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color.fromRGBO(
                                    153,
                                    167,
                                    223,
                                    1,
                                  ).withOpacity(
                                    1,
                                  ),
                                  spreadRadius: 5,
                                  blurRadius: 6,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: Column(
                              // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                              children: [
                                SizedBox(
                                  height: screenHeight / 26.26,
                                ),
                                Container(
                                  height: screenHeight / 16.08,
                                  width: screenWidth / 5.14,
                                  decoration: const BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage("assets/SVG/A2x.png"),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                 Text(
                                  "English",
                                  style:  GoogleFonts.merriweather(
                                    fontSize: screenWidth/25.7,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      )),
                      GestureDetector(
                        onTap: () async {
                          if (kIsWeb) {
                          } else {
                            final fcmToken =
                                await FirebaseMessaging.instance.getToken();
                            print(fcmToken);
                          }
                          SharedPreferences prefs =
                              await SharedPreferences.getInstance();
                          //
                          var phone = prefs.getBool("islogin");
                          if (phone == true) {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => BottomNavigationBarScreen(
                                  pageIndex: 0,
                                ),
                              ),
                            );
                          } else {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const PhoneRegister(),
                              ),
                            );
                          }
                        },
                        child: Container(
                          margin:  EdgeInsets.only(
                            top: screenHeight/16.43,
                          ),
                          width: 247,
                          height: screenHeight/16.43,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              screenWidth/14.4,
                            ),
                            border: Border.all(
                              width: screenWidth/180,
                              color: const Color.fromRGBO(
                                2,
                                44,
                                67,
                                1,
                              ),
                            ),
                          ),
                          child:  Center(
                            child: Text(
                              "GET STARTED",
                              style:  GoogleFonts.merriweather(
                                fontSize: screenWidth/21.17,
                                color: Color.fromRGBO(
                                  2,
                                  44,
                                  67,
                                  1,
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Center(
                child: Container(
                  margin:  EdgeInsets.only(
                    top: screenHeight/15.12,
                  ),
                  width: screenWidth/1.83,
                  child: Text(
                    "Welcome To Naksa Discover the Best Solution Easy & Simple",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.merriweather(
                      fontSize: screenWidth/22.5,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  showDialogBox() => showCupertinoDialog(
        context: context,
        builder: (BuildContext context) => CupertinoAlertDialog(
          title:  Text(
            "No Connection",
            style:  GoogleFonts.merriweather(
              fontWeight: FontWeight.bold,
            ),
          ),
          content:  Text(
            "Please Check your connectivity",
            style:  GoogleFonts.merriweather(
              color: Colors.grey,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.pop(
                  context,
                  "Cancel",
                );
                setState(
                  () => isAlertSet = false,
                );
                isDeviceConnected =
                    await InternetConnectionChecker().hasConnection;

                if (!isDeviceConnected) {
                  showDialogBox();
                  setState(
                    () => isAlertSet = true,
                  );
                }
              },
              child: const Text(
                "Ok",
              ),
            )
          ],
        ),
      );
}

class DynamicDialog extends StatefulWidget {
  final title;
  final body;
  const DynamicDialog({super.key, this.title, this.body});
  @override
  _DynamicDialogState createState() => _DynamicDialogState();
}

class _DynamicDialogState extends State<DynamicDialog> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      actions: <Widget>[
        OutlinedButton.icon(
            label: const Text('Close'),
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.close))
      ],
      content: Text(widget.body),
    );
  }
}
