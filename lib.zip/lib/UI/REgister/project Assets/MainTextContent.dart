import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MainTextContent extends StatelessWidget {
  final String txt2;
  const MainTextContent({Key? key, required this.txt2}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 10,
        right: 10,
       ),
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        child: Text(
          txt2,
          // textAlign: TextAlign.justify,
          maxLines: 10,
          textAlign: TextAlign.justify,
          overflow: TextOverflow.fade,
          style: GoogleFonts.merriweather(fontSize: 15),
        ),
      ),
    );
  }
}
