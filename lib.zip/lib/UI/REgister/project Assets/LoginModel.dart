import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/MainUtility/Terms_and_conditions.dart';
import 'package:naksaa_services/UI/Home/MainUtility/privacy_policy.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../../API/NetworkProvider.dart';
import 'otpalert.dart';

class LoginModel extends StatefulWidget {
  const LoginModel({super.key});

  @override
  State<LoginModel> createState() => _LoginModelState();
}

class _LoginModelState extends State<LoginModel> {
  var isloading = false;
  var isloading1 = false;
  var networkHandler = NetworkHandler();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _mobile = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final _formMobileKey = GlobalKey<FormState>();
  String? ftoken;
  @override
  void initState() {
    super.initState();
    gettoken();
  }

  Future<void> gettoken() async {
    final fcmToken = await FirebaseMessaging.instance.getToken();
    print(fcmToken);
    print("aryaman");
    setState(() {
      ftoken = fcmToken.toString();
      print("fcm  $ftoken" "  aryamans");
    });
  }

  @override
  Widget build(BuildContext context) {
    Color themeColor = const Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = const Color.fromRGBO(56, 56, 56, 1);
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopLoginModal();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopLoginModal();
      } else {
        return MobileLoginModal(context);
      }
    });
  }

  Widget DesktopLoginModal() {
    
    var screenSize = MediaQuery.of(context).size;
    return AlertDialog(
      backgroundColor: Colors.transparent,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(screenSize.width/192)),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                color: Colors.white,
              ))
        ],
      ),
      content: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.65,
            width: screenSize.width/3.49,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin:  EdgeInsets.only(top: screenSize.height/192.2),
                  height: screenSize.width/4.8,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        "assets/SVG/back.png",
                      ),
                    ),
                  ),
                  child: Container(
                    height: screenSize.height/2.46,
                    width: screenSize.width/5.64,
                    margin:  EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/96),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(screenSize.width/192),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.12),
                          offset: const Offset(
                            3.0,
                            3.0,
                          ),
                          blurRadius: 8.0,
                          spreadRadius: 2.0,
                        ), //BoxShadow
                        const BoxShadow(
                          color: Colors.white,
                          offset: Offset(
                            0.0,
                            0.0,
                          ),
                          blurRadius: 0.0,
                          spreadRadius: 0.0,
                        ), //BoxShadow
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(children: [
                        Container(
                          width: screenSize.width/4.8,
                          margin:  EdgeInsets.symmetric(
                            vertical: screenSize.height/27.45,
                            horizontal: screenSize.width/48,
                          ),
                          child: Text(
                            "Log In",
                            textAlign: TextAlign.center,
                            style: GoogleFonts.merriweather(
                              fontSize: screenSize.width/73.84,
                              color: const Color.fromRGBO(2, 44, 67, 1),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          height: screenSize.height/17.16,
                          width: screenSize.width/4.8,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              screenSize.width/76.8,
                            ),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(
                                  0.12,
                                ),
                                offset: const Offset(
                                  3.0,
                                  3.0,
                                ),
                                blurRadius: 8.0,
                                spreadRadius: 2.0,
                              ),
                              const BoxShadow(
                                color: Colors.white,
                                offset: Offset(
                                  0.0,
                                  0.0,
                                ),
                                blurRadius: 0.0,
                                spreadRadius: 0.0,
                              ), //BoxShadow////////////////////
                            ],
                          ),
                          child: Row(
                            children: [
                               SizedBox(
                                width: screenSize.width/320,
                              ),
                              Container(
                                height: screenSize.height/19.2,
                                width: screenSize.width/38.4,
                                decoration: const BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                      "assets/SVG/flag-2x.png",
                                    ),
                                  ),
                                ),
                              ),
                               SizedBox(
                                width: screenSize.width/96,
                              ),
                              Container(
                                child: Center(
                                  child: Text(
                                    "INDIA +91",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width/120,
                                      color: const Color.fromRGBO(
                                        164,
                                        164,
                                        164,
                                        1,
                                      ),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/48.05,
                        ),
                        Container(
                          height: screenSize.height/17.16,
                          width: screenSize.width/4.8,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(screenSize.width/76.8),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.12),
                                offset: const Offset(
                                  3.0,
                                  3.0,
                                ),
                                blurRadius: 8.0,
                                spreadRadius: 2.0,
                              ), //BoxShadow
                              const BoxShadow(
                                color: Colors.white,
                                offset: Offset(0.0, 0.0),
                                blurRadius: 0.0,
                                spreadRadius: 0.0,
                              ), //BoxShadow
                            ],
                          ),
                          child: Center(
                              child: TextFormField(
                            controller: _phone,
                            textAlign: TextAlign.center,
                            keyboardType: TextInputType.phone,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Enter Mobile Number',
                              hintStyle: GoogleFonts.merriweather(
                                fontSize: screenSize.width/120,
                              ),
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter your mobile';
                              } else if (value.length < 10) {
                                return 'Enter 10 digit mobile number';
                              } else if (value.length > 10) {
                                return 'Enter 10 digit mobile number';
                              }
                              return null;
                            },
                            style: GoogleFonts.merriweather(
                              fontSize: screenSize.width/120,
                              color: const Color.fromRGBO(2, 44, 67, 1),
                              fontWeight: FontWeight.bold,
                            ),
                          )),
                        ),
                         SizedBox(
                          height: screenSize.height/24.02,
                        ),
                        GestureDetector(
                          onTap: () async {
                            if (_formKey.currentState!.validate()) {
                              setState(() {
                                isloading = true;
                              });
                              Map<String, String> data = {
                                'phone': _phone.text,
                                'mob_notification': ftoken.toString()
                              };
                              var response = await networkHandler.post(
                                  'customer-reg', data);

                              if (response.statusCode == 200) {
                                Map jsonResponse = jsonDecode(response.body);
                                if (jsonResponse['status'] == true) {
                                  setState(() {
                                    isloading = false;
                                  });
                                  Fluttertoast.showToast(
                                      msg: jsonResponse['otp'],
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: themeColor,
                                      textColor: Colors.white,
                                      fontSize: screenSize.width/24.05);
                                  Navigator.pop(context);
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return OTPAlertVarification(
                                        mobile: _phone.text,
                                      );
                                    },
                                  );
                                } else {
                                  setState(() {
                                    isloading = false;
                                  });
                                  Fluttertoast.showToast(
                                    msg:
                                        "Something went wrong!, please try again..",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    timeInSecForIosWeb: 1,
                                    backgroundColor: themeColor,
                                    textColor: Colors.white,
                                    fontSize: screenSize.width/24.02,
                                  );
                                }
                              }
                            }
                          },
                          child: isloading == false
                              ? Container(
                                  width: screenSize.width/7.77,
                                  height: screenSize.height/17.16,
                                  decoration: BoxDecoration(
                                      color: Colors.yellow,
                                      borderRadius: BorderRadius.circular(screenSize.width/76.8),
                                      border: Border.all(
                                          width: screenSize.width/960, color: Colors.yellow)),
                                  child: Center(
                                    child: Text(
                                      "GET OTP",
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width/120,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                )
                              : Container(
                                  width: screenSize.width/7.77,
                                  height: screenSize.height/17.16,
                                  decoration: BoxDecoration(
                                      color: Colors.yellow,
                                      borderRadius: BorderRadius.circular(screenSize.width/76.8),
                                      border: Border.all(
                                          width: screenSize.width/960, color: Colors.yellow)),
                                  child: const Center(
                                      child: CircularProgressIndicator(
                                    color: Colors.white,
                                  )),
                                ),
                        )
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  final scaffoldKey = GlobalKey<ScaffoldState>();
  MobileLoginModal(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    return Padding(
      padding: EdgeInsets.only(
          left: screenSize.width/12,
          right: screenSize.width/12,
          top: screenSize.height/37.8,
          bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Form(
        key: _formMobileKey,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: screenSize.height/16.8,
                width: screenSize.width/8,
                decoration: BoxDecoration(
                    image:
                        DecorationImage(image: AssetImage("assets/logo.png"))),
              ),
              IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: Icon(Icons.close))
            ],
          ),
           SizedBox(
            height: screenSize.height/21.6,
          ),
          Row(
            children: [
              Text("Login"),
               SizedBox(
                width: screenSize.width/72,
              ),
              Text("or"),
               SizedBox(
                width: screenSize.width/72,
              ),
              Text("Sign Up")
            ],
          ),
           SizedBox(
            height: screenSize.height/21.6,
          ),
          Container(
            height: screenSize.height/17.5,
            child: TextFormField(
              controller: _mobile,
              keyboardType: TextInputType.number,
              style:   GoogleFonts.merriweather(color: darkBlue, fontSize: screenSize.width/27.6),
              decoration: InputDecoration(
                  labelText: "Mobile Number",
                  labelStyle:
                        GoogleFonts.merriweather(color: Colors.black54, fontSize: screenSize.width/27.6),
                  prefix: Padding(
                    padding: EdgeInsets.only(left: screenSize.width/36, top: screenSize.height/50.4),
                    child: Text(
                      "+91 | ",
                      style:  GoogleFonts.merriweather(fontSize: 13, color: Colors.black54),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(width: 1, color: darkBlue)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(width: 1.5, color: darkBlue))),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Enter your mobile';
                } else if (value.length < 10) {
                  return 'Enter 10 digit mobile number';
                } else if (value.length > 10) {
                  return 'Enter 10 digit mobile number';
                }
                return null;
              },
            ),
          ),
           SizedBox(
            height: screenSize.height/50.4,
          ),
          Row(
            children: [
              Text(
                "By Continuing",
                style:  GoogleFonts.merriweather(
                  color: Colors.black54,
                  fontSize: screenSize.width/36,
                ),
              ),
               SizedBox(
                width: screenSize.width/90,
              ),
              Text(
                "I agree to ",
                style:  GoogleFonts.merriweather(
                  color: Colors.black54,
                  fontSize: screenSize.width/36,
                ),
              ),
               SizedBox(
                width: screenSize.width/90,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => TermsAndConditions()));
                },
                child: Text(
                  "Terms of use",
                  style:  GoogleFonts.merriweather(
                      color: Colors.red,
                      fontSize: screenSize.width/36,
                      fontWeight: FontWeight.bold),
                ),
              ),
               SizedBox(
                width: screenSize.width/90,
              ),
              Text(
                " & ",
                style:  GoogleFonts.merriweather(
                  color: Colors.black54,
                  fontSize: screenSize.width/36,
                ),
              ),
               SizedBox(
                width: screenSize.width/90,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => PrivacyPolicy()));
                },
                child: Text(
                  "Privacy Policy",
                  style:  GoogleFonts.merriweather(
                      color: Colors.red,
                      fontSize: screenSize.width/36,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
         SizedBox(
            height: screenSize.height/25.2,
          ),
          GestureDetector(
            onTap: () async {
              if (_formMobileKey.currentState!.validate()) {
                setState(() {
                  isloading1 = true;
                });
                Map<String, String> data = {
                  'phone': _mobile.text,
                  'mob_notification': ftoken.toString()
                };
                var response = await networkHandler.post('customer-reg', data);

                if (response.statusCode == 200) {
                  Map jsonResponse = jsonDecode(response.body);
                  if (jsonResponse['status'] == true) {
                    setState(() {
                      isloading1 = false;
                    });
                    Fluttertoast.showToast(
                        msg: jsonResponse['otp'],
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        timeInSecForIosWeb: 1,
                        backgroundColor: themeColor,
                        textColor: Colors.white,
                        fontSize: screenSize.width/22.5);
                    Navigator.pop(context);
                    showModalBottomSheet(
                      isDismissible: false,
                      isScrollControlled: true,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(screenSize.width/36)),
                      context: context,
                      builder: (BuildContext context) {
                        return OTPAlertVarification(
                          mobile: _mobile.text,
                        );
                      },
                    );
                  } else {
                    setState(() {
                      isloading1 = false;
                    });
                    Fluttertoast.showToast(
                      msg: "Something went wrong!, please try again..",
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.BOTTOM,
                      timeInSecForIosWeb: 1,
                      backgroundColor: themeColor,
                      textColor: Colors.white,
                      fontSize: screenSize.width/22.5,
                    );
                    Navigator.pop(context);
                  }
                }
              }
            },
            child: isloading1 == false
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: screenSize.height/16.08,
                    decoration: BoxDecoration(
                        color: Colors.yellow,
                        borderRadius: BorderRadius.circular(screenSize.width/36),
                        border: Border.all(width: 2, color: Colors.yellow)),
                    child: Center(
                      child: Text(
                        "GET OTP",
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width/22.5,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  )
                : Container(
                    width: screenSize.width/1.45,
                    height: screenSize.height/16.08,
                    decoration: BoxDecoration(
                        color: Colors.yellow,
                        borderRadius: BorderRadius.circular(screenSize.width/36),
                        border: Border.all(width: screenSize.width/180, color: Colors.yellow)),
                    child: const Center(
                        child: CircularProgressIndicator(
                      color: Colors.white,
                    )),
                  ),
          ),
           SizedBox(
            height: screenSize.height/21.6,
          ),
          Row(
            children: [
              Text(
                "Having trouble logging in",
                style:  GoogleFonts.merriweather(
                  color: Colors.black54,
                  fontSize: screenSize.width/36,
                ),
              ),
               SizedBox(
                width: screenSize.width/51.4,
              ),
              Text(
                "Get help",
                style:  GoogleFonts.merriweather(
                    color: Colors.red,
                    fontSize: screenSize.width/36,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
           SizedBox(
            height: screenSize.height/37.8,
          )
        ]),
      ),
    );
  }
}
