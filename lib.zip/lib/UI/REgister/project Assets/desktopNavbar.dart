import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/Home/CallScreen.dart';
import 'package:naksaa_services/UI/Home/HistoryScreen.dart';
import 'package:naksaa_services/UI/Home/HomeScreen.dart';
import 'package:naksaa_services/UI/Home/Notification.dart';
import 'package:naksaa_services/UI/Home/Partner/CallRequest.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/Custombutton.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/LoginModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../aboutus/aboutus.dart';
import '../../Home/BottomNavigation.dart';
import '../../Home/ChatScreen.dart';
import 'constants.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  _NavBarState createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  var networkHandler = NetworkHandler();
  final TextEditingController _phone = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final List _isHovering = [false, false, false, false, false, false];
  var isloading = false;
  String? ftoken;
  @override
  void initState() {
    super.initState();
    gettoken();
  }

  Future<void> gettoken() async {
    final fcmToken = await FirebaseMessaging.instance.getToken();
    print(fcmToken);
    print("aryaman");
    setState(() {
      ftoken = fcmToken.toString();
      print("fcm  $ftoken" "  aryamans");
    });
  }

  String dynamictext = "Register";
  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    return PreferredSize(
      preferredSize: Size(screenSize.width, 1000),
      child: Container(
        color: Colors.transparent,
        child: Padding(
          padding:  EdgeInsets.all(screenSize.width/18),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
               SizedBox(
                width: screenSize.width/18,
              ),
              SizedBox(
                  height: screenSize.height/8.4, width: screenSize.width/4, child: Image.asset("assets/logo.png")),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(width: screenSize.width / 8),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[0] = true
                              : _isHovering[0] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => BottomNavigationBarScreen(
                                      pageIndex: 0,
                                    )));
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                           SizedBox(
                            height: screenSize.height/63,
                          ),
                          Text('Home',
                              style: GoogleFonts.merriweather(
                                fontSize: 16,
                                color: _isHovering[0] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          const SizedBox(height: 5),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[0],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(20)),
                              height: 7,
                              width: 7,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[1] = true
                              : _isHovering[1] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Aboutus()));
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                           SizedBox(
                            height: screenSize.height/63,
                          ),
                          Text('About Us',
                              style: GoogleFonts.merriweather(
                                fontSize: 16,
                                color: _isHovering[1] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          const SizedBox(height: 5),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[1],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(20)),
                              height: 7,
                              width: 7,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[2] = true
                              : _isHovering[2] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => IncomingCallRequest(
                                      token: "fdfsdsd",
                                      channelname: 'cdfdf',
                                      vendorid: '11',
                                    )));
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                           SizedBox(
                            height: screenSize.height/63,
                          ),
                          Text('Services',
                              style: GoogleFonts.merriweather(
                                fontSize: 16,
                                color: _isHovering[2] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          const SizedBox(height: 5),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[2],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(20)),
                              height: 7,
                              width: 7,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[3] = true
                              : _isHovering[3] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ChatMainScreen()));
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            height: 12,
                          ),
                          Text('Chat With US',
                              style: GoogleFonts.merriweather(
                                fontSize: 16,
                                color: _isHovering[3] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          const SizedBox(height: 5),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[3],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(20)),
                              height: 7,
                              width: 7,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[4] = true
                              : _isHovering[4] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const CallMainScreen()));
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            height: 12,
                          ),
                          Text('Call With Us',
                              style: GoogleFonts.merriweather(
                                fontSize: 16,
                                color: _isHovering[4] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )
                              // style: TextStyle(
                              //   fontSize: 16,
                              //   fontWeight: FontWeight.bold,
                              //   color: _isHovering[4] ? active : disable,
                              // ),
                              ),
                          const SizedBox(height: 5),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[4],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(20)),
                              height: 7,
                              width: 7,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: screenSize.width / 20),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const HistoryScreen()));
                },
                child: const CustomButton(
                  text: "Register",
                ),
              ),
              SizedBox(width: screenSize.width / 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget DesktopServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    print(screenSize.height);
    print(screenSize.width);
    return PreferredSize(
      preferredSize: Size(screenSize.width, 1000),
      child: Container(
        color: Colors.white,
        child: Padding(
          padding: EdgeInsets.all(screenSize.width / 96),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: screenSize.width / 96,
              ),
              SizedBox(
                  height: screenSize.height / 10.67,
                  width: screenSize.width / 21.33,
                  child: Image.asset("assets/naksa_logo.png")),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(width: screenSize.width / 8),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[0] = true
                              : _isHovering[0] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamed(
                          context,
                          "/",
                        );
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: screenSize.height / 80.08,
                          ),
                          Text(
                            'Home',
                            style: GoogleFonts.merriweather(
                              fontSize: screenSize.width / 120,
                              color: _isHovering[0] ? active : disable,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: screenSize.height / 192.2),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[0],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 96)),
                              height: screenSize.height/137.2,
                              width: screenSize.width/274.2,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[1] = true
                              : _isHovering[1] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamed(
                          context,
                          "/about_us",
                        );
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: screenSize.height / 80.08,
                          ),
                          Text('About Us',
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 120,
                                color: _isHovering[1] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          SizedBox(height: screenSize.height / 192.2),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[1],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 96)),
                              height: screenSize.height/137.2,
                              width: screenSize.width/274.2,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[2] = true
                              : _isHovering[2] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamed(context, "/our_Services");
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: screenSize.height / 80.08,
                          ),
                          Text('Services',
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 120,
                                color: _isHovering[2] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          SizedBox(height: screenSize.height / 192.2),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[2],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 96)),
                             height: screenSize.height/137.2,
                              width: screenSize.width/274.2,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[3] = true
                              : _isHovering[3] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamed(context, "/chat_with_us");
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                           SizedBox(
                            height: screenSize.height/80.0,
                          ),
                          Text('Chat With US',
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 120,
                                color: _isHovering[3] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )),
                          SizedBox(height: screenSize.height / 192.2),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[3],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 96)),
                              height: screenSize.height/137.2,
                              width: screenSize.width/274.2,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[4] = true
                              : _isHovering[4] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamed(context, "/call_with_us");
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: screenSize.height / 80.08,
                          ),
                          Text('Call With Us',
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 120,
                                color: _isHovering[4] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )
                             
                              ),
                          SizedBox(height: screenSize.height / 192.2),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[4],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 96)),
                              height: screenSize.height/137.2,
                              width: screenSize.width/274.2,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: screenSize.width / 20),
                    InkWell(
                      onHover: (value) {
                        setState(() {
                          value
                              ? _isHovering[5] = true
                              : _isHovering[5] = false;
                        });
                      },
                      hoverColor: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamed(context, "/our_live_vendor");
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: screenSize.height / 80.08,
                          ),
                          Text('Live Naksian',
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 120,
                                color: _isHovering[5] ? active : disable,
                                fontWeight: FontWeight.bold,
                              )
                              // style: TextStyle(
                              //   fontSize: 16,
                              //   fontWeight: FontWeight.bold,
                              //   color: _isHovering[4] ? active : disable,
                              // ),
                              ),
                          SizedBox(height: screenSize.height / 192.2),
                          Visibility(
                            maintainAnimation: true,
                            maintainState: true,
                            maintainSize: true,
                            visible: _isHovering[5],
                            child: Container(
                              decoration: BoxDecoration(
                                  color: active,
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 96)),
                              height: screenSize.height/137.2,
                              width: screenSize.width/274.2,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: screenSize.width / 20),
              Builder(builder: (context) {
                return ElevatedButton(
                    onPressed: () async{
                      SharedPreferences pref =
                      await SharedPreferences.getInstance();
                  if (pref.getString('uid') == null) {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return const LoginModel();
                      },
                    );
                  }
                  else{
                      showAlignedDialog(
                          context: context,
                          builder: _localDialogBuilder,
                          followerAnchor: Alignment.topRight,
                          targetAnchor: Alignment.bottomLeft,
                          barrierColor: Colors.transparent);
                    }
                    },
                    style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    foregroundColor: Colors.black,
                    elevation: 0,
                    ),
                    child: Container(
        decoration: BoxDecoration(
            color: active, borderRadius: BorderRadius.circular(30)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Icon(Icons.person)));
              }),
              SizedBox(width: screenSize.width / 40),
            ],
          ),
        ),
      ),
    );
  }

  WidgetBuilder get _localDialogBuilder {
    
    var screenSize = MediaQuery.of(context).size;
    return (BuildContext context) {
      return Container(
        height: screenSize.height/2.74,
        width: screenSize.width/7.68,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(screenSize.width/192),
            boxShadow: [
              BoxShadow(
                  blurRadius: 0.6,
                  spreadRadius: 0.1,
                  color: Colors.grey,
                  offset: Offset(0.5, 0.5)),
              BoxShadow(
                  blurRadius: 0.6,
                  spreadRadius: 0.1,
                  color: Colors.grey,
                  offset: Offset(-0.5, -0.5))
            ]),
        child: Column(
          children: [
            Column(
              children: [
                SizedBox(
                  height: screenSize.height/64.06,
                ),
                CircleAvatar(
                  radius: screenSize.width/64,
                  backgroundImage: NetworkImage(
                      'https://w7.pngwing.com/pngs/81/570/png-transparent-profile-logo-computer-icons-user-user-blue-heroes-logo-thumbnail.png'),
                ),
                SizedBox(
                  height: screenSize.height/96.1,
                ),
                Text(
                  "Arjun",
                  style: TextStyle(
                      fontSize: screenSize.width/112.9,
                      fontWeight: FontWeight.bold,
                      color: darkBlue),
                ),
                SizedBox(
                  height: screenSize.height/192.2,
                ),
                Text(
                  "+91 6305623566",
                  style: TextStyle(
                      fontSize: screenSize.width/112.9,
                      fontWeight: FontWeight.w600,
                      color: Colors.black),
                ),
                Divider(
                  thickness: screenSize.height/961,
                  color: Colors.grey,
                ),
              ],
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: screenSize.width/128),
              // height: 40,
              width: screenSize.width/7.68,
              // color: Colors.red,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => NaksaNotifictaion()));
                      },
                      child: Text(
                        "Notification",
                        style: TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      )),
                  SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => HistoryScreen()));
                      },
                      child: Text(
                        "Wallet Transactions",
                        style: TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      )),
                  SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => HistoryScreen()));
                      },
                      child: Text(
                        "Order History",
                        style: TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      )),
                  SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  InkWell(
                      onTap: () {},
                      child: Text(
                        "Customer Support Chat",
                        style: TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      )),
                  SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  InkWell(
                      onTap: () async {
                        SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        prefs.clear();
                        Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (_) {
                          return HomeScreen();
                        }));
                      },
                      child: Text(
                        "Logout",
                        style: TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      )),
                  SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  InkWell(
                      onTap: () {},
                      child: Text(
                        "Logout From Other Devices",
                        style: TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      )),
                  SizedBox(
                    height: screenSize.height/96.1,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    };
  }
}
