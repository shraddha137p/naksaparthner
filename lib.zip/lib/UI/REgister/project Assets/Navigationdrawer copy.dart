import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/customerFollowing.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class NavigationDrawer extends StatefulWidget {
  const NavigationDrawer({super.key});

  @override
  State<NavigationDrawer> createState() => _NavigationDrawerState();
}

class _NavigationDrawerState extends State<NavigationDrawer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 30),
      child: Column(
        children: [
          Container(
            height: 120,
            child: DrawerHeader(
              decoration: const BoxDecoration(
                color: themeColor,
              ),
              child: Container(
                  child: Row(
                children: [
                  Container(
                    height: 45,
                    width: 45,
                    decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: ornageColor),
                    child: const Center(
                        child: Icon(
                      Icons.person,
                      color: Colors.white,
                    )),
                  ),
                  const SizedBox(
                    width: 15,
                  ),
                  Container(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Rohit Kushwaha",
                              style: GoogleFonts.merriweather(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              )),
                          const SizedBox(
                            height: 4,
                          ),
                          Text("Gomti Nagar, Lucknow",
                              style: GoogleFonts.merriweather(
                                fontSize: 12,
                                fontWeight: FontWeight.normal,
                              ))
                        ]),
                  )
                ],
              )),
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.home,
              color: Colors.white,
            ),
            title: Text('Home',
                style: GoogleFonts.merriweather(color: Colors.white)),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => BottomNavigationBarScreen(
                            pageIndex: 0,
                          )));
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.home,
              color: Colors.white,
            ),
            title: Text('Orders',
                style: GoogleFonts.merriweather(
                  color: Colors.white,
                )),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          BottomNavigationBarScreen(pageIndex: 4)));
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.home,
              color: Colors.white,
            ),
            title: Text('My Following',
                style: GoogleFonts.merriweather(color: Colors.white)),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const CustomerFollowingScreen()));
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.home,
              color: Colors.white,
            ),
            title: Text('Contact',
                style: GoogleFonts.merriweather(color: Colors.white)),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.home,
              color: Colors.white,
            ),
            title: Text('Wallet',
                style: GoogleFonts.merriweather(color: Colors.white)),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.home,
              color: Colors.white,
            ),
            title: Text('FAQ',
                style: GoogleFonts.merriweather(color: Colors.white)),
            onTap: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}
