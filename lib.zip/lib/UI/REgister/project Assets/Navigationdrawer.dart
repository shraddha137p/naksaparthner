import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/customerFollowing.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/customerFollowingModel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../MainAsset/URL.dart';
import '../../../model/CustomerProfileModel.dart';
import '../../Home/CompleteProfileScreen.dart';
import '../../Home/HistoryScreen.dart';
import '../../Home/our_services.dart';
import 'LoginModel.dart';

final Uri _url = Uri.parse('https://rakleitsolutions.com/');

class NavigationDrawers extends StatefulWidget {
  const NavigationDrawers({
    super.key,
  });

  @override
  State<NavigationDrawers> createState() => _NavigationDrawerState();
}

class _NavigationDrawerState extends State<NavigationDrawers> {
  Future<void> _launchUrl() async {
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _checkLogin();
  }

  bool _islogin = false;
  void _checkLogin() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? islogin = pref.getString("uid");
    if (islogin != null) {
      getProfileDetails();
    } else {
      setState(() {
        isdataloading = true;
      });
    }
  }

  bool isdataloading = false;
  List<CustomerP> _customerList = [];
  var customerService = CustomerProfileService();
  Future<void> getProfileDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var phone = prefs.getString("phone");
    var response = await customerService.viewCustomerProfile(phone.toString());
    if (response != null) {
      setState(() {
        isdataloading = true;
        _customerList = response;
      });
    } else {
      throw Exception("Failed to load data");
    }
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return isdataloading != false
        ? Scaffold(
            backgroundColor: darkBlue,
            body: ListView(
              // Important: Remove any padding from the ListView.
              padding: EdgeInsets.zero,
              children: [
                SizedBox(
                  height: screenSize.height / 6.3,
                  child: DrawerHeader(
                    decoration: const BoxDecoration(
                      color: themeColor,
                    ),
                    child: Container(
                      child: Row(
                        children: [
                          _customerList.length >= 1
                              ? _customerList[0].photo != null
                                  ? Container(
                                      height: screenSize.height / 15.12,
                                      width: screenSize.width / 7.2,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "${MainUrl}customer-image/${_customerList.isNotEmpty ? _customerList[0].photo : "profile photo"}"),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      child: const Center(
                                          child: Icon(
                                        Icons.person,
                                        color: Colors.white,
                                      )),
                                    )
                                  : Container(
                                      height: screenSize.height/16.8,
                                      width: screenSize.width/8,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color.fromRGBO(
                                          246,
                                          87,
                                          15,
                                          1,
                                        ),
                                      ),
                                      child:  Center(
                                        child: Icon(
                                          Icons.person,
                                          size: screenSize.width/18,
                                          color: Colors.white,
                                        ),
                                      ),
                                    )
                              : Container(
                                  
                                      height: screenSize.height/16.8,
                                      width: screenSize.width/8,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color.fromRGBO(
                                      246,
                                      87,
                                      15,
                                      1,
                                    ),
                                  ),
                                  child:  Center(
                                    child: Icon(
                                      Icons.person,
                                      size: screenSize.width/18,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                           SizedBox(
                            width: screenSize.width/45,
                          ),
                          Container(
                            child: Padding(
                              padding:  EdgeInsets.only(left: screenSize.width/45),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                      _customerList.isNotEmpty
                                          ? _customerList[0].name.toString()
                                          : "Naksa",
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width/18,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      )),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  Text(
                                    "Gomti Nagar, Lucknow",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width/30,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            BottomNavigationBarScreen(pageIndex: 0),
                      ),
                    );
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                       Icon(
                        Icons.person,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Home',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BottomNavigationBarScreen(
                          pageIndex: 4,
                        ),
                      ),
                    );
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                     Icon(
                        Icons.wallet,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'My Orders',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () async {
                    SharedPreferences pref =
                        await SharedPreferences.getInstance();
                    if (pref.getString('uid') != null) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CustomerFollowingScreen(),
                        ),
                      );
                    } else {
                      showModalBottomSheet(
                        isDismissible: false,
                        context: context,
                        isScrollControlled: true,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(screenSize.width/36)),
                        builder: (BuildContext context) {
                          return const LoginModel();
                        },
                      );
                    }
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                       Icon(
                        Icons.people_outline,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'My following',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () {
                    Navigator.pop(
                      context,
                    );
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width:screenSize.width/18,
                      ),
                       Icon(
                        Icons.contact_phone,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Contact Us',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const HistoryScreen(),
                      ),
                    );
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                       Icon(
                        Icons.wallet,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Wallet Transections',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () {
                    _launchUniversalLinkIos(
                        Uri.parse("https://d1st343ritdnag.cloudfront.net/"));
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                       Icon(
                        Icons.person_add,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Sign up as Vendor',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CustomerProfileScreen(),
                      ),
                    );
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                     Icon(
                        Icons.settings,
                        color: Colors.white,
                        size: screenSize.width/21.17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Setting',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const OurServices(),
                      ),
                    );
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                       Icon(
                        Icons.design_services,
                        color: Colors.white,
                        size: screenSize.width/21.1,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Our Services',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: screenSize.width/22.5),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: screenSize.height/37.8,
                ),
                InkWell(
                  onTap: () async {
                    SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    prefs.clear();
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (_) {
                      return BottomNavigationBarScreen(
                        pageIndex: 0,
                      );
                    }));
                  },
                  child: Row(
                    children: [
                      SizedBox(
                        width: screenSize.width/18,
                      ),
                      const Icon(
                        Icons.logout,
                        color: Colors.white,
                        size: 17,
                      ),
                       SizedBox(
                        width: screenSize.width/24,
                      ),
                      Text(
                        'Logout',
                        style: GoogleFonts.merriweather(
                            color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
              ],
            ),
            bottomNavigationBar: SizedBox(
              height: screenSize.height/7.56,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(
                    color: Colors.white,
                    thickness: 1.5,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: screenSize.width/72,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(Uri.parse(
                              "whatsapp://send?phone=+916394856756&text=Welcome In Naksa"));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.blue,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child:  Icon(
                            FontAwesomeIcons.telegram,
                            size: screenSize.width/14.4,
                            color: Colors.white,
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/36,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(Uri.parse(
                              "whatsapp://send?phone=+916394856756&text=Welcome In Naksa"));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.green,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child:  Icon(
                            FontAwesomeIcons.whatsapp,
                            size: screenSize.width/14.4,
                            color: Colors.white,
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/36,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(Uri.parse(
                              "https://www.instagram.com/official_naksa/ "));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.red,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child:  Icon(
                            FontAwesomeIcons.instagram,
                            size: screenSize.width/14.4,
                            color: Colors.white,
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/36,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(Uri.parse(
                              "https://www.facebook.com/officialnaksa"));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.blue,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child:  Icon(
                            FontAwesomeIcons.facebook,
                            size: screenSize.width/14.4,
                            color: Colors.white,
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/36,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(Uri.parse(
                              "https://www.linkedin.com/company/94862035/admin/"));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.blue,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child: Padding(
                            padding:  EdgeInsets.all(screenSize.width/120),
                            child:  Icon(
                              FontAwesomeIcons.linkedinIn,
                              size: screenSize.width/18,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/36,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(
                              Uri.parse("https://twitter.com/naksa_official"));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.blue,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child: Padding(
                            padding:  EdgeInsets.all(screenSize.width/120),
                            child:  Icon(
                              FontAwesomeIcons.twitter,
                              size: screenSize.width/18,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/36,
                      ),
                      GestureDetector(
                        onTap: () {
                          _launchUniversalLinkIos(Uri.parse(
                              "https://www.facebook.com/officialnaksa"));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.red,
                              border: Border.all(
                                width: screenSize.width/360,
                              )),
                          child:  Icon(
                            FontAwesomeIcons.pinterest,
                            size: screenSize.width/14.4,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                   SizedBox(
                    height: screenSize.height/37.8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Text(
                        "V : 12.0.0.1",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()));
  }

  Future<void> _launchUniversalLinkIos(Uri url) async {
    final bool nativeAppLaunchSucceeded = await launchUrl(
      url,
      mode: LaunchMode.externalNonBrowserApplication,
    );
    if (!nativeAppLaunchSucceeded) {
      await launchUrl(
        url,
        mode: LaunchMode.inAppWebView,
      );
    }
  }
}
