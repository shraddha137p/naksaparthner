import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/ChatScreen.dart';

import 'constants.dart';

class ChatAndCallScreenOptions extends StatefulWidget {
  ValueChanged<String> sname;
  ChatAndCallScreenOptions({super.key, required this.sname});

  @override
  State<ChatAndCallScreenOptions> createState() =>
      _ChatAndCallScreenOptionsState();
}

class _ChatAndCallScreenOptionsState extends State<ChatAndCallScreenOptions> {
  bool isHover1 = false;
  bool isHover2 = false;
  bool isHover3 = false;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopChatAndCallScreenOptions();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopChatAndCallScreenOptions();
      } else {
        return MobileChatAndCallScreenOptions();
      }
    });
  }

  @override
  Widget DesktopChatAndCallScreenOptions() {
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: screenSize.height/3.67,
                  width: screenSize.width/6.50,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: darkBlue,
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width/240),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: screenSize.height/24.6,
                        width: double.infinity,
                        decoration:  BoxDecoration(
                          color: darkBlue,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(screenSize.width/240),
                              topRight: Radius.circular(screenSize.width/240)),
                        ),
                        child: Padding(
                          padding:  EdgeInsets.only(left: screenSize.width/96),
                          child: Row(
                            children: [
                              const Icon(Icons.message_rounded,
                                  color: Colors.white),
                               SizedBox(
                                width: screenSize.width/192,
                              ),
                              Text(
                                "Consult With Us",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/128,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                          height: screenSize.height/4.36,
                          child: Column(
                            children: [
                              Padding(
                                padding:
                                     EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/384),
                                child: Column(
                                  children: [
                                     SizedBox(
                                      height: screenSize.height/96.1,
                                    ),
                                    Row(
                                      children: [
                                         Icon(
                                          Icons.arrow_forward,
                                          size: screenSize.width/147.6,
                                        ),
                                         SizedBox(
                                          width: screenSize.width/192,
                                        ),
                                        InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                          ChatMainScreen()));
                                            },
                                            onHover: (val) {
                                              setState(() {
                                                val
                                                    ? isHover1 = true
                                                    : isHover1 = false;
                                              });
                                            },
                                            child: Text(
                                              "Call With Us",
                                              style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/147.6,
                                                  fontWeight: FontWeight.bold,
                                                  color: isHover1 != true
                                                      ? Colors.black
                                                      : themeColor),
                                            )),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                     EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/384),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                         Icon(
                                          Icons.arrow_forward,
                                          size: screenSize.width/147.6,
                                        ),
                                         SizedBox(
                                          width: screenSize.width/192,
                                        ),
                                        InkWell(
                                            onTap: () {},
                                            onHover: (val) {
                                              setState(() {
                                                val
                                                    ? isHover2 = true
                                                    : isHover2 = false;
                                              });
                                            },
                                            child: Text(
                                              "Chat With Us",
                                              style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/147.6,
                                                  fontWeight: FontWeight.bold,
                                                  color: isHover2 != true
                                                      ? Colors.black
                                                      : themeColor),
                                            )),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                     EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/334),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                         Icon(
                                          Icons.arrow_forward,
                                          size: screenSize.width/147.6,
                                        ),
                                         SizedBox(
                                          width: screenSize.width/192,
                                        ),
                                        InkWell(
                                            onTap: () {},
                                            onHover: (val) {
                                              setState(() {
                                                val
                                                    ? isHover3 = true
                                                    : isHover3 = false;
                                              });
                                            },
                                            child: Text(
                                              "Live Vendor",
                                              style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/147,
                                                  fontWeight: FontWeight.bold,
                                                  color: isHover3 != true
                                                      ? Colors.black
                                                      : themeColor),
                                            )),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ))
                    ],
                  ),
                ),
                 SizedBox(
                  width: screenSize.width/96,
                ),
                Container(
                 height: screenSize.height/3.67,
                  width: screenSize.width/6.50,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: darkBlue,
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width/240),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: screenSize.height/24.64,
                        width: double.infinity,
                        decoration:  BoxDecoration(
                          color: darkBlue,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(screenSize.width/240),
                              topRight: Radius.circular(screenSize.width/240)),
                        ),
                        child: Padding(
                          padding:  EdgeInsets.only(left: screenSize.width/96),
                          child: Row(
                            children: [
                              const Icon(Icons.message_rounded,
                                  color: Colors.white),
                               SizedBox(
                                width: screenSize.width/192,
                              ),
                              Text(
                                "City Wise Vender",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/128,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: screenSize.height/4.36,
                        child: ListView.builder(
                            shrinkWrap: false,
                            itemCount: city.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding:
                                     EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/334),
                                child: Column(
                                  children: [
                                     SizedBox(
                                      height: screenSize.height/96.1,
                                    ),
                                    Row(
                                      children: [
                                         Icon(
                                          Icons.arrow_forward,
                                          size: screenSize.width/147.6,
                                        ),
                                         SizedBox(
                                          width: screenSize.width/192,
                                        ),
                                        InkWell(
                                            onTap: () {
                                              setState(() {
                                                widget.sname(
                                                    "${'city'},${city[index]}");
                                              });
                                            },
                                            onHover: (val) {
                                              setState(() {
                                                val
                                                    ? city_hover[index] = true
                                                    : city_hover[index] = false;
                                              });
                                            },
                                            child: Text(
                                              "$name in ${city[index]}  ",
                                              style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/147.6,
                                                  fontWeight: FontWeight.bold,
                                                  color:
                                                      city_hover[index] != true
                                                          ? Colors.black
                                                          : themeColor),
                                            )),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                ),
                 SizedBox(
                  width: screenSize.width/96,
                ),
                Container(
                  height: screenSize.height/3.67,
                  width: screenSize.width/6.50,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: darkBlue,
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width/240),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: screenSize.height/24.64,
                        width: double.infinity,
                        decoration:  BoxDecoration(
                          color: darkBlue,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(screenSize.width/240),
                              topRight: Radius.circular(screenSize.width/240)),
                        ),
                        child: Padding(
                          padding:  EdgeInsets.only(left: screenSize.width/96),
                          child: Row(
                            children: [
                              const Icon(Icons.message_rounded,
                                  color: Colors.white),
                               SizedBox(
                                width: screenSize.width/192,
                              ),
                              Text(
                                "Country Wise Vendor",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/128,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: screenSize.height/4.36,
                        child: ListView.builder(
                            shrinkWrap: false,
                            itemCount: country.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding:
                                     EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/334),
                                child: Column(
                                  children: [
                                     SizedBox(
                                      height: screenSize.height/96.1,
                                    ),
                                    Row(
                                      children: [
                                         Icon(
                                          Icons.arrow_forward,
                                          size: screenSize.width/147.6,
                                        ),
                                         SizedBox(
                                          width: screenSize.width/192,
                                        ),
                                        InkWell(
                                            onTap: () {
                                              setState(() {
                                                widget.sname(
                                                    "${'country'},${country[index]}");
                                              });
                                            },
                                            onHover: (val) {
                                              setState(() {
                                                val
                                                    ? country_hover[index] =
                                                        true
                                                    : country_hover[index] =
                                                        false;
                                              });
                                            },
                                            child: Text(
                                              "$name In ${country[index]}",
                                              style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/147.6,
                                                  fontWeight: FontWeight.bold,
                                                  color: country_hover[index] !=
                                                          true
                                                      ? Colors.black
                                                      : themeColor),
                                            )),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                ),
                 SizedBox(
                  width: screenSize.width/96,
                ),
                Container(
                  height: screenSize.height/3.67,
                  width: screenSize.width/6.50,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: darkBlue,
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width/240),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: screenSize.height/24.6,
                        width: double.infinity,
                        decoration:  BoxDecoration(
                          color: darkBlue,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(screenSize.width/240),
                              topRight: Radius.circular(screenSize.width/240)),
                        ),
                        child: Padding(
                          padding:  EdgeInsets.only(left: screenSize.width/96),
                          child: Row(
                            children: [
                              const Icon(Icons.message_rounded,
                                  color: Colors.white),
                               SizedBox(
                                width: screenSize.width/192,
                              ),
                              Text(
                                "Category Wise",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/128,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: screenSize.height/4.36,
                        child: ListView.builder(
                            shrinkWrap: false,
                            itemCount: category.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding:
                                     EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/334),
                                child: Column(
                                  children: [
                                     SizedBox(
                                      height: screenSize.height/96.1,
                                    ),
                                    Row(
                                      children: [
                                         Icon(
                                          Icons.arrow_forward,
                                          size: screenSize.width/147.6,
                                        ),
                                         SizedBox(
                                          width: screenSize.width/192,
                                        ),
                                        InkWell(
                                            onTap: () {
                                              setState(() {
                                                widget.sname(
                                                    "${'category'},${category[index]}");
                                              });
                                            },
                                            onHover: (val) {
                                              setState(() {
                                                val
                                                    ? category_hover[index] =
                                                        true
                                                    : category_hover[index] =
                                                        false;
                                              });
                                            },
                                            child: Text(
                                              "$name In ${category[index]}",
                                              style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/147.6,
                                                  fontWeight: FontWeight.bold,
                                                  color:
                                                      category_hover[index] !=
                                                              true
                                                          ? Colors.black
                                                          : themeColor),
                                            )),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Widget MobileChatAndCallScreenOptions() {
    
    
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: screenSize.height/2.89,
              width: screenSize.width/1.22,
              decoration: BoxDecoration(
                border: Border.all(
                  color: darkBlue,
                ),
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/45),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: screenSize.height/19.3,
                    width: double.infinity,
                    decoration:  BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(screenSize.width/45),
                          topRight: Radius.circular(screenSize.width/45)),
                    ),
                    child: Padding(
                      padding:  EdgeInsets.only(left: screenSize.width/18),
                      child: Row(
                        children: [
                          const Icon(Icons.message_rounded,
                              color: Colors.white),
                           SizedBox(
                            width: screenSize.width/36,
                          ),
                          Text(
                            "Consult With Us",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/24,
                                color: Colors.white,
                                fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                      height: screenSize.height/3.43,
                      child: Column(
                        children: [
                          Padding(
                            padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/72),
                            child: Column(
                              children: [
                                 SizedBox(
                                  height: screenSize.height/75.6,
                                ),
                                Row(
                                  children: [
                                     Icon(
                                      Icons.arrow_forward,
                                      size: screenSize.width/27.6,
                                    ),
                                     SizedBox(
                                      width: screenSize.width/36,
                                    ),
                                    InkWell(
                                        onTap: () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      BottomNavigationBarScreen(
                                                          pageIndex: 1)));
                                        },
                                        onHover: (val) {
                                          setState(() {
                                            val
                                                ? isHover1 = true
                                                : isHover1 = false;
                                          });
                                        },
                                        child: Text(
                                          "Call With Us",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/27.6,
                                              fontWeight: FontWeight.bold,
                                              color: isHover1 != true
                                                  ? Colors.black
                                                  : themeColor),
                                        )),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/72),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                     Icon(
                                      Icons.arrow_forward,
                                      size: screenSize.width/27.6,
                                    ),
                                     SizedBox(
                                      width: screenSize.width/36,
                                    ),
                                    InkWell(
                                        onTap: () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      BottomNavigationBarScreen(
                                                          pageIndex: 3)));
                                        },
                                        onHover: (val) {
                                          setState(() {
                                            val
                                                ? isHover2 = true
                                                : isHover2 = false;
                                          });
                                        },
                                        child: Text(
                                          "Chat with Us",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/27.6,
                                              fontWeight: FontWeight.bold,
                                              color: isHover2 != true
                                                  ? Colors.black
                                                  : themeColor),
                                        )),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/72),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                   Icon(
                                      Icons.arrow_forward,
                                      size: screenSize.width/27.6,
                                    ),
                                     SizedBox(
                                      width: screenSize.width/36,
                                    ),
                                    InkWell(
                                      onTap: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    BottomNavigationBarScreen(
                                                        pageIndex: 2)));
                                      },
                                      onHover: (val) {
                                        setState(() {
                                          val
                                              ? isHover3 = true
                                              : isHover3 = false;
                                        });
                                      },
                                      child: Text(
                                        "Live Vendor",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width/27.6,
                                            fontWeight: FontWeight.bold,
                                            color: isHover3 != true
                                                ? Colors.black
                                                : themeColor),
                                      ),
                                    ),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ))
                ],
              ),
            ),
             SizedBox(
              width: screenSize.width/18,
              height: screenSize.height/37.8,
            ),
            Container(
              height: screenSize.height/2.89,
              width: screenSize.width/1.22,
              decoration: BoxDecoration(
                border: Border.all(
                  color: darkBlue,
                ),
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/45),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: screenSize.height/19.3,
                    width: double.infinity,
                    decoration:  BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(
                          screenSize.width/45,
                        ),
                        topRight: Radius.circular(
                          screenSize.width/45,
                        ),
                      ),
                    ),
                    child: Padding(
                      padding:  EdgeInsets.only(
                        left: screenSize.width/18,
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.message_rounded,
                            color: Colors.white,
                          ),
                           SizedBox(
                            width: screenSize.width/36,
                          ),
                          Text(
                            "City Wise Vender",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/24,
                                color: Colors.white,
                                fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height:  screenSize.height/3.43,
                    child: ListView.builder(
                        shrinkWrap: false,
                        itemCount: city.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/72),
                            child: Column(
                              children: [
                                 SizedBox(
                                  height:  screenSize.height/75.6,
                                ),
                                Row(
                                  children: [
                                     Icon(
                                      Icons.arrow_forward,
                                      size: screenSize.width/27.6,
                                    ),
                                     SizedBox(
                                      width: screenSize.width/36,
                                    ),
                                    InkWell(
                                        onTap: () {
                                          setState(() {
                                            widget.sname(
                                                "${'city'},${city[index]}");
                                          });
                                        },
                                        onHover: (val) {
                                          setState(() {
                                            val
                                                ? city_hover[index] = true
                                                : city_hover[index] = false;
                                          });
                                        },
                                        child: Text(
                                          "$name in ${city[index]}  ",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/27.6,
                                              fontWeight: FontWeight.bold,
                                              color: city_hover[index] != true
                                                  ? Colors.black
                                                  : themeColor),
                                        )),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          );
                        }),
                  )
                ],
              ),
            ),
             SizedBox(
              width: screenSize.width/18,
              height:  screenSize.height/37.8,
            ),
            Container(
              height:  screenSize.height/2.89,
              width: screenSize.width/1.22,
              decoration: BoxDecoration(
                border: Border.all(
                  color: darkBlue,
                ),
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/45),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height:  screenSize.height/19.3,
                    width: double.infinity,
                    decoration:  BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(screenSize.width/45),
                          topRight: Radius.circular(screenSize.width/45)),
                    ),
                    child: Padding(
                      padding:  EdgeInsets.only(left: screenSize.width/18),
                      child: Row(
                        children: [
                          const Icon(Icons.message_rounded,
                              color: Colors.white),
                           SizedBox(
                            width: screenSize.width/36,
                          ),
                          Text(
                            "Country Wise Vendor",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/24,
                                color: Colors.white,
                                fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height/3.43,
                    child: ListView.builder(
                        shrinkWrap: false,
                        itemCount: country.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding:  EdgeInsets.only(left:screenSize.width/24, right: screenSize.width/72),
                            child: Column(
                              children: [
                                 SizedBox(
                                  height: screenSize.height/75.6,
                                ),
                                Row(
                                  children: [
                                     Icon(
                                      Icons.arrow_forward,
                                      size: screenSize.width/27.6,
                                    ),
                                     SizedBox(
                                      width: screenSize.width/36,
                                    ),
                                    InkWell(
                                        onTap: () {
                                          setState(() {
                                            widget.sname(
                                                "${'country'},${country[index]}");
                                          });
                                        },
                                        onHover: (val) {
                                          setState(() {
                                            val
                                                ? country_hover[index] = true
                                                : country_hover[index] = false;
                                          });
                                        },
                                        child: Text(
                                          "$name In ${country[index]}",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/27.6,
                                              fontWeight: FontWeight.bold,
                                              color:
                                                  country_hover[index] != true
                                                      ? Colors.black
                                                      : themeColor),
                                        )),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          );
                        }),
                  )
                ],
              ),
            ),
             SizedBox(
              width: screenSize.width/18,
              height: screenSize.height/37.8,
            ),
            Container(
              height: screenSize.height/2.89,
              width: screenSize.width/1.22,
              decoration: BoxDecoration(
                border: Border.all(
                  color: darkBlue,
                ),
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/45),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: screenSize.height/19.3,
                    width: double.infinity,
                    decoration:  BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(screenSize.width/45),
                          topRight: Radius.circular(screenSize.width/45)),
                    ),
                    child: Padding(
                      padding:  EdgeInsets.only(left: screenSize.width/18),
                      child: Row(
                        children: [
                          const Icon(Icons.message_rounded,
                              color: Colors.white),
                           SizedBox(
                            width: screenSize.width/36,
                          ),
                          Text(
                            "Category Wise",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/24,
                                color: Colors.white,
                                fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height/3.43,
                    child: ListView.builder(
                        shrinkWrap: false,
                        itemCount: category.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/72),
                            child: Column(
                              children: [
                                 SizedBox(
                                  height: screenSize.height/75.6,
                                ),
                                Row(
                                  children: [
                                     Icon(
                                      Icons.arrow_forward,
                                      size: screenSize.width/27.6,
                                    ),
                                     SizedBox(
                                      width: screenSize.width/36,
                                    ),
                                    InkWell(
                                        onTap: () {
                                          setState(() {
                                            widget.sname(
                                                "${'category'},${category[index]}");
                                          });
                                        },
                                        onHover: (val) {
                                          setState(() {
                                            val
                                                ? category_hover[index] = true
                                                : category_hover[index] = false;
                                          });
                                        },
                                        child: Text(
                                          "$name In ${category[index]}",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/27.6,
                                              fontWeight: FontWeight.bold,
                                              color:
                                                  category_hover[index] != true
                                                      ? Colors.black
                                                      : themeColor),
                                        )),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          );
                        }),
                  )
                ],
              ),
            ),
          ],
        ));
  }

  String name = "Vendor";
  List city_hover = [false, false, false, false, false, false];
  List country_hover = [false, false, false, false, false, false];
  List category_hover = [
    false,
    false,
    false,
    false,
    false,
  ];

  List city = [
    "Lucknow",
    "Kanpur",
    "Delhi",
    "Vanarshi",
    "Mirzapur",
    "Prayagraj"
  ];
  List country = ["India", "Pakistan", "China", "Japan", "Korea", "Sapan"];
  List category = [
    "Interior Desginer",
    "Architecture",
    "Structure Engineer",
    "Vastu Consultant",
    "3D Desginer"
  ];
}
