import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/BannerService.dart';
import 'package:naksaa_services/model/BannerModel.dart';

class MainSlider extends StatefulWidget {
  const MainSlider({super.key});

  @override
  State<MainSlider> createState() => _MainSliderState();
}

class _MainSliderState extends State<MainSlider> {
  List<BDatum> results = [];
  var vendorService = BannerService();
  bool isloading = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    // allVendor = vendorService.viewallVendor();
  }

  Future<List<BDatum>> getdata() async {
    setState(() {
      isloading = true;
    });
    results = (await vendorService.viewallBanner())!;
    if (results != null) {
      setState(() {
        isloading = false;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopBanner();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopBanner();
      } else {
        return Mobilebanner();
      }
    });
  }

  Widget DesktopBanner() {
    var screenSize = MediaQuery.of(context).size;
    return isloading != true
        ? Container(
            margin:  EdgeInsets.only(left: screenSize.width/192, right: screenSize.width/192),
            height: screenSize.height/2.74,
            color: Colors.transparent,
            child: ListView(
              children: [
                CarouselSlider(
                  items: results
                      .map((e) => Container(
                            margin:  EdgeInsets.all(screenSize.width/320),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(screenSize.width/240),
                              image: DecorationImage(
                                image: NetworkImage(
                                    '${MainUrl}banner/${e.banimage}'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ))
                      .toList(),

                  // //Slider Container properties
                  options: CarouselOptions(
                    height: screenSize.height/2.74,
                    enlargeCenterPage: true,
                    autoPlay: true,
                    aspectRatio: 16 / 9,
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enableInfiniteScroll: true,
                    autoPlayAnimationDuration:
                        const Duration(milliseconds: 800),
                    viewportFraction: 0.9,
                  ),
                ),
              ],
            ),
          )
        :  SizedBox(
            height: screenSize.height/8.008,
            child: LoadingIndicator(),
          );
  }

  Widget Mobilebanner() {
    
    var screenSize = MediaQuery.of(context).size;
    return isloading != true
        ? SizedBox(
            height: screenSize.height/6.3,
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
               shrinkWrap: false,
              children: [
                CarouselSlider(
                  items: results
                      .map((e) => Container(
                            margin:  EdgeInsets.all(screenSize.width/60),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(screenSize.width/60),
                              image: DecorationImage(
                                image: NetworkImage(
                                    '${MainUrl}banner/${e.banimage}'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ))
                      .toList(),

                  // //Slider Container properties
                  options: CarouselOptions(
                    height: screenSize.height/6.3,
                    enlargeCenterPage: true,
                    autoPlay: true,
                    aspectRatio: 16 / 9,
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enableInfiniteScroll: true,
                    autoPlayAnimationDuration:
                        const Duration(milliseconds: 800),
                    viewportFraction: 0.9,
                  ),
                ),
              ],
            ),
          )
        :  SizedBox(
            height: screenSize.height/6.3,
            child: LoadingIndicator(),
          );
  }
}
