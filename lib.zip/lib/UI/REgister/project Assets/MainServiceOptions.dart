import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MainServiceOptions extends StatefulWidget {
  const MainServiceOptions({super.key});

  @override
  State<MainServiceOptions> createState() => _MainServiceOptionsState();
}

class _MainServiceOptionsState extends State<MainServiceOptions> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceOptions();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceOptions();
      } else {
        return MobileServiceOptions();
      }
    });
  }

  Widget DesktopServiceOptions() {
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
      width: double.infinity,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, "/chat_with_us");
            },
            child: Container(
              height: screenSize.height/6.36,
              width: screenSize.width/6.73,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/192),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(
                      0,
                      0,
                    ),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height/12.8,
                    width: screenSize.width/25.6,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(screenSize.width/38.4),
                    ),
                    child:  Icon(
                      Icons.chat,
                      size: screenSize.width/51.8,
                      color: Colors.white,
                    ),
                  ),
                   SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  Text(
                    "Chat With Us",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/96,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
           SizedBox(
            width: screenSize.width/96,
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, "/call_with_us");
            },
            child: Container(
              height: screenSize.height/6.36,
              width: screenSize.width/6.73,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/192),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                  height: screenSize.height/12.8,
                    width: screenSize.width/25.6,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(screenSize.width/38.4),
                    ),
                    child:  Icon(
                      Icons.call_sharp,
                      size: screenSize.width/51.8,
                      color: Colors.white,
                    ),
                  ),
                   SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  Text(
                    "Call With Us",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/96,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
           SizedBox(
            width: screenSize.width/96,
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, "/our_live_vendor");
            },
            child: Container(
              height: screenSize.height/6.36,
              width: screenSize.width/6.73,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/192),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ),
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                   height: screenSize.height/12.8,
                    width: screenSize.width/25.6,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(screenSize.width/38.4),
                    ),
                    child:  Icon(
                      Icons.video_call,
                      size: screenSize.width/51.8,
                      color: Colors.white,
                    ),
                  ),
                   SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  Text(
                    "Live Vendor",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/96,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
           SizedBox(
            width: screenSize.width/96,
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, "/blogPage");
            },
            child: Container(
             height: screenSize.height/6.36,
              width: screenSize.width/6.73,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width/192),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(
                      0,
                      0,
                      0,
                      0.16,
                    ),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ),
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(
                      0.0,
                      0.0,
                    ),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height/12.8,
                    width: screenSize.width/25.6,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(screenSize.width/38.4),
                    ),
                    child:  Icon(
                      Icons.cast_for_education,
                      size: screenSize.width/51.8,
                      color: Colors.white,
                    ),
                  ),
                   SizedBox(
                    height: screenSize.height/96.1,
                  ),
                  Text(
                    "Naksa Blog",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/96,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
           SizedBox(
            width: screenSize.width/96,
          ),
        ],
      ),
    );
  }

  Widget MobileServiceOptions() {
    
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
      width: screenSize.width/0.6,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: screenSize.height/11.6,
                  width: screenSize.width/5.53,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(screenSize.width/7.2),
                      color: Colors.red),
                  child:  Icon(
                    Icons.chat,
                    size: screenSize.width/14.4,
                    color: Colors.white,
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/151.2,
                ),
                SizedBox(
                  width: screenSize.width/5.53,
                  child: Text(
                    "Chat With Us",
                    style: GoogleFonts.merriweather(
                      fontSize: screenSize.width/25.71,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 4,
                    textAlign: TextAlign.center,
                  ),
                )
              ],
            ),
          ),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: screenSize.height/11.6,
                  width: screenSize.width/5.53,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(screenSize.width/7.2),
                      color: Colors.green),
                  child:  Icon(
                    Icons.chat,
                    size: screenSize.width/14.4,
                    color: Colors.white,
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/151.2,
                ),
                SizedBox(
                    width: screenSize.width/5.53,
                    child: Text(
                      "Call With Us",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/25.71,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 4,
                      textAlign: TextAlign.center,
                    )),
              ],
            ),
          ),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                 height: screenSize.height/11.6,
                  width: screenSize.width/5.53,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(screenSize.width/7.2),
                      color: Colors.yellow),
                  child:  Icon(
                    Icons.chat,
                    size: screenSize.width/14.4,
                    color: Colors.white,
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/151.2,
                ),
                SizedBox(
                    width: screenSize.width/5.53,
                    child: Text(
                      "Live Vendor",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/25.71,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 4,
                      textAlign: TextAlign.center,
                    )),
              ],
            ),
          ),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                 height: screenSize.height/11.6,
                  width: screenSize.width/5.53,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(screenSize.width/7.2),
                      color: Colors.redAccent),
                  child:  Icon(
                    Icons.chat,
                    size: screenSize.width/14.4,
                    color: Colors.white,
                  ),
                ),
                 SizedBox(
                  height: screenSize.height/151.2,
                ),
                SizedBox(
                    width: screenSize.width/5.53,
                    child: Text(
                      "Naksa Blogs",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/25.71,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 4,
                      textAlign: TextAlign.center,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
