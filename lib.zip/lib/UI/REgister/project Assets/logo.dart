import 'package:flutter/material.dart';

class MainLogo extends StatefulWidget {
  const MainLogo({super.key});

  @override
  State<MainLogo> createState() => _MainLogoState();
}

class _MainLogoState extends State<MainLogo> {
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(top: 94, left: 21),
          height: 84,
          width: 219,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(
              height: 64,
              width: 198,
              child: Image.asset(
                "assets/logo.png",
                fit: BoxFit.fill,
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            const Text(
              "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
              style: TextStyle(
                  fontSize: 10, color: Color.fromRGBO(112, 112, 112, 1)),
            )
          ]),
        ),
        Container(
          margin: const EdgeInsets.only(top: 68),
          height: 390,
          width: double.infinity,
          decoration: const BoxDecoration(
              image: DecorationImage(image: AssetImage("assets/SVG/back.png"))),
          child: Container(
            height: 390,
            width: 340,
            margin: const EdgeInsets.only(left: 20, right: 20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.12),
                  offset: const Offset(
                    3.0,
                    3.0,
                  ),
                  blurRadius: 8.0,
                  spreadRadius: 2.0,
                ), //BoxShadow
                const BoxShadow(
                  color: Colors.white,
                  offset: Offset(0.0, 0.0),
                  blurRadius: 0.0,
                  spreadRadius: 0.0,
                ), //BoxShadow
              ],
            ),
            child: Column(children: [
              Container(
                margin:
                    const EdgeInsets.symmetric(vertical: 43, horizontal: 62.10),
                child: const Text(
                  "Select Your Language",
                  style: TextStyle(
                      fontSize: 20, color: Color.fromRGBO(78, 78, 78, 1)),
                ),
              ),
              Container(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    child: Container(
                      height: screenHeight / 6.73,
                      width: screenWidth / 3.0763,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: const Color.fromRGBO(153, 167, 223, 1)
                                  .withOpacity(1),
                              spreadRadius: 5,
                              blurRadius: 6,
                              offset: const Offset(
                                  0, 6), // changes position of shadow
                            ),
                          ]),
                      child: Column(
                          // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                          children: [
                            SizedBox(
                              height: screenHeight / 26.26,
                            ),
                            Container(
                              height: screenHeight / 16.08,
                              width: screenWidth / 7.2,
                              decoration: const BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage("assets/SVG/अ2x.png"),
                                      fit: BoxFit.cover)),
                            ),
                            const Text(
                              "Hindi",
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )
                          ]),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(10),
                    height: 4,
                    width: 24,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: const Color.fromRGBO(154, 154, 154, 1)),
                  ),
                  Container(
                    height: screenHeight / 6.73,
                    width: screenWidth / 3.0763,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: const Color.fromRGBO(255, 215, 0, 1),
                        boxShadow: [
                          BoxShadow(
                            color: const Color.fromRGBO(153, 167, 223, 1)
                                .withOpacity(1),
                            spreadRadius: 5,
                            blurRadius: 6,
                            offset: const Offset(
                                0, 6), // changes position of shadow
                          ),
                        ]),
                    child: Column(
                        // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                        children: [
                          SizedBox(
                            height: screenHeight / 26.26,
                          ),
                          Container(
                            height: screenHeight / 16.08,
                            width: screenWidth / 5.14,
                            decoration: const BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage("assets/SVG/A2x.png"),
                                    fit: BoxFit.cover)),
                          ),
                          const Text(
                            "English",
                            style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          )
                        ]),
                  )
                ],
              )),
              Container(
                margin: const EdgeInsets.only(top: 46),
                width: 247,
                height: 56,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        width: 2, color: const Color.fromRGBO(2, 44, 67, 1))),
                child: const Center(
                  child: Text(
                    "GET STARTED",
                    style: TextStyle(
                        fontSize: 17, color: Color.fromRGBO(2, 44, 67, 1)),
                  ),
                ),
              )
            ]),
          ),
        ),
        Center(
          child: Container(
            margin: const EdgeInsets.only(
              top: 50,
            ),
            width: 196,
            child: const Text(
              "Welcome To Naksa Discover the Best Solution Easy & Simple",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.black),
            ),
          ),
        )
      ],
    );
  }
}
