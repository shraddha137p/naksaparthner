import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MainTextHead extends StatelessWidget {
  final String txt1;
   MainTextHead({Key? key, required this.txt1}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        HeadingPricingPolicy(txt1),
      ],
    );
  }
  Widget HeadingPricingPolicy(String txt1){
    return Text(txt1,
        maxLines: 2,
        textAlign: TextAlign.justify,
        style: GoogleFonts.merriweather(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black));
  }

}
