import 'package:flutter/material.dart';

class BulletPointWidget extends StatelessWidget {
  final String bltTxt;
  const BulletPointWidget({Key? key, required this.bltTxt}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8666,
      child: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 3,
              width: 3,
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            BulletPointText(bltTxt, context),
          ],
        ),
      ),
    );
  }
}

Widget BulletPointText(String bulTxt, BuildContext context) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.830,
    child: Text(
      bulTxt,
      textAlign: TextAlign.justify,
      overflow: TextOverflow.fade,
      maxLines: 5,
    ),
  );
}
