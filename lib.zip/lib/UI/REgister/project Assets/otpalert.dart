import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/CompleteProfileScreen.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'CompleteProfileModal.dart';

class OTPAlertVarification extends StatefulWidget {
  String mobile;
  OTPAlertVarification({super.key, required this.mobile});

  @override
  State<OTPAlertVarification> createState() => _OTPVarificationState();
}

class _OTPVarificationState extends State<OTPAlertVarification>
    with SingleTickerProviderStateMixin {
  var networkHandler = NetworkHandler();
  bool isloading = false;
  final TextEditingController _otp1 = TextEditingController();
  final TextEditingController _otp2 = TextEditingController();
  final TextEditingController _otp3 = TextEditingController();
  final TextEditingController _otp4 = TextEditingController();
  AnimationController? _animationController;
  int levelClock = 60;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
        vsync: this, duration: Duration(seconds: levelClock));

    _animationController!.forward();
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopOTPVarification();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopOTPVarification();
      } else {
        return MobileOTPVarification();
      }
    });
  }

  Widget DesktopOTPVarification() {
    return AlertDialog(
        shadowColor: Colors.transparent,
        backgroundColor: Colors.transparent,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(
                  Icons.close,
                  size: 20,
                  color: Colors.white,
                )),
          ],
        ),
        content: SizedBox(
          // color: Colors.transparent,
          height: 800,
          width: 700,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 10),
                height: 450,
                padding: const EdgeInsets.only(
                  left: 10,
                  right: 10,
                ),
                width: double.infinity,
                decoration: const BoxDecoration(
                    // image: DecorationImage(
                    //   image: AssetImage(
                    //     "assets/SVG/back.png",
                    //   ),
                    // ),
                    ),
                child: Container(
                  height: 281,
                  width: 227,
                  margin: const EdgeInsets.only(
                    left: 65,
                    right: 65,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      const BoxShadow(
                        color: Colors.white,
                        offset: Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 100,
                        child: Stack(
                          children: [
                            Container(
                              margin: const EdgeInsets.only(top: 45),
                              height: 76,
                              width: 76,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    width: 8, color: Colors.transparent),
                              ),
                              child: const Image(
                                image:
                                    AssetImage("assets/SVG/ic-contact-2x.png"),
                                fit: BoxFit.contain,
                              ),
                            ),
                            Positioned(
                              top: 37,
                              // left: 150,
                              right: 0,
                              child: Container(
                                height: 23,
                                width: 23,
                                decoration: const BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                      "assets/SVG/message-2x.png",
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Container(
                        child: Text(
                          "Enter 4 Digits code",
                          style: GoogleFonts.merriweather(
                            fontSize: 10,
                            color: const Color.fromRGBO(164, 164, 164, 1),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      // Container(
                      //   margin: EdgeInsets.all(10),
                      //   child: Center(
                      //     child: PinFieldAutoFill(
                      //       controller: _otp,
                      //       codeLength: 4,
                      //       autoFocus: true,
                      //       decoration: UnderlineDecoration(
                      //         lineHeight: 2,
                      //         lineStrokeCap: StrokeCap.square,
                      //         bgColorBuilder: PinListenColorBuilder(
                      //             Colors.green.shade200, Colors.yellow),
                      //         colorBuilder: const FixedColorBuilder(Colors.white),
                      //       ),
                      //       onCodeChanged: (value) {
                      //         otp = value.toString();
                      //       },
                      //       onCodeSubmitted: (code) async {
                      //         print(code);
                      //       },
                      //     ),
                      //   ),
                      // ),
                      Container(
                        margin: const EdgeInsets.all(10),
                        child: Form(
                          key: _formKey,
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                SizedBox(
                                  height: 60,
                                  width: 60,
                                  child: TextFormField(
                                    controller: _otp1,
                                    onChanged: ((value) {
                                      if (value.length == 1) {
                                        FocusScope.of(context).nextFocus();
                                      }
                                    }),
                                    decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: darkBlue, width: 2.0),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: themeColor, width: 1.0),
                                      ),
                                    ),
                                    // style: Theme.of(context).textTheme.headline6,
                                    keyboardType: TextInputType.number,
                                    textAlign: TextAlign.center,
                                    inputFormatters: [
                                      LengthLimitingTextInputFormatter(1),
                                      FilteringTextInputFormatter.digitsOnly
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 60,
                                  width: 60,
                                  child: TextFormField(
                                    controller: _otp2,

                                    onChanged: ((value) {
                                      if (value.length == 1) {
                                        FocusScope.of(context).nextFocus();
                                      }
                                    }),
                                    decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: darkBlue, width: 2.0),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: themeColor, width: 1.0),
                                      ),
                                    ),
                                    // style: Theme.of(context).textTheme.headline6,
                                    keyboardType: TextInputType.number,
                                    textAlign: TextAlign.center,
                                    inputFormatters: [
                                      LengthLimitingTextInputFormatter(1),
                                      FilteringTextInputFormatter.digitsOnly
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 60,
                                  width: 60,
                                  child: TextFormField(
                                    controller: _otp3,
                                    onChanged: ((value) {
                                      if (value.length == 1) {
                                        FocusScope.of(context).nextFocus();
                                      }
                                    }),
                                    decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: darkBlue, width: 2.0),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: themeColor, width: 1.0),
                                      ),
                                    ),
                                    // style: Theme.of(context).textTheme.headline6,
                                    keyboardType: TextInputType.number,
                                    textAlign: TextAlign.center,
                                    inputFormatters: [
                                      LengthLimitingTextInputFormatter(1),
                                      FilteringTextInputFormatter.digitsOnly
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 60,
                                  width: 60,
                                  child: TextFormField(
                                    controller: _otp4,
                                    onChanged: ((value) {
                                      if (value.length == 1) {
                                        FocusScope.of(context).nextFocus();
                                      }
                                    }),
                                    decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                          color: darkBlue,
                                          width: 2.0,
                                        ),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: const BorderSide(
                                            color: themeColor, width: 1.0),
                                      ),
                                    ),
                                    // style: Theme.of(context).textTheme.headline6,
                                    keyboardType: TextInputType.number,
                                    textAlign: TextAlign.center,
                                    inputFormatters: [
                                      LengthLimitingTextInputFormatter(1),
                                      FilteringTextInputFormatter.digitsOnly
                                    ],
                                  ),
                                )
                              ]),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 10, right: 10),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Countdown(
                                animation: StepTween(
                                  begin: levelClock,
                                  end: 0,
                                ).animate(_animationController!),
                              ),
                              GestureDetector(
                                onTap: () async {
                                  _animationController!.reset();
                                  _animationController!.forward();
                                },
                                child: Container(
                                  child: Row(
                                    children: [
                                      Text(
                                        "Resend >",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 14,
                                          color: const Color.fromRGBO(
                                              2, 44, 67, 1),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              )
                            ]),
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      GestureDetector(
                        onTap: () async {
                          String otpnumber =
                              '${_otp1.text}${_otp2.text}${_otp3.text}${_otp4.text}';

                          if (_formKey.currentState!.validate()) {
                            setState(() {
                              isloading = true;
                            });
                            Map<String, String> data = {
                              'phone': widget.mobile,
                              'otp': otpnumber
                            };
                            var response = await networkHandler.post(
                                'customer-verify_otp', data);

                            if (response.statusCode == 200) {
                              setState(() {
                                isloading = false;
                              });
                              Map jsonResponse = jsonDecode(response.body);
                              if (jsonResponse['status'] == true) {
                                Fluttertoast.showToast(
                                    msg: "OTP Verified Succesfully",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    timeInSecForIosWeb: 1,
                                    backgroundColor: themeColor,
                                    textColor: Colors.white,
                                    fontSize: 16.0);

                                getProfileDetailDesktop(widget.mobile);

                                // Navigator.push(
                                //     context,
                                //     MaterialPageRoute(
                                //         builder: (context) =>
                                //             const CustomerProfileScreen()));
                              } else {
                                Fluttertoast.showToast(
                                    msg: "Please enter correct OTP",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    timeInSecForIosWeb: 1,
                                    backgroundColor: themeColor,
                                    textColor: Colors.white,
                                    fontSize: 16.0);
                              }
                            }
                          }
                        },
                        child: Container(
                          margin: const EdgeInsets.only(left: 10, right: 10),
                          width: 247,
                          height: 56,
                          decoration: BoxDecoration(
                              color: Colors.yellow,
                              borderRadius: BorderRadius.circular(25),
                              border:
                                  Border.all(width: 2, color: Colors.yellow)),
                          child: Center(
                            child: isloading == false
                                ? Text(
                                    "CONFIRM",
                                    style: GoogleFonts.merriweather(
                                      fontSize: 17,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                : const CircularProgressIndicator(
                                    color: Colors.white,
                                  ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  Widget MobileOTPVarification() {
    return Padding(
        padding: EdgeInsets.only(
            left: 30,
            right: 30,
            top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 45,
                  width: 45,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/logo.png"))),
                ),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.close))
              ],
            ),
            const SizedBox(
              height: 5,
            ),
            Padding(
              padding: EdgeInsets.all(10),
              child: Container(
                // margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.transparent,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(
                        0.12,
                      ),
                      offset: const Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 8.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                    const BoxShadow(
                      color: Colors.white,
                      offset: Offset(0.0, 0.0),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ), //BoxShadow
                  ],
                ),
                child: Column(children: [
                  SizedBox(
                    height: 121,
                    child: Stack(
                      children: [
                        Container(
                          margin: const EdgeInsets.only(top: 45),
                          height: 76,
                          width: 76,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              width: 8,
                              color: const Color.fromRGBO(
                                240,
                                240,
                                240,
                                1,
                              ),
                            ),
                          ),
                          child: const Image(
                            image: AssetImage("assets/SVG/ic-contact-2x.png"),
                            fit: BoxFit.contain,
                          ),
                        ),
                        Positioned(
                            top: 37,
                            // left: 150,
                            right: 0,
                            child: Container(
                              height: 23,
                              width: 23,
                              decoration: const BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                    "assets/SVG/message-2x.png",
                                  ),
                                ),
                              ),
                            ))
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    child: Text(
                      "Enter 4 Digits code",
                      style: GoogleFonts.merriweather(
                        fontSize: 12,
                        color: const Color.fromRGBO(164, 164, 164, 1),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  // Container(
                  //   margin: EdgeInsets.all(10),
                  //   child: Center(
                  //     child: PinFieldAutoFill(
                  //       controller: _otp,
                  //       codeLength: 4,
                  //       autoFocus: true,
                  //       decoration: UnderlineDecoration(
                  //         lineHeight: 2,
                  //         lineStrokeCap: StrokeCap.square,
                  //         bgColorBuilder: PinListenColorBuilder(
                  //             Colors.green.shade200, Colors.yellow),
                  //         colorBuilder: const FixedColorBuilder(Colors.white),
                  //       ),
                  //       onCodeChanged: (value) {
                  //         otp = value.toString();
                  //       },
                  //       onCodeSubmitted: (code) async {
                  //         print(code);
                  //       },
                  //     ),
                  //   ),
                  // ),
                  Container(
                    margin: const EdgeInsets.all(10),
                    child: Form(
                      key: _formKey,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              height: 60,
                              width: 60,
                              child: TextFormField(
                                controller: _otp1,
                                onChanged: ((
                                  value,
                                ) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: darkBlue, width: 2.0),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: themeColor, width: 1.0),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 60,
                              width: 60,
                              child: TextFormField(
                                controller: _otp2,

                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: darkBlue, width: 2.0),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: themeColor, width: 1.0),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 60,
                              width: 60,
                              child: TextFormField(
                                controller: _otp3,
                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: darkBlue, width: 2.0),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: themeColor, width: 1.0),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 60,
                              width: 60,
                              child: TextFormField(
                                controller: _otp4,
                                onChanged: ((value) {
                                  if (value.length == 1) {
                                    FocusScope.of(context).nextFocus();
                                  }
                                }),
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                        color: darkBlue, width: 2.0),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: const BorderSide(
                                      color: themeColor,
                                      width: 1,
                                    ),
                                  ),
                                ),
                                // style: Theme.of(context).textTheme.headline6,
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(1),
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                              ),
                            )
                          ]),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 10, right: 10),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Countdown(
                            animation: StepTween(
                              begin:
                                  levelClock, // THIS IS A USER ENTERED NUMBER
                              end: 0,
                            ).animate(_animationController!),
                          ),
                          GestureDetector(
                            onTap: () async {
                              _animationController!.reset();
                              _animationController!.forward();
                            },
                            child: Row(
                              children: [
                                Text("Resend >",
                                    style: GoogleFonts.merriweather(
                                      fontSize: 12,
                                      color: const Color.fromRGBO(2, 44, 67, 1),
                                      fontWeight: FontWeight.bold,
                                    ))
                              ],
                            ),
                          )
                        ]),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  GestureDetector(
                    onTap: () async {
                      String otpnumber =
                          '${_otp1.text}${_otp2.text}${_otp3.text}${_otp4.text}';

                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          isloading = true;
                        });
                        Map<String, String> data = {
                          'phone': widget.mobile,
                          'otp': otpnumber
                        };
                        var response = await networkHandler.post(
                            'customer-verify_otp', data);

                        if (response.statusCode == 200) {
                          setState(() {
                            isloading = false;
                          });
                          Map jsonResponse = jsonDecode(response.body);
                          if (jsonResponse['status'] == true) {
                            Fluttertoast.showToast(
                                msg: "OTP Verified Succesfully",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                timeInSecForIosWeb: 1,
                                backgroundColor: themeColor,
                                textColor: Colors.white,
                                fontSize: 16.0);

                            getProfileDetails(widget.mobile);

                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) =>
                            //             const CustomerProfileScreen()));
                          } else {
                            Fluttertoast.showToast(
                                msg: "Please enter correct OTP",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                timeInSecForIosWeb: 1,
                                backgroundColor: themeColor,
                                textColor: Colors.white,
                                fontSize: 16.0);
                          }
                        }
                      }
                    },
                    child: Container(
                      margin: const EdgeInsets.only(left: 10, right: 10),
                      width: 247,
                      height: 36,
                      decoration: BoxDecoration(
                          color: Colors.yellow,
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(width: 2, color: Colors.yellow)),
                      child: Center(
                        child: isloading == false
                            ? Text(
                                "CONFIRM",
                                style: GoogleFonts.merriweather(
                                  fontSize: 17,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            : const CircularProgressIndicator(
                                color: Colors.white,
                              ),
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 10,
                  ),
                ]),
              ),
            ),
          ],
        ));
  }

  List<CustomerP> _customerList = [];
  var customerService = CustomerProfileService();
  Future<void> getProfileDetailDesktop(String phone) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await customerService.viewCustomerProfile(phone);
    print(response);
    if (response != null) {
      _customerList = response;
      SharedPreferences pref = await SharedPreferences.getInstance();
      pref.setBool("islogin", true);
      pref.setString("phone", _customerList[0].phone!);
      pref.setString("uid", _customerList[0].id.toString());
      if (_customerList[0].name != null) {
        Navigator.pop(context);

        // showModalBottomSheet(
        //   isDismissible: false,
        //   isScrollControlled: true,
        //   shape: RoundedRectangleBorder(
        //       borderRadius: BorderRadius.circular(10)),
        //   context: context,
        //   builder: (BuildContext context) {
        //     return OTPAlertVarification(
        //       mobile: _mobile.text,
        //     );
        //   },
        // );
      } else {
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return CustomerProfileModal();
          },
        );
      }
    } else {
      throw Exception("Failed to load data");
    }
  }

  Future<void> getProfileDetails(String phone) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await customerService.viewCustomerProfile(phone);
    print(response);
    if (response != null) {
      _customerList = response;
      SharedPreferences pref = await SharedPreferences.getInstance();
      pref.setBool("islogin", true);
      pref.setString("phone", _customerList[0].phone!);
      pref.setString("uid", _customerList[0].id.toString());
      if (_customerList[0].name != null) {
        Navigator.pop(context);

        // showModalBottomSheet(
        //   isDismissible: false,
        //   isScrollControlled: true,
        //   shape: RoundedRectangleBorder(
        //       borderRadius: BorderRadius.circular(10)),
        //   context: context,
        //   builder: (BuildContext context) {
        //     return OTPAlertVarification(
        //       mobile: _mobile.text,
        //     );
        //   },
        // );
      } else {
        Navigator.pop(context);
        showModalBottomSheet(
          isDismissible: false,
          isScrollControlled: true,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          context: context,
          builder: (BuildContext context) {
            return CustomerProfileModal();
          },
        );
      }
    } else {
      throw Exception("Failed to load data");
    }
  }
}

class Countdown extends AnimatedWidget {
  Countdown({Key? key, required this.animation})
      : super(key: key, listenable: animation);
  Animation<int> animation;

  @override
  build(BuildContext context) {
    String value = '';
    Duration clockTimer = Duration(seconds: animation.value);
    print(animation.value);

    String timerText =
        '${clockTimer.inMinutes.remainder(60).toString()}:${clockTimer.inSeconds.remainder(60).toString().padLeft(2, '0')}';
    return Text(timerText,
        style: GoogleFonts.merriweather(
          fontSize: 14,
          color: const Color.fromRGBO(2, 44, 67, 1),
          fontWeight: FontWeight.bold,
        ));
  }
}
