import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/PaymentLogService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerWalletModel.dart';
import 'package:naksaa_services/model/PaymentLogs.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Service/WalletService.dart';
import '../../Home/BottomNavigation.dart';
import '../../Home/Utility/rechargeNowUtility.dart';

class WalletSection extends StatefulWidget {
  const WalletSection({super.key});

  @override
  State<WalletSection> createState() => _WalletSectionState();
}

class _WalletSectionState extends State<WalletSection> {
  List<Walletdatum> _walletList = [];
  List<Paymentlog> _paymentLog = [];
  bool isloading = false;
  bool ploading = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getWalletAmount();
    getPaymentLogs();
  }

  var walletService = CustomerWalletService();
  Future<void> getWalletAmount() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    print(uid);
    var response = await walletService.viewCustomerWallet(uid!);
    if (response != null) {
      setState(() {
        isloading = true;
      });
      _walletList = response;
    }
  }

  var paymentLogService = CustomerPaymentLogService();
  Future<void> getPaymentLogs() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    print(uid);
    print("ryamansri");
    var response = await paymentLogService.viewCustomerPaymentLog(uid!);
    if (response != null) {
      setState(() {
        ploading = true;
      });
      _paymentLog = response;
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopWallet();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopWallet();
      } else {
        return MobileWallet();
      }
    });
  }

  Widget DesktopWallet() {
    
    var screenSize = MediaQuery.of(context).size;
    return Container(
      margin:  EdgeInsets.all(screenSize.width/96),
      child: Column(children: [
        Container(
          height:  screenSize.height/8.00,
          padding:  EdgeInsets.only(left: screenSize.width/64, right: screenSize.width/64),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(screenSize.width/54.85), color: blueColor),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            isloading != false
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                       Text(
                        "Available Balance",
                        style:  GoogleFonts.merriweather(
                            color: Colors.white,
                            fontSize: screenSize.width/160,
                            fontWeight: FontWeight.bold),
                      ),
                       SizedBox(
                        height:  screenSize.height/96.1,
                      ),
                      Text(
                        "₹ ${_walletList.length >= 1 ? _walletList[0].walletamount : "0"}",
                        style:   GoogleFonts.merriweather(
                            color: Colors.white,
                            fontSize: screenSize.width/60,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      CircularProgressIndicator(
                        color: themeColor,
                      )
                    ],
                  ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                 Text(
                  "Add More",
                  style:  GoogleFonts.merriweather(
                      color: Colors.white,
                      fontSize: screenSize.width/160,
                      fontWeight: FontWeight.bold),
                ),
                 SizedBox(
                  height:  screenSize.height/43.68,
                ),
                GestureDetector(
                  onTap: () {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding:  EdgeInsets.only(
                              left: screenSize.width/96, right: screenSize.width/36, top:  screenSize.height/192.2, bottom:  screenSize.height/192.2),
                          titlePadding:  EdgeInsets.only(
                              left: screenSize.width/96, right: screenSize.width/36, top:  screenSize.height/192.2, bottom:  screenSize.height/192.2),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                               Text('Recharge Plan',style:  GoogleFonts.merriweather(),),
                              IconButton(
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )
                            ],
                          ),
                          content: const RechargeNow(),
                        );
                      },
                    );
                  },
                  child: Container(
                    height:  screenSize.height/38.44,
                    width: screenSize.width/24.93,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/320),
                        color: themeColor),
                    child:  Center(
                      child: Text(
                        "Recharge",
                        style: TextStyle(
                            color: darkBlue,
                            fontSize: screenSize.width/160,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                )
              ],
            )
          ]),
        ),
         SizedBox(
          height:  screenSize.height/96.1,
        ),
        ploading != false
            ? Container(
                height:  screenSize.height/2.40,
                width: MediaQuery.of(context).size.width,
                child: GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio: 3.6,
                            crossAxisSpacing: 15.0,
                            mainAxisSpacing: 15.0),
                    itemCount: _paymentLog.length,
                    shrinkWrap: false,
                    itemBuilder: ((context, index) {
                      return Container(
                        margin:  EdgeInsets.only(top:  screenSize.height/160.1, bottom:  screenSize.height/160.1),
                        padding:  EdgeInsets.all(screenSize.width/192),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(screenSize.width/192)),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                   Text(
                                    "Recharge",
                                    style:  GoogleFonts.merriweather(
                                        fontSize: screenSize.width/137.1,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    "₹ ${_paymentLog[index].toString()}",
                                    style:   GoogleFonts.merriweather(
                                        fontSize: screenSize.width/137.1,
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold),
                                  )
                                ],
                              ),
                               SizedBox(
                                height:  screenSize.height/96.1,
                              ),
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      _paymentLog[index].createdAt.toString(),
                                      style:   GoogleFonts.merriweather(
                                          fontSize: screenSize.width/137.1,
                                          color: textColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "GST : ₹ ${_paymentLog[index].gst ?? 0}",
                                      style:   GoogleFonts.merriweather(
                                          fontSize: screenSize.width/137.1,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ]),
                               SizedBox(
                                height:  screenSize.height/96.1,
                              ),
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "#Naksa${_paymentLog[index].id.toString()}",
                                      style:   GoogleFonts.merriweather(
                                          fontSize: screenSize.width/137.1,
                                          color: textColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      _paymentLog[index].status.toString(),
                                      style:  GoogleFonts.merriweather(
                                          fontSize: screenSize.width/137.1,
                                          color: _paymentLog[index].status ==
                                                  'pending'
                                              ? darkBlue
                                              : _paymentLog[index].status ==
                                                      'success'
                                                  ? Colors.green
                                                  : Colors.red,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ])
                            ]),
                      );
                    })),
              )
            : const SizedBox(
                height: 200,
                child: LoadingIndicator(),
              )
      ]),
    );
  }

  Widget MobileWallet() {
    
    var screenSize = MediaQuery.of(context).size;
    return Container(
      margin:  EdgeInsets.all(screenSize.width/18),
      child: Column(children: [
        Container(
          height: screenSize.height/6.3,
          padding:  EdgeInsets.only(left: screenSize.width/12, right: screenSize.width/12),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(screenSize.width/10.28), color: blueColor),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            isloading != false
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                       Text(
                        "Available Balance",
                        style: GoogleFonts.merriweather(
                            color: Colors.white,
                            fontSize: screenSize.width/30,
                            fontWeight: FontWeight.bold),
                      ),
                       SizedBox(
                        height: screenSize.height/75.6,
                      ),
                      Text(
                        "₹ ${_walletList.length >= 1 ? _walletList[0].walletamount : "0"}",
                        style:  GoogleFonts.merriweather(
                            color: Colors.white,
                            fontSize: screenSize.width/11.25,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      CircularProgressIndicator(
                        color: themeColor,
                      )
                    ],
                  ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                 Text(
                  "Add More",
                  style:  GoogleFonts.merriweather(
                      color: Colors.white,
                      fontSize: screenSize.width/30,
                      fontWeight: FontWeight.bold),
                ),
                 SizedBox(
                  height: screenSize.height/34.3,
                ),
                GestureDetector(
                  onTap: () {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding:  EdgeInsets.only(
                            left: screenSize.width/18,
                            right: screenSize.width/36,
                            top: screenSize.height/151.2,
                            bottom:  screenSize.height/151.2,
                          ),
                          titlePadding:  EdgeInsets.only(
                             left: screenSize.width/18,
                            right: screenSize.width/36,
                            top: screenSize.height/151.2,
                            bottom:  screenSize.height/151.2,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              screenSize.width/24,
                            ),
                          ),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                               Text('Recharge Plan',style:  GoogleFonts.merriweather(),),
                              IconButton(
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )
                            ],
                          ),
                          content: const RechargeNow(),
                        );
                      },
                    );
                  },
                  child: Container(
                    height:  screenSize.height/30.24,
                    width: screenSize.width/4.67,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/60),
                        color: themeColor),
                    child:  Center(
                      child: Text(
                        "Recharge",
                        style:  GoogleFonts.merriweather(
                            color: darkBlue,
                            fontSize: screenSize.width/30,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                )
              ],
            )
          ]),
        ),
         SizedBox(
          height:  screenSize.height/75.6,
        ),
        ploading != false
            ? _paymentLog.isNotEmpty
                ? SizedBox(
                    height:  screenSize.height/3.21,
                    child: ListView.builder(
                        itemCount: _paymentLog.length,
                        shrinkWrap: true,
                        itemBuilder: ((context, index) {
                          return Container(
                            margin:  EdgeInsets.only(top:  screenSize.height/126, bottom:  screenSize.height/126),
                            padding:  EdgeInsets.all(screenSize.width/36),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(screenSize.width/36)),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                       Text(
                                        "Recharge",
                                        style:  GoogleFonts.merriweather(
                                            fontSize: screenSize.width/25.71,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        "₹ ${_paymentLog[index].amount ?? ""}",
                                        style:   GoogleFonts.merriweather(
                                            fontSize: screenSize.width/25.71,
                                            color: Colors.green,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                   SizedBox(
                                    height:  screenSize.height/75.6,
                                  ),
                                  Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "${_paymentLog[index].createdAt ?? ""}",
                                          style:   GoogleFonts.merriweather(
                                              fontSize: screenSize.width/25.71,
                                              color: textColor,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          "GST : ₹ ${_paymentLog[index].gst ?? 0}",
                                          style:   GoogleFonts.merriweather(
                                              fontSize: screenSize.width/25.71,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ]),
                                   SizedBox(
                                    height:  screenSize.height/75.6,
                                  ),
                                  Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "#Naksa${_paymentLog[index].id ?? ""}",
                                          style:   GoogleFonts.merriweather(
                                              fontSize: screenSize.width/25.71,
                                              color: textColor,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          _paymentLog[index].status ??
                                              'not known',
                                          style:  GoogleFonts.merriweather(
                                              fontSize: screenSize.width/25.71,
                                              color: _paymentLog[index]
                                                          .status ==
                                                      'pending'
                                                  ? darkBlue
                                                  : _paymentLog[index].status ==
                                                          'success'
                                                      ? Colors.green
                                                      : Colors.red,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ])
                                ]),
                          );
                        })),
                  )
                : Container(
                    margin:  EdgeInsets.all(screenSize.width/18),
                    child: Center(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                         Text(
                          "Oops!",
                          style:  GoogleFonts.merriweather(
                              fontSize: screenSize.width/14.4,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        ),
                         SizedBox(
                          height:  screenSize.height/50.4,
                        ),
                         Text(
                          "You've not taken any call consultations yet!",
                          style:  GoogleFonts.merriweather(
                              fontSize: screenSize.width/25.71,
                              color: textColor,
                              fontWeight: FontWeight.bold),
                        ),
                         SizedBox(
                          height:  screenSize.height/50.4,
                        ),
                        SizedBox(
                          height:  screenSize.height/12.6,
                          width: screenSize.width/7.2,
                          child: SvgPicture.asset("assets/SVG/phone3.svg"),
                        ),
                         SizedBox(
                          height:  screenSize.height/18.9,
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        BottomNavigationBarScreen(
                                          pageIndex: 3,
                                        )));
                          },
                          child: Container(
                            height:  screenSize.height/15.12,
                            width: screenSize.width/2.46,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(screenSize.width/14.4),
                                color: themeColor),
                            child:  Center(
                                child: Text(
                              "Search Now",
                              style:  GoogleFonts.merriweather(fontWeight: FontWeight.bold),
                            )),
                          ),
                        )
                      ],
                    )),
                  )
            :  SizedBox(
                height:  screenSize.height/3.78,
                child: LoadingIndicator(),
              )
      ]),
    );
  }
}
