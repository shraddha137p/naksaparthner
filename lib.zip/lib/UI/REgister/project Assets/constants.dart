//color

import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';

const textColor = Color.fromRGBO(112, 112, 112, 1);
const themeColor = Color.fromRGBO(255, 215, 0, 1);
const blueColor = Color.fromRGBO(17, 81, 115, 1);
const lightblueColor = Color.fromRGBO(0, 199, 250, 1);
const ornageColor = Color.fromRGBO(246, 87, 15, 1);
const darkBlue = Color.fromRGBO(2, 44, 67, 1);
const backgroundColor = Color.fromRGBO(242, 244, 243, 1);
Color active = const Color(0xFFED9B59);
Color disable = const Color(0xFF7D8790);
Color bgColor = Color.fromRGBO(242, 244, 243, 1);
