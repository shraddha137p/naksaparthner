import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/CompleteProfileScreen.dart';
import 'package:naksaa_services/UI/Home/Notification.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Home/Profile.dart';
import '../../Home/SearchScreen.dart';
import 'LoginModel.dart';

class AppBarScreen extends StatefulWidget {
  const AppBarScreen({super.key});

  @override
  State<AppBarScreen> createState() => _AppBarScreenState();
}

class _AppBarScreenState extends State<AppBarScreen> {
  @override
  Widget build(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    Color themeColor = const Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = const Color.fromRGBO(56, 56, 56, 1);

    if (kIsWeb) {
      return Container(
        // padding: EdgeInsets.only(left: 40, right: 40),
        decoration: BoxDecoration(
          color: themeColor,
          borderRadius:  BorderRadius.only(
              bottomLeft: Radius.circular(screenSize.width/12),
              bottomRight: Radius.circular(screenSize.width/12)),
        ),
        child: Column(children: [
          Container(
            height: screenSize.height/17,
            margin:  EdgeInsets.only(top: screenSize.height/50),
            child: Container(
              padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/36),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            child: Container(
                              child: Icon(
                                Icons.menu,
                                color: secondColor,
                                size: screenSize.width/14.4,
                              ),
                            ),
                          ),
                           SizedBox(
                            width: screenSize.width/30,
                          ),
                          SizedBox(
                              height: screenSize.height/21.6,
                              child: Image.asset("assets/naksa_logo.png")),
                           SizedBox(
                            width: screenSize.width/3.27,
                          ),
                        ]),
                  ),
                  Container(
                    child: Row(children: [
                      Padding(
                          padding:  EdgeInsets.only(right: screenSize.width/18),
                          child: GestureDetector(
                            onTap: () async {
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                              if (pref.getString('uid') != null) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const CustomerProfileScreen()));
                              } else {
                                showModalBottomSheet(
                                  isDismissible: false,
                                  context: context,
                                  isScrollControlled: true,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/36)),
                                  builder: (BuildContext context) {
                                    return const LoginModel();
                                  },
                                );
                              }
                            },
                            child: Icon(
                              color: secondColor,
                              Icons.person,
                              size:screenSize.width/13.8,
                            ),
                          )),
                      Padding(
                          padding:  EdgeInsets.only(right: screenSize.width/18),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const NaksaNotifictaion()));
                            },
                            child: Icon(
                              color: secondColor,
                              Icons.notifications,
                              size: screenSize.width/13.84
                            ),
                          )),
                    ]),
                  )
                ],
              ),
            ),
          ),
           SizedBox(
            height: screenSize.height/42,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const SearchScreen()));
            },
            child: Container(
              margin:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/18),
              padding:  EdgeInsets.only(left: screenSize.width/45, right: screenSize.width/45),
              height: screenSize.height/16.8,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(screenSize.width/36), color: Colors.white),
              child: Row(children:  [
                Icon(
                  Icons.search,
                  color: Color.fromRGBO(183, 190, 198, 1),
                  size: screenSize.width/12,
                ),
                SizedBox(
                  width: screenSize.width/24,
                ),
                Text(
                  "Search Service",
                  style: TextStyle(
                    fontSize: screenSize.width/25.71,
                    color: Color.fromRGBO(183, 190, 198, 1),
                  ),
                )
              ]),
            ),
          ),
         
        ]),
      );
    }
    if (Platform.isAndroid || Platform.isIOS) {
      return Container(
        // padding: EdgeInsets.only(left: 40, right: 40),
        decoration: BoxDecoration(
          color: themeColor,
          borderRadius:  BorderRadius.only(
              bottomLeft: Radius.circular(screenSize.width/12),
              bottomRight: Radius.circular(screenSize.width/12)),
        ),
        child: Column(children: [
          Container(
            height: screenSize.height/17.5,
            margin:  EdgeInsets.only(top: screenSize.height/17.1),
            child: Container(
              padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/36),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            child: Container(
                              child: Icon(
                                Icons.menu,
                                color: secondColor,
                                size: screenSize.width/14.4,
                              ),
                            ),
                          ),
                           SizedBox(
                            width: screenSize.width/30,
                          ),
                          SizedBox(
                              height: screenSize.height/21.6,
                              child: Image.asset("assets/logo.png")),
                           SizedBox(
                            width: screenSize.width/3.27,
                          ),
                        ]),
                  ),
                  Container(
                    child: Row(children: [
                      Padding(
                          padding:  EdgeInsets.only(right: screenSize.width/18),
                          child: GestureDetector(
                            onTap: () async {
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                              if (pref.getString('uid') != null) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const CustomerProfile()));
                              } else {
                                showModalBottomSheet(
                                  isDismissible: false,
                                  context: context,
                                  isScrollControlled: true,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width/36)),
                                  builder: (BuildContext context) {
                                    return const LoginModel();
                                  },
                                );
                              }
                            },
                            child: Icon(
                              color: secondColor,
                              Icons.person,
                              size: screenSize.width/13.8,
                            ),
                          )),
                      Padding(
                          padding:  EdgeInsets.only(right: screenSize.width/18),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const NaksaNotifictaion()));
                            },
                            child: Icon(
                              color: secondColor,
                              Icons.notifications,
                              size: screenSize.width/13.8,
                            ),
                          )),
                    ]),
                  )
                ],
              ),
            ),
          ),
           SizedBox(
            height: screenSize.height/42,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const SearchScreen()));
            },
            child: Container(
              margin:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/18),
              padding:  EdgeInsets.only(left: screenSize.width/45, right: screenSize.width/45),
              height: screenSize.height/16.8,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(screenSize.width/36), color: Colors.white),
              child: Row(children:  [
                Icon(
                  Icons.search,
                  color: Color.fromRGBO(183, 190, 198, 1),
                  size: screenSize.width/12,
                ),
                SizedBox(
                  width: screenSize.width/24,
                ),
                Text(
                  "Search Service",
                  style: TextStyle(
                    fontSize: screenSize.width/25.7,
                    color: Color.fromRGBO(183, 190, 198, 1),
                  ),
                )
              ]),
            ),
          ),
         
        ]),
      );
    }
    return Container();
  }
}
