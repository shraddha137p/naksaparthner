import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/CustomerOrderService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerOrderModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Home/BottomNavigation.dart';

class CustomerOrderScreenForChat extends StatefulWidget {
  const CustomerOrderScreenForChat({super.key});

  @override
  State<CustomerOrderScreenForChat> createState() =>
      _CustomerOrderScreenForChatState();
}

class _CustomerOrderScreenForChatState
    extends State<CustomerOrderScreenForChat> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getorder();
    // allVendor = vendorService.viewallVendor();
  }

  List<CustomerOrderdata> _orderdata = [];
  var customerOrderService = CustomerOrderService();
  Future<List<CustomerOrderdata>> getorder() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await customerOrderService.viewCustomerOrder(uid!);
    _orderdata = response;
    return _orderdata;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopCustomerOrderScreenChat();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopCustomerOrderScreenChat();
      } else {
        return MobileCustomerOrderScreenChat();
      }
    });
  }

  Widget DesktopCustomerOrderScreenChat() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      padding:  EdgeInsets.only(left: screenSize.width/27.42, right: screenSize.width/27.42),
      child: Column(children: [
        Expanded(
          child: FutureBuilder(
            future: getorder(),
            builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                    .hasData
                ? item.data!.isNotEmpty
                    ? GridView.builder(
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                childAspectRatio: 1.9,
                                crossAxisSpacing: 15.0,
                                mainAxisSpacing: 15.0),
                        itemCount: item.data!.length,
                        // physics: AlwaysScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemBuilder: ((context, index) {
                          return _orderdata[index].orderfor == "chat"
                              ? Container(
                                  margin:  EdgeInsets.only(
                                      top:  screenSize.height/96.1, bottom:  screenSize.height/96.1),
                                  padding:  EdgeInsets.all(screenSize.width/192),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(screenSize.width/192)),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Text(
                                              "#Naksa${_orderdata[index].orderid}",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/160,
                                                  color: textColor,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/96.1,
                                            ),
                                            Text(
                                              _orderdata[index].name,
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/137.1,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/192.2,
                                            ),
                                            Text(
                                              "${_orderdata[index].createdat}",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/160,
                                                  color: textColor,
                                                  fontWeight:
                                                      FontWeight.normal),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/96.1,
                                            ),
                                            Text(
                                              _orderdata[index].orderstatus,
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/137.1,
                                                  color: Colors.green,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/96.1,
                                            ),
                                            Text(
                                              "Order For : ${_orderdata[index].orderfor}",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/160,
                                                  color: textColor,
                                                  fontWeight:
                                                      FontWeight.normal),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/192.2,
                                            ),
                                            Text(
                                              "Rate: ₹ ${_orderdata[index].audicallprice}/mins",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/120,
                                                  color: textColor,
                                                  fontWeight:
                                                      FontWeight.normal),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/192.2,
                                            ),
                                            Text(
                                              "Duration: ${_orderdata[index].completecalltime} minutes",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/160,
                                                  color: textColor,
                                                  fontWeight:
                                                      FontWeight.normal),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/192.2,
                                            ),
                                            Text(
                                              "Deduction: ₹ ${_orderdata[index].callingamount}",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/160,
                                                  color: textColor,
                                                  fontWeight:
                                                      FontWeight.normal),
                                            ),
                                          ]),
                                      Container(
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              height:  screenSize.height/14.7,
                                              width: screenSize.width/26.30,
                                              child: Stack(children: [
                                                Container(
                                                  height:  screenSize.height/14.7,
                                                  width: screenSize.width/29.53,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      // color: Colors.red,
                                                      border: Border.all(
                                                          width: screenSize.width/960,
                                                          color:
                                                              lightblueColor),
                                                      image: DecorationImage(
                                                          image: NetworkImage(
                                                              "${MainUrl}vendor-image/${_orderdata[index].photo}"))),
                                                ),
                                                Positioned(
                                                    top: 6,
                                                    right: 0,
                                                    child: Container(
                                                      height:  screenSize.height/38.44,
                                                      width: screenSize.width/76.8,
                                                      decoration: const BoxDecoration(
                                                          image: DecorationImage(
                                                              image: AssetImage(
                                                                  "assets/SVG/star2-2x.png"),
                                                              fit:
                                                                  BoxFit.fill)),
                                                    )),
                                              ]),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/96.1,
                                            ),
                                            Container(
                                              height:  screenSize.height/43.68,
                                              width: screenSize.width/30.96,
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(screenSize.width/192),
                                                  color: themeColor),
                                              child: Center(
                                                  child: Text(
                                                _orderdata[index].orderfor,
                                                style:   GoogleFonts.merriweather(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: screenSize.width/160,
                                                    color: blueColor),
                                              )),
                                            ),
                                             SizedBox(
                                              height:  screenSize.height/160.1,
                                            ),
                                            Text(
                                              "Wait time - ${_orderdata[index].waittime} m",
                                              style:   GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/160,
                                                  color: textColor,
                                                  fontWeight:
                                                      FontWeight.normal),
                                            )
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Container();
                        }))
                    : Container(
                        margin:  EdgeInsets.all(screenSize.width/96),
                        child: Center(
                            child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                             Text(
                              "Oops!",
                              style:  GoogleFonts.merriweather(
                                  fontSize: screenSize.width/76.8,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            ),
                             SizedBox(
                              height:  screenSize.height/64.06,
                            ),
                             Text(
                              "You've not taken any call consultations yet!",
                              style:  GoogleFonts.merriweather(
                                  fontSize: screenSize.width/137.1,
                                  color: textColor,
                                  fontWeight: FontWeight.bold),
                            ),
                             SizedBox(
                              height:  screenSize.height/64.06,
                            ),
                            SizedBox(
                              height:  screenSize.height/16.01,
                              width: screenSize.width/7.2,
                              child: SvgPicture.asset("assets/SVG/phone3.svg"),
                            ),
                             SizedBox(
                              height:  screenSize.height/24.02,
                            ),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            BottomNavigationBarScreen(
                                              pageIndex: 1,
                                            )));
                              },
                              child: Container(
                                height:  screenSize.height/19.22,
                                width: screenSize.width/2.46,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(screenSize.width/14.4),
                                    color: themeColor),
                                child:  Center(
                                    child: Text(
                                  "Search Now",
                                  style:  GoogleFonts.merriweather(fontWeight: FontWeight.bold),
                                )),
                              ),
                            )
                          ],
                        )),
                      )
                : const LoadingIndicator(),
          ),
        )
      ]),
    );
  }

  Widget MobileCustomerOrderScreenChat() {
    
    var screenSize = MediaQuery.of(context).size;
    return Container(
      margin:  EdgeInsets.all(screenSize.width/18),
      child: Column(
        children: [
          Expanded(
            child: FutureBuilder(
                future: getorder(),
                builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                        .hasData
                    ? item.data!.isNotEmpty
                        ? ListView.builder(
                            itemCount: item.data!.length,
                            // physics: AlwaysScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemBuilder: ((context, index) {
                              return _orderdata[index].orderfor == "chat"
                                  ? Container(
                                      margin:  EdgeInsets.only(
                                          top:  screenSize.height/75.6, bottom:  screenSize.height/75.6),
                                      padding:  EdgeInsets.all(screenSize.width/18),
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(screenSize.width/36)),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "#Naksa${_orderdata[index].orderid ?? ""}",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/75.6,
                                                ),
                                                Text(
                                                  _orderdata[index].name,
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/25.71,
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/151.2,
                                                ),
                                                Text(
                                                  "${_orderdata[index].createdat ?? ""}",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/75.6,
                                                ),
                                                Text(
                                                  _orderdata[index]
                                                          .orderstatus ??
                                                      "",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/25.71,
                                                      color: Colors.green,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/75.6,
                                                ),
                                                Text(
                                                  "Order For : ${_orderdata[index].orderfor ?? ""}",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/151.2,
                                                ),
                                                Text(
                                                  "Rate: ₹ ${_orderdata[index].audicallprice ?? ""}/mins",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/151.2,
                                                ),
                                                Text(
                                                  "Duration: ${_orderdata[index].completecalltime ?? ""} minutes",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/151.2,
                                                ),
                                                Text(
                                                  "Deduction: ₹ ${_orderdata[index].callingamount ?? ""}",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                ),
                                              ]),
                                          Container(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                SizedBox(
                                                  height:  screenSize.height/11.6,
                                                  width: screenSize.width/4.9,
                                                  child: Stack(children: [
                                                    Container(
                                                      height:  screenSize.height/11.6,
                                                      width: screenSize.width/4.9,
                                                      decoration: BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          // color: Colors.red,
                                                          border: Border.all(
                                                              width: screenSize.width/180,
                                                              color:
                                                                  lightblueColor),
                                                          image: DecorationImage(
                                                              image: NetworkImage(
                                                                  "${MainUrl}vendor-image/${_orderdata[index].photo}"))),
                                                    ),
                                                    Positioned(
                                                        top: 6,
                                                        right: 0,
                                                        child: Container(
                                                          height:  screenSize.height/30.24,
                                                          width: screenSize.width/14.4,
                                                          decoration: const BoxDecoration(
                                                              image: DecorationImage(
                                                                  image: AssetImage(
                                                                      "assets/SVG/star2-2x.png"),
                                                                  fit: BoxFit
                                                                      .fill)),
                                                        )),
                                                  ]),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/75.6,
                                                ),
                                                Container(
                                                  height:  screenSize.height/34.3,
                                                  width: screenSize.width/5.80,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width/36),
                                                      color: themeColor),
                                                  child: Center(
                                                      child: Text(
                                                    _orderdata[index]
                                                            .orderfor ??
                                                        "",
                                                    style:   GoogleFonts.merriweather(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: screenSize.width/30,
                                                        color: blueColor),
                                                  )),
                                                ),
                                                 SizedBox(
                                                  height:  screenSize.height/126,
                                                ),
                                                Text(
                                                  "Wait time - ${_orderdata[index].waittime ?? ""} m",
                                                  style:   GoogleFonts.merriweather(
                                                      fontSize: screenSize.width/30,
                                                      color: textColor,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                )
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    )
                                  : Container();
                            }))
                        : Container(
                            margin:  EdgeInsets.all(screenSize.width/18),
                            child: Center(
                                child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                 Text(
                                  "Oops!",
                                  style:  GoogleFonts.merriweather(
                                      fontSize: screenSize.width/14.4,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                                 SizedBox(
                                  height:  screenSize.height/50.4,
                                ),
                                 Text(
                                  "You've not taken any call consultations yet!",
                                  style:  GoogleFonts.merriweather(
                                      fontSize: screenSize.width/25.71,
                                      color: textColor,
                                      fontWeight: FontWeight.bold),
                                ),
                                 SizedBox(
                                  height:  screenSize.height/50.4,
                                ),
                                SizedBox(
                                  height:  screenSize.height/12.6,
                                  width: screenSize.width/7.2,
                                  child:
                                      SvgPicture.asset("assets/SVG/phone3.svg"),
                                ),
                                 SizedBox(
                                  height:  screenSize.height/18.9,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                BottomNavigationBarScreen(
                                                  pageIndex: 1,
                                                )));
                                  },
                                  child: Container(
                                    height:  screenSize.height/15.12,
                                    width: screenSize.width/2.46,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(screenSize.width/14.4),
                                        color: themeColor),
                                    child:  Center(
                                        child: Text(
                                      "Search Now",
                                      style:  GoogleFonts.merriweather(
                                          fontWeight: FontWeight.bold),
                                    )),
                                  ),
                                )
                              ],
                            )),
                          )
                    : const LoadingIndicator()
                      
                      ),
          )
        ],
      ),
    );
  }
}
