import 'package:flutter/material.dart';

class MainSideBar extends StatelessWidget {
  const MainSideBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      height: 700,
      color: Colors.red,
    );
  }
}
