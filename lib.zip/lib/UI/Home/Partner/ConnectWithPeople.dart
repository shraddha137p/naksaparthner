import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfile.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../../Service/AllVendorService.dart';
import '../../../model/AllVendorModel.dart';

class ConnectWithPeople extends StatefulWidget {
  const ConnectWithPeople({super.key});

  @override
  State<ConnectWithPeople> createState() => _ConnectWithPeopleState();
}

class _ConnectWithPeopleState extends State<ConnectWithPeople> {
  List<Datum> results = [];
  var vendorService = AllVendorService();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    // allVendor = vendorService.viewallVendor();
  }

  Future<List<Datum>> getdata() async {
    results = (await vendorService.viewallVendor("stype", "sname"))!;
    if (results != null) {
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopConnectWithPeople();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopConnectWithPeople();
      } else {
        return MobileConnectWithPeople();
      }
    });
  }

  Widget MobileConnectWithPeople() {
    var screenSize = MediaQuery.of(context).size;
    return RefreshIndicator(
      onRefresh: () {
        return getdata();
      },
      child: SizedBox(
          height: screenSize.height / 5.6,
          child: FutureBuilder(
            future: getdata(),
            builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                    .hasData
                ? item.data!.isNotEmpty
                    ? ListView.builder(
                        itemCount: results.length >= 10 ? 10 : results.length,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: ((context, index) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => VendorProfileScreen(
                                          vid: results[index].id.toString())));
                            },
                            child: Container(
                              height: screenSize.height / 5.6,
                              width: screenSize.width / 4,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: const Color.fromRGBO(2, 44, 67, 1),
                              ),
                              margin: const EdgeInsets.only(right: 10),
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: screenSize.height / 12.6,
                                      width: screenSize.width / 6,
                                      decoration: BoxDecoration(
                                        color: Color.fromRGBO(2, 44, 67, 1),
                                        border: Border.all(
                                            width: screenSize.width / 180,
                                            color: const Color.fromRGBO(
                                                255, 215, 0, 1)),
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              '${MainUrl}vendor-image/${results[index].photo}'),
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: screenSize.height / 94.5,
                                    ),
                                    Container(
                                      child: Text(
                                        results[index].name,
                                        style: TextStyle(
                                            fontSize: screenSize.width / 45,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ),
                                    SizedBox(
                                      height: screenSize.height / 94.5,
                                    ),
                                    Container(
                                      child: Text(
                                        "₹ ${results[index].audicallprice} /min",
                                        style: TextStyle(
                                            fontSize: screenSize.width / 45,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ),
                                    SizedBox(
                                      height: screenSize.height / 94.5,
                                    ),
                                    Container(
                                      height: screenSize.height / 44.4,
                                      width: screenSize.width / 7.65,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                              screenSize.width / 36),
                                          border: Border.all(
                                              width: screenSize.width / 360,
                                              color: Colors.white)),
                                      child: Center(
                                        child: Text(
                                          "Connect",
                                          style: TextStyle(
                                              fontSize: screenSize.width / 45,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white),
                                        ),
                                      ),
                                    )
                                  ]),
                            ),
                          );
                        }))
                    : const Center(
                        child: Text("No Data Found"),
                      )
                : const Center(
                    child: CircularProgressIndicator(),
                  ),
          )),
    );
  }

  Widget DesktopConnectWithPeople() {
    var screenSize = MediaQuery.of(context).size;
    return RefreshIndicator(
      onRefresh: () {
        return getdata();
      },
      child: SizedBox(
          height: screenSize.height / 3.84,
          child: FutureBuilder(
            future: getdata(),
            builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                item.hasData
                    ? item.data!.isNotEmpty
                        ? ListView.builder(
                            itemCount: results.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: ((context, index) {
                              return cardConnect(index);
                            }))
                        : const Center(
                            child: Text("No Data Found"),
                          )
                    : const Center(
                        child: CircularProgressIndicator(),
                      ),
          )),
    );
  }

  List isHover = [false, false];
  Widget cardConnect(int index) {
    var screenSize = MediaQuery.of(context).size;
    return InkWell(
      onHover: (s) {
        setState(() {
          s ? isHover[index] = true : isHover[index] = false;
        });
      },
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    VendorProfileScreen(vid: results[index].id.toString())));
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: screenSize.height / 5.65,
        width: screenSize.width / 11.2,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(screenSize.width / 192),
          color: const Color.fromRGBO(2, 44, 67, 1),
        ),
        margin: EdgeInsets.only(right: screenSize.width / 192),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            height: screenSize.height / 8.73,
            width: screenSize.width / 17.45,
            decoration: BoxDecoration(
                color: isHover[index]
                    ? themeColor
                    : const Color.fromRGBO(2, 44, 67, 1),
                border: Border.all(
                    width: screenSize.width / 960,
                    color: const Color.fromRGBO(255, 215, 0, 1)),
                shape: BoxShape.circle,
                image: DecorationImage(
                    image: NetworkImage(
                        '${MainUrl}vendor-image/${results[index].photo}'),
                    fit: BoxFit.contain)),
          ),
          SizedBox(
            height: screenSize.height / 120.1,
          ),
          Container(
            child: Text(
              results[index].name,
              style: TextStyle(
                  fontSize: screenSize.width / 120,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          SizedBox(
            height: screenSize.height / 120.1,
          ),
          Container(
            child: Text(
              "₹ ${results[index].audicallprice} /min",
              style: TextStyle(
                  fontSize: screenSize.width / 174.5,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          SizedBox(
            height: screenSize.height / 120.1,
          ),
          Container(
            height: screenSize.height / 34.32,
            width: screenSize.width / 24,
            decoration: BoxDecoration(
                color: isHover[index] ? themeColor : Colors.transparent,
                borderRadius: BorderRadius.circular(screenSize.width / 36),
                border: Border.all(
                    width: screenSize.width / 1920, color: Colors.white)),
            child: Center(
              child: Text(
                "Connect",
                style: TextStyle(
                    fontSize: screenSize.width / 160,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
          )
        ]),
      ),
    );
  }
}
