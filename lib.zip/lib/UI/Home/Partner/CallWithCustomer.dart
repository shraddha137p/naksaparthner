import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/constants.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../API/AgoraConfig.dart';
import '../BottomNavigation.dart';

class CallWithCustomer extends StatefulWidget {
  List<Vdatum?> vendorData;
  String channelName;
  String token;
  String uid;
  CallWithCustomer(
      {super.key,
      required this.channelName,
      required this.token,
      required this.vendorData,
      required this.uid});

  @override
  State<CallWithCustomer> createState() => _CallWithCustomerState();
}

class _CallWithCustomerState extends State<CallWithCustomer> {
  // uid of the local user

  int? _remoteUid; // uid of the remote user
  bool _isJoined = false; // Indicates if the local user has joined the channel
  late RtcEngine agoraEngine; //
  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>(); // Global key to access the scaffold

  showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(message),
    ));
  }

  @override
  void initState() {
    super.initState();
    // Set up an instance of Agora engine
    setupVideoSDKEngine();
  }

  Future<void> setupVideoSDKEngine() async {
    // retrieve or request camera and microphone permissions
    await [Permission.microphone].request();
    // await window.navigator.getUserMedia(audio: true, video: true);

    //create an instance of the Agora engine
    // agoraEngine = createAgoraRtcEngine();
    // await agoraEngine
    //     .initialize(const RtcEngineContext(appId: AgoraChatConfig.appKey));
    agoraEngine = await RtcEngine.create(AgoraChatConfig.appKey);

    // await agoraEngine.enableVideo();

    // Register the event handler
    agoraEngine.setEventHandler(
      RtcEngineEventHandler(
        joinChannelSuccess: (String channel, int uid, int elapsed) {
          showMessage("Local user uid:$uid joined the channel");
          setState(() {
            _isJoined = true;
          });
        },
        userJoined: (int uid, int elapsed) {
          showMessage("Remote user uid:$uid joined the channel");
          setState(() {
            _remoteUid = uid;
          });
        },
        userOffline: (int uid, UserOfflineReason reason) {
          showMessage("Remote user uid:$uid left the channel");
          setState(() {
            _remoteUid = null;
          });
        },
      ),
    );
    join();
  }

  void join() async {
    await agoraEngine.startPreview();

    // // Set channel options including the client role and channel profile
    // ChannelMediaOptions options = const ChannelMediaOptions(
    //   clientRoleType: ClientRoleType.clientRoleBroadcaster,
    //   channelProfile: ChannelProfileType.channelProfileCommunication,
    // );

    // await agoraEngine.joinChannel(
    //   token: widget.token,
    //   channelId: widget.channnelName,
    //   options: options,
    //   uid: int.parse(widget.userid),
    // );
    await agoraEngine.joinChannel(
        widget.token, widget.channelName, null, int.parse(widget.uid));
  }

  @override
  void dispose() async {
    await agoraEngine.leaveChannel();
    // agoraEngine.release();
    super.dispose();
  }

  void leave() {
    setState(() {
      _isJoined = false;
      _remoteUid = null;
    });
    agoraEngine.leaveChannel();
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => BottomNavigationBarScreen(pageIndex: 0)));
  }

  bool mutecall = false;
  Future<void> _onmute(bool sts) async {
    await agoraEngine.muteLocalAudioStream(true);
  }

  bool ishold = false;
  Future<void> onhold(bool newval) async {
    await agoraEngine.muteLocalAudioStream(true);

    await agoraEngine.muteAllRemoteAudioStreams(true);
  }

  bool isSwitched = false;
  void _onHandsFree(bool newValue) {
    agoraEngine.setDefaultAudioRouteToSpeakerphone(
        false); // Disables the default audio route.
    agoraEngine.setEnableSpeakerphone(
        newValue); // Enables or disables the speakerphone temporarily.
  }

  // Clean up the resources when you leave

  Widget _status() {
    String statusText;

    if (!_isJoined) {
      statusText = 'Join a channel';
    } else if (_remoteUid == null) {
      statusText = 'Waiting for a remote user to join...';
    } else {
      statusText = 'Connected to remote user, uid:$_remoteUid';
    }

    return Text(
      statusText,
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: themeColor,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 50,
          automaticallyImplyLeading: false,
          foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: Container(
            margin: EdgeInsets.only(
                top: screenSize.height / 22.2,
                left: screenSize.width / 24,
                right: screenSize.width / 25.7),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(
                      Icons.arrow_back,
                      size: screenSize.width / 14.4,
                    ),
                    Container(
                      height: screenSize.height / 31.5,
                      width: screenSize.width / 6,
                      decoration: BoxDecoration(
                          border: Border.all(
                              width: screenSize.width / 360,
                              color: Color.fromRGBO(47, 47, 47, 1)),
                          borderRadius:
                              BorderRadius.circular(screenSize.width / 72)),
                      child: Center(
                          child: Text(
                        "END",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 27.6,
                            color: Color.fromRGBO(47, 47, 47, 1)),
                      )),
                    ),
                  ],
                ),
              ],
            ),
          )),
      body: SizedBox(
        height: screenSize.height / 0.51,
        child: Stack(
          children: [
            Positioned(
                bottom: 0,
                child: Container(
                  height: 283,
                  width: 360,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(screenSize.width / 18),
                        topRight: Radius.circular(screenSize.width / 18)),
                    color: blueColor,
                  ),
                )),
            Container(
              // height: 815,
              width: screenSize.width / 0.96,
              margin: EdgeInsets.only(
                  top: screenSize.height / 75.6,
                  left: screenSize.width / 24,
                  right: screenSize.width / 25.71),
              child: SingleChildScrollView(
                child: Container(
                  child: Column(children: [
                    Container(
                      padding: EdgeInsets.all(screenSize.width / 36),
                      height: screenSize.height / 1.21,
                      width: screenSize.width / 1.09,
                      decoration: BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(screenSize.width / 18),
                          color: Colors.white),
                      child: Column(children: [
                        SizedBox(
                            height: screenSize.height / 18.9,
                            child: Center(child: _status())),
                        SizedBox(
                          height: screenSize.height / 14.26,
                        ),
                        GestureDetector(
                          onTap: () {
                            join();
                          },
                          child: Container(
                            height: screenSize.height / 4.27,
                            width: screenSize.width / 2.03,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    width: screenSize.width / 180,
                                    color: themeColor),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: NetworkImage(
                                        '${MainUrl}vendor-image/${widget.vendorData[0]!.photo}'),
                                    fit: BoxFit.fill)),
                          ),
                        ),
                        SizedBox(
                          height: screenSize.height / 42,
                        ),
                        Container(
                          child: Text(
                            "Aditya Roy",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 20,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(
                          height: screenSize.height / 94.5,
                        ),
                        Container(
                          child: Text(
                            "Numerology, Loshu Grid",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 27.6,
                                color: Colors.black,
                                fontWeight: FontWeight.normal),
                          ),
                        ),
                        SizedBox(
                          height: screenSize.height / 94.5,
                        ),
                        Container(
                          child: Text(
                            "03:04",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 27.6,
                                color: Colors.black,
                                fontWeight: FontWeight.normal),
                          ),
                        ),
                        SizedBox(
                          height: screenSize.height / 22.2,
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              mutecall = !mutecall;
                            });
                            _onmute(mutecall);
                          },
                          child: Container(
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Container(
                                    child: Column(children: [
                                      Container(
                                        height: screenSize.height / 10.64,
                                        width: screenSize.width / 5.07,
                                        decoration: BoxDecoration(
                                          color: mutecall != true
                                              ? themeColor
                                              : Colors.red,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                            child: Icon(
                                          Icons.mic,
                                          size: screenSize.width / 14.4,
                                          color: mutecall != true
                                              ? Colors.black
                                              : Colors.white,
                                        )),
                                      ),
                                      SizedBox(
                                        height: screenSize.height / 84,
                                      ),
                                      Text(
                                        "Mute",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width / 36,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ]),
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        ishold = !ishold;
                                      });
                                      onhold(ishold);
                                    },
                                    child: Container(
                                      child: Column(children: [
                                        Container(
                                          height: screenSize.height / 10.6,
                                          width: screenSize.width / 5.07,
                                          decoration: BoxDecoration(
                                              color: ishold != true
                                                  ? themeColor
                                                  : Colors.red,
                                              shape: BoxShape.circle),
                                          child: Center(
                                              child: Icon(
                                            Icons.pause,
                                            size: screenSize.width / 14.4,
                                            color: ishold != true
                                                ? Colors.black
                                                : Colors.white,
                                          )),
                                        ),
                                        SizedBox(
                                          height: screenSize.height / 84,
                                        ),
                                        Text(
                                          "Hold",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width / 36,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ]),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        isSwitched = !isSwitched;
                                      });
                                      _onHandsFree(isSwitched);
                                    },
                                    child: Container(
                                      child: Column(children: [
                                        Container(
                                          height: screenSize.height / 10.6,
                                          width: screenSize.width / 5.07,
                                          decoration: BoxDecoration(
                                              color: isSwitched != true
                                                  ? themeColor
                                                  : Colors.red,
                                              shape: BoxShape.circle),
                                          child: Center(
                                              child: Icon(
                                            Icons.volume_up,
                                            size: screenSize.width / 14.4,
                                            color: isSwitched != true
                                                ? Colors.black
                                                : Colors.white,
                                          )),
                                        ),
                                        SizedBox(
                                          height: screenSize.height / 84,
                                        ),
                                        Text(
                                          "Speaker",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width / 36,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ]),
                                    ),
                                  ),
                                ]),
                          ),
                        ),
                        SizedBox(
                          height: screenSize.height / 25.2,
                        ),
                        GestureDetector(
                          onTap: () {
                            leave();
                          },
                          child: Container(
                            child: Column(children: [
                              Container(
                                height: screenSize.height / 10.6,
                                width: screenSize.width / 5.07,
                                decoration: const BoxDecoration(
                                    color: Colors.red, shape: BoxShape.circle),
                                child:  Center(
                                    child: Icon(
                                  Icons.call,
                                  size: screenSize.width/14.4,
                                  color: Colors.white,
                                )),
                              ),
                               SizedBox(
                                height: screenSize.height/84,
                              ),
                               Text(
                                "End",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/36, fontWeight: FontWeight.bold),
                              )
                            ]),
                          ),
                        ),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget DesktopServiceMain() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: themeColor,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 50,
          automaticallyImplyLeading: false,
          foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: Container(
            margin:  EdgeInsets.only(top: screenSize.height/40.04, left: screenSize.width/128, right: screenSize.width/137.1),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                     Icon(
                      Icons.arrow_back,
                      size: screenSize.width/76.8,
                    ),
                    Container(
                      height: screenSize.height/38.44,
                      width: screenSize.width/32,
                      decoration: BoxDecoration(
                          border: Border.all(
                              width: screenSize.width/1920,
                              color: const Color.fromRGBO(47, 47, 47, 1)),
                          borderRadius: BorderRadius.circular(5)),
                      child:  Center(
                          child: Text(
                        "END",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width/147.6, color: Color.fromRGBO(47, 47, 47, 1)),
                      )),
                    ),
                  ],
                ),
              ],
            ),
          )),
      body: SizedBox(
        height: screenSize.height/1.37,
        width: MediaQuery.of(context).size.width,
        child: Stack(
          children: [
            Positioned(
                bottom: 0,
                child: Container(
                  height: screenSize.height/4.03,
                  width: MediaQuery.of(context).size.width,
                  decoration:  BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(screenSize.width/96),
                        topRight: Radius.circular(screenSize.width/96)),
                    color: blueColor,
                  ),
                )),
            Container(
              // height: 815,
              width: MediaQuery.of(context).size.width,
              margin:  EdgeInsets.only(top: screenSize.height/96.1, left: screenSize.width/128, right: screenSize.width/137.1),
              child: SingleChildScrollView(
                child: Container(
                  child: Column(children: [
                    Container(
                      padding:  EdgeInsets.all(screenSize.width/192),
                      height: screenSize.height/1.54,
                      width: MediaQuery.of(context).size.width * 0.9,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(screenSize.width/96),
                          color: Colors.white),
                      child: Column(children: [
                        SizedBox(height: screenSize.height/24.02, child: Center(child: _status())),
                         SizedBox(
                          height: screenSize.height/18.1,
                        ),
                        GestureDetector(
                          onTap: () {
                            join();
                          },
                          child: Container(
                            height: screenSize.height/5.42,
                            width: screenSize.width/10.8,
                            decoration: BoxDecoration(
                                border: Border.all(width: screenSize.width/960, color: themeColor),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: NetworkImage(
                                        '${MainUrl}vendor-image/${widget.vendorData[0]!.photo}'),
                                    fit: BoxFit.fill)),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/53.3,
                        ),
                        Container(
                          child:  Text(
                            "Aditya Roy",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/106.6,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/120.1,
                        ),
                        Container(
                          child:  Text(
                            "Numerology, Loshu Grid",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/147.6,
                                color: Colors.black,
                                fontWeight: FontWeight.normal),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/120.1,
                        ),
                        Container(
                          child:  Text(
                            "03:04",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/147.6,
                                color: Colors.black,
                                fontWeight: FontWeight.normal),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/28.2,
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              mutecall = !mutecall;
                            });
                            _onmute(mutecall);
                          },
                          child: Container(
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    child: Column(children: [
                                      Container(
                                        height: screenSize.height/13.5,
                                          width: screenSize.width/27.0,
                                        decoration: BoxDecoration(
                                          color: mutecall != true
                                              ? themeColor
                                              : Colors.red,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                            child: Icon(
                                          Icons.mic,
                                          size: screenSize.width/76.8,
                                          color: mutecall != true
                                              ? Colors.black
                                              : Colors.white,
                                        )),
                                      ),
                                       SizedBox(
                                        height: screenSize.height/106.7,
                                        width: screenSize.width/192,
                                      ),
                                       Text(
                                        "Mute",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width/192,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ]),
                                  ),
                                   SizedBox(
                                    width: screenSize.width/128,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        ishold = !ishold;
                                      });
                                      onhold(ishold);
                                    },
                                    child: Container(
                                      child: Column(children: [
                                        Container(
                                         height: screenSize.height/13.5,
                                          width: screenSize.width/27.0,
                                          decoration: BoxDecoration(
                                              color: ishold != true
                                                  ? themeColor
                                                  : Colors.red,
                                              shape: BoxShape.circle),
                                          child: Center(
                                              child: Icon(
                                            Icons.pause,
                                            size: screenSize.width/76.8,
                                            color: ishold != true
                                                ? Colors.black
                                                : Colors.white,
                                          )),
                                        ),
                                         SizedBox(
                                          height: screenSize.height/106.7,
                                        ),
                                         Text(
                                          "Hold",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/192,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ]),
                                    ),
                                  ),
                                   SizedBox(
                                    width: screenSize.width/128,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        isSwitched = !isSwitched;
                                      });
                                      _onHandsFree(isSwitched);
                                    },
                                    child: Container(
                                      child: Column(children: [
                                        Container(
                                           height: screenSize.height/13.5,
                                          width: screenSize.width/27.0,
                                          decoration: BoxDecoration(
                                              color: isSwitched != true
                                                  ? themeColor
                                                  : Colors.red,
                                              shape: BoxShape.circle),
                                          child: Center(
                                              child: Icon(
                                            Icons.volume_up,
                                            size: screenSize.width/76.8,
                                            color: isSwitched != true
                                                ? Colors.black
                                                : Colors.white,
                                          )),
                                        ),
                                         SizedBox(
                                          height: screenSize.height/106.7,
                                        ),
                                         Text(
                                          "Speaker",
                                          style: GoogleFonts.merriweather(
                                              fontSize: screenSize.width/192,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ]),
                                    ),
                                  ),
                                ]),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/32.03,
                        ),
                        GestureDetector(
                          onTap: () {
                            leave();
                          },
                          child: Container(
                            child: Column(children: [
                              Container(
                                height: screenSize.height/13.5,
                                          width: screenSize.width/27.0,
                                decoration: const BoxDecoration(
                                    color: Colors.red, shape: BoxShape.circle),
                                child:  Center(
                                    child: Icon(
                                  Icons.call,
                                  size: screenSize.width/76.8,
                                  color: Colors.white,
                                )),
                              ),
                               SizedBox(
                                height: screenSize.height/106.7,
                              ),
                               Text(
                                "End",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width/192, fontWeight: FontWeight.bold),
                              )
                            ]),
                          ),
                        ),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
