import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/WalletService.dart';
import 'package:naksaa_services/Service/giftsservices.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorAvailability.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfileWork.dart';
import 'dart:math' as math;

import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/RatingReviewModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:naksaa_services/model/VendorWorkModel.dart';
import 'package:naksaa_services/model/VenodrFollowerCheck.dart';
import 'package:naksaa_services/model/giiftsmodels.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Service/AllVendorService.dart';
import '../../../Service/VendorFollowerChekerService.dart';
import '../../../model/CustomerWalletModel.dart';
import '../../../model/VendorAvailabilityModel.dart';
import '../../REgister/project Assets/AppBar.dart';
import '../../REgister/project Assets/LoginModel.dart';
import '../../REgister/project Assets/desktopNavbar.dart';
import '../BottomFooter.dart';
import '../Utility/rechargeNowUtility.dart';
import 'VendorAvailabilityWidget.dart';
import 'VideoCall/OrderSuccessModel.dart';
import 'VideoCall/VideoCallandAudioCallModal.dart';

class VendorProfileScreen extends StatefulWidget {
  String vid;
  VendorProfileScreen({
    super.key,
    required this.vid,
  });

  @override
  State<VendorProfileScreen> createState() => _VendorProfileScreenState(vid);
}

class _VendorProfileScreenState extends State<VendorProfileScreen> {
  String vid;
  _VendorProfileScreenState(this.vid);
  List<Vdatum> results = [];
  List<VendorWork> wportdata = [];
  List<RatingData> ratingReviewData = [];
  var vendorService = AllVendorService();
  var networkProvider = NetworkHandler();
  List<VendorAData> result = [];

  Future<List<VendorAData>> getVendorAvailabitliyDetails() async {
    result = await vendorService.viewVendorAvailability(vid);
    print("availability data");
    print(result);
    if (result != null) {
      return result;
    } else {
      throw Exception('Failed to load');
    }
  }

  bool isdataloading = false;
  List<gifft> _giftlist = [];
  var gifftservice = GiftService();
  bool giftLoading = false;
  Future<List<gifft>>? Giftdetails() async {
    setState(() {
      giftLoading = true;
    });
    var response = await gifftservice.gift();
    setState(() {
      _giftlist = response!;
    });
    if (_giftlist != null) {
      setState(() {
        giftLoading = false;
      });
      print(_giftlist);
      return _giftlist;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  void initState() {
    super.initState();
    // getVendorDetails();
    // getWorkPortfolio();
    // getVendorAvailabitliyDetails();
    getWalletAmount();
    getReviews();
    _getvendorFollower();

    Giftdetails();
  }

  void showSnackBar({required String message, int duration = 1}) {
    scaffoldMessengerKey.currentState!.removeCurrentSnackBar();
    scaffoldMessengerKey.currentState!.showSnackBar(
      SnackBar(
        content: Text(message),
        duration: Duration(seconds: duration),
      ),
    );
  }

  Future<List<Vdatum>> getVendorDetails() async {
    var response = await vendorService.viewSingleVendor(vid);

    results = VendorDetailsmodel.fromJson(jsonDecode(response)).vdata.toList();
    if (results != null) {
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  Future<List<VendorWork>> getWorkPortfolio() async {
    wportdata = await vendorService.viewWorkPortfolio(vid);

    if (wportdata != null) {
      return wportdata;
    } else {
      throw Exception('Failed to load');
    }
  }

  bool isfollowing = false;

  List<FollowDatum> _vendorFollwer = [];
  var followerCheker = FollowerService();
  Future<void> _getvendorFollower() async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    String? uid = pref.getString("uid");
    print(uid!);
    var response = await followerCheker.viewVendorFollower(vid, uid);
    if (response != null) {
      _vendorFollwer = response;
      if (_vendorFollwer.length >= 1) {
        if (_vendorFollwer[0].follow == "true") {
          setState(() {
            isfollowing = true;
          });
        } else {
          setState(() {
            isfollowing = false;
          });
        }
      }
    } else {
      setState(() {
        isfollowing = false;
      });
    }
  }

  // ScreenshotController screenshotController = ScreenshotController();
  Future<List<RatingData>> getReviews() async {
    ratingReviewData = await vendorService.viewRatingReview(vid);
    print("vhjv");
    print(ratingReviewData);
    if (ratingReviewData != null) {
      return ratingReviewData;
    } else {
      throw Exception('Failed to load');
    }
  }

  // Future<void> _takeScreenShotAndShare() async {
  //   // final imageFile = await screenshotController.capture();
  //   print("captured");
  //   Uint8List pngimage = imageFile!;
  //   Share.shareFiles(['$imageFile'], text: "This is okay");
  // }

  bool isloading = false;
  List<Walletdatum> _walletList = [];
  var walletService = CustomerWalletService();
  Future<void> getWalletAmount() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await walletService.viewCustomerWallet(uid!);
    if (response != null) {
      setState(() {
        isloading = true;
      });
      _walletList = response;
    }
  }

  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVendorProfile();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVendorProfile();
      } else {
        return MobileVendorProfile();
      }
    });
  }

  Widget DesktopVendorProfile() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      key: scaffoldKey,
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.only(
          left: screenSize.width / 64,
          right: screenSize.width / 64,
        ),
        child: SingleChildScrollView(
            child: Column(
          children: [
            RefreshIndicator(
              onRefresh: () {
                return getVendorDetails();
              },
              child: FutureBuilder(
                  future: getVendorDetails(),
                  builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                      item.hasData
                          ? item.data!.isNotEmpty
                              ? SizedBox(
                                  height: screenSize.height / 1.92,
                                  // margin: const EdgeInsets.only(top: 35),
                                  child: Column(children: [
                                    SizedBox(
                                      height: screenSize.height/3.37,
                                      width: screenSize.width / 1.92,
                                      child: Row(
                                        children: [
                                          Column(
                                            children: [
                                              SizedBox(
                                                height:
                                                    screenSize.height / 4.80,
                                                width: screenSize.width / 6.4,
                                                child: Stack(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  children: [
                                                    Positioned(
                                                      top: screenSize.height /
                                                          192.2,
                                                      child: Container(
                                                        height:
                                                            screenSize.height /
                                                                4.80,
                                                        width:
                                                            screenSize.width /
                                                                9.6,
                                                        decoration:
                                                            BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          border: Border.all(
                                                            width: screenSize
                                                                    .width /
                                                                960,
                                                            color:
                                                                lightblueColor,
                                                          ),
                                                          image:
                                                              DecorationImage(
                                                            image: NetworkImage(
                                                                '${MainUrl}vendor-image/${results[0].photo}'),
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      top: 15,
                                                      right: 60,
                                                          
                                                      child: Container(
                                                        height:
                                                            screenSize.height /
                                                                24.0,
                                                        width:
                                                            screenSize.width /
                                                                48,
                                                        decoration:
                                                            const BoxDecoration(
                                                          image:
                                                              DecorationImage(
                                                            image: AssetImage(
                                                                "assets/SVG/star2-2x.png"),
                                                            fit: BoxFit.fill,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(
                                                height:
                                                    screenSize.height / 96.1,
                                              ),
                                              GestureDetector(
                                                onTap: () async {
                                                  SharedPreferences pref =
                                                      await SharedPreferences
                                                          .getInstance();
                                                  String? uid =
                                                      pref.getString("uid");
                                                  followVendor(
                                                    uid!,
                                                    vid,
                                                    !isfollowing,
                                                  );
                                                },
                                                child: Container(
                                                  height:
                                                      screenSize.height / 25.9,
                                                  width:
                                                      screenSize.width / 15.8,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                42.6),
                                                    color: const Color.fromRGBO(
                                                      17,
                                                      81,
                                                      115,
                                                      1,
                                                    ),
                                                  ),
                                                  child: Center(
                                                    child: isfollowing != true
                                                        ? Text(
                                                            "Follow",
                                                            style: GoogleFonts
                                                                .merriweather(
                                                              color:
                                                                  Colors.white,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: screenSize
                                                                      .width /
                                                                  128,
                                                            ),
                                                          )
                                                        : Text(
                                                            "Following",
                                                            style: GoogleFonts
                                                                .merriweather(
                                                              color:
                                                                  Colors.white,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: screenSize
                                                                      .width /
                                                                  128,
                                                            ),
                                                          ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                height:
                                                    screenSize.height / 48.05,
                                              ),
                                            ],
                                          ),
                                          Container(
                                            child: Row(
                                              children: [
                                                Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Container(
                                                        child: Column(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              SizedBox(
                                                                height: screenSize
                                                                        .height /
                                                                    48.05,
                                                              ),
                                                              Row(
                                                                children: [
                                                                  Text(
                                                                    results[0]
                                                                        .name,
                                                                    style: GoogleFonts
                                                                        .merriweather(
                                                                      fontSize:
                                                                          screenSize.width /
                                                                              87.27,
                                                                      color: Color
                                                                          .fromRGBO(
                                                                        17,
                                                                        81,
                                                                        115,
                                                                        1,
                                                                      ),
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    width: screenSize
                                                                            .width /
                                                                        7.68,
                                                                  ),
                                                                  IconButton(
                                                                    icon: Icon(
                                                                      Icons
                                                                          .share,
                                                                      size: screenSize
                                                                              .width /
                                                                          76.8,
                                                                    ),
                                                                    onPressed:
                                                                        () async {
                                                                      // final image =
                                                                      //     await controller
                                                                      //         .captureFromWidget(
                                                                      //   buildImage(),
                                                                      // );
                                                                      // if (image ==
                                                                      //     null) {
                                                                      //   return;
                                                                      // }
                                                                      // await saveImage(
                                                                      //   image,
                                                                      // );
                                                                      // saveAndShare(
                                                                      //   image,
                                                                      // );
                                                                      // _takeScreenShotAndShare();
                                                                      // screenshotController
                                                                      //     .capture(
                                                                      //         delay:
                                                                      //             Duration(milliseconds: 10))
                                                                      //     .then((capturedImage) async {
                                                                      //   // ShowCapturedWidget(
                                                                      //   //     context, capturedImage!);
                                                                      //   await Share.shareFiles(
                                                                      //       ['${capturedImage}'],
                                                                      //       text: 'Great picture');
                                                                      // }).catchError((onError) {
                                                                      //   print(onError);
                                                                      // });
                                                                    },
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: screenSize
                                                                        .height /
                                                                    96.1,
                                                              ),
                                                              Text(
                                                                results[0]
                                                                    .primaryskills,
                                                                style: GoogleFonts.merriweather(
                                                                    fontSize:
                                                                        screenSize.width /
                                                                            160,
                                                                    color: Colors
                                                                        .black,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                              ),
                                                              SizedBox(
                                                                height: screenSize
                                                                        .height /
                                                                    96.1,
                                                              ),
                                                              Text(
                                                                results[0]
                                                                    .language,
                                                                style: GoogleFonts.merriweather(
                                                                    fontSize:
                                                                        screenSize.width /
                                                                            120,
                                                                    color: Colors
                                                                        .black,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                              ),
                                                              SizedBox(
                                                                height: screenSize
                                                                        .height /
                                                                    96.1,
                                                              ),
                                                              Text(
                                                                "Exp: 5 Years",
                                                                style: GoogleFonts
                                                                    .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          137.1,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: screenSize
                                                                        .height /
                                                                    96.1,
                                                              ),
                                                              Text(
                                                                "₹ ${results[0].audicallprice} / min",
                                                                style: GoogleFonts
                                                                    .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          128,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: screenSize
                                                                        .height /
                                                                    56.5,
                                                              ),
                                                              SizedBox(
                                                                width: screenSize
                                                                        .width /
                                                                    2.95,
                                                                child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Container(
                                                                        child: Column(
                                                                            children: [
                                                                              Text(
                                                                                "Chat",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 106.6, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 96.1,
                                                                              ),
                                                                              Text(
                                                                                "49k",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 64, color: Color.fromRGBO(17, 81, 115, 1), fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 192.2,
                                                                              ),
                                                                              Text(
                                                                                "mins",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 137.1, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                            ]),
                                                                      ),
                                                                      Container(
                                                                        child: Column(
                                                                            children: [
                                                                              Text(
                                                                                "Calls",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 106.6, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 96.1,
                                                                              ),
                                                                              Text(
                                                                                "49k",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 64, color: Color.fromRGBO(17, 81, 115, 1), fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 192.2,
                                                                              ),
                                                                              Text(
                                                                                "mins",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 137.1, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                            ]),
                                                                      ),
                                                                      Container(
                                                                        child: Column(
                                                                            children: [
                                                                              Text(
                                                                                "Video Chat",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 106.6, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 96.1,
                                                                              ),
                                                                              Text(
                                                                                "500",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 64, color: Color.fromRGBO(17, 81, 115, 1), fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 192.2,
                                                                              ),
                                                                              Text(
                                                                                "mins",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 137.1, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                            ]),
                                                                      ),
                                                                      Container(
                                                                        child: Column(
                                                                            children: [
                                                                              Text(
                                                                                "Followers",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 106.6, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 96.1,
                                                                              ),
                                                                              Text(
                                                                                "2k",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 64, color: Color.fromRGBO(17, 81, 115, 1), fontWeight: FontWeight.bold),
                                                                              ),
                                                                              SizedBox(
                                                                                height: screenSize.height / 192.2,
                                                                              ),
                                                                              Text(
                                                                                "Following",
                                                                                style: GoogleFonts.merriweather(fontSize: screenSize.width / 137.1, color: Colors.black, fontWeight: FontWeight.bold),
                                                                              ),
                                                                            ]),
                                                                      )
                                                                    ]),
                                                              )
                                                            ]),
                                                      ),
                                                    ]),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    Container(
                                        margin: EdgeInsets.only(
                                            top: screenSize.height / 27.4,
                                            left: screenSize.width / 96,
                                            right: screenSize.width / 27.42),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "About ${results[0].name}",
                                              textAlign: TextAlign.center,
                                              style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 147.6,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 48.05,
                                            ),
                                            Text(
                                              results[0].aboutus,
                                              textAlign: TextAlign.left,
                                              style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 147.6,
                                                  fontWeight: FontWeight.normal,
                                                  color: Color.fromRGBO(
                                                      17, 81, 115, 1)),
                                            ),
                                          ],
                                        ))
                                  ]),
                                )
                              : const Center(
                                  child: Text("No Data Found"),
                                )
                          : SizedBox(
                              height: screenSize.height / 12.01,
                              child: Center(
                                child: CircularProgressIndicator(),
                              ),
                            )),
            ),
            SizedBox(
              height: screenSize.height / 43.68,
            ),
            Container(
              child: Column(children: [
                Container(
                  margin: EdgeInsets.only(
                    left: screenSize.width / 96,
                    right: screenSize.width / 96,
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Photos",
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 147.6,
                            fontWeight: FontWeight.normal,
                            color: Colors.black,
                          ),
                        ),
                        Transform.rotate(
                            angle: 180 * math.pi / 180,
                            child: GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              VendorProfileWork(
                                                  wportdata: wportdata)));
                                },
                                child: const Icon(Icons.arrow_back)))
                      ]),
                ),
                RefreshIndicator(
                  onRefresh: () {
                    return getWorkPortfolio();
                  },
                  child: Container(
                    height: screenSize.height / 4.36,
                    margin: EdgeInsets.all(screenSize.width / 128),
                    child: FutureBuilder(
                        future: getWorkPortfolio(),
                        builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                            item.hasData
                                ? wportdata.length >= 1
                                    ? ListView.builder(
                                        itemCount: wportdata.length,
                                        scrollDirection: Axis.horizontal,
                                        shrinkWrap: true,
                                        itemBuilder: (context, index) {
                                          return GestureDetector(
                                            onTap: () async {
                                              await showDialog(
                                                  context: context,
                                                  builder: (_) => ImageDialog(
                                                      '${MainUrl}vendor-work/${wportdata[index].photo}'));
                                            },
                                            child: Container(
                                              height: screenSize.height / 4.36,
                                              width: screenSize.width / 8.72,
                                              margin: EdgeInsets.only(
                                                  right:
                                                      screenSize.width / 192),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          screenSize.width /
                                                              38.4),
                                                  image: DecorationImage(
                                                      image: NetworkImage(
                                                          '${MainUrl}vendor-work/${wportdata[index].photo}'),
                                                      fit: BoxFit.fill)),
                                            ),
                                          );
                                        })
                                    : const Center(
                                        child: Text("No Data Found"),
                                      )
                                : SizedBox(
                                    height: screenSize.height / 1.201,
                                    child: Center(
                                      child: CircularProgressIndicator(),
                                    ),
                                  )),
                  ),
                )
              ]),
            ),
            Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      child: Column(
                        children: [
                          Container(
                            margin: EdgeInsets.only(
                                left: screenSize.width / 128,
                                right: screenSize.width / 128),
                            height: screenSize.height / 4,
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(screenSize.width / 192),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(
                                  color: Color.fromRGBO(0, 0, 0, 0.16),
                                  offset: Offset(
                                    3.0,
                                    3.0,
                                  ),
                                  blurRadius: 6.0,
                                  spreadRadius: 2.0,
                                ),
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(0.0, 0.0),
                                  blurRadius: 0.0,
                                  spreadRadius: 0.0,
                                ),
                              ],
                            ),
                            child: Column(children: [
                              Container(
                                margin: EdgeInsets.only(
                                    left: screenSize.width / 128,
                                    right: screenSize.width / 128,
                                    top: screenSize.height / 43.4),
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Rating & Reviews",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width / 147.6,
                                            fontWeight: FontWeight.normal,
                                            color: Colors.black),
                                      ),
                                      Transform.rotate(
                                          angle: 180 * math.pi / 180,
                                          child: const Icon(Icons.arrow_back))
                                    ]),
                              ),
                              Container(
                                margin: EdgeInsets.only(
                                    top: screenSize.height / 75.6),
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      SizedBox(
                                        width: screenSize.width / 19.2,
                                        child: Column(children: [
                                          Text(
                                            "4.93",
                                            style: GoogleFonts.merriweather(
                                                fontSize:
                                                    screenSize.width / 50.5,
                                                fontWeight: FontWeight.bold,
                                                color: blueColor),
                                          ),
                                          SizedBox(
                                            height: screenSize.height / 96.1,
                                          ),
                                          Container(
                                            child: RatingBarIndicator(
                                              rating: 4.5,
                                              itemBuilder: (context, index) =>
                                                  const Icon(
                                                Icons.star,
                                                color: Colors.amber,
                                              ),
                                              itemCount: 5,
                                              itemSize: 13.0,
                                              direction: Axis.horizontal,
                                            ),
                                          ),
                                          SizedBox(
                                            height: screenSize.height / 75.6,
                                          ),
                                          Text(
                                            "734 Reviews",
                                            style: GoogleFonts.merriweather(
                                                fontSize:
                                                    screenSize.width / 174.5,
                                                fontWeight: FontWeight.bold,
                                                color: blueColor),
                                          ),
                                        ]),
                                      ),
                                      Container(
                                        child: Column(
                                          children: [
                                            Row(children: [
                                              Container(
                                                child: Text(
                                                  "5",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                          fontSize:
                                                              screenSize.width /
                                                                  120,
                                                          color: blueColor),
                                                ),
                                              ),
                                              SizedBox(
                                                width: screenSize.width / 128,
                                              ),
                                              Container(
                                                height: screenSize.height / 48,
                                                width: screenSize.width / 13.24,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                192),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color: Color.fromRGBO(
                                                            0, 0, 0, 0.16),
                                                        offset: Offset(
                                                          3.0,
                                                          3.0,
                                                        ),
                                                        blurRadius: 6.0,
                                                        spreadRadius: 2.0,
                                                      ),
                                                      BoxShadow(
                                                        color: Colors.white,
                                                        offset:
                                                            Offset(0.0, 0.0),
                                                        blurRadius: 0.0,
                                                        spreadRadius: 0.0,
                                                      ),
                                                    ],
                                                    color: Colors.white),
                                                child: Container(
                                                  height:
                                                      screenSize.height / 48,
                                                  width:
                                                      screenSize.width / 22.58,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width /
                                                                  192),
                                                      color: themeColor),
                                                ),
                                              )
                                            ]),
                                            SizedBox(
                                              height: screenSize.height / 75.6,
                                            ),
                                            Row(children: [
                                              Container(
                                                child: Text(
                                                  "4",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                          fontSize:
                                                              screenSize.width /
                                                                  120,
                                                          color: blueColor),
                                                ),
                                              ),
                                              SizedBox(
                                                width: screenSize.width / 128,
                                              ),
                                              Container(
                                                height: screenSize.height / 48,
                                                width: screenSize.width / 13.24,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                192),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color: Color.fromRGBO(
                                                            0, 0, 0, 0.16),
                                                        offset: Offset(
                                                          3.0,
                                                          3.0,
                                                        ),
                                                        blurRadius: 6.0,
                                                        spreadRadius: 2.0,
                                                      ),
                                                      BoxShadow(
                                                        color: Colors.white,
                                                        offset:
                                                            Offset(0.0, 0.0),
                                                        blurRadius: 0.0,
                                                        spreadRadius: 0.0,
                                                      ),
                                                    ],
                                                    color: Colors.white),
                                                child: Container(
                                                  height:
                                                      screenSize.height / 48,
                                                  width:
                                                      screenSize.width / 22.5,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width /
                                                                  192),
                                                      color: themeColor),
                                                ),
                                              )
                                            ]),
                                            SizedBox(
                                              height: screenSize.height / 96.1,
                                            ),
                                            Row(children: [
                                              Container(
                                                child: Text(
                                                  "3",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                          fontSize:
                                                              screenSize.width /
                                                                  120,
                                                          color: blueColor),
                                                ),
                                              ),
                                              SizedBox(
                                                width: screenSize.width / 128,
                                              ),
                                              Container(
                                                height: screenSize.height / 48,
                                                width: screenSize.width / 13.24,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                192),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color: Color.fromRGBO(
                                                            0, 0, 0, 0.16),
                                                        offset: Offset(
                                                          3.0,
                                                          3.0,
                                                        ),
                                                        blurRadius: 6.0,
                                                        spreadRadius: 2.0,
                                                      ),
                                                      BoxShadow(
                                                        color: Colors.white,
                                                        offset:
                                                            Offset(0.0, 0.0),
                                                        blurRadius: 0.0,
                                                        spreadRadius: 0.0,
                                                      ),
                                                    ],
                                                    color: Colors.white),
                                                child: Container(
                                                  height:
                                                      screenSize.height / 48,
                                                  width:
                                                      screenSize.width / 13.24,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width /
                                                                  192),
                                                      color: themeColor),
                                                ),
                                              )
                                            ]),
                                            SizedBox(
                                              height: screenSize.height / 96.1,
                                            ),
                                            Row(children: [
                                              Container(
                                                child: Text(
                                                  "2",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                          fontSize:
                                                              screenSize.width /
                                                                  120,
                                                          color: blueColor),
                                                ),
                                              ),
                                              SizedBox(
                                                width: screenSize.width / 128,
                                              ),
                                              Container(
                                                height:
                                                    screenSize.height / 48.05,
                                                width: screenSize.width / 13.24,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                192),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color: Color.fromRGBO(
                                                            0, 0, 0, 0.16),
                                                        offset: Offset(
                                                          3.0,
                                                          3.0,
                                                        ),
                                                        blurRadius: 6.0,
                                                        spreadRadius: 2.0,
                                                      ),
                                                      BoxShadow(
                                                        color: Colors.white,
                                                        offset:
                                                            Offset(0.0, 0.0),
                                                        blurRadius: 0.0,
                                                        spreadRadius: 0.0,
                                                      ),
                                                    ],
                                                    color: Colors.white),
                                                child: Container(
                                                  height:
                                                      screenSize.height / 48.05,
                                                  width:
                                                      screenSize.width / 22.58,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width /
                                                                  192),
                                                      color: themeColor),
                                                ),
                                              )
                                            ]),
                                            SizedBox(
                                              height: screenSize.height / 96.1,
                                            ),
                                            Row(children: [
                                              Container(
                                                child: Text(
                                                  "1",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                          fontSize:
                                                              screenSize.width /
                                                                  120,
                                                          color: blueColor),
                                                ),
                                              ),
                                              SizedBox(
                                                width: screenSize.width / 128,
                                              ),
                                              Container(
                                                height:
                                                    screenSize.height / 48.05,
                                                width: screenSize.width / 13.24,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                192),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color: Color.fromRGBO(
                                                            0, 0, 0, 0.16),
                                                        offset: Offset(
                                                          3.0,
                                                          3.0,
                                                        ),
                                                        blurRadius: 6.0,
                                                        spreadRadius: 2.0,
                                                      ),
                                                      BoxShadow(
                                                        color: Colors.white,
                                                        offset:
                                                            Offset(0.0, 0.0),
                                                        blurRadius: 0.0,
                                                        spreadRadius: 0.0,
                                                      ),
                                                    ],
                                                    color: Colors.white),
                                                child: Container(
                                                  height:
                                                      screenSize.height / 48.05,
                                                  width:
                                                      screenSize.width / 22.58,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width /
                                                                  192),
                                                      color: themeColor),
                                                ),
                                              )
                                            ]),
                                          ],
                                        ),
                                      )
                                    ]),
                              )
                            ]),
                          ),
                          SizedBox(
                            height: screenSize.height / 2.40,
                            child: Column(children: [
                              Container(
                                margin: EdgeInsets.only(
                                    left: screenSize.width / 96,
                                    right: screenSize.width / 96,
                                    top: screenSize.height / 96.1),
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "User Reviews",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width / 147.6,
                                            fontWeight: FontWeight.normal,
                                            color: Colors.black),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          scaffoldKey.currentState!
                                              .showBottomSheet((context) =>
                                                  StatefulBuilder(builder:
                                                      (BuildContext context,
                                                          StateSetter
                                                              setState) {
                                                    return DraggableScrollableSheet(
                                                      expand: false,
                                                      maxChildSize: 0.8,
                                                      minChildSize: 0.75,
                                                      initialChildSize: 0.75,
                                                      builder: (BuildContext
                                                              context,
                                                          ScrollController
                                                              scrollController) {
                                                        return AllReviews(
                                                            scrollController);
                                                      },
                                                    );
                                                  }));
                                        },
                                        child: Transform.rotate(
                                            angle: 180 * math.pi / 180,
                                            child:
                                                const Icon(Icons.arrow_back)),
                                      )
                                    ]),
                              ),
                              RefreshIndicator(
                                onRefresh: () {
                                  return getReviews();
                                },
                                child: Container(
                                  // height: 280,
                                  margin: EdgeInsets.only(
                                      left: screenSize.width / 128,
                                      right: screenSize.width / 128,
                                      top: screenSize.height / 96.1),
                                  child: MediaQuery.removePadding(
                                    context: context,
                                    removeTop: true,
                                    child: FutureBuilder(
                                        future: getReviews(),
                                        builder: (BuildContext ctx,
                                                AsyncSnapshot<List> item) =>
                                            item.hasData
                                                ? item.data!.isNotEmpty
                                                    ? ListView.builder(
                                                        itemCount: ratingReviewData
                                                                    .length >=
                                                                3
                                                            ? 3
                                                            : ratingReviewData
                                                                .length,
                                                        shrinkWrap: true,
                                                        physics:
                                                            const NeverScrollableScrollPhysics(),
                                                        itemBuilder:
                                                            (context, index) {
                                                          return Container(
                                                            padding: EdgeInsets
                                                                .all(screenSize
                                                                        .width /
                                                                    128),
                                                            margin: EdgeInsets.only(
                                                                bottom: screenSize
                                                                        .height /
                                                                    96.1),
                                                            // height: 130,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      screenSize
                                                                              .width /
                                                                          192),
                                                              color:
                                                                  Colors.white,
                                                              boxShadow: const [
                                                                BoxShadow(
                                                                  color: Color
                                                                      .fromRGBO(
                                                                          0,
                                                                          0,
                                                                          0,
                                                                          0.16),
                                                                  offset:
                                                                      Offset(
                                                                    3.0,
                                                                    3.0,
                                                                  ),
                                                                  blurRadius:
                                                                      6.0,
                                                                  spreadRadius:
                                                                      2.0,
                                                                ),
                                                                BoxShadow(
                                                                  color: Colors
                                                                      .white,
                                                                  offset:
                                                                      Offset(
                                                                          0.0,
                                                                          0.0),
                                                                  blurRadius:
                                                                      0.0,
                                                                  spreadRadius:
                                                                      0.0,
                                                                ),
                                                              ],
                                                            ),
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Container(
                                                                        child: Row(
                                                                            children: [
                                                                              Container(
                                                                                height: screenSize.height / 21.84,
                                                                                width: screenSize.width / 43.63,
                                                                                decoration: BoxDecoration(shape: BoxShape.circle, image: DecorationImage(image: NetworkImage("${MainUrl}customer-image/${ratingReviewData[index].photo}"), fit: BoxFit.fill)),
                                                                              ),
                                                                              SizedBox(
                                                                                width: screenSize.width / 128,
                                                                              ),
                                                                              Container(
                                                                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                                                                  Text(
                                                                                    ratingReviewData[index].name.toString(),
                                                                                    style: TextStyle(fontSize: screenSize.width / 137.1, fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                  Container(
                                                                                    child: RatingBarIndicator(
                                                                                      rating: double.parse(ratingReviewData[index].rating.toString()),
                                                                                      itemBuilder: (context, index) => const Icon(
                                                                                        Icons.star,
                                                                                        color: Colors.amber,
                                                                                      ),
                                                                                      itemCount: 5,
                                                                                      itemSize: 13.0,
                                                                                      direction: Axis.horizontal,
                                                                                    ),
                                                                                  ),
                                                                                ]),
                                                                              ),
                                                                            ]),
                                                                      ),
                                                                      Container(
                                                                        child: PopupMenuButton<
                                                                            int>(
                                                                          itemBuilder:
                                                                              (context) => [
                                                                            // popupmenu item 1
                                                                            PopupMenuItem(
                                                                              value: 1,
                                                                              // row has two child icon and text.
                                                                              child: Row(
                                                                                children: const [
                                                                                  Text("Report Review")
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            // popupmenu item 2
                                                                            PopupMenuItem(
                                                                              value: 2,
                                                                              // row has two child icon and text
                                                                              child: Row(
                                                                                children: const [
                                                                                  Text("Block Review")
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                          offset: const Offset(
                                                                              10,
                                                                              40),
                                                                          color:
                                                                              Colors.white,
                                                                          elevation:
                                                                              4,
                                                                        ),
                                                                        //  Icon(
                                                                        //   Icons.more_vert,
                                                                        //   size: 28,
                                                                        // ),
                                                                      )
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                    height: screenSize
                                                                            .height /
                                                                        96.1,
                                                                  ),
                                                                  Container(
                                                                    child: Text(
                                                                      ratingReviewData[
                                                                              index]
                                                                          .review
                                                                          .toString(),
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      style: TextStyle(
                                                                          fontSize: screenSize.width /
                                                                              160,
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.53)),
                                                                    ),
                                                                  )
                                                                ]),
                                                          );
                                                        })
                                                    : const Center(
                                                        child: Text(
                                                            "No Data Found"),
                                                      )
                                                : SizedBox(
                                                    height: screenSize.height /
                                                        9.61,
                                                    child: Center(
                                                      child:
                                                          CircularProgressIndicator(),
                                                    ),
                                                  )),
                                  ),
                                ),
                              ),
                            ]),
                          ),
                          SizedBox(
                            height: screenSize.height / 96.1,
                          ),
                          Container(
                            padding: EdgeInsets.all(screenSize.width / 128),
                            margin: EdgeInsets.only(
                                bottom: screenSize.height / 96.1,
                                left: screenSize.width / 128,
                                right: screenSize.width / 128),
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(screenSize.width / 192),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(
                                  color: Color.fromRGBO(0, 0, 0, 0.16),
                                  offset: Offset(
                                    3.0,
                                    3.0,
                                  ),
                                  blurRadius: 6.0,
                                  spreadRadius: 2.0,
                                ),
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(0.0, 0.0),
                                  blurRadius: 0.0,
                                  spreadRadius: 0.0,
                                ),
                              ],
                            ),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [
                                      Icon(Icons.calendar_month,
                                          size: screenSize.width / 87.2,
                                          color: Color.fromRGBO(68, 68, 68, 1)),
                                      SizedBox(
                                        width: screenSize.width / 106.6,
                                      ),
                                      Text(
                                        "Availability",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width / 137.1,
                                            fontWeight: FontWeight.bold,
                                            color:
                                                Color.fromRGBO(68, 68, 68, 1)),
                                      )
                                    ]),
                                  ),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    size: screenSize.width / 106.6,
                                  )
                                ]),
                          ),
                          SizedBox(
                            height: screenSize.height / 96.1,
                          ),
                          isfollowing != true
                              ? GestureDetector(
                                  onTap: () async {
                                    SharedPreferences pref =
                                        await SharedPreferences.getInstance();
                                    String? uid = pref.getString("uid");
                                    followVendor(uid!, vid, !isfollowing);
                                  },
                                  child: Container(
                                    padding:
                                        EdgeInsets.all(screenSize.width / 128),
                                    margin: EdgeInsets.only(
                                        bottom: screenSize.height / 96.1,
                                        left: screenSize.width / 128,
                                        right: screenSize.width / 128),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          screenSize.width / 192),
                                      color: Colors.white,
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 0.16),
                                          offset: Offset(
                                            3.0,
                                            3.0,
                                          ),
                                          blurRadius: 6.0,
                                          spreadRadius: 2.0,
                                        ),
                                        BoxShadow(
                                          color: Colors.white,
                                          offset: Offset(0.0, 0.0),
                                          blurRadius: 0.0,
                                          spreadRadius: 0.0,
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            child: Row(children: [
                                              Transform.rotate(
                                                angle: 0,
                                                child: Icon(
                                                    Icons.push_pin_sharp,
                                                    size: screenSize.width /
                                                        87.27,
                                                    color: Color.fromRGBO(
                                                        68, 68, 68, 1)),
                                              ),
                                              SizedBox(
                                                width: screenSize.width / 192,
                                              ),
                                              Text(
                                                "Follow ${results[0].name}",
                                                style: GoogleFonts.merriweather(
                                                    fontSize: screenSize.width /
                                                        137.1,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color.fromRGBO(
                                                        68, 68, 68, 1)),
                                              )
                                            ]),
                                          ),
                                          Icon(
                                            Icons.arrow_forward_ios,
                                            size: screenSize.width / 106.6,
                                          )
                                        ]),
                                  ),
                                )
                              : Container(),
                          SizedBox(
                            height: screenSize.height / 96.1,
                          ),
                          GestureDetector(
                            onTap: () async {
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                              if (pref.getString('uid') != null) {
                                if (_walletList.length >= 1) {
                                  if (double.parse(
                                          _walletList[0].walletamount) >=
                                      100.0) {
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) =>
                                          VideoCallAndAudioCallModal(
                                        name: results[0].name,
                                        image: results[0].photo,
                                        vid: results[0].id.toString(),
                                        audioCallPrice:
                                            results[0].audicallprice,
                                        videoCallPrice:
                                            results[0].audicallprice,
                                      ),
                                    );
                                  } else {
                                    showDialog<void>(
                                      context: context,
                                      barrierDismissible:
                                          false, // user must tap button!
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          elevation: 0.6,
                                          contentPadding: EdgeInsets.only(
                                            left: screenSize.width / 96,
                                            right: screenSize.width / 192,
                                            top: screenSize.height / 192.2,
                                            bottom: screenSize.height / 192.2,
                                          ),
                                          titlePadding: EdgeInsets.only(
                                            left: screenSize.width / 96,
                                            right: screenSize.width / 192,
                                            top: screenSize.height / 192.2,
                                            bottom: screenSize.height / 192.2,
                                          ),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              screenSize.width / 128,
                                            ),
                                          ),
                                          title: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              const Text(
                                                'Recharge Plan',
                                              ),
                                              IconButton(
                                                icon: const Icon(
                                                  Icons.close,
                                                  color: Colors.red,
                                                ),
                                                onPressed: () {
                                                  Navigator.of(
                                                    context,
                                                  ).pop();
                                                },
                                              )
                                            ],
                                          ),
                                          content: const RechargeNow(),
                                        );
                                      },
                                    );
                                  }
                                } else {
                                  showDialog<void>(
                                    context: context,
                                    barrierDismissible:
                                        false, // user must tap button!
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        elevation: 0.6,
                                        contentPadding: EdgeInsets.only(
                                          left: screenSize.width / 96,
                                          right: screenSize.width / 192,
                                          top: screenSize.height / 192.2,
                                          bottom: screenSize.height / 192.2,
                                        ),
                                        titlePadding: EdgeInsets.only(
                                          left: screenSize.width / 96,
                                          right: screenSize.width / 192,
                                          top: screenSize.height / 192.2,
                                          bottom: screenSize.height / 192.2,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            screenSize.width / 128,
                                          ),
                                        ),
                                        title: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('Recharge Plan'),
                                            IconButton(
                                              icon: const Icon(
                                                Icons.close,
                                                color: Colors.red,
                                              ),
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                              },
                                            )
                                          ],
                                        ),
                                        content: const RechargeNow(),
                                      );
                                    },
                                  );
                                }
                              } else {
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return const LoginModel();
                                  },
                                );
                              }
                            },
                            child: Container(
                              padding: EdgeInsets.all(screenSize.width / 128),
                              margin: EdgeInsets.only(
                                  bottom: screenSize.height / 96.1,
                                  left: screenSize.width / 128,
                                  right: screenSize.width / 128),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    screenSize.width / 192),
                                color: Colors.white,
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.16),
                                    offset: Offset(
                                      3.0,
                                      3.0,
                                    ),
                                    blurRadius: 6.0,
                                    spreadRadius: 2.0,
                                  ),
                                  BoxShadow(
                                    color: Colors.white,
                                    offset: Offset(0.0, 0.0),
                                    blurRadius: 0.0,
                                    spreadRadius: 0.0,
                                  ),
                                ],
                              ),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      child: Row(children: [
                                        Icon(Icons.video_call,
                                            size: screenSize.width / 87.27,
                                            color:
                                                Color.fromRGBO(68, 68, 68, 1)),
                                        SizedBox(
                                          width: screenSize.width / 192,
                                        ),
                                        Text(
                                          "Audio Call & Video Call",
                                          style: GoogleFonts.merriweather(
                                              fontSize:
                                                  screenSize.width / 137.1,
                                              fontWeight: FontWeight.bold,
                                              color: Color.fromRGBO(
                                                  68, 68, 68, 1)),
                                        )
                                      ]),
                                    ),
                                    Icon(
                                      Icons.arrow_forward_ios,
                                      size: screenSize.width / 106.6,
                                    )
                                  ]),
                            ),
                          ),
                          SizedBox(
                            height: screenSize.height / 96.1,
                          ),
                          GestureDetector(
                            onTap: () async {
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                              if (pref.getString('uid') != null) {
                                if (_walletList.length >= 1) {
                                  SmartDialog.show(builder: (_) {
                                    return SendGift(
                                        _walletList[0].walletamount.toString());
                                  });
                                } else {
                                  SmartDialog.show(builder: (_) {
                                    return SendGift("0");
                                  });
                                }
                              } else {
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return const LoginModel();
                                  },
                                );
                              }
                            },
                            child: Container(
                              padding: EdgeInsets.all(screenSize.width / 128),
                              margin: EdgeInsets.only(
                                  bottom: screenSize.height / 96.1,
                                  left: screenSize.width / 128,
                                  right: screenSize.width / 128),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    screenSize.width / 192),
                                color: Colors.white,
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.16),
                                    offset: Offset(
                                      3.0,
                                      3.0,
                                    ),
                                    blurRadius: 6.0,
                                    spreadRadius: 2.0,
                                  ),
                                  BoxShadow(
                                    color: Colors.white,
                                    offset: Offset(0.0, 0.0),
                                    blurRadius: 0.0,
                                    spreadRadius: 0.0,
                                  ),
                                ],
                              ),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      child: Row(children: [
                                        Icon(Icons.diamond,
                                            size: screenSize.width / 87.27,
                                            color:
                                                Color.fromRGBO(68, 68, 68, 1)),
                                        SizedBox(
                                          width: screenSize.width / 192,
                                        ),
                                        Text(
                                          "Send Gift to ${results[0].name}",
                                          style: GoogleFonts.merriweather(
                                              fontSize:
                                                  screenSize.width / 137.1,
                                              fontWeight: FontWeight.bold,
                                              color: Color.fromRGBO(
                                                  68, 68, 68, 1)),
                                        )
                                      ]),
                                    ),
                                    Icon(
                                      Icons.arrow_forward_ios,
                                      size: screenSize.width / 106.6,
                                    )
                                  ]),
                            ),
                          ),
                          SizedBox(
                            height: screenSize.height / 96.1,
                          ),
                        ],
                      ),
                    ),
                    Container(
                        width: MediaQuery.of(context).size.width * 0.4,
                        child: VendorAvailabilityWidget(result: result)),
                  ]),
            ),
            BottomFooter()
          ],
        )),
      ),
      bottomNavigationBar: Container(
        height: screenSize.height / 19.22,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(screenSize.width / 192),
              topRight: Radius.circular(screenSize.width / 192)),
          border: Border.all(
            width: screenSize.width / 1920,
            color: Colors.transparent,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () async {
                SharedPreferences pref = await SharedPreferences.getInstance();
                if (pref.getString('uid') != null) {
                  if (_walletList.length >= 1) {
                    if (double.parse(_walletList[0].walletamount) >= 100.0) {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) =>
                            VideoCallAndAudioCallModal(
                          name: results[0].name,
                          image: results[0].photo,
                          vid: results[0].id.toString(),
                          audioCallPrice: results[0].audicallprice,
                          videoCallPrice: results[0].audicallprice,
                        ),
                      );
                    } else {
                      showDialog<void>(
                        context: context,
                        barrierDismissible: false, // user must tap button!
                        builder: (BuildContext context) {
                          return AlertDialog(
                            elevation: 0.6,
                            contentPadding: EdgeInsets.only(
                              left: screenSize.width / 96,
                              right: screenSize.width / 192,
                              top: screenSize.height / 192.2,
                              bottom: screenSize.height / 192.2,
                            ),
                            titlePadding: EdgeInsets.only(
                              left: screenSize.width / 96,
                              right: screenSize.width / 192,
                              top: screenSize.height / 192.2,
                              bottom: screenSize.height / 192.2,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                screenSize.width / 128,
                              ),
                            ),
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text(
                                  'Recharge Plan',
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.close,
                                    color: Colors.red,
                                  ),
                                  onPressed: () {
                                    Navigator.of(
                                      context,
                                    ).pop();
                                  },
                                )
                              ],
                            ),
                            content: const RechargeNow(),
                          );
                        },
                      );
                    }
                  } else {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 192,
                            top: screenSize.height / 192.2,
                            bottom: screenSize.height / 192.2,
                          ),
                          titlePadding: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 192,
                            top: screenSize.height / 192.2,
                            bottom: screenSize.height / 192.2,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              screenSize.width / 128,
                            ),
                          ),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Recharge Plan'),
                              IconButton(
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )
                            ],
                          ),
                          content: const RechargeNow(),
                        );
                      },
                    );
                  }
                } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return const LoginModel();
                    },
                  );
                }
              },
              child: Container(
                margin: EdgeInsets.only(
                  left: screenSize.width / 192,
                  right: screenSize.width / 384,
                ),
                width: MediaQuery.of(
                      context,
                    ).size.width *
                    0.1,
                height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    screenSize.width / 384,
                  ),
                  color: themeColor,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.phone,
                      color: blueColor,
                      size: screenSize.width / 96,
                    ),
                    Text(
                      "call",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width / 137.1,
                        color: blueColor,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () async {
                SharedPreferences pref = await SharedPreferences.getInstance();
                if (pref.getString('uid') != null) {
                  if (_walletList.length >= 1) {
                    if (double.parse(_walletList[0].walletamount) >= 100.0) {
                      Map<String, String> data = {
                        "userid": pref
                            .getString(
                              "uid",
                            )
                            .toString(),
                        "vid": results[0].id.toString(),
                        "orderfor": "chat",
                        "orderstatus": "created",
                        "createdat": DateTime.now().toString()
                      };
                      _createOrderForChat(
                        data,
                        results[0].photo,
                        results[0].name,
                      );
                    }
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 192,
                            top: screenSize.height / 192.2,
                            bottom: screenSize.height / 192.2,
                          ),
                          titlePadding: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 192,
                            top: screenSize.height / 192.2,
                            bottom: screenSize.height / 192.2,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              screenSize.width / 128,
                            ),
                          ),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Recharge Plan'),
                              IconButton(
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(
                                    context,
                                  ).pop();
                                },
                              )
                            ],
                          ),
                          content: const RechargeNow(),
                        );
                      },
                    );
                  } else {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 192,
                            top: screenSize.height / 192.2,
                            bottom: screenSize.height / 192.2,
                          ),
                          titlePadding: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 192,
                            top: screenSize.height / 192.2,
                            bottom: screenSize.height / 192.2,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              screenSize.width / 128,
                            ),
                          ),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Recharge Plan'),
                              IconButton(
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(
                                    context,
                                  ).pop();
                                },
                              )
                            ],
                          ),
                          content: const RechargeNow(),
                        );
                      },
                    );
                  }
                } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return const LoginModel();
                    },
                  );
                }
              },
              child: Container(
                margin: EdgeInsets.only(
                  left: screenSize.width / 384,
                  right: screenSize.width / 192,
                ),
                width: screenSize.width / 12,
                height: screenSize.height / 22.88,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    screenSize.height / 192.2,
                  ),
                  color: themeColor,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Icon(
                      Icons.message,
                      color: blueColor,
                      size: screenSize.width / 96,
                    ),
                    Text(
                      "Chat",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width / 137.1,
                        color: blueColor,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  final imageURL = 'https://tts.net.in/wp-content/uploads/2022/03/flutter.png';
  // final controller = ScreenshotController();

  Widget MobileVendorProfile() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Column(
        children: [
          RefreshIndicator(
            onRefresh: () {
              return getVendorDetails();
            },
            child: FutureBuilder(
              future: getVendorDetails(),
              builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                      .hasData
                  ? item.data!.isNotEmpty
                      ? Container(
                          height: MediaQuery.of(context).size.height / 1.28,
                          width: MediaQuery.of(context).size.width,
                          color: themeColor,
                          margin:
                              EdgeInsets.only(top: screenSize.height / 30.24),
                          child: Column(
                            children: [
                              SizedBox(
                                // margin:
                                //     const EdgeInsets.only(left: 14, right: 14),
                                height: screenSize.height / 15.12,
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        child:  Icon(
                                          Icons.arrow_back,
                                          size: screenSize.width/14.4,
                                        ),
                                      ),
                                      IconButton(
                                        icon: Icon(
                                          Icons.share,
                                          size: screenSize.width / 14.4,
                                        ),
                                        onPressed: () async {
                                          // final image = await controller
                                          //     .captureFromWidget(
                                          //   buildImage(),
                                          // );
                                          // if (image == null) return;
                                          // await saveImage(image);
                                          // saveAndShare(image);
                                          // _takeScreenShotAndShare();
                                          // screenshotController
                                          //     .capture(
                                          //   delay: const Duration(
                                          //     milliseconds: 10,
                                          //   ),
                                          // )
                                          //     .then((capturedImage) async {
                                          //   // ShowCapturedWidget(
                                          //   //     context, capturedImage!);
                                          //   await Share.shareFiles(
                                          //     ['$capturedImage'],
                                          //   );
                                          // }).catchError((onError) {
                                          //   print(onError);
                                          // });
                                        },
                                      )
                                    ]),
                              ),

                              // controller: screenshotController,

                              SizedBox(
                                height: 565.625,
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Positioned(
                                      top: screenSize.height / 151.2,
                                      child: Container(
                                        height: screenSize.height / 7.13,
                                        width: screenSize.width / 3.39,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                              screenSize.width / 6),
                                          border: Border.all(
                                              width: screenSize.width / 180,
                                              color: lightblueColor),
                                          image: DecorationImage(
                                            image: NetworkImage(
                                              '${MainUrl}vendor-image/${results[0].photo}',
                                            ),
                                            fit: BoxFit.contain,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                        top: screenSize.height / 151.2,
                                        left: screenSize.width / 1.81,
                                        child: Container(
                                          height: screenSize.height / 30.24,
                                          width: screenSize.width / 14.4,
                                          decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/SVG/star2-2x.png"),
                                                  fit: BoxFit.fill)),
                                        )),
                                    Positioned(
                                        top: 135,
                                        child: Container(
                                          child: Column(children: [
                                            Text(
                                              results[0].name,
                                              style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 18,
                                                  color: Color.fromRGBO(
                                                      17, 81, 115, 1),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 75.6,
                                            ),
                                            Text(
                                              results[0].primaryskills,
                                              style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 25.71,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 75.6,
                                            ),
                                            Text(
                                              results[0].language,
                                              style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 25.71,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 75.6,
                                            ),
                                            Text(
                                              "Exp: 5 Years",
                                              style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 25.7,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 75.6,
                                            ),
                                            Text(
                                              "₹ ${results[0].audicallprice} / min",
                                              style: GoogleFonts.merriweather(
                                                fontSize: screenSize.width / 30,
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 44.4,
                                            ),
                                            GestureDetector(
                                              onTap: () async {
                                                SharedPreferences pref =
                                                    await SharedPreferences
                                                        .getInstance();
                                                String? uid =
                                                    pref.getString("uid");
                                                if (pref.getString('uid') !=
                                                    null) {
                                                  followVendor(
                                                    uid!,
                                                    vid,
                                                    !isfollowing,
                                                  );
                                                } else {
                                                  showModalBottomSheet(
                                                    isDismissible: false,
                                                    context: context,
                                                    isScrollControlled: true,
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                screenSize
                                                                        .width /
                                                                    36)),
                                                    builder:
                                                        (BuildContext context) {
                                                      return const LoginModel();
                                                    },
                                                  );
                                                }
                                              },
                                              child: Container(
                                                height:
                                                    screenSize.height / 20.43,
                                                width: screenSize.width / 2.97,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width /
                                                                8),
                                                    color: const Color.fromRGBO(
                                                        17, 81, 115, 1)),
                                                child: Center(
                                                  child: isfollowing != true
                                                      ? Text(
                                                          "Follow",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          24),
                                                        )
                                                      : Text(
                                                          "Following",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          24),
                                                        ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: screenSize.height / 37.8,
                                            ),
                                            SizedBox(
                                              width: screenSize.width / 1.02,
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Chat",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                            fontSize: screenSize
                                                                    .width /
                                                                32.72,
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              75.6,
                                                        ),
                                                        Text(
                                                          "49k",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                            fontSize: screenSize
                                                                    .width /
                                                                18,
                                                            color:
                                                                Color.fromRGBO(
                                                              17,
                                                              81,
                                                              115,
                                                              1,
                                                            ),
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              151.2,
                                                        ),
                                                        Text(
                                                          "mins",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          40,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "calls",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          32.7,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              75.6,
                                                        ),
                                                        Text(
                                                          "49k",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          18,
                                                                  color: Color
                                                                      .fromRGBO(
                                                                          17,
                                                                          81,
                                                                          115,
                                                                          1),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              151.2,
                                                        ),
                                                        Text(
                                                          "mins",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          40,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Video Chat",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          32.7,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              75.6,
                                                        ),
                                                        Text(
                                                          "500",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                            fontSize: screenSize
                                                                    .width /
                                                                18,
                                                            color:
                                                                Color.fromRGBO(
                                                              17,
                                                              81,
                                                              115,
                                                              1,
                                                            ),
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              151.2,
                                                        ),
                                                        Text(
                                                          "mins",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                            fontSize: screenSize
                                                                    .width /
                                                                40,
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Followers",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          32.7,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              75.6,
                                                        ),
                                                        Text(
                                                          "2k",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                                  fontSize:
                                                                      screenSize
                                                                              .width /
                                                                          18,
                                                                  color: Color
                                                                      .fromRGBO(
                                                                          17,
                                                                          81,
                                                                          115,
                                                                          1),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                        ),
                                                        SizedBox(
                                                          height: screenSize
                                                                  .height /
                                                              151.2,
                                                        ),
                                                        Text(
                                                          "Following",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                            fontSize: screenSize
                                                                    .width /
                                                                40,
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ]),
                                                    )
                                                  ]),
                                            )
                                          ]),
                                        )),
                                    Positioned(
                                      top: screenSize.height / 1.82,
                                      left: 0,
                                      width: screenSize.width / 0.962,
                                      height: screenSize.height / 2.42,
                                      child: Container(
                                        decoration: const BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(
                                              "assets/SVG/Path 2-2x.png",
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      top: screenSize.height / 1.80,
                                      left: screenSize.width / 2.68,
                                      width: screenSize.width / 0.962,
                                      height: screenSize.height / 2.42,
                                      child: Container(
                                        decoration: const BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(
                                              "assets/SVG/Path 4-2x.png",
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      top: screenSize.height / 1.81,
                                      left: 0.63,
                                      width: screenSize.width / 0.873,
                                      height: screenSize.height / 1.68,
                                      child: Container(
                                        decoration: const BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(
                                              "assets/SVG/Path 3-2x.png",
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          margin: EdgeInsets.only(
                                            top: screenSize.height / 19,
                                            left: screenSize.width / 18,
                                            right: screenSize.width / 5.14,
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "About ${results[0].name}",
                                                textAlign: TextAlign.center,
                                                style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 27.6,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              SizedBox(
                                                height:
                                                    screenSize.height / 37.8,
                                              ),
                                              Text(
                                                results[0].aboutus,
                                                textAlign: TextAlign.left,
                                                style: GoogleFonts.merriweather(
                                                  fontSize:
                                                      screenSize.width / 27.69,
                                                  fontWeight: FontWeight.normal,
                                                  color: Color.fromRGBO(
                                                    17,
                                                    81,
                                                    115,
                                                    1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        )
                      : const Center(
                          child: Text(
                            "No Data Found",
                          ),
                        )
                  : SizedBox(
                      height: screenSize.height / 0.9,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    ),
            ),
          ),
          SizedBox(
            height: screenSize.height / 34,
          ),
          Container(
            margin: EdgeInsets.only(
              left: screenSize.width / 24,
              right: screenSize.width / 24,
            ),
            height: screenSize.height / 3.63,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                screenSize.width / 36,
              ),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                  color: Color.fromRGBO(
                    0,
                    0,
                    0,
                    0.16,
                  ),
                  offset: Offset(
                    3.0,
                    3.0,
                  ),
                  blurRadius: 6.0,
                  spreadRadius: 2.0,
                ),
                BoxShadow(
                  color: Colors.white,
                  offset: Offset(
                    0.0,
                    0.0,
                  ),
                  blurRadius: 0.0,
                  spreadRadius: 0.0,
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(
                    left: screenSize.width / 24,
                    right: screenSize.width / 24,
                    top: screenSize.height / 37.5,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Rating & Reviews",
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 27.69,
                          fontWeight: FontWeight.normal,
                          color: Colors.black,
                        ),
                      ),
                      Transform.rotate(
                        angle: 180 * math.pi / 180,
                        child: const Icon(
                          Icons.arrow_back,
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(
                    top: screenSize.height / 100,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        width: screenSize.width / 3.6,
                        child: Column(
                          children: [
                            Text(
                              "4.93",
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 9.47,
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                              ),
                            ),
                            SizedBox(
                              height: screenSize.height / 75.6,
                            ),
                            Container(
                              child: RatingBarIndicator(
                                rating: 4.5,
                                itemBuilder: (
                                  context,
                                  index,
                                ) =>
                                    const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                itemCount: 5,
                                itemSize: 13.0,
                                direction: Axis.horizontal,
                              ),
                            ),
                            SizedBox(
                              height: screenSize.height / 75.6,
                            ),
                            Text(
                              "734 Reviews",
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 32.7,
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  child: Text(
                                    "5",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 22.5,
                                      color: blueColor,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: screenSize.width / 24,
                                ),
                                Container(
                                  height: screenSize.height / 37.8,
                                  width: screenSize.width / 2.48,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          screenSize.width / 36),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 0.16),
                                          offset: Offset(
                                            3.0,
                                            3.0,
                                          ),
                                          blurRadius: 6.0,
                                          spreadRadius: 2.0,
                                        ),
                                        BoxShadow(
                                          color: Colors.white,
                                          offset: Offset(0.0, 0.0),
                                          blurRadius: 0.0,
                                          spreadRadius: 0.0,
                                        ),
                                      ],
                                      color: Colors.white),
                                  child: Container(
                                    height: screenSize.width / 37.8,
                                    width: screenSize.width / 4.23,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            screenSize.width / 36),
                                        color: themeColor),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: screenSize.height / 75.6,
                            ),
                            Row(
                              children: [
                                Container(
                                  child: Text(
                                    "4",
                                    style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 12.5,
                                        color: blueColor),
                                  ),
                                ),
                                SizedBox(
                                  width: screenSize.width / 24,
                                ),
                                Container(
                                  height: screenSize.height / 37.8,
                                  width: screenSize.width / 2.48,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          screenSize.width / 36),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 0.16),
                                          offset: Offset(
                                            3.0,
                                            3.0,
                                          ),
                                          blurRadius: 6.0,
                                          spreadRadius: 2.0,
                                        ),
                                        BoxShadow(
                                          color: Colors.white,
                                          offset: Offset(0.0, 0.0),
                                          blurRadius: 0.0,
                                          spreadRadius: 0.0,
                                        ),
                                      ],
                                      color: Colors.white),
                                  child: Container(
                                    height: screenSize.height / 37.8,
                                    width: screenSize.width / 4.23,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            screenSize.width / 36),
                                        color: themeColor),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: screenSize.height / 75.6,
                            ),
                            Row(
                              children: [
                                Container(
                                  child: Text(
                                    "3",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 22.5,
                                      color: blueColor,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: screenSize.width / 24,
                                ),
                                Container(
                                  height: screenSize.height / 37.8,
                                  width: screenSize.width / 2.48,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                        screenSize.width / 36),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ),
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ),
                                    ],
                                    color: Colors.white,
                                  ),
                                  child: Container(
                                    height: screenSize.height / 37.8,
                                    width: screenSize.width / 4.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          screenSize.width / 36),
                                      color: themeColor,
                                    ),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: screenSize.height / 75.6,
                            ),
                            Row(
                              children: [
                                Container(
                                  child: Text(
                                    "2",
                                    style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 22.5,
                                        color: blueColor),
                                  ),
                                ),
                                SizedBox(
                                  width: screenSize.width / 24,
                                ),
                                Container(
                                  height: screenSize.height / 37.8,
                                  width: screenSize.width / 2.48,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          screenSize.width / 36),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 0.16),
                                          offset: Offset(
                                            3.0,
                                            3.0,
                                          ),
                                          blurRadius: 6.0,
                                          spreadRadius: 2.0,
                                        ),
                                        BoxShadow(
                                          color: Colors.white,
                                          offset: Offset(0.0, 0.0),
                                          blurRadius: 0.0,
                                          spreadRadius: 0.0,
                                        ),
                                      ],
                                      color: Colors.white),
                                  child: Container(
                                    height: screenSize.height / 37.8,
                                    width: screenSize.width / 4.23,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            screenSize.width / 36),
                                        color: themeColor),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: screenSize.height / 75.6,
                            ),
                            Row(
                              children: [
                                Container(
                                  child: Text(
                                    "1",
                                    style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 22.5,
                                        color: blueColor),
                                  ),
                                ),
                                SizedBox(
                                  width: screenSize.width / 24,
                                ),
                                Container(
                                  height: screenSize.height / 37.8,
                                  width: screenSize.width / 2.48,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          screenSize.width / 36),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 0.16),
                                          offset: Offset(
                                            3.0,
                                            3.0,
                                          ),
                                          blurRadius: 6.0,
                                          spreadRadius: 2.0,
                                        ),
                                        BoxShadow(
                                          color: Colors.white,
                                          offset: Offset(0.0, 0.0),
                                          blurRadius: 0.0,
                                          spreadRadius: 0.0,
                                        ),
                                      ],
                                      color: Colors.white),
                                  child: Container(
                                    height: screenSize.height / 37.8,
                                    width: screenSize.width / 4.23,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            screenSize.width / 36),
                                        color: themeColor),
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          Container(
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(
                      left: screenSize.width / 18,
                      right: screenSize.width / 18,
                      top: screenSize.height / 25.2),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Photos",
                          style: GoogleFonts.merriweather(
                              fontSize: screenSize.width / 27.69,
                              fontWeight: FontWeight.normal,
                              color: Colors.black),
                        ),
                        Transform.rotate(
                            angle: 180 * math.pi / 180,
                            child: GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              VendorProfileWork(
                                                  wportdata: wportdata)));
                                },
                                child: const Icon(Icons.arrow_back)))
                      ]),
                ),
                RefreshIndicator(
                  onRefresh: () {
                    return getWorkPortfolio();
                  },
                  child: Container(
                    height: screenSize.height / 6.87,
                    margin: EdgeInsets.all(screenSize.width / 24),
                    child: FutureBuilder(
                      future: getWorkPortfolio(),
                      builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                          item.hasData
                              ? wportdata.length >= 1
                                  ? ListView.builder(
                                      itemCount: wportdata.length,
                                      scrollDirection: Axis.horizontal,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return GestureDetector(
                                          onTap: () async {
                                            await showDialog(
                                                context: context,
                                                builder: (_) => ImageDialog(
                                                    '${MainUrl}vendor-work/${wportdata[index].photo}'));
                                          },
                                          child: Container(
                                            height: screenSize.height / 6.87,
                                            width: screenSize.width / 3.27,
                                            margin: EdgeInsets.only(
                                                right: screenSize.width / 36),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      screenSize.width / 7.2),
                                              image: DecorationImage(
                                                image: NetworkImage(
                                                    '${MainUrl}vendor-work/${wportdata[index].photo}'),
                                                fit: BoxFit.fill,
                                              ),
                                            ),
                                          ),
                                        );
                                      })
                                  : const Center(
                                      child: Text(
                                        "No Data Found",
                                      ),
                                    )
                              : SizedBox(
                                  height: screenSize.height / 0.945,
                                  child: Center(
                                    child: CircularProgressIndicator(),
                                  ),
                                ),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            child: Column(children: [
              Container(
                margin: EdgeInsets.only(
                    left: screenSize.width / 18,
                    right: screenSize.width / 18,
                    top: screenSize.height / 75.6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "User Reviews",
                      style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 27.69,
                          fontWeight: FontWeight.normal,
                          color: Colors.black),
                    ),
                    InkWell(
                      onTap: () {
                        scaffoldKey.currentState!.showBottomSheet(
                          (context) => StatefulBuilder(
                            builder:
                                (BuildContext context, StateSetter setState) {
                              return DraggableScrollableSheet(
                                expand: false,
                                maxChildSize: 0.8,
                                minChildSize: 0.75,
                                initialChildSize: 0.75,
                                builder: (BuildContext context,
                                    ScrollController scrollController) {
                                  return AllReviews(scrollController);
                                },
                              );
                            },
                          ),
                        );
                      },
                      child: Transform.rotate(
                        angle: 180 * math.pi / 180,
                        child: const Icon(
                          Icons.arrow_back,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              RefreshIndicator(
                onRefresh: () {
                  return getReviews();
                },
                child: Container(
                  // height: 280,
                  margin: EdgeInsets.only(
                      left: screenSize.width / 24,
                      right: screenSize.width / 24,
                      top: screenSize.height / 75.6),
                  child: MediaQuery.removePadding(
                    context: context,
                    removeTop: true,
                    child: FutureBuilder(
                        future: getReviews(),
                        builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                            item.hasData
                                ? item.data!.isNotEmpty
                                    ? ListView.builder(
                                        itemCount: ratingReviewData.length >= 3
                                            ? 3
                                            : ratingReviewData.length,
                                        shrinkWrap: true,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemBuilder: (context, index) {
                                          return Container(
                                            padding: EdgeInsets.all(
                                                screenSize.width / 24),
                                            margin: EdgeInsets.only(
                                                bottom:
                                                    screenSize.height / 75.6),
                                            // height: 130,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      screenSize.width / 36),
                                              color: Colors.white,
                                              boxShadow: const [
                                                BoxShadow(
                                                  color: Color.fromRGBO(
                                                    0,
                                                    0,
                                                    0,
                                                    0.16,
                                                  ),
                                                  offset: Offset(
                                                    3.0,
                                                    3.0,
                                                  ),
                                                  blurRadius: 6.0,
                                                  spreadRadius: 2.0,
                                                ),
                                                BoxShadow(
                                                  color: Colors.white,
                                                  offset: Offset(
                                                    0.0,
                                                    0.0,
                                                  ),
                                                  blurRadius: 0.0,
                                                  spreadRadius: 0.0,
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Container(
                                                        child: Row(children: [
                                                          Container(
                                                            height: screenSize
                                                                    .height /
                                                                17.18,
                                                            width: screenSize
                                                                    .width /
                                                                8.18,
                                                            decoration: BoxDecoration(
                                                                shape: BoxShape
                                                                    .circle,
                                                                image: DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${MainUrl}customer-image/${ratingReviewData[index].photo}"),
                                                                    fit: BoxFit
                                                                        .fill)),
                                                          ),
                                                          SizedBox(
                                                            width: screenSize
                                                                    .width /
                                                                24,
                                                          ),
                                                          Container(
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                    ratingReviewData[
                                                                            index]
                                                                        .name
                                                                        .toString(),
                                                                    style: GoogleFonts.merriweather(
                                                                        fontSize:
                                                                            screenSize.width /
                                                                                25.71,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  Container(
                                                                    child:
                                                                        RatingBarIndicator(
                                                                      rating: double.parse(ratingReviewData[
                                                                              index]
                                                                          .rating
                                                                          .toString()),
                                                                      itemBuilder:
                                                                          (context, index) =>
                                                                              const Icon(
                                                                        Icons
                                                                            .star,
                                                                        color: Colors
                                                                            .amber,
                                                                      ),
                                                                      itemCount:
                                                                          5,
                                                                      itemSize:
                                                                          13.0,
                                                                      direction:
                                                                          Axis.horizontal,
                                                                    ),
                                                                  ),
                                                                ]),
                                                          ),
                                                        ]),
                                                      ),
                                                      Container(
                                                        child: PopupMenuButton<
                                                            int>(
                                                          itemBuilder:
                                                              (context) => [
                                                            // popupmenu item 1
                                                            PopupMenuItem(
                                                              value: 1,
                                                              // row has two child icon and text.
                                                              child: Row(
                                                                children: const [
                                                                  Text(
                                                                      "Report Review")
                                                                ],
                                                              ),
                                                            ),
                                                            // popupmenu item 2
                                                            PopupMenuItem(
                                                              value: 2,
                                                              // row has two child icon and text
                                                              child: Row(
                                                                children: const [
                                                                  Text(
                                                                      "Block Review")
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                          offset: const Offset(
                                                              10, 40),
                                                          color: Colors.white,
                                                          elevation: 4,
                                                        ),
                                                        //  Icon(
                                                        //   Icons.more_vert,
                                                        //   size: 28,
                                                        // ),
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: screenSize.height /
                                                        75.6,
                                                  ),
                                                  Container(
                                                    child: Text(
                                                      ratingReviewData[index]
                                                          .review
                                                          .toString(),
                                                      textAlign:
                                                          TextAlign.start,
                                                      style: GoogleFonts
                                                          .merriweather(
                                                              fontSize: screenSize
                                                                      .width /
                                                                  30,
                                                              color: Colors
                                                                  .black
                                                                  .withOpacity(
                                                                      0.53)),
                                                    ),
                                                  )
                                                ]),
                                          );
                                        })
                                    : const Center(
                                        child: Text("No Data Found"),
                                      )
                                : SizedBox(
                                    height: screenSize.height / 7.56,
                                    child: Center(
                                      child: CircularProgressIndicator(),
                                    ),
                                  )),
                  ),
                ),
              ),
            ]),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => VendorAvailabilityScreen(
                          Vendor: results, wallet: _walletList)));
            },
            child: Container(
              padding: EdgeInsets.all(screenSize.width / 24),
              margin: EdgeInsets.only(
                  bottom: screenSize.width / 75.6,
                  left: screenSize.width / 24,
                  right: screenSize.width / 24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(screenSize.width / 36),
                color: Colors.white,
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ),
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ),
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.calendar_month,
                            size: screenSize.width / 16.36,
                            color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Availability",
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 25.71,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(
                              68,
                              68,
                              68,
                              1,
                            ),
                          ),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: screenSize.width / 20,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          isfollowing != true
              ? GestureDetector(
                  onTap: () async {
                    SharedPreferences pref =
                        await SharedPreferences.getInstance();
                    String? uid = pref.getString("uid");

                    if (pref.getString('uid') != null) {
                      followVendor(uid!, vid, !isfollowing);
                    } else {
                      showModalBottomSheet(
                        isDismissible: false,
                        context: context,
                        isScrollControlled: true,
                        shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(screenSize.width / 36)),
                        builder: (BuildContext context) {
                          return const LoginModel();
                        },
                      );
                    }
                  },
                  child: Container(
                    padding: EdgeInsets.all(screenSize.width / 24),
                    margin: EdgeInsets.only(
                        bottom: screenSize.height / 75.6,
                        left: screenSize.width / 24,
                        right: screenSize.width / 24),
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(screenSize.width / 36),
                      color: Colors.white,
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.16),
                          offset: Offset(
                            3.0,
                            3.0,
                          ),
                          blurRadius: 6.0,
                          spreadRadius: 2.0,
                        ),
                        BoxShadow(
                          color: Colors.white,
                          offset: Offset(
                            0.0,
                            0.0,
                          ),
                          blurRadius: 0.0,
                          spreadRadius: 0.0,
                        ),
                      ],
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Row(children: [
                              Transform.rotate(
                                angle: 0,
                                child: Icon(Icons.push_pin_sharp,
                                    size: screenSize.width / 16.36,
                                    color: Color.fromRGBO(68, 68, 68, 1)),
                              ),
                              SizedBox(
                                width: screenSize.width / 36,
                              ),
                              Text(
                                "Follow ${results[0].name}",
                                style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width / 25.71,
                                    fontWeight: FontWeight.bold,
                                    color: Color.fromRGBO(68, 68, 68, 1)),
                              )
                            ]),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: screenSize.width / 20,
                          )
                        ]),
                  ),
                )
              : Container(),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          GestureDetector(
            onTap: () {
              if (_walletList.length >= 1) {
                if (double.parse(_walletList[0].walletamount) >= 100.0) {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) =>
                        VideoCallAndAudioCallModal(
                      name: results[0].name,
                      image: results[0].photo,
                      vid: results[0].id.toString(),
                      audioCallPrice: results[0].audicallprice,
                      videoCallPrice: results[0].audicallprice,
                    ),
                  );
                } else {
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false, // user must tap button!
                    builder: (BuildContext context) {
                      return AlertDialog(
                        elevation: 0.6,
                        contentPadding: EdgeInsets.only(
                          left: screenSize.width / 18,
                          right: screenSize.width / 36,
                          top: screenSize.height / 151.2,
                          bottom: screenSize.height / 151.2,
                        ),
                        titlePadding: EdgeInsets.only(
                          left: screenSize.width / 18,
                          right: screenSize.width / 36,
                          top: screenSize.height / 151.2,
                          bottom: screenSize.height / 151.2,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            screenSize.width / 24,
                          ),
                        ),
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              'Recharge Plan',
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.close,
                                color: Colors.red,
                              ),
                              onPressed: () {
                                Navigator.of(
                                  context,
                                ).pop();
                              },
                            )
                          ],
                        ),
                        content: const RechargeNow(),
                      );
                    },
                  );
                }
              } else {
                showDialog<void>(
                  context: context,
                  barrierDismissible: false, // user must tap button!
                  builder: (BuildContext context) {
                    return AlertDialog(
                      elevation: 0.6,
                      contentPadding: EdgeInsets.only(
                        left: screenSize.width / 18,
                        right: screenSize.width / 36,
                        top: screenSize.height / 151.2,
                        bottom: screenSize.height / 151.2,
                      ),
                      titlePadding: EdgeInsets.only(
                        left: screenSize.width / 18,
                        right: screenSize.width / 36,
                        top: screenSize.height / 151.2,
                        bottom: screenSize.height / 151.2,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                          screenSize.width / 24,
                        ),
                      ),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Recharge Plan'),
                          IconButton(
                            icon: const Icon(
                              Icons.close,
                              color: Colors.red,
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )
                        ],
                      ),
                      content: const RechargeNow(),
                    );
                  },
                );
              }
            },
            child: Container(
              padding: EdgeInsets.all(screenSize.width / 24),
              margin: EdgeInsets.only(
                  bottom: screenSize.height / 75.6,
                  left: screenSize.width / 24,
                  right: screenSize.width / 24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(screenSize.width / 36),
                color: Colors.white,
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ),
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ),
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.video_call,
                            size: screenSize.width / 16.3,
                            color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: screenSize.width / 36,
                        ),
                        Text(
                          "Audio Call & Video Call",
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 25.71,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(
                              68,
                              68,
                              68,
                              1,
                            ),
                          ),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: screenSize.width / 20,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          GestureDetector(
            onTap: () {
              if (_walletList.length >= 1) {
                showModalBottomSheet(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  context: context,
                  builder: (context) {
                    return SendGift(_walletList[0].walletamount.toString());
                  },
                );
              } else {
                showModalBottomSheet(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  context: context,
                  builder: (context) {
                    return SendGift("0");
                  },
                );
              }
            },
            child: Container(
              padding: EdgeInsets.all(screenSize.width / 24),
              margin: EdgeInsets.only(
                  bottom: screenSize.height / 75.6,
                  left: screenSize.width / 24,
                  right: screenSize.width / 24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(screenSize.width / 36),
                color: Colors.white,
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(
                      0,
                      0,
                      0,
                      0.16,
                    ),
                    offset: Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ),
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ),
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.diamond,
                            size: screenSize.width / 16.36,
                            color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Send Gift to ${results[0].name}",
                          style: GoogleFonts.merriweather(
                              fontSize: screenSize.width / 25.71,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: screenSize.width / 20,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
        ],
      )),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
              height: screenSize.height / 15.12,
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      if (_walletList.length >= 1) {
                        if (double.parse(_walletList[0].walletamount) >=
                            100.0) {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) =>
                                VideoCallAndAudioCallModal(
                              name: results[0].name,
                              image: results[0].photo,
                              vid: results[0].id.toString(),
                              audioCallPrice: results[0].audicallprice,
                              videoCallPrice: results[0].audicallprice,
                            ),
                          );
                        } else {
                          showDialog<void>(
                            context: context,
                            barrierDismissible: false,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                elevation: 0.6,
                                contentPadding: EdgeInsets.only(
                                  left: screenSize.width / 18,
                                  right: screenSize.width / 36,
                                  top: screenSize.height / 151.2,
                                  bottom: screenSize.height / 151.2,
                                ),
                                titlePadding: EdgeInsets.only(
                                  left: screenSize.width / 18,
                                  right: screenSize.width / 36,
                                  top: screenSize.height / 151.2,
                                  bottom: screenSize.height / 151.2,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(
                                    screenSize.width / 24,
                                  ),
                                ),
                                title: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      'Recharge Plan',
                                    ),
                                    IconButton(
                                      icon: const Icon(
                                        Icons.close,
                                        color: Colors.red,
                                      ),
                                      onPressed: () {
                                        Navigator.of(
                                          context,
                                        ).pop();
                                      },
                                    )
                                  ],
                                ),
                                content: const RechargeNow(),
                              );
                            },
                          );
                        }
                      } else {
                        showDialog<void>(
                          context: context,
                          barrierDismissible: false, // user must tap button!
                          builder: (BuildContext context) {
                            return AlertDialog(
                              elevation: 0.6,
                              contentPadding: EdgeInsets.only(
                                left: screenSize.width / 18,
                                right: screenSize.width / 36,
                                top: screenSize.height / 151.2,
                                bottom: screenSize.height / 151.2,
                              ),
                              titlePadding: EdgeInsets.only(
                                left: screenSize.width / 18,
                                right: screenSize.width / 36,
                                top: screenSize.height / 151.2,
                                bottom: screenSize.height / 151.2,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                  screenSize.width / 24,
                                ),
                              ),
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Recharge Plan'),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.close,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  )
                                ],
                              ),
                              content: const RechargeNow(),
                            );
                          },
                        );
                      }
                    },
                    child: Container(
                      // alignment: Alignment.center,
                      // margin: const EdgeInsets.only(left: 10, right: 5),
                      width: MediaQuery.of(context).size.width * 0.45,
                      height: screenSize.height / 18,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          screenSize.width / 72,
                        ),
                        color: themeColor,
                      ),
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Icon(
                              Icons.phone,
                              color: blueColor,
                              size: screenSize.width / 18,
                            ),
                            Text(
                              "Call",
                              style: GoogleFonts.merriweather(
                                  fontSize: screenSize.width / 25.71,
                                  color: blueColor,
                                  fontWeight: FontWeight.bold),
                            )
                          ]),
                    ),
                  ),
                  SizedBox(
                    width: screenSize.width / 36,
                  ),
                  GestureDetector(
                    onTap: () async {
                      if (_walletList.length >= 1) {
                        if (double.parse(_walletList[0].walletamount) >=
                            100.0) {
                          SharedPreferences pref =
                              await SharedPreferences.getInstance();

                          Map<String, String> data = {
                            "userid": pref
                                .getString(
                                  "uid",
                                )
                                .toString(),
                            "vid": results[0].id.toString(),
                            "orderfor": "chat",
                            "orderstatus": "created",
                            "createdat": DateTime.now().toString()
                          };
                          _createOrderForChat(
                            data,
                            results[0].photo,
                            results[0].name,
                          );
                        }
                        showDialog<void>(
                          context: context,
                          barrierDismissible: false, // user must tap button!
                          builder: (BuildContext context) {
                            return AlertDialog(
                              elevation: 0.6,
                              contentPadding: EdgeInsets.only(
                                left: screenSize.width / 18,
                                right: screenSize.width / 36,
                                top: screenSize.height / 151.2,
                                bottom: screenSize.height / 151.2,
                              ),
                              titlePadding: EdgeInsets.only(
                                left: screenSize.width / 18,
                                right: screenSize.width / 36,
                                top: screenSize.height / 151.2,
                                bottom: screenSize.height / 151.2,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                  screenSize.width / 24,
                                ),
                              ),
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Recharge Plan'),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.close,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      Navigator.of(
                                        context,
                                      ).pop();
                                    },
                                  )
                                ],
                              ),
                              content: const RechargeNow(),
                            );
                          },
                        );
                      } else {
                        showDialog<void>(
                          context: context,
                          barrierDismissible: false, // user must tap button!
                          builder: (BuildContext context) {
                            return AlertDialog(
                              elevation: 0.6,
                              contentPadding: EdgeInsets.only(
                                left: screenSize.width / 18,
                                right: screenSize.width / 36,
                                top: screenSize.height / 151.2,
                                bottom: screenSize.height / 151.2,
                              ),
                              titlePadding: EdgeInsets.only(
                                left: screenSize.width / 18,
                                right: screenSize.width / 36,
                                top: screenSize.height / 151.2,
                                bottom: screenSize.height / 151.2,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                  screenSize.width / 24,
                                ),
                              ),
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Recharge Plan'),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.close,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      Navigator.of(
                                        context,
                                      ).pop();
                                    },
                                  )
                                ],
                              ),
                              content: const RechargeNow(),
                            );
                          },
                        );
                      }
                    },
                    child: Container(
                      // margin: const EdgeInsets.only(
                      //   left: 5,
                      //   right: 10,
                      // ),
                      width: MediaQuery.of(context).size.width * 0.45,
                      height: screenSize.height / 18,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          screenSize.width / 72,
                        ),
                        color: themeColor,
                      ),
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Icon(
                              Icons.message,
                              color: blueColor,
                              size: screenSize.width / 18,
                            ),
                            Text(
                              "Chat",
                              style: GoogleFonts.merriweather(
                                  fontSize: screenSize.width / 25.71,
                                  color: blueColor,
                                  fontWeight: FontWeight.bold),
                            )
                          ]),
                    ),
                  )
                ],
              )),
        ],
      ),
    );
  }

  void _createOrderForChat(
      Map<String, String> data, String image, String name) async {
    var response = await networkProvider.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "success",
          ),
        );
        print("Order created succesflly");
      } else {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "failed",
          ),
        );
        print("Something went wrong");
      }
    }
  }

  Widget buildImage() => Container(
        color: Colors.white,
        height: 600,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              top: 5,
              child: Container(
                height: 106,
                width: 106,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(45),
                  border: Border.all(width: 2, color: lightblueColor),
                  image: DecorationImage(
                    image: NetworkImage(
                        '${MainUrl}vendor-image/${results[0].photo}'),
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 5,
              left: 205,
              child: Container(
                height: 25,
                width: 25,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      "assets/SVG/star2-2x.png",
                    ),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 135,
              child: Container(
                child: Column(
                  children: [
                    Text(
                      results[0].name,
                      style: const TextStyle(
                          fontSize: 20,
                          color: Color.fromRGBO(17, 81, 115, 1),
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      results[0].primaryskills,
                      style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      results[0].language,
                      style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    const Text(
                      "Exp: 5 Years",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      "₹ ${results[0].audicallprice} / min",
                      style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 17,
                    ),
                    GestureDetector(
                      onTap: () async {
                        SharedPreferences pref =
                            await SharedPreferences.getInstance();
                        String? uid = pref.getString("uid");
                        followVendor(uid!, vid, !isfollowing);
                      },
                      child: Container(
                        height: 37,
                        width: 121,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(45),
                            color: const Color.fromRGBO(17, 81, 115, 1)),
                        child: Center(
                          child: isfollowing != true
                              ? const Text(
                                  "Follow",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                )
                              : const Text(
                                  "FEollowing",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      width: 350,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            child: Column(children: const [
                              Text(
                                "Chat",
                                style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                "49k",
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Color.fromRGBO(17, 81, 115, 1),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                "mins",
                                style: TextStyle(
                                  fontSize: 9,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ]),
                          ),
                          Container(
                            child: Column(children: const [
                              Text(
                                "Calls",
                                style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                "49k",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Color.fromRGBO(17, 81, 115, 1),
                                    fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                "mins",
                                style: TextStyle(
                                    fontSize: 9,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ]),
                          ),
                          Container(
                            child: Column(
                              children: const [
                                Text(
                                  "Video Chat",
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "500",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Color.fromRGBO(
                                      17,
                                      81,
                                      115,
                                      1,
                                    ),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "mins",
                                  style: TextStyle(
                                    fontSize: 9,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            child: Column(
                              children: const [
                                Text(
                                  "Followers",
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "2k",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Color.fromRGBO(
                                      17,
                                      81,
                                      115,
                                      1,
                                    ),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Following",
                                  style: TextStyle(
                                    fontSize: 9,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: 413,
              left: 0,
              width: 374,
              height: 312,
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      "assets/SVG/Path 2-2x.png",
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 418,
              left: 134,
              width: 374,
              height: 312,
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      "assets/SVG/Path 4-2x.png",
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 417,
              left: 0.63,
              width: 412,
              height: 449,
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      "assets/SVG/Path 3-2x.png",
                    ),
                  ),
                ),
                child: Container(
                  margin: const EdgeInsets.only(
                    top: 55,
                    left: 20,
                    right: 70,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "About ${results[0].name}",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Text(
                        results[0].aboutus,
                        textAlign: TextAlign.left,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.normal,
                          color: Color.fromRGBO(
                            17,
                            81,
                            115,
                            1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      );

  Widget SendGift(String amount) {
    return giftLoading != true
        ? _giftlist.length >= 1
            ? Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20)),
                height: 300,
                width: 300,
                child: Column(
                  children: [
                    Container(
                      margin:
                          const EdgeInsets.only(left: 20, right: 20, top: 10),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Send Gift to ${results[0].name}",
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.normal,
                                color: Colors.black,
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: const Icon(
                                Icons.close,
                              ),
                            )
                          ]),
                    ),
                    Container(
                      height: 210,
                      margin: const EdgeInsets.only(top: 10),
                      // color: Colors.black,
                      child: GridView.count(
                        crossAxisCount: 3,
                        crossAxisSpacing: 4.0,
                        // scrollDirection: Axis,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 3.0,
                        children: List.generate(
                          _giftlist.length,
                          (index) => Container(
                            child: Column(
                              children: [
                                Container(
                                  height: 45,
                                  width: 45,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: NetworkImage(
                                        MainUrl +
                                            "gift-plan/" +
                                            _giftlist[index].icon.toString(),
                                      ),
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "₹ " + _giftlist[index].amount.toString(),
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: blueColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  _giftlist[index].name.toString(),
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: blueColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const Divider(
                      height: 2,
                      color: blueColor,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            child: Column(
                              children: [
                                const Text(
                                  "Wallet Balance",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: textColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "₹ $amount",
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: textColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(
                                context,
                              );
                              showDialog<void>(
                                context: context,
                                barrierDismissible:
                                    false, // user must tap button!
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    elevation: 0.6,
                                    contentPadding: const EdgeInsets.only(
                                      left: 20,
                                      right: 10,
                                      top: 5,
                                      bottom: 5,
                                    ),
                                    titlePadding: const EdgeInsets.only(
                                      left: 20,
                                      right: 10,
                                      top: 5,
                                      bottom: 5,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                        15,
                                      ),
                                    ),
                                    title: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text('Recharge Plan'),
                                        IconButton(
                                          icon: const Icon(
                                            Icons.close,
                                            color: Colors.red,
                                          ),
                                          onPressed: () {
                                            Navigator.of(
                                              context,
                                            ).pop();
                                          },
                                        )
                                      ],
                                    ),
                                    content: const RechargeNow(),
                                  );
                                },
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 15),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: themeColor,
                              ),
                              child: const Center(
                                child: Text(
                                  "Recharge",
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 15),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: themeColor,
                            ),
                            child: const Center(
                              child: Text(
                                "Send Gift",
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ))
            : Center(
                child: Text("No Data Found"),
              )
        : Center(
            child: CircularProgressIndicator(),
          );
  }

  Future saveAndShare(Uint8List bytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final image = File('${directory.path}/flutter.png');

    image.writeAsBytesSync(bytes);
    await Share.shareFiles(
      [
        image.path,
      ],
    );
    // final text =
    // await FlutterBranchSdk.getShortUrl(buo: buo!, linkProperties: lp);

    // BranchResponse response = await FlutterBranchSdk.showShareSheet(
    //   buo: buo!,
    //   linkProperties: lp,
    //   messageText: 'Hii',
    //   androidMessageTitle: 'How r u ',
    //   androidSharingTitle: 'share with',

    //   // image:File("${directory.path}/flutter.png");
    // );
    // final text = response.success.toString();

    // if (response.success) {
    //   showSnackBar(message: 'showShareSheet Success', duration: 5);
    // } else {
    //   showSnackBar(
    //       message:
    //           'showShareSheet Error: ${response.errorCode} - ${response.errorMessage}',
    //       duration: 5);
    // }
  }

  Future<String> saveImage(Uint8List bytes) async {
    await [Permission.storage].request();
    final time = DateTime.now()
        .toIso8601String()
        .replaceAll('.', '_')
        .replaceAll(':', '_');
    final name = "screenshot_$time";
    final result = await ImageGallerySaver.saveImage(bytes, name: name);

    return result['filePath'];
  }

  Future<dynamic> ShowCapturedWidget(
      BuildContext context, Uint8List capturedImage) {
    return showDialog(
      useSafeArea: false,
      context: context,
      builder: (context) => Scaffold(
        appBar: AppBar(
          title: const Text("Captured widget screenshot"),
        ),
        body: Center(
            child: capturedImage != null
                ? Image.memory(capturedImage)
                : Container()),
      ),
    );
  }

  // void showStartChat() async {
  //   SmartDialog.show(builder: (_) {
  //     return Container(
  //         height: 203,
  //         width: 265,
  //         decoration: BoxDecoration(
  //           color: Colors.white,
  //           borderRadius: BorderRadius.circular(10),
  //         ),
  //         alignment: Alignment.center,
  //         child: Column(
  //           children: [
  //             Container(
  //               margin: const EdgeInsets.only(left: 20, right: 20, top: 10),
  //               child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
  //                 GestureDetector(
  //                     onTap: () {
  //                       Navigator.pop(context, true);
  //                     },
  //                     child: const Icon(Icons.close))
  //               ]),
  //             ),
  //             GestureDetector(
  //               child: Container(
  //                 height: 65,
  //                 width: 65,
  //                 margin: const EdgeInsets.only(top: 10),
  //                 // color: Colors.black,
  //                 decoration: BoxDecoration(
  //                     borderRadius: BorderRadius.circular(50),
  //                     image: const DecorationImage(
  //                         image: NetworkImage(
  //                             "http://rationcart.in/assets/img/team/rohit.jfif"),
  //                         fit: BoxFit.fill)),
  //               ),
  //             ),
  //             const SizedBox(
  //               height: 10,
  //             ),
  //             const Text(
  //               'Aditya Roy',
  //               style: TextStyle(
  //                   fontSize: 19,
  //                   fontWeight: FontWeight.bold,
  //                   color: Colors.black),
  //             ),
  //             const SizedBox(
  //               height: 10,
  //             ),
  //             const SizedBox(
  //               width: 166,
  //               child: Text(
  //                 'Aditya will connect with you within 5 minutes.',
  //                 textAlign: TextAlign.center,
  //                 style: TextStyle(
  //                     fontSize: 14,
  //                     fontWeight: FontWeight.normal,
  //                     color: Colors.black),
  //               ),
  //             )
  //           ],
  //         ));
  //   });
  // }

  bool isFollwLoading = false;
  void followVendor(String cid, String vid, bool follow) async {
    Map<String, dynamic> data = {
      'customerid': cid,
      'vendorid': vid,
      'follow': follow,
    };
    setState(() {
      isFollwLoading = true;
    });
    var response = await networkProvider.post('vendor-follower', data);
    print(response.body);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse['data'] == 'inserted' ||
          jsonResponse['data'] == 'updated') {
        if (follow == false) {
          setState(() {
            isfollowing = false;
          });
          Fluttertoast.showToast(
              msg: "Sorry for inconvenience with  ${results[0].name}",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: darkBlue,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      }
      if (follow == true) {
        setState(() {
          isfollowing = true;
        });
        Fluttertoast.showToast(
          msg: "Thanks for following ${results[0].name}",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: darkBlue,
          textColor: Colors.white,
          fontSize: 16.0,
        );
      }
    }
  }

  Widget AllReviews(ScrollController scrollController) {
    return Column(
      children: <Widget>[
        Container(
          padding: const EdgeInsets.symmetric(
            vertical: 10,
            horizontal: 10,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Customer Review"),
              InkWell(
                onTap: () {
                  Navigator.pop(
                    context,
                  );
                },
                child: const Icon(
                  Icons.cancel,
                ),
              )
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            controller: scrollController,
            itemCount: ratingReviewData.length,
            itemBuilder: (
              context,
              index,
            ) {
              return Container(
                padding: const EdgeInsets.all(
                  15,
                ),
                margin: const EdgeInsets.only(
                  bottom: 10,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                  color: Colors.white,
                  boxShadow: const [
                    BoxShadow(
                      color: Color.fromRGBO(
                        0,
                        0,
                        0,
                        0.16,
                      ),
                      offset: Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 6.0,
                      spreadRadius: 2.0,
                    ),
                    BoxShadow(
                      color: Colors.white,
                      offset: Offset(
                        0.0,
                        0.0,
                      ),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Row(
                            children: [
                              Container(
                                height: 44,
                                width: 44,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    image: NetworkImage(
                                      "${MainUrl}customer-image/${ratingReviewData[index].photo}",
                                    ),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 15,
                              ),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      ratingReviewData[index].name.toString(),
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Container(
                                      child: RatingBarIndicator(
                                        rating: ratingReviewData[index]
                                            .rating!
                                            .toDouble(),
                                        itemBuilder: (
                                          context,
                                          index,
                                        ) =>
                                            const Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                        ),
                                        itemCount: 5,
                                        itemSize: 13.0,
                                        direction: Axis.horizontal,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: PopupMenuButton<int>(
                            itemBuilder: (
                              context,
                            ) =>
                                [
                              PopupMenuItem(
                                value: 1,
                                child: Row(
                                  children: const [
                                    Text(
                                      "Report Review",
                                    ),
                                  ],
                                ),
                              ),
                              PopupMenuItem(
                                value: 2,
                                child: Row(
                                  children: const [
                                    Text(
                                      "Block Review",
                                    ),
                                  ],
                                ),
                              ),
                            ],
                            offset: const Offset(
                              10,
                              40,
                            ),
                            color: Colors.white,
                            elevation: 4,
                          ),
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                      child: Text(
                        ratingReviewData[index].review.toString(),
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.black.withOpacity(
                            0.53,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        )
      ],
    );
  }
}

class ImageDialog extends StatelessWidget {
  ImageDialog(this.image, {super.key});
  String image;
  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(5),
      elevation: 5,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(
            32.0,
          ),
        ),
      ),
      // contentPadding: EdgeInsets.only(top: 10.0),
      child: Container(
        height: 300,
        width: 300,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          image: DecorationImage(
            image: NetworkImage(
              image,
            ),
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}
