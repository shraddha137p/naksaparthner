import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../MainAsset/URL.dart';
import '../../../Service/AllVendorService.dart';
import '../../../model/VendorDetailsModel.dart';
import 'ChatWithCustomer.dart';

class IncomingChatRequest extends StatefulWidget {
  String vendorid;
  String orderid;

  IncomingChatRequest(
      {super.key, required this.vendorid, required this.orderid});

  @override
  State<IncomingChatRequest> createState() => _IncomingChatRequestState();
}

class _IncomingChatRequestState extends State<IncomingChatRequest>
    with WidgetsBindingObserver {
  Map<String, dynamic> userMap = {};
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool isloading = false;
  bool isloginloading = false;
  List<Vdatum> results = [];
  var vendorService = AllVendorService();
  var customerService = CustomerProfileService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    getVendorDetails();
    getUserDetails();
    setStatus("Online");
  }

  Future<List<Vdatum>> getVendorDetails() async {
    print(widget.vendorid);
    var response = await vendorService.viewSingleVendor(widget.vendorid);

    results = VendorDetailsmodel.fromJson(jsonDecode(response)).vdata!.toList();
    print(results);
    if (results != null) {
      setState(() {
        isloading = true;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  List<CustomerP?> _customerList = [];
  Future<List<CustomerP?>> getUserDetails() async {
    print(widget.vendorid);
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? phone = pref.getString("phone");
    var response = await customerService.viewCustomerProfile(phone!);

    if (results != null) {
      setState(() {
        _customerList = response!;
        isloading = true;
      });
      return _customerList;
    } else {
      throw Exception('Failed to load');
    }
  }

  String chatRoomId(String user1, String user2) {
    if (user1[0].toLowerCase().codeUnits[0] >
        user2[0].toLowerCase().codeUnits[0]) {
      return '$user1$user2';
    } else {
      return '$user2$user1';
    }
  }

  void setStatus(String status) async {
    await _firestore.collection('users').doc(_auth.currentUser!.uid).update({
      "status": status,
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      setStatus("Online");
    } else {
      setStatus("Offline");
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget DesktopServiceMain() {
    
    var screenSize = MediaQuery.of(context).size;
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              color: darkBlue,
              child: Center(
                child: Container(
                  height: screenSize.height/1.18,
                  margin:  EdgeInsets.only(top: screenSize.height/32.03, bottom: screenSize.height/32.03),
                  width: MediaQuery.of(context).size.width * 0.5,
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.shade300,
                          blurRadius: 5,
                        )
                      ],
                      borderRadius: BorderRadius.circular(screenSize.width/38.4),
                      color: Colors.black,
                      border: Border.all(
                        width: screenSize.width/384,
                        color: Colors.transparent,
                        style: BorderStyle.solid,
                      ),
                      image: DecorationImage(
                        image: const AssetImage("assets/SVG/request.png"),
                        fit: BoxFit.fill,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.25), BlendMode.dstATop),
                      )),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin:  EdgeInsets.only(top: screenSize.height/10.67),
                          child:  Text(
                            "Incoming Chat Request From",
                            style: GoogleFonts.merriweather(fontSize: screenSize.width/137.1, color: Colors.white),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/48.05,
                        ),
                        Container(
                          height: screenSize.height/22.3,
                          width: screenSize.width/16.2,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                            image: AssetImage("assets/logo.png"),
                          )),
                        ),
                         SizedBox(
                          height: screenSize.width/8.00,
                        ),
                        Container(
                          height: screenSize.height/8.35,
                          width:  screenSize.width/16.6,
                          decoration: BoxDecoration(
                              border: Border.all(width: screenSize.width/960, color: themeColor),
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: NetworkImage(
                                      '${MainUrl}vendor-image/${results[0].photo}'),
                                  fit: BoxFit.fill)),
                        ),
                         SizedBox(
                          height: screenSize.height/64.0,
                        ),
                        Container(
                          child: Text(
                            results[0].name!,
                            style:  GoogleFonts.merriweather(
                                fontSize: screenSize.width/106.6,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/7.39,
                        ),
                        isloginloading != true
                            ? GestureDetector(
                                onTap: () async {
                                  // setState(() {
                                  //   isloginloading = true;
                                  // });
                                  // Navigator.push(
                                  //     context,
                                  //     MaterialPageRoute(
                                  //         builder: (context) => ChatWithCustomer(
                                  //             chatRoomId:
                                  //                 "${_customerList[0]!.phone}${results[0].id}",
                                  //             customer: _customerList,
                                  //             vdetails: results)));
                                  setState(() {
                                    isloginloading = false;
                                  });
                                  Map<String, String> data = {
                                    "status": "received"
                                  };
                                  var response = await _networkHandler.post(
                                      "accept-order-customer/${_customerList[0]!.id.toString()}/${widget.vendorid}/${widget.orderid}",
                                      data);

                                  if (response.statusCode == 200) {
                                    Map jsonResponse =
                                        json.decode(response.body);
                                    if (jsonResponse["data"] == "received") {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  ChatWithCustomer(
                                                      chatRoomId:
                                                          "${_customerList[0]!.phone}${results[0].id}",
                                                      customer: _customerList,
                                                      vdetails: results)));
                                    } else {
                                      Fluttertoast.showToast(
                                          msg: "Something went wrong",
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.BOTTOM,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: darkBlue,
                                          textColor: Colors.white,
                                          fontSize: screenSize.width/120);
                                    }
                                    setState(() {
                                      isloginloading = false;
                                    });
                                  }
                                },
                                child: Container(
                                  height: screenSize.height/21.3,
                                  width: screenSize.width/11.4,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(screenSize.width/56.4),
                                      color: themeColor),
                                  child:  Center(
                                    child: Text(
                                      "Start Chat",
                                      style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width/106.6,
                                          color: blueColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              )
                            : const LoadingIndicator(),
                         SizedBox(
                          height: screenSize.height/96.1,
                        ),
                         Text(
                          "Reject Chat Request",
                          style: GoogleFonts.merriweather(
                              fontSize: screenSize.width/192,
                              color: Colors.white,
                              fontWeight: FontWeight.normal),
                        ),
                      ]),
                ),
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }

  Widget MobileServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              color: darkBlue,
              child: Center(
                child: Container(
                  height: screenSize.height/0.93,
                  margin:  EdgeInsets.only(top: screenSize.height/25.2, bottom: screenSize.height/25.2),
                  width: MediaQuery.of(context).size.width * 0.5,
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.shade300,
                          blurRadius: 5,
                        )
                      ],
                      borderRadius: BorderRadius.circular(screenSize.width/7.2),
                      color: Colors.black,
                      border: Border.all(
                        width: screenSize.width/72,
                        color: Colors.transparent,
                        style: BorderStyle.solid,
                      ),
                      image: DecorationImage(
                        image: const AssetImage("assets/SVG/request.png"),
                        fit: BoxFit.fill,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.25), BlendMode.dstATop),
                      )),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin:  EdgeInsets.only(top: screenSize.height/8.4),
                          child:  Text(
                            "Incoming Chat Request From",
                            style: GoogleFonts.merriweather(fontSize: screenSize.width/25.7, color: Colors.white),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/37.8,
                        ),
                        Container(
                          height: screenSize.width/17.5,
                          width: screenSize.width/3.05,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                            image: AssetImage("assets/logo.png"),
                          )),
                        ),
                         SizedBox(
                          height: screenSize.height/6.3,
                        ),
                        Container(
                          height: screenSize.height/6.57,
                          width: screenSize.width/3.13,
                          decoration: BoxDecoration(
                              border: Border.all(width: screenSize.width/180, color: themeColor),
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: NetworkImage(
                                      '${MainUrl}vendor-image/${results[0].photo}'),
                                  fit: BoxFit.fill)),
                        ),
                         SizedBox(
                          height: screenSize.height/50.4,
                        ),
                        Container(
                          child: Text(
                            results[0].name!,
                            style:  GoogleFonts.merriweather(
                                fontSize: screenSize.width/20,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                         SizedBox(
                          height: screenSize.height/5.81,
                        ),
                        isloginloading != true
                            ? GestureDetector(
                                onTap: () async {
                                  setState(() {
                                    isloginloading = true;
                                  });
                                  Map<String, String> data = {
                                    "status": "received"
                                  };
                                  var response = await _networkHandler.post(
                                      "accept-order-customer/${_customerList[0]!.id.toString()}/${widget.vendorid}/${widget.orderid}",
                                      data);

                                  if (response.statusCode == 200) {
                                    Map jsonResponse =
                                        json.decode(response.body);
                                    if (jsonResponse["data"] == "received") {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  ChatWithCustomer(
                                                      chatRoomId:
                                                          "${_customerList[0]!.phone}${results[0].id}",
                                                      customer: _customerList,
                                                      vdetails: results)));
                                    } else {
                                      Fluttertoast.showToast(
                                          msg: "Something went wrong",
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.BOTTOM,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: darkBlue,
                                          textColor: Colors.white,
                                          fontSize: screenSize.height/22.5);
                                    }
                                    setState(() {
                                      isloginloading = false;
                                    });
                                  }
                                },
                                child: Container(
                                  height: screenSize.height/16.8,
                                  width: screenSize.height/2.15,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(screenSize.width/10.5),
                                      color: themeColor),
                                  child:  Center(
                                    child: Text(
                                      "Start Chat",
                                      style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width/20,
                                          color: blueColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              )
                            : const LoadingIndicator(),
                         SizedBox(
                          height: screenSize.height/75.6,
                        ),
                         Text(
                          "Reject Chat Request",
                          style: GoogleFonts.merriweather(
                              fontSize: screenSize.width/36,
                              color: Colors.white,
                              fontWeight: FontWeight.normal),
                        ),
                      ]),
                ),
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }

  final NetworkHandler _networkHandler = NetworkHandler();
  callrequest(String userid, String vid, String orderid, String status) async {}
}
