import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../API/NetworkProvider.dart';
import '../../../MainAsset/URL.dart';
import 'CallWithCustomer.dart';

class IncomingCallRequest extends StatefulWidget {
  String channelname;
  String token;
  String vendorid;
  IncomingCallRequest(
      {super.key,
      required this.channelname,
      required this.token,
      required this.vendorid});

  @override
  State<IncomingCallRequest> createState() => _IncomingCallRequestState();
}

class _IncomingCallRequestState extends State<IncomingCallRequest>
    with WidgetsBindingObserver {
  bool isloading = false;
  bool isloginloading = false;
  List<Vdatum> results = [];
  var vendorService = AllVendorService();
  var customerService = CustomerProfileService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    getVendorDetails();
    getUserDetails();
  }

  Future<List<Vdatum>> getVendorDetails() async {
    print(widget.vendorid);
    var response = await vendorService.viewSingleVendor(widget.vendorid);

    results = VendorDetailsmodel.fromJson(jsonDecode(response)).vdata!.toList();
    print(results);
    if (results != null) {
      setState(() {
        isloading = true;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  var networkHandler = NetworkHandler();
  String token = "";
  List<CustomerP?> _customerList = [];
  Future<List<CustomerP?>> getUserDetails() async {
    print(widget.vendorid);
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? phone = pref.getString("phone");
    var response = await customerService.viewCustomerProfile(phone!);

    if (results != null) {
      setState(() {
        _customerList = response!;
        isloading = true;
      });
      var response1 = await networkHandler
          .get("rtc/${widget.channelname}/publisher/3600/2");
      Map jsonresponse = response1;
      setState(() {
        isloading = true;
        token = jsonresponse["token"];
        print(token);
      });
      return _customerList;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              color: darkBlue,
              child: Center(
                child: Container(
                  height: screenSize.height/0.93,
                  width: MediaQuery.of(context).size.width * 0.5,
                  margin:  EdgeInsets.only(top: screenSize.height/25.2, bottom: screenSize.height/25.2),
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.shade300,
                          blurRadius: 5,
                        )
                      ],
                      borderRadius: BorderRadius.circular( screenSize.width/7.2),
                      color: Colors.black,
                      image: DecorationImage(
                        image: const AssetImage("assets/SVG/request.png"),
                        fit: BoxFit.fill,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.25), BlendMode.dstATop),
                      )),
                  child: Column(children: [
                    Container(
                      margin:  EdgeInsets.only(top: screenSize.height/8.4),
                      child:  Text(
                        "Incoming Chat Request From",
                        style: TextStyle(fontSize:  screenSize.width/25.71, color: Colors.white),
                      ),
                    ),
                     SizedBox(
                      height: screenSize.height/37.8,
                    ),
                    Container(
                      height: screenSize.height/17.5,
                      width:  screenSize.width/3.050,
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                        image: AssetImage("assets/logo.png"),
                      )),
                    ),
                     SizedBox(
                      height: 144,
                    ),
                    Container(
                      height: screenSize.height/5.25,
                      width:  screenSize.width/2.83,
                      decoration: BoxDecoration(
                          border: Border.all(width:  screenSize.width/180, color: themeColor),
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: NetworkImage(
                                  '${MainUrl}vendor-image/${results[0].photo}'),
                              fit: BoxFit.fill)),
                    ),
                     SizedBox(
                      height: screenSize.height/34.3,
                    ),
                    Container(
                      child: Text(
                        results[0].name!,
                        style:  TextStyle(
                            fontSize:  screenSize.width/20,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                     SizedBox(
                      height: screenSize.height/9,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        isloginloading != true
                            ? GestureDetector(
                                onTap: () async {
                                  setState(() {
                                    isloginloading = true;
                                  });
                                  SharedPreferences pref =
                                      await SharedPreferences.getInstance();
                                  String? uid = pref.getString("uid");
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CallWithCustomer(
                                                  channelName:
                                                      widget.channelname,
                                                  token: token,
                                                  vendorData: results,
                                                  uid: "2")));
                                  setState(() {
                                    isloginloading = false;
                                  });
                                },
                                child: Container(
                                  height: screenSize.height/10.6,
                                  width:  screenSize.width/5.07,
                                  decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Color.fromRGBO(67, 217, 102, 1)),
                                  child:  Center(
                                    child: Icon(
                                      Icons.call,
                                      color: Colors.white,
                                      size:  screenSize.width/12,
                                    ),
                                  ),
                                ),
                              )
                            : const LoadingIndicator(),
                        GestureDetector(
                          onTap: () async {},
                          child: Container(
                            height: screenSize.height/10.6,
                            width:  screenSize.width/5.07,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle, color: Colors.red),
                            child:  Center(
                              child: Icon(
                                Icons.call,
                                color: Colors.white,
                                size:  screenSize.width/12,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                     SizedBox(
                      height: screenSize.height/37.8,
                    ),
                    // Text(
                    //   "Reject Chat Request",
                    //   style: TextStyle(
                    //       fontSize: 10,
                    //       color: Colors.white,
                    //       fontWeight: FontWeight.normal),
                    // ),
                  ]),
                ),
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }

  Widget DesktopServiceMain() {
    
    var screenSize = MediaQuery.of(context).size;
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              color: darkBlue,
              child: Center(
                child: Container(
                  height: screenSize.height/1.18,
                  width: MediaQuery.of(context).size.width * 0.5,
                  margin:  EdgeInsets.only(top: screenSize.height/32.03, bottom: screenSize.height/32.03),
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.shade300,
                          blurRadius: 5,
                        )
                      ],
                      borderRadius: BorderRadius.circular( screenSize.width/38.4),
                      color: Colors.black,
                      image: DecorationImage(
                        image: const AssetImage("assets/SVG/request.png"),
                        fit: BoxFit.fill,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.25), BlendMode.dstATop),
                      )),
                  child: Column(children: [
                    Container(
                      margin:  EdgeInsets.only(top: screenSize.height/10.6),
                      child:  Text(
                        "Incoming Chat Request From",
                        style: TextStyle(fontSize:  screenSize.width/137.1, color: Colors.white),
                      ),
                    ),
                     SizedBox(
                      height: screenSize.height/48.05,
                    ),
                    Container(
                      height: screenSize.height/22.3,
                      width:  screenSize.width/16.27,
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                        image: AssetImage("assets/logo.png"),
                      )),
                    ),
                     SizedBox(
                      height: screenSize.height/6.67,
                    ),
                    Container(
                      height: screenSize.height/7.56,
                      width:  screenSize.width/15.11,
                      decoration: BoxDecoration(
                          border: Border.all(width: screenSize.width/960, color: themeColor),
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: NetworkImage(
                                  '${MainUrl}vendor-image/${results[0].photo}'),
                              fit: BoxFit.fill)),
                    ),
                     SizedBox(
                      height: screenSize.height/43.6,
                    ),
                    Container(
                      child: Text(
                        results[0].name!,
                        style:  TextStyle(
                            fontSize:  screenSize.width/106.6,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                     SizedBox(
                      height: screenSize.height/11.44,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        isloginloading != true
                            ? GestureDetector(
                                onTap: () async {
                                  setState(() {
                                    isloginloading = true;
                                  });
                                  SharedPreferences pref =
                                      await SharedPreferences.getInstance();
                                  String? uid = pref.getString("uid");
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CallWithCustomer(
                                                  channelName:
                                                      widget.channelname,
                                                  token: token,
                                                  vendorData: results,
                                                  uid: "2")));
                                  setState(() {
                                    isloginloading = false;
                                  });
                                },
                                child: Container(
                                  height: screenSize.height/13.5,
                                  width:  screenSize.width/27.04,
                                  decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Color.fromRGBO(67, 217, 102, 1)),
                                  child:  Center(
                                    child: Icon(
                                      Icons.call,
                                      color: Colors.white,
                                      size:  screenSize.width/64,
                                    ),
                                  ),
                                ),
                              )
                            : const LoadingIndicator(),
                        GestureDetector(
                          onTap: () async {},
                          child: Container(
                            height: screenSize.height/13.5,
                            width:  screenSize.width/27.04,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle, color: Colors.red),
                            child:  Center(
                              child: Icon(
                                Icons.call,
                                color: Colors.white,
                                size:  screenSize.width/64,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                     SizedBox(
                      height: screenSize.height/48.05,
                    ),
                    // Text(
                    //   "Reject Chat Request",
                    //   style: TextStyle(
                    //       fontSize: 10,
                    //       color: Colors.white,
                    //       fontWeight: FontWeight.normal),
                    // ),
                  ]),
                ),
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }
}
