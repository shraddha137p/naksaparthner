import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';
import 'package:naksaa_services/UI/Home/Partner/LiveVendorScreen.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/livestreamfirebase.dart';

import '../../../API/FirebaseMethods.dart';
import '../../../MainAsset/LoadingIndicator.dart';
import '../../../aboutus/aboutnavigation.dart';
import '../../REgister/project Assets/desktopNavbar.dart';

class AllLiveVendor extends StatefulWidget {
  const AllLiveVendor({super.key});

  @override
  State<AllLiveVendor> createState() => _AllLiveVendorState();
}

class _AllLiveVendorState extends State<AllLiveVendor>
    with TickerProviderStateMixin {
  late TabController _controller;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TabController(
      vsync: this,
      length: 2,
      initialIndex: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopAllLivevendor();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopAllLivevendor();
      } else {
        return MobileAllLiveVendor();
      }
    });
  }

  var networkHander = NetworkHandler();
  Widget MobileAllLiveVendor() {
    var screenSize = MediaQuery.of(context).size;   
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Live Naksian"),
        backgroundColor: themeColor,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              TabBar(
                labelColor: darkBlue,
                // labelStyle: theme.textTheme.headline1,
                indicatorColor: darkBlue,
                // indicatorSize: TabBarIndicatorSize.label,
                // indicatorPadding: tab,

                unselectedLabelColor: Colors.grey,
                controller: _controller,
                tabs:  [
                  Tab(
                    child: Text(
                      "OnGoing",
                      style:
                          TextStyle(fontSize: screenSize.width/20, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Tab(
                    child: Text(
                      "UpComing",
                      style:
                          TextStyle(fontSize: screenSize.width/18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
               SizedBox(
                height: screenSize.height/75.6,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                child: StreamBuilder<dynamic>(
                    stream: FirebaseFirestore.instance
                        .collection('livestream')
                        .where("islive", isEqualTo: "true")
                        .snapshots(),
                    builder: (BuildContext context,
                        AsyncSnapshot<dynamic> snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const LoadingIndicator();
                      }
                      return GridView.builder(
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            childAspectRatio: 0.9,
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 5,
                          ),
                          itemCount: snapshot.data.docs.length,
                          itemBuilder: ((context, index) {
                            Object? mapdata = snapshot.data!.docs[index].data();

                            LiveStreamFirebase liveData =
                                LiveStreamFirebase.fromMap(
                                    snapshot.data!.docs[index].data());
                            return InkWell(
                              onTap: () async {
                                Map reponse = await networkHander.get(
                                    "rtc/${liveData.Channelname}/publisher/3600/3");
                                if (reponse["token"] != null) {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              LiveVendorScreen(
                                                  edata: snapshot,
                                                  isRole: false,
                                                  channelId: liveData.channelId,
                                                  uid: 3,
                                                  channnelName:
                                                      liveData.Channelname,
                                                  index: index,
                                                  token: reponse["token"])));
                                  await updateViewCount(
                                      "3", true, liveData.channelId);
                                }
                              },
                              child: Container(
                                margin:
                                     EdgeInsets.only(left: screenSize.width/36, right: screenSize.width/36),
                                child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                            color: Colors.yellow,
                                            borderRadius:
                                                BorderRadius.circular(screenSize.width/36),
                                            image: DecorationImage(
                                                image: NetworkImage(
                                                    liveData.image.toString()),
                                                fit: BoxFit.fill)),
                                      ),
                                      Positioned(
                                        bottom: screenSize.height/37.8,
                                        left: screenSize.width/5.14,
                                        child: Container(
                                          padding:  EdgeInsets.symmetric(
                                            vertical: screenSize.height/378,
                                            horizontal: screenSize.width/72,
                                          ),
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                              screenSize.width/72,
                                            ),
                                            color: const Color.fromRGBO(
                                              56,
                                              56,
                                              56,
                                              1,
                                            ).withOpacity(
                                              0.55,
                                            ),
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                height: screenSize.height/94.5,
                                                width: screenSize.width/45,
                                                decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: Color.fromRGBO(
                                                    36,
                                                    220,
                                                    55,
                                                    1,
                                                  ),
                                                ),
                                              ),
                                               SizedBox(
                                                width: screenSize.width/72,
                                              ),
                                              Text(
                                                "Live",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: screenSize.width/36,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                          bottom: screenSize.height/151.2,
                                          // left: 10,
                                          child: Container(
                                            child: Text(
                                              liveData.name,
                                              style: GoogleFonts.merriweather(
                                                fontSize: screenSize.width/36,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ))
                                    ]),
                              ),
                            );
                          }));
                    }),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget DesktopAllLivevendor() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Container(
                color: Colors.white,
                child: const Aboutnavigation(
                  MainContent: "Home",
                  SubContent: "Live Vendor",
                ),
              ),
               SizedBox(
                height: screenSize.height/19.2,
              ),
              TabBar(
                labelColor: darkBlue,
                // labelStyle: theme.textTheme.headline1,
                indicatorColor: darkBlue,
                // indicatorSize: TabBarIndicatorSize.label,
                // indicatorPadding: tab,

                unselectedLabelColor: Colors.grey,
                controller: _controller,
                tabs:  [
                  Tab(
                    child: Text(
                      "OnGoing",
                      style:
                          TextStyle(fontSize: screenSize.width/106.6, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Tab(
                    child: Text(
                      "UpComing",
                      style:
                          TextStyle(fontSize: screenSize.width/106.6, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              Container(
                padding:  EdgeInsets.all(screenSize.width/240),
                height: screenSize.height/1.44,
                child: TabBarView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    controller: _controller,
                    children: [
                      Container(
                          child: StreamBuilder<dynamic>(
                              stream: FirebaseFirestore.instance
                                  .collection('livestream')
                                  .where("islive", isEqualTo: "true")
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<dynamic> snapshot) {
                                if (snapshot.connectionState ==
                                    ConnectionState.waiting) {
                                  return const LoadingIndicator();
                                }
                                return GridView.builder(
                                  itemCount: snapshot.data!.docs.length,
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                          childAspectRatio: 0.8,
                                          crossAxisCount: 4,
                                          crossAxisSpacing: 26,
                                          mainAxisSpacing: 12),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    Object? mapdata =
                                        snapshot.data!.docs[index].data();

                                    LiveStreamFirebase liveData =
                                        LiveStreamFirebase.fromMap(
                                            snapshot.data!.docs[index].data());
                                    return InkWell(
                                      onTap: () async {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    LiveVendorScreen(
                                                        edata: snapshot,
                                                        isRole: false,
                                                        channelId:
                                                            liveData.channelId,
                                                        uid: int.parse(
                                                            liveData.uid),
                                                        channnelName: liveData
                                                            .Channelname,
                                                        index: index,
                                                        token: liveData
                                                            .tempToken)));
                                        await updateViewCount(
                                            "1", true, liveData.channelId);
                                      },
                                      child: Container(
                                        height: screenSize.height/6.86,
                                        margin:
                                             EdgeInsets.only(right: screenSize.width/192),
                                        child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Container(
                                                height: MediaQuery.of(context)
                                                        .size
                                                        .height *
                                                    0.7,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.55,
                                                decoration: BoxDecoration(
                                                  // color: Colors.yellow,
                                                  borderRadius:
                                                      BorderRadius.circular(screenSize.width/192),
                                                ),
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(screenSize.width/76.8),
                                                  child: Image.network(
                                                    (mapdata as Map)["image"]
                                                        .toString(),
                                                    height:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .height *
                                                            0.5,
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.5,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                  top: 10,
                                                  left: 10,
                                                  child: Container(
                                                    padding:  EdgeInsets
                                                            .symmetric(
                                                        vertical: screenSize.height/480.5,
                                                        horizontal: screenSize.width/384),
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(screenSize.width/384),
                                                        color: const Color
                                                                    .fromRGBO(
                                                                56, 56, 56, 1)
                                                            .withOpacity(0.55)),
                                                    child: Row(
                                                      children: [
                                                        Container(
                                                          height: screenSize.width/240,
                                                          width: screenSize.width/240,
                                                          decoration:
                                                               BoxDecoration(
                                                                  shape: BoxShape
                                                                      .circle,
                                                                  color: Color
                                                                      .fromRGBO(
                                                                          36,
                                                                          220,
                                                                          55,
                                                                        screenSize.width/1920  )),
                                                        ),
                                                         SizedBox(
                                                          width: screenSize.width/384,
                                                        ),
                                                        Text(
                                                          "Live",
                                                          style: GoogleFonts
                                                              .merriweather(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: screenSize.width/174.5,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )),
                                              Positioned(
                                                  bottom: screenSize.height/27.4,
                                                  // left: 10,
                                                  child: Container(
                                                    child: Text(
                                                        (mapdata)["name"]
                                                            .toString(),
                                                        style: GoogleFonts
                                                            .merriweather(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: screenSize.width/96,
                                                        )),
                                                  ))
                                            ]),
                                      ),
                                    );
                                  },
                                );
                              })),
                      Container()
                    ]),
              ),
              const BottomFooter()
            ],
          ),
        ),
      ),
    );
  }
}
