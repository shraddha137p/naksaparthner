import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ClientTestimonials extends StatefulWidget {
  const ClientTestimonials({super.key});

  @override
  State<ClientTestimonials> createState() => _ClientTestimonialsState();
}

class _ClientTestimonialsState extends State<ClientTestimonials> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 1200) {
          return DesktopClientTestimonials();
        } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
          return DesktopClientTestimonials();
        } else {
          return MobileClientTestimonials();
        }
      },
    );
  }

  Widget DesktopClientTestimonials() {
    
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
      height: screenSize.height/3.20,
      width: MediaQuery.of(context).size.width / 0.1,
      child: ListView.builder(
        itemCount: 10,
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {
          return Container(
            margin:  EdgeInsets.only(right: screenSize.width/80, top: screenSize.height/192.2, bottom: screenSize.height/192.2),
            width: screenSize.width/4.8,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                  color: Color.fromRGBO(
                    0,
                    0,
                    0,
                    0.16,
                  ),
                  offset: Offset(
                    0.0,
                    3.0,
                  ),
                  blurRadius: 6.0,
                  spreadRadius: 2.0,
                ),
                BoxShadow(
                  color: Colors.white,
                  offset: Offset(
                    0.0,
                    0.0,
                  ),
                  blurRadius: 0.0,
                  spreadRadius: 0.0,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding:  EdgeInsets.all(
                    screenSize.width/96,
                  ),
                  child: Text(
                    "This app helped me to get a job in my dream company. I was stressed about not getting a career opportunity after my graduation. One prediction from an astrologer gave me a ray of hope and within a few months, I got selected Thanks you so much Naksa.",
                    textAlign: TextAlign.justify,
                    style: GoogleFonts.merriweather(
                      fontSize: screenSize.width/137.1,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Ashwin Pandey",
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/137.1,
                                color: const Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold,
                              ),
                              // style: TextStyle(
                              //     fontSize: 12,
                              //     color: Color.fromRGBO(2, 44, 67, 1),
                              //     fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Lucknow, India",
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/160,
                                color: const Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          ]),
                    ),
                     SizedBox(
                      width: screenSize.width/36,
                    ),
                    Padding(
                      padding:  EdgeInsets.only(right: screenSize.width/36),
                      child: Container(
                        height: screenSize.height/20.4,
                        width: screenSize.width/40.85,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            width: screenSize.width/960,
                            color: const Color.fromRGBO(
                              255,
                              215,
                              0,
                              1,
                            ),
                          ),
                          image: const DecorationImage(
                            image: NetworkImage(
                              "http://rationcart.in/assets/img/team/rohit.jfif",
                            ),
                          ),
                        ),
                      ),
                    ),
                     SizedBox(
                      height: screenSize.height/68.6,
                    ),
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }

  Widget MobileClientTestimonials() {
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.25,
      width: MediaQuery.of(context).size.width,
      child: ListView.builder(
        itemCount: 10,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {
          return Container(
            margin:  EdgeInsets.only(
              right: screenSize.width/15,
              top: screenSize.height/151.2,
              bottom: screenSize.height/151.2,
              left: screenSize.width/72,
            ),
            // height: 170,
            width: MediaQuery.of(context).size.width * 0.9,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(screenSize.width/18),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                  color: Color.fromRGBO(
                    0,
                    0,
                    0,
                    0.16,
                  ),
                  offset: Offset(
                    0.0,
                    1.0,
                  ),
                  blurRadius: 2.0,
                  spreadRadius: 1.0,
                ),
                BoxShadow(
                  color: Colors.white,
                  offset: Offset(0.0, 0.0),
                  blurRadius: 0.0,
                  spreadRadius: 0.0,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  child: Padding(
                    padding:  EdgeInsets.only(
                      left: screenSize.width/45,
                      right: screenSize.width/45,
                    ),
                    child: Text(
                      "This app helped me to get a job in my dream company. I was stressed about not getting a career opportunity after my graduation. One prediction from an astrologer gave me a ray of hope and within a few months, I got selected Thanks you so much Naksa.",
                      textAlign: TextAlign.justify,
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/30,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "Ashwin Pandey",
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/30,
                                color: const Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold,
                              ),
                              // style: TextStyle(
                              //     fontSize: 12,
                              //     color: Color.fromRGBO(2, 44, 67, 1),
                              //     fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Lucknow, India",
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width/40,
                                color: const Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          ]),
                    ),
                     SizedBox(
                      width: screenSize.width/36,
                    ),
                    Container(
                      height: screenSize.height/18.9,
                      width: screenSize.width/9,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: screenSize.width/180,
                          color: const Color.fromRGBO(
                            255,
                            215,
                            0,
                            1,
                          ),
                        ),
                        image: const DecorationImage(
                          image: NetworkImage(
                            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2QUrWTGU6yMTSZaWSgY698etN_vmnZpNOGYNFXEIQiw&usqp=CAU&ec=48665701",
                          ),
                        ),
                      ),
                    ),
                     SizedBox(
                      width: screenSize.width/25.7,
                    ),
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
