import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../../model/VendorAvailabilityModel.dart';

class VendorAvailabilityWidget extends StatefulWidget {
  List<VendorAData> result;
  VendorAvailabilityWidget({super.key, required this.result});

  @override
  State<VendorAvailabilityWidget> createState() =>
      _VendorAvailabilityWidgetState();
}

class _VendorAvailabilityWidgetState extends State<VendorAvailabilityWidget> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVendorAvailabilityWidget();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVendorAvailabilityWidget();
      } else {
        return MobileVendorAvailabilityWidget();
      }
    });
  }

  Widget DesktopVendorAvailabilityWidget() {
    return Container(
        width: 300,
        margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: widget.result.length,
          itemBuilder: (context, index) {
            List slotdata = widget.result[index].slotrange.split(',');
            return Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 65,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              widget.result[index].day,
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "October 8th",
                              style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            )
                          ]),
                    ),
                    const SizedBox(
                      width: 25,
                    ),
                    Container(
                      child: Column(children: [
                        Container(
                          height: 18,
                          width: 18,
                          decoration: const BoxDecoration(
                              color: themeColor, shape: BoxShape.circle),
                        ),
                        Container(
                          width: 1,
                          height: 217,
                          color: const Color.fromRGBO(112, 112, 112, 1),
                        )
                      ]),
                    ),
                    Container(
                        width: 150,
                        margin: const EdgeInsets.only(left: 35, top: 15),
                        child: ListView.builder(
                            itemCount: slotdata.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, nindex) {
                              return Container(
                                height: 34,
                                width: 174,
                                margin: const EdgeInsets.only(bottom: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(21),
                                    color: blueColor),
                                child: Center(
                                  child: Text(
                                    slotdata[nindex],
                                    style: const TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ),
                              );
                            }))
                  ]),
            );
          },
        ));
  }

  Widget MobileVendorAvailabilityWidget() {
    return Container(
        width: 300,
        margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: widget.result.length,
          itemBuilder: (context, index) {
            List slotdata = widget.result[index].slotrange.split(',');
            return Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 65,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              widget.result[index].day,
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "October 8th",
                              style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            )
                          ]),
                    ),
                    const SizedBox(
                      width: 25,
                    ),
                    Container(
                      child: Column(children: [
                        Container(
                          height: 18,
                          width: 18,
                          decoration: const BoxDecoration(
                              color: themeColor, shape: BoxShape.circle),
                        ),
                        Container(
                          width: 1,
                          height: 217,
                          color: const Color.fromRGBO(112, 112, 112, 1),
                        )
                      ]),
                    ),
                    Container(
                        width: 150,
                        margin: const EdgeInsets.only(left: 35, top: 15),
                        child: ListView.builder(
                            itemCount: slotdata.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, nindex) {
                              return Container(
                                height: 34,
                                width: 174,
                                margin: const EdgeInsets.only(bottom: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(21),
                                    color: blueColor),
                                child: Center(
                                  child: Text(
                                    slotdata[nindex],
                                    style: const TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ),
                              );
                            }))
                  ]),
            );
          },
        ));
  }
}
