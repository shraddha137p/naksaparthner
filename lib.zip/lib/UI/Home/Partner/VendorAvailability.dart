import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorAvailabilityWidget.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerWalletModel.dart';
import 'package:naksaa_services/model/VendorAvailabilityModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Utility/rechargeNowUtility.dart';
import 'VideoCall/OrderSuccessModel.dart';
import 'VideoCall/VideoCallandAudioCallModal.dart';

class VendorAvailabilityScreen extends StatefulWidget {
  List<Vdatum> Vendor;
  List<Walletdatum> wallet;
  VendorAvailabilityScreen(
      {super.key, required this.Vendor, required this.wallet});

  @override
  State<VendorAvailabilityScreen> createState() =>
      _VendorAvailabilityScreenState(Vendor);
}

class _VendorAvailabilityScreenState extends State<VendorAvailabilityScreen> {
  List<Vdatum> Vendor;
  _VendorAvailabilityScreenState(this.Vendor);
  var vendorService = AllVendorService();
  List<VendorAData> result = [];

  Future<List<VendorAData>> getVendorDetails() async {
    result =
        await vendorService.viewVendorAvailability(Vendor[0].id.toString());
    print(result);
    if (result != null) {
      return result;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVendorAvailability();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVendorAvailability();
      } else {
        return MobileVendorAvailability();
      }
    });
  }

  Widget DesktopVendorAvailability() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Availability"),
        backgroundColor: themeColor,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            margin:  EdgeInsets.only(top: screenSize.height / 96.1),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: screenSize.height / 11.30,
                    width: screenSize.width / 19.2,
                    child: Stack(children: [
                      Container(
                        margin:  EdgeInsets.only(left: screenSize.width / 192),
                        height: screenSize.height / 12.64,
                        width: screenSize.width / 25.26,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // color: Colors.red,
                            border: Border.all(width: 2, color: lightblueColor),
                            image: DecorationImage(
                                image: NetworkImage(
                                    '${MainUrl}vendor-image/${Vendor[0].photo}'),
                                fit: BoxFit.cover)),
                      ),
                      Positioned(
                          top: 8,
                          right: 6,
                          child: Container(
                            height: 25,
                            width: 25,
                            decoration: const BoxDecoration(
                                image: DecorationImage(
                                    image:
                                        AssetImage("assets/SVG/star2-2x.png"),
                                    fit: BoxFit.fill)),
                          )),
                    ]),
                  ),
                  Container(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Vendor[0].name,
                            style:  TextStyle(
                                fontSize: screenSize.width / 160, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: screenSize.width / 16,
                            child: Text(
                              Vendor[0].primaryskills,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: screenSize.width / 160,
                                fontWeight: FontWeight.normal,
                                color: Colors.black.withOpacity(
                                  0.53,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: screenSize.width / 16,
                            child: Text(
                              Vendor[0].language,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: screenSize.width / 160,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            ),
                          ),
                          Text(
                            "Exp: ${(Vendor[0].startdate.difference(Vendor[0].enddate)).inDays} Years",
                            style: TextStyle(
                                fontSize: screenSize.width / 160,
                                fontWeight: FontWeight.normal,
                                color: Colors.black.withOpacity(0.53)),
                          )
                        ]),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 49),
                    child: Column(children: [
                      InkWell(
                        onTap: () {
                          if (double.parse(widget.wallet[0].walletamount) >=
                              100.0) {
                            showDialog(
                                context: context,
                                builder: (BuildContext context) =>
                                    VideoCallAndAudioCallModal(
                                        name: widget.Vendor[0].name,
                                        image: widget.Vendor[0].photo,
                                        vid: widget.Vendor[0].id.toString(),
                                        audioCallPrice:
                                            widget.Vendor[0].audicallprice,
                                        videoCallPrice:
                                            widget.Vendor[0].audicallprice));
                          } else {
                            showDialog<void>(
                              context: context,
                              barrierDismissible:
                                  false, // user must tap button!
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  elevation: 0.6,
                                  contentPadding:  EdgeInsets.only(
                                      left: screenSize.width / 96, right: screenSize.width / 192, top: screenSize.height / 192.2, bottom: screenSize.height / 192.2),
                                  titlePadding:  EdgeInsets.only(
                                      left: screenSize.width / 96, right: screenSize.width / 192, top: screenSize.height / 192.2, bottom: screenSize.height / 192.2),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)),
                                  title: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Recharge Plan'),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.close,
                                          color: Colors.red,
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      )
                                    ],
                                  ),
                                  content: const RechargeNow(),
                                );
                              },
                            );
                          }
                        },
                        child: Container(
                          height: screenSize.height / 26.69,
                          width: screenSize.width / 23.13,
                          decoration:  BoxDecoration(
                            color: themeColor,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(
                                screenSize.width / 87.27,
                              ),
                              bottomLeft: Radius.circular(
                                screenSize.width / 87.27,
                              ),
                            ),
                          ),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children:  [
                                Icon(
                                  Icons.phone,
                                  color: blueColor,
                                  size: screenSize.width / 96,
                                ),
                                SizedBox(
                                  width: screenSize.width / 384,
                                ),
                                Text(
                                  "Call",
                                  style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 137.1,
                                      color: blueColor,
                                      fontWeight: FontWeight.bold),
                                )
                              ]),
                        ),
                      ),
                       SizedBox(
                        height: screenSize.height / 96.1,
                      ),
                      GestureDetector(
                        onTap: () {
                          showDialog<void>(
                            context: context,
                            barrierDismissible: false, // user must tap button!
                            builder: (BuildContext context) {
                              return AlertDialog(
                                elevation: 0.6,
                                contentPadding:  EdgeInsets.only(
                                   left: screenSize.width / 96, right: screenSize.width / 192, top: screenSize.height / 192.2, bottom: screenSize.height / 192.2),
                                titlePadding:  EdgeInsets.only(
                                   left: screenSize.width / 96, right: screenSize.width / 192, top: screenSize.height / 192.2, bottom: screenSize.height / 192.2),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(screenSize.width / 128)),
                                title: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('Recharge Plan'),
                                    IconButton(
                                      icon: const Icon(
                                        Icons.close,
                                        color: Colors.red,
                                      ),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    )
                                  ],
                                ),
                                content: const RechargeNow(),
                              );
                            },
                          );
                        },
                        child: Container(
                            height: screenSize.height / 26.69,
                            width: screenSize.width / 23.13,
                            decoration:  BoxDecoration(
                                color: themeColor,
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(screenSize.width / 87.27),
                                    bottomLeft: Radius.circular(screenSize.width / 87.27))),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children:  [
                                  Icon(
                                    Icons.message,
                                    color: blueColor,
                                    size: screenSize.width / 96,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    "Chat",
                                    style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 137.1,
                                        color: blueColor,
                                        fontWeight: FontWeight.bold),
                                  )
                                ])),
                      ),
                    ]),
                  )
                ]),
          ),
          RefreshIndicator(
            onRefresh: () {
              return getVendorDetails();
            },
            child: FutureBuilder(
                future: getVendorDetails(),
                builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                    item.hasData
                        ? item.data!.length != 0
                            ? VendorAvailabilityWidget(result: result)
                            : const Center(
                                child: Text("No Data Found"),
                              )
                        :  SizedBox(
                            height: screenSize.height / 1.20,
                            child: Center(
                              child: CircularProgressIndicator(),
                            ),
                          )),
          )
        ]),
      ),
    );
  }

  Widget MobileVendorAvailability() {
    var screenSize =
        MediaQuery.of(context).size; // bottom: screenSize.height/151.2,

    return Scaffold(
      appBar: AppBar(
        title:  Text("Availability",style: GoogleFonts.merriweather(fontSize: 20),),
        backgroundColor: themeColor,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            margin: EdgeInsets.only(top: screenSize.height / 75.6),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: screenSize.height / 8.89,
                    width: screenSize.width / 3.6,
                    child: Stack(children: [
                      Container(
                        margin: EdgeInsets.only(left: screenSize.width / 36),
                        height: screenSize.height / 9.94,
                        width: screenSize.width / 4.73,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // color: Colors.red,
                            border: Border.all(
                                width: screenSize.width / 180,
                                color: lightblueColor),
                            image: DecorationImage(
                                image: NetworkImage(
                                    '${MainUrl}vendor-image/${Vendor[0].photo}'),
                                fit: BoxFit.cover)),
                      ),
                      Positioned(
                          top: 8,
                          right: 6,
                          child: Container(
                            height: screenSize.height / 30.24,
                            width: screenSize.width / 14.4,
                            decoration: const BoxDecoration(
                                image: DecorationImage(
                                    image:
                                        AssetImage("assets/SVG/star2-2x.png"),
                                    fit: BoxFit.fill)),
                          )),
                    ]),
                  ),
                  Container(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Vendor[0].name,
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 30,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: screenSize.width / 3,
                            child: Text(
                              Vendor[0].primaryskills,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.merriweather(
                                  fontSize: screenSize.width / 30,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            ),
                          ),
                          SizedBox(
                            width: screenSize.width / 3,
                            child: Text(
                              Vendor[0].language,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.merriweather(
                                  fontSize: screenSize.width / 30,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            ),
                          ),
                          Text(
                            "Exp: ${(Vendor[0].startdate.difference(Vendor[0].enddate)).inDays} Years",
                            style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 30,
                                fontWeight: FontWeight.normal,
                                color: Colors.black.withOpacity(0.53)),
                          )
                        ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: screenSize.width / 7.34),
                    child: Column(children: [
                      GestureDetector(
                        onTap: () {
                          if (widget.wallet.length >= 1) {
                            if (double.parse(widget.wallet[0].walletamount) >=
                                100.0) {
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) =>
                                      VideoCallAndAudioCallModal(
                                          name: widget.Vendor[0].name,
                                          image: widget.Vendor[0].photo,
                                          vid: widget.Vendor[0].id.toString(),
                                          audioCallPrice:
                                              widget.Vendor[0].audicallprice,
                                          videoCallPrice:
                                              widget.Vendor[0].audicallprice));
                            } else {
                              showDialog<void>(
                                context: context,
                                barrierDismissible:
                                    false, // user must tap button!
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    elevation: 0.6,
                                    contentPadding: EdgeInsets.only(
                                        left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                    titlePadding:  EdgeInsets.only(
                                        left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(screenSize.width / 24)),
                                    title: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text('Recharge Plan'),
                                        IconButton(
                                          icon: const Icon(
                                            Icons.close,
                                            color: Colors.red,
                                          ),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        )
                                      ],
                                    ),
                                    content: const RechargeNow(),
                                  );
                                },
                              );
                            }
                          } else {
                            showDialog<void>(
                              context: context,
                              barrierDismissible:
                                  false, // user must tap button!
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  elevation: 0.6,
                                  contentPadding:  EdgeInsets.only(
                                      left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                  titlePadding:  EdgeInsets.only(
                                      left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width / 24)),
                                  title: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Recharge Plan'),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.close,
                                          color: Colors.red,
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      )
                                    ],
                                  ),
                                  content: const RechargeNow(),
                                );
                              },
                            );
                          }
                        },
                        child: Container(
                          height: screenSize.height / 21,
                          width: screenSize.width / 4.33,
                          decoration:  BoxDecoration(
                              color: themeColor,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(screenSize.width / 16.3),
                                  bottomLeft: Radius.circular(screenSize.width / 16.3))),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children:  [
                                Icon(
                                  Icons.phone,
                                  color: blueColor,
                                  size: screenSize.width / 18,
                                ),
                                SizedBox(
                                  width: screenSize.width / 72,
                                ),
                                Text(
                                  "Call",
                                  style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 25.7,
                                      color: blueColor,
                                      fontWeight: FontWeight.bold),
                                )
                              ]),
                        ),
                      ),
                       SizedBox(
                        height: screenSize.height / 75.6,
                      ),
                      GestureDetector(
                        onTap: () async {
                          if (widget.wallet.length >= 1) {
                            if (double.parse(widget.wallet[0].walletamount) >=
                                100.0) {
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();

                              Map<String, String> data = {
                                "userid": pref
                                    .getString(
                                      "uid",
                                    )
                                    .toString(),
                                "vid": widget.Vendor[0].id.toString(),
                                "orderfor": "chat",
                                "orderstatus": "created",
                                "createdat": DateTime.now().toString()
                              };
                              _createOrderForChat(
                                data,
                                widget.Vendor[0].photo,
                                widget.Vendor[0].name,
                              );
                            } else {
                              showDialog<void>(
                                context: context,
                                barrierDismissible:
                                    false, // user must tap button!
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    elevation: 0.6,
                                    contentPadding:  EdgeInsets.only(
                                        left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                    titlePadding:  EdgeInsets.only(
                                        left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(screenSize.width / 24)),
                                    title: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text('Recharge Plan'),
                                        IconButton(
                                          icon: const Icon(
                                            Icons.close,
                                            color: Colors.red,
                                          ),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        )
                                      ],
                                    ),
                                    content: const RechargeNow(),
                                  );
                                },
                              );
                            }
                          } else {
                            showDialog<void>(
                              context: context,
                              barrierDismissible:
                                  false, // user must tap button!
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  elevation: 0.6,
                                  contentPadding:  EdgeInsets.only(
                                      left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                  titlePadding:  EdgeInsets.only(
                                      left: screenSize.width / 18, right: screenSize.width / 36, top: screenSize.height / 151.2, bottom: screenSize.height / 151.1),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(screenSize.width / 24)),
                                  title: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Recharge Plan'),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.close,
                                          color: Colors.red,
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      )
                                    ],
                                  ),
                                  content: const RechargeNow(),
                                );
                              },
                            );
                          }
                        },
                        child: Container(
                            height: screenSize.height / 21,
                            width: screenSize.width / 4.33,
                            decoration:  BoxDecoration(
                                color: themeColor,
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(screenSize.width / 16.3),
                                    bottomLeft: Radius.circular(screenSize.width / 16.3))),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children:  [
                                  Icon(
                                    Icons.message,
                                    color: blueColor,
                                    size: screenSize.width / 18,
                                  ),
                                  SizedBox(
                                    width: screenSize.width / 72,
                                  ),
                                  Text(
                                    "Chat",
                                    style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 25.7,
                                        color: blueColor,
                                        fontWeight: FontWeight.bold),
                                  )
                                ])),
                      ),
                    ]),
                  )
                ]),
          ),
          RefreshIndicator(
            onRefresh: () {
              return getVendorDetails();
            },
            child: FutureBuilder(
                future: getVendorDetails(),
                builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                    item.hasData
                        ? item.data!.length != 0
                            ? VendorAvailabilityWidget(result: result)
                            : const Center(
                                child: Text("No Data Found"),
                              )
                        :  SizedBox(
                            height: screenSize.height / 0.945,
                            child: Center(
                              child: CircularProgressIndicator(),
                            ),
                          )),
          )
        ]),
      ),
    );
  }

  var networkProvider = NetworkHandler();
  bool isloading = false;
  void _createOrderForChat(
      Map<String, String> data, String image, String name) async {
    var response = await networkProvider.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "success",
          ),
        );
        print("Order created succesflly");
      } else {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "failed",
          ),
        );
        print("Something went wrong");
      }
    }
  }
}
