import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfile.dart';
import 'package:naksaa_services/model/VendorWorkModel.dart';

import '../../../MainAsset/URL.dart';
import '../../REgister/project Assets/constants.dart';

class VendorProfileWork extends StatelessWidget {
  List<VendorWork> wportdata;
  VendorProfileWork({super.key, required this.wportdata});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVendorProfileWork();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVendorProfileWork();
      } else {
        return MobileVendorProfileWork();
      }
    });
  }

  Widget DesktopVendorProfileWork() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Work Portfolio"),
        elevation: 0,
        backgroundColor: themeColor,
      ),
      body: Container(
        height: 250,
        width: 250,
        margin: const EdgeInsets.only(top: 15, bottom: 15, left: 5),
        child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                childAspectRatio: 1,
                crossAxisCount: 3,
                crossAxisSpacing: 3.0,
                mainAxisSpacing: 3.0),
            itemCount: wportdata.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () async {
                  await showDialog(
                      context: context,
                      builder: (_) => ImageDialog(
                          '${MainUrl}vendor-work/${wportdata[index].photo}'));
                },
                child: Container(
                  width: 250,
                  height: 250,
                  margin: const EdgeInsets.only(bottom: 10, right: 5),
                  child: CircleAvatar(
                    backgroundImage: NetworkImage(
                        '${MainUrl}vendor-work/${wportdata[index].photo}'),
                  ),
                ),
              );
            }),
      ),
    );
  }

  Widget MobileVendorProfileWork() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Work Portfolio"),
        elevation: 0,
        backgroundColor: themeColor,
      ),
      body: Container(
        // height: 250,
        // width: 250,
        margin: const EdgeInsets.only(top: 15, bottom: 15, left: 5),
        child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                
                crossAxisCount: 2,
                crossAxisSpacing: 3.0,
                mainAxisSpacing: 3.0),
            itemCount: wportdata.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () async {
                  await showDialog(
                      context: context,
                      builder: (_) => ImageDialog(
                          '${MainUrl}vendor-work/${wportdata[index].photo}'));
                },
                child: Container(
                  width: 250,
                  height: 250,
                  margin: const EdgeInsets.only(bottom: 10, right: 5),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.withOpacity(0.4), width: 1),
                    borderRadius: BorderRadius.circular(10),
                    image: DecorationImage(image: NetworkImage('${MainUrl}vendor-work/${wportdata[index].photo}'))),
                ),
              );
            }),
      ),
    );
  }
}
