import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:uuid/uuid.dart';

import '../../../API/FirebaseMethods.dart';

class ChatWithVideoCall extends StatefulWidget {
  final String chatRoomId;

  const ChatWithVideoCall({
    super.key,
    required this.chatRoomId,
  });

  @override
  State<ChatWithVideoCall> createState() => _ChatWithVideoCallState();
}

class _ChatWithVideoCallState extends State<ChatWithVideoCall> {
  final TextEditingController _message = TextEditingController();
  final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  File? imageFIle;
  Future getImage() async {
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.gallery).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getImageByCamera() async {
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getDocumentForUpload() async {
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future uploadImage() async {
    String filename = const Uuid().v1();
    int status = 1;
    await _fireStore
        .collection('chatRoom')
        .doc(widget.chatRoomId)
        .collection('chats')
        .doc(filename)
        .set({
      "sendby": _auth.currentUser!.displayName,
      "message": "",
      "type": "img",
      "time": FieldValue.serverTimestamp()
    });
    var ref =
        FirebaseStorage.instance.ref().child('images').child('$filename.jpg');
    var uploadTask = await ref.putFile(imageFIle!).catchError((error) async {
      await _fireStore
          .collection('chatRoom')
          .doc(widget.chatRoomId)
          .collection('chats')
          .doc(filename)
          .delete();
      status = 0;
    });

    if (status == 1) {
      String imageurl = await uploadTask.ref.getDownloadURL();

      await _fireStore
          .collection('chatRoom')
          .doc(widget.chatRoomId)
          .collection('chats')
          .doc(filename)
          .update({"message": imageurl});
      print(imageurl);
    }

    // String imageUrl = await uploadTask.ref.getDownloadURL();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    print(size.height);
    print(size.width);
    return SizedBox(
      height: size.height / 1.12,
      child: Stack(
        children: [
          Positioned(
              bottom: 0,
              child: Container(
                height: size.height / 2.88,
                width: size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20)),
                  color: blueColor,
                ),
              )),
          Container(
            width: size.width,
            margin: EdgeInsets.only(
                top: MediaQuery.of(context).size.height * 0.02,
                left: 15,
                right: 14),
            child: SingleChildScrollView(
              child: Column(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  height: MediaQuery.of(context).size.height * 0.85,
                  width: MediaQuery.of(context).size.width * 0.3,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white),
                  child: StreamBuilder<dynamic>(
                      stream: _fireStore
                          .collection('livechat')
                          .doc(widget.chatRoomId)
                          .collection('live')
                          .orderBy("createdAt", descending: false)
                          .snapshots(),
                      builder: (BuildContext context,
                          AsyncSnapshot<dynamic> snapshot) {
                        print(snapshot.data);
                        if (snapshot.data != null) {
                          return ListView.builder(
                            shrinkWrap: true,
                            itemCount: snapshot.data!.docs.length,
                            itemBuilder: (context, index) {
                              Map map = snapshot.data!.docs[index].data();

                              return messageScreenWithVideoChat(size, map);
                            },
                          );
                        } else {
                          return Container();
                        }
                      }),
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  height: 50,
                  child: Row(children: [
                    GestureDetector(
                        onTap: () {
                          showDialog<void>(
                            barrierDismissible: true,
                            context: context,
                            builder: (BuildContext context) {
                              return Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.all(0),
                                    child: Container(
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      color: darkBlue,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: <Widget>[
                                          GestureDetector(
                                            onTap: () => getImageByCamera(),
                                            child: Container(
                                              height: 65,
                                              width: 65,
                                              decoration: BoxDecoration(
                                                  color: darkBlue,
                                                  borderRadius:
                                                      BorderRadius.circular(50),
                                                  image: const DecorationImage(
                                                      image: AssetImage(
                                                          "assets/SVG/upload-2x.png"),
                                                      fit: BoxFit.fill)),
                                            ),
                                          ),
                                          GestureDetector(
                                            onTap: () => getImage(),
                                            child: Container(
                                              height: 65,
                                              width: 65,
                                              decoration: BoxDecoration(
                                                  color: darkBlue,
                                                  borderRadius:
                                                      BorderRadius.circular(50),
                                                  image: const DecorationImage(
                                                      image: AssetImage(
                                                          "assets/SVG/upload-2x.png"),
                                                      fit: BoxFit.fill)),
                                            ),
                                          ),
                                          Container(
                                            height: 65,
                                            width: 65,
                                            decoration: BoxDecoration(
                                                color: darkBlue,
                                                borderRadius:
                                                    BorderRadius.circular(50),
                                                image: const DecorationImage(
                                                    image: AssetImage(
                                                        "assets/SVG/upload-2x.png"),
                                                    fit: BoxFit.fill)),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              );
                            },
                          );
                        },
                        child: Container(
                          height: 49,
                          width: 49,
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage("assets/SVG/upload-2x.png"),
                                  fit: BoxFit.fill)),
                        )),
                    const SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 49,
                      width: MediaQuery.of(context).size.width * 0.33,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white),
                      child: Row(children: [
                        Form(
                          key: _formKey,
                          child: Container(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            height: 49,
                            width: MediaQuery.of(context).size.width * 0.3,
                            child: TextFormField(
                              controller: _message,
                              decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  contentPadding: EdgeInsets.only(
                                      left: 15, bottom: 11, top: 11, right: 15),
                                  hintText: "Type Comment here",
                                  hintStyle: TextStyle(
                                      fontSize: 14,
                                      color: Color.fromRGBO(196, 196, 196, 1))),
                              style: const TextStyle(
                                fontSize: 14,
                                color: blueColor,
                              ),
                              keyboardType: TextInputType.multiline,
                              maxLines: null,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter message';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        GestureDetector(
                          onTap: () async {
                            if (_formKey.currentState!.validate()) {
                              Map<String, dynamic> messages = {
                                "sendby": " widget.customer[0]!.name",
                                "message": _message.text,
                                "type": "text",
                                "time": FieldValue.serverTimestamp()
                              };
                              await chatFirebase(
                                _message.text,
                                "fdf",
                                context,
                                widget.chatRoomId,
                                "fdf",
                                "text",
                              );
                              _message.clear();
                            }
                          },
                          child: Container(
                            height: 21,
                            width: 25,
                            decoration: const BoxDecoration(
                                // shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: AssetImage("assets/SVG/Group.png"),
                                    fit: BoxFit.fill)),
                          ),
                        ),
                      ]),
                    )
                  ]),
                )
              ]),
            ),
          ),
        ],
      ),
    );
  }

  // Future<void> chatFirebase(String text, String id, BuildContext context,
  //     String commentid, String username, String uid, String type) async {
  //   FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  //   try {
  //     await firebaseFirestore
  //         .collection('livechat')
  //         .doc(commentid)
  //         .collection('live')
  //         .add({
  //       'username': username,
  //       'message': text,
  //       'uid': uid,
  //       'createdAt': DateTime.now(),
  //       'commentId': commentid,
  //       'type': type
  //     });
  //   } on FirebaseException catch (e) {
  //     print(e.toString());
  //   }
  // }

  Widget messageScreenWithVideoChat(Size size, Map snapshot) {
    return (snapshot)['type'] != "img"
        ? Container(
            width: size.width / 2.5,
            alignment: Alignment.centerLeft,
            child: Container(
              decoration: const BoxDecoration(
                  color: darkBlue,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                      bottomLeft: Radius.circular(20))),
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
              margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    snapshot['message'],
                    style: const TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    snapshot['username'],
                    style: const TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ))
        : Container(
            alignment: Alignment.centerLeft,
            child: snapshot['message'] != ""
                ? GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => broadImageView(
                                    image: snapshot['message'],
                                  )));
                    },
                    child: Container(
                      width: size.width / 2,
                      height: size.height / 3,
                      decoration: BoxDecoration(
                          color: darkBlue,
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                              bottomLeft: Radius.circular(20)),
                          image: DecorationImage(
                              image: NetworkImage(snapshot['message']),
                              fit: BoxFit.cover)),
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 14),
                      margin: const EdgeInsets.symmetric(
                          vertical: 5, horizontal: 8),
                      alignment: Alignment.center,
                    ),
                  )
                : Container(
                    width: size.width / 2,
                    height: size.height / 3,
                    decoration: const BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                          bottomLeft: Radius.circular(20)),
                    ),
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                    margin:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    alignment: Alignment.center,
                    child: const Center(child: LoadingIndicator()),
                  ),
          );
  }
}

class broadImageView extends StatelessWidget {
  String image;
  broadImageView({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          foregroundColor: darkBlue,
          elevation: 0,
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.share)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert))
          ],
        ),
        body: Container(
          height: size.height / 1.2,
          width: size.width,
          decoration: BoxDecoration(
            image: DecorationImage(image: NetworkImage(image)),
          ),
        ));
  }
}
