import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/MainUtility/blog_details.dart';
import 'package:webviewx/webviewx.dart';

class NaksaBlog extends StatefulWidget {
  const NaksaBlog({super.key});

  @override
  State<NaksaBlog> createState() => _NaksaBlogState();
}

class _NaksaBlogState extends State<NaksaBlog> {
  late WebViewXController webviewController;

  Size get screenSize => MediaQuery.of(context).size;

  @override
  void dispose() {
    webviewController.dispose();
    super.dispose();
  }

  bool isloading = true;

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.only(bottom: 10),
        child: WebViewX(
          key: const ValueKey('webviewx'),
          initialContent: 'https://naksa.kesarwanisangh.com/slider/',
          initialSourceType: SourceType.url,
          height: screenSize.height,
          width: screenSize.width,
          onWebViewCreated: (controller) => webviewController = controller,
          onPageStarted: (src) {
            debugPrint('A new page has started loading: $src\n');
          },
          onPageFinished: (src) {
            debugPrint('The page has finished loading: $src\n');
            setState(() {
              isloading = false;
            });
          },
          jsContent: const {
            EmbeddedJsContent(
              js: "function testPlatformIndependentMethod() { console.log('Hi from JS') }",
            ),
            EmbeddedJsContent(
              webJs:
                  "function testPlatformSpecificMethod(msg) { TestDartCallback('Web callback says: ' + msg) }",
              mobileJs:
                  "function testPlatformSpecificMethod(msg) { TestDartCallback.postMessage('Mobile callback says: ' + msg) }",
            ),
          },
          dartCallBacks: {},
          webSpecificParams: const WebSpecificParams(
            printDebugInfo: true,
          ),
          mobileSpecificParams: const MobileSpecificParams(
            androidEnableHybridComposition: true,
          ),
          navigationDelegate: (navigation) {
            debugPrint(navigation.content.sourceType.toString());
            return NavigationDecision.navigate;
          },
        ));
  }

  Widget DesktopLatestnews() {
    return SizedBox(
      height: 50,
      child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                // Navigator.push(context,
                //     MaterialPageRoute(builder: (context) => BlogDetailsPage()));
              },
              child: Container(
                margin: const EdgeInsets.only(right: 10),
                // decoration: BoxDecoration(
                //     border:
                //         Border.all(width: 1, color: Color.fromRGBO(2, 44, 67, 1)),
                //     borderRadius: BorderRadius.circular(10)),
                child: Column(children: [
                  SizedBox(
                    height: 143,
                    width: 236,
                    child: Stack(children: [
                      Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            image: DecorationImage(
                                image: NetworkImage(
                                    "https://images.indianexpress.com/2020/11/diwali-feature-1.jpg"),
                                fit: BoxFit.fill)),
                      ),
                      Positioned(
                          top: 9,
                          left: 186,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                vertical: 2, horizontal: 5),
                            decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.78),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(children: [
                              const Icon(
                                Icons.remove_red_eye_rounded,
                                size: 15,
                              ),
                              Text(
                                "3222",
                                style: GoogleFonts.merriweather(
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ]),
                          ))
                    ]),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    width: 236,
                    child: Text(
                      "Navratri 2022 is round the corner: Here is your whole information about Navratri parv",
                      textAlign: TextAlign.left,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.merriweather(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                ]),
              ),
            );
          }),
    );
  }

  Widget MobileLatestnews() {
    return SizedBox(
      height: 190,
      child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => IncomingCallRequest(
                //             channelname: 'bbkj',
                //             token: 'token',
                //             vendorimage: 'vendorimage')));
              },
              child: Container(
                margin: const EdgeInsets.only(right: 10),
                // decoration: BoxDecoration(
                //     border:
                //         Border.all(width: 1, color: Color.fromRGBO(2, 44, 67, 1)),
                //     borderRadius: BorderRadius.circular(10)),
                child: Column(children: [
                  SizedBox(
                    height: 143,
                    width: 236,
                    child: Stack(children: [
                      Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            image: DecorationImage(
                                image: NetworkImage(
                                    "https://images.indianexpress.com/2020/11/diwali-feature-1.jpg"),
                                fit: BoxFit.fill)),
                      ),
                      Positioned(
                          top: 9,
                          left: 186,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                vertical: 2, horizontal: 5),
                            decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.78),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(children: [
                              const Icon(
                                Icons.remove_red_eye_rounded,
                                size: 15,
                              ),
                              Text(
                                "3222",
                                style: GoogleFonts.merriweather(
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ]),
                          ))
                    ]),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    width: 236,
                    child: Text(
                      "Navratri 2022 is round the corner: Here is your whole information about Navratri parv",
                      textAlign: TextAlign.left,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.merriweather(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                ]),
              ),
            );
          }),
    );
  }
}
