import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../API/NetworkProvider.dart';
import '../../../REgister/project Assets/constants.dart';
import '../../BottomNavigation.dart';

class ConfirmBackPress extends StatelessWidget {
  String orderid;

  ConfirmBackPress({super.key, required this.orderid});

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return AlertDialog(
      elevation: 0.6,
      contentPadding: EdgeInsets.only(
          left: width / 18,
          right: width / 36,
          top: height / 151.2,
          bottom: height / 151.2),
      titlePadding: EdgeInsets.only(
          left: width / 18,
          right: width / 36,
          top: height / 151.2,
          bottom: height / 151.2),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(width / 24)),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Do you want to go back?",
            style: TextStyle(
                fontSize: width / 21.176470,
                fontWeight: FontWeight.bold,
                color: darkBlue),
          ),
          IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                color: Colors.black,
              ))
        ],
      ),
      actionsAlignment: MainAxisAlignment.end,
      actions: [
        TextButton(
          onPressed: () {
            // Navigator.pop(context
            _completeOrder(orderid, context);
          },
          child: Text(
            'Yes',
            style: TextStyle(
                fontSize: width / 22.5,
                fontWeight: FontWeight.bold,
                color: darkBlue),
          ),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          child: Text(
            'No',
            style: TextStyle(
                fontSize: width / 22.5,
                fontWeight: FontWeight.bold,
                color: blueColor),
          ),
        ),
      ],
    );
  }

  var networkHandler = NetworkHandler();
  void _completeOrder(String orderid, BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? vid = prefs.getString("vid");

    Map<String, String> data = {};
    var reponse =
        await networkHandler.post("complete-order-customer/${orderid}", data);
    if (reponse.statusCode == 200) {
      Map jsonResponse = jsonDecode(reponse.body);
      if (jsonResponse["status"] == true) {
        Navigator.pop(context, true);
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
                builder: (context) => BottomNavigationBarScreen(pageIndex: 0)),
            (route) => false);
      } else {
        Fluttertoast.showToast(
            msg: "something went wrong",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            textColor: Colors.white,
            fontSize: 16.0);
        Navigator.pop(context, false);
      }
    }
  }
}
