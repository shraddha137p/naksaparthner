import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/URL.dart';

import '../../../REgister/project Assets/constants.dart';

class OrderSuccessModel extends StatefulWidget {
  String vendorimage;
  String vendorName;
  String response;
  OrderSuccessModel(
      {super.key,
      required this.vendorimage,
      required this.vendorName,
      required this.response});

  @override
  State<OrderSuccessModel> createState() => _OrderSuccessModelState();
}

class _OrderSuccessModelState extends State<OrderSuccessModel> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(const Duration(seconds: 20), () {
      Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(60), bottomRight: Radius.circular(60))),
      elevation: 5,
      backgroundColor: Colors.white,
      title: const Center(
          child: Text('Request Submitted Succesfully',
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
      content: SizedBox(
        height: 200,
        width: 200,
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            // Column(
            //   children: [
            //     CircleAvatar(
            //       radius: 30,
            //       backgroundImage: NetworkImage(
            //           MainUrl + 'customer-image/' + widget.customerimage),
            //     ),
            //     SizedBox(
            //       height: 5,
            //     ),
            //     Text("${widget.customerName}",
            //         style: TextStyle(color: Colors.black)),
            //   ],
            // ),
            // for (int i = 0; i < 20; i++)
            //   Container(
            //     width: 5,
            //     height: 1,
            //     decoration: BoxDecoration(
            //       border: Border(
            //         bottom: BorderSide(
            //           width: 1,
            //           color: i % 2 == 0 ? Colors.black : Colors.transparent,
            //         ),
            //       ),
            //     ),
            //   ),
            // const SizedBox(
            //   height: 5,
            // ),
            Column(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage(
                      '${MainUrl}vendor-image/${widget.vendorimage}'),
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  widget.vendorName,
                  style: const TextStyle(color: Colors.black),
                ),
              ],
            )
          ]),
          const SizedBox(
            height: 20,
          ),
          const Text(
            'Our Partner will respond you soon.',
            style: TextStyle(
                fontSize: 14, color: Colors.black, fontWeight: FontWeight.w300),
          ),
          const Text(
            'It will close automatically with in 20 sec or press close',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 12, color: Colors.black, fontWeight: FontWeight.w100),
          ),
          const SizedBox(
            height: 4,
          ),
          TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Container(
                height: 30,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: darkBlue, borderRadius: BorderRadius.circular(10)),
                child: const Center(
                    child:
                        Text('Close', style: TextStyle(color: Colors.white))),
              ))
        ]),
      ),
    );
  }
}
