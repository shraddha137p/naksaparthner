import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/VideoCallWithVendor.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../MainAsset/URL.dart';

class IncomingVideoCallRequest extends StatefulWidget {
  String channelname;
  String token;
  String vendorid;
  IncomingVideoCallRequest(
      {super.key,
      required this.channelname,
      required this.token,
      required this.vendorid});

  @override
  State<IncomingVideoCallRequest> createState() =>
      _IncomingVideoCallRequestState();
}

class _IncomingVideoCallRequestState extends State<IncomingVideoCallRequest>
    with WidgetsBindingObserver {
  bool isloading = false;
  bool isloginloading = false;
  List<Vdatum> results = [];
  var vendorService = AllVendorService();
  var customerService = CustomerProfileService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    getVendorDetails();
    getUserDetails();
  }

  Future<List<Vdatum>> getVendorDetails() async {
    print(widget.vendorid);
    var response = await vendorService.viewSingleVendor(widget.vendorid);

    setState(() {
      results =
          VendorDetailsmodel.fromJson(jsonDecode(response)).vdata.toList();
    });
    print(results);

    return results;
  }

  var networkHandler = NetworkHandler();
  String token = "";
  List<CustomerP?> _customerList = [];
  Future<List<CustomerP?>> getUserDetails() async {
    print(widget.vendorid);
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? phone = pref.getString("phone");
    var response = await customerService.viewCustomerProfile(phone!);

    if (results != null) {
      setState(() {
        _customerList = response!;
      });
      var response1 = await networkHandler
          .get("rtc/${widget.channelname}/publisher/3600/2");
      Map jsonresponse = response1;
      setState(() {
        isloading = true;
        token = jsonresponse["token"];
        print(token);
      });
      return _customerList;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVIdeoCallscreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVIdeoCallscreen();
      } else {
        return MobileVIdeoCallscreen();
      }
    });
  }

  Widget DesktopVIdeoCallscreen() {
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              color: darkBlue,
              child: Center(
                child: Container(
                  height: 812,
                  width: MediaQuery.of(context).size.width * 0.5,
                  margin: const EdgeInsets.only(top: 30, bottom: 30),
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.shade300,
                          blurRadius: 5,
                        )
                      ],
                      borderRadius: BorderRadius.circular(50),
                      color: Colors.black,
                      image: DecorationImage(
                        image: const AssetImage("assets/SVG/request.png"),
                        fit: BoxFit.fill,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.25), BlendMode.dstATop),
                      )),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(top: 90),
                          child: const Text(
                            "Incoming Chat Request From",
                            style: TextStyle(fontSize: 14, color: Colors.white),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          height: 43,
                          width: 118,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                            image: AssetImage("assets/logo.png"),
                          )),
                        ),
                        const SizedBox(
                          height: 144,
                        ),
                        Container(
                          height: 127,
                          width: 127,
                          decoration: BoxDecoration(
                              border: Border.all(width: 2, color: themeColor),
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: NetworkImage(
                                      '${MainUrl}vendor-image/${results[0].photo}'),
                                  fit: BoxFit.fill)),
                        ),
                        const SizedBox(
                          height: 22,
                        ),
                        Container(
                          child: Text(
                            results[0].name!,
                            style: const TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        const SizedBox(
                          height: 84,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            isloginloading != true
                                ? GestureDetector(
                                    onTap: () async {
                                      setState(() {
                                        isloginloading = true;
                                      });
                                      SharedPreferences pref =
                                          await SharedPreferences.getInstance();
                                      String? uid = pref.getString("uid");
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  VideoCallWithVendor(
                                                      channnelName:
                                                          widget.token,
                                                      token: token,
                                                      // vendorData: results,
                                                      userid: _customerList[0]!
                                                          .id
                                                          .toString())));
                                      setState(() {
                                        isloginloading = false;
                                      });
                                    },
                                    child: Container(
                                      height: 71,
                                      width: 71,
                                      decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                          color:
                                              Color.fromRGBO(67, 217, 102, 1)),
                                      child: const Center(
                                        child: Icon(
                                          Icons.call,
                                          color: Colors.white,
                                          size: 30,
                                        ),
                                      ),
                                    ),
                                  )
                                : const LoadingIndicator(),
                            GestureDetector(
                              onTap: () async {},
                              child: Container(
                                height: 71,
                                width: 71,
                                decoration: const BoxDecoration(
                                    shape: BoxShape.circle, color: Colors.red),
                                child: const Center(
                                  child: Icon(
                                    Icons.call,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        // Text(
                        //   "Reject Chat Request",
                        //   style: TextStyle(
                        //       fontSize: 10,
                        //       color: Colors.white,
                        //       fontWeight: FontWeight.normal),
                        // ),
                      ]),
                ),
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }

  Widget MobileVIdeoCallscreen() {
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: Colors.black,
                    image: DecorationImage(
                      image: const AssetImage("assets/SVG/request.png"),
                      fit: BoxFit.fill,
                      colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.25), BlendMode.dstATop),
                    )),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 90),
                        child: const Text(
                          "Incoming Chat Request From",
                          style: TextStyle(fontSize: 14, color: Colors.white),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 43,
                        width: 118,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                          image: AssetImage("assets/logo.png"),
                        )),
                      ),
                      const SizedBox(
                        height: 110,
                      ),
                      Container(
                        height: 110,
                        width: 110,
                        decoration: BoxDecoration(
                            border: Border.all(width: 2, color: themeColor),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                image: NetworkImage(
                                    '${MainUrl}vendor-image/${results[0].photo}'),
                                fit: BoxFit.fill)),
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Container(
                        child: Text(
                          results[0].name!,
                          style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(
                        height: 150,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          isloginloading != true
                              ? GestureDetector(
                                  onTap: () async {
                                    setState(() {
                                      isloginloading = true;
                                    });
                                    SharedPreferences pref =
                                        await SharedPreferences.getInstance();
                                    String? uid = pref.getString("uid");
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                VideoCallWithVendor(
                                                    channnelName:
                                                        widget.channelname,
                                                    token: token,
                                                    userid: "2")
                                            // LiveVendorScreen(
                                            //   isRole: false,
                                            //   index: 0,
                                            //   channelId: "vdcv",
                                            //   uid: 11,
                                            //   channnelName: "naks",
                                            //   token:
                                            //       "007eJxTYGBXakh0rlJ32iVxw6v6mH3zLG7P29zWngesmnK33S5M4VBgSDIzTDYzMbA0MTRONkkxSktKMk8zMbKwSDUxT0y0SDETT9BKaQhkZLDJN2JlZIBAEJ+FIS8xu5iBAQArjxsc",
                                            //   // vendorData: results,
                                            ));
                                    setState(() {
                                      isloginloading = false;
                                    });
                                  },
                                  child: Container(
                                    height: 71,
                                    width: 71,
                                    decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color.fromRGBO(67, 217, 102, 1)),
                                    child: const Center(
                                      child: Icon(
                                        Icons.call,
                                        color: Colors.white,
                                        size: 30,
                                      ),
                                    ),
                                  ),
                                )
                              : const LoadingIndicator(),
                          GestureDetector(
                            onTap: () async {},
                            child: Container(
                              height: 71,
                              width: 71,
                              decoration: const BoxDecoration(
                                  shape: BoxShape.circle, color: Colors.red),
                              child: const Center(
                                child: Icon(
                                  Icons.call,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      // Text(
                      //   "Reject Chat Request",
                      //   style: TextStyle(
                      //       fontSize: 10,
                      //       color: Colors.white,
                      //       fontWeight: FontWeight.normal),
                      // ),
                    ]),
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }
}
