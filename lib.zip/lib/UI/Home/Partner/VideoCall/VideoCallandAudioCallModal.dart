import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/OrderSuccessModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../REgister/project Assets/constants.dart';

class VideoCallAndAudioCallModal extends StatefulWidget {
  String name;
  String image;
  String audioCallPrice;
  String videoCallPrice;
  String vid;
  VideoCallAndAudioCallModal(
      {super.key,
      required this.name,
      required this.vid,
      required this.audioCallPrice,
      required this.image,
      required this.videoCallPrice});

  @override
  State<VideoCallAndAudioCallModal> createState() =>
      _VideoCallAndAudioCallModalState();
}

class _VideoCallAndAudioCallModalState
    extends State<VideoCallAndAudioCallModal> {
  bool isloading = false;
  var networkHandler = NetworkHandler();
  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return AlertDialog(
      elevation: 0.6,
      contentPadding:
           EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/36, top: screenSize.height/151.2, bottom: screenSize.height/151.2),
      titlePadding:
           EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/36, top: screenSize.height/151.2, bottom: screenSize.height/151.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(screenSize.width/24)),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Call with ${widget.name}",
            style:  TextStyle(
                fontSize: screenSize.width/24, fontWeight: FontWeight.bold, color: darkBlue),
          ),
          IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                color: Colors.black,
              ))
        ],
      ),
      content: isloading != true
          ? SizedBox(
              height: screenSize.height/5.6,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isloading = true;
                      });
                      audioCallOrder(widget.name, widget.image, widget.vid);
                    },
                    child: Column(
                      children: [
                        Container(
                            height: screenSize.height/11.63,
                            width: screenSize.width/5.53,
                            decoration: const BoxDecoration(
                                color: themeColor, shape: BoxShape.circle),
                            child: const Icon(Icons.call)),
                         SizedBox(
                          height: screenSize.height/75.6,
                        ),
                         Text(
                          "Audio Call",
                          style: TextStyle(
                              fontSize: screenSize.width/24,
                              fontWeight: FontWeight.bold,
                              color: darkBlue),
                        ),
                         SizedBox(
                          height: screenSize.height/151.2,
                        ),
                        Text(
                          "₹ ${widget.audioCallPrice}/min",
                          style:  TextStyle(
                              fontSize: screenSize.width/30, fontWeight: FontWeight.w500),
                        )
                      ],
                    ),
                  ),
                   SizedBox(
                    width: screenSize.width/30,
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isloading = true;
                      });

                      videoCallOrder(widget.vid, widget.name, widget.image);
                    },
                    child: Column(
                      children: [
                        Container(
                            height: screenSize.height/11.63,
                            width: screenSize.width/5.53,
                            decoration: const BoxDecoration(
                                color: themeColor, shape: BoxShape.circle),
                            child: const Icon(Icons.video_call)),
                         SizedBox(
                          height: screenSize.height/75.6,
                        ),
                         Text(
                          "Video Call",
                          style: TextStyle(
                              fontSize: screenSize.width/24,
                              fontWeight: FontWeight.bold,
                              color: darkBlue),
                        ),
                        Text(
                          "₹ ${widget.videoCallPrice}/min",
                          style:  TextStyle(
                              fontSize: screenSize.width/30, fontWeight: FontWeight.w500),
                        )
                      ],
                    ),
                  )
                ],
              ))
          : Container(
              height: screenSize.height/5.6,
              color: Colors.white,
              child: const Center(
                child: CircularProgressIndicator(
                  color: themeColor,
                ),
              ),
            ),
    );
  }

  void audioCallOrder(String name, String image, String vid) async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    Map<String, String> data = {
      "userid": pref.getString("uid").toString(),
      "vid": vid,
      "orderfor": "call",
      "orderstatus": "created",
      "createdat": DateTime.now().toString()
    };

    var response = await networkHandler.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        print("Order created succesflly");
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "success",
          ),
        );
      } else {
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "failed",
          ),
        );
        print("Something went wrong");
      }
    }
  }

  void videoCallOrder(String vid, String name, String image) async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    Map<String, String> data = {
      "userid": pref.getString("uid").toString(),
      "vid": vid,
      "orderfor": "video-call",
      "orderstatus": "created",
      "createdat": DateTime.now().toString()
    };

    var response = await networkHandler.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        print("Order created succesflly");
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
              vendorName: name, vendorimage: image, response: "success"),
        );
      } else {
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
            context: context,
            builder: (BuildContext context) => OrderSuccessModel(
                  vendorName: name,
                  vendorimage: image,
                  response: "failed",
                ));
        print("Something went wrong");
      }
    }
  }
}
