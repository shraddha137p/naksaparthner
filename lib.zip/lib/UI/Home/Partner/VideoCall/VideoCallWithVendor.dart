////
import 'dart:async';
import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/AgoraConfig.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/CompleteOrderModel.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:agora_rtc_engine/rtc_local_view.dart' as RtcLocalView;
import 'package:agora_rtc_engine/rtc_remote_view.dart' as RtcRemoteView;
import 'package:permission_handler/permission_handler.dart';

// import 'package:agora_rtc_engine/agora_rtc_engine.dart';///

import '../../BottomNavigation.dart';
import '../ChatWithVideoCall.dart';

class VideoCallWithVendor extends StatefulWidget {
  String channnelName;
  String token;
  String userid;

  VideoCallWithVendor(
      {super.key,
      required this.channnelName,
      required this.token,
      required this.userid});

  @override
  State<VideoCallWithVendor> createState() => _VideoCallWithVendorState();
}

class _VideoCallWithVendorState extends State<VideoCallWithVendor> {
  bool mAudio = false;
  bool mVideo = false;
  bool shareScreen = false;
  // int uid = 0; // uid of the local user
  // final String channnelName = "naks";
  // final String token =
  //     "007eJxTYFjgN/PdQ6/63d7y/DOlLviv72J6Ks+XcJ/xQ/WJ2Q/nPbNWYEgyM0w2MzGwNDE0TjZJMUpLSjJPMzGysEg1MU9MtEgx+1l4PbkhkJHhSv5HBkYoBPFZGPISs4sZGACRqCFX";
  int? _remoteUid; // uid of the remote user
  bool _isJoined = false; // Indicates if the local user has joined the channel
  late RtcEngine agoraEngine; // Agora engine instance

  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>(); // Global key to access the scaffold

  showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(message),
    ));
  }

  @override
  void initState() {
    super.initState();
    // Set up an instance of Agora engine
    setupVideoSDKEngine();
  }

  Future<void> setupVideoSDKEngine() async {
    // retrieve or request camera and microphone permissions
    await [Permission.microphone, Permission.camera].request();
    // await window.navigator.getUserMedia(audio: true, video: true);

    //create an instance of the Agora engine
    // agoraEngine = createAgoraRtcEngine();
    // await agoraEngine
    //     .initialize(const RtcEngineContext(appId: AgoraChatConfig.appKey));
    agoraEngine = await RtcEngine.create(AgoraChatConfig.appKey);

    await agoraEngine.enableVideo();

    // Register the event handler
    agoraEngine.setEventHandler(
      RtcEngineEventHandler(
        joinChannelSuccess: (String channel, int uid, int elapsed) {
          showMessage("Local user uid:$uid joined the channel");
          setState(() {
            _isJoined = true;
          });
        },
        userJoined: (int uid, int elapsed) {
          showMessage("Remote user uid:$uid joined the channel");
          setState(() {
            _remoteUid = uid;
          });
        },
        userOffline: (int uid, UserOfflineReason reason) {
          showMessage("Remote user uid:$uid left the channel");
          setState(() {
            _remoteUid = null;
          });
        },
      ),
    );
    join();
  }

  void join() async {
    await agoraEngine.startPreview();

    // // Set channel options including the client role and channel profile
    // ChannelMediaOptions options = const ChannelMediaOptions(
    //   clientRoleType: ClientRoleType.clientRoleBroadcaster,
    //   channelProfile: ChannelProfileType.channelProfileCommunication,
    // );

    // await agoraEngine.joinChannel(
    //   token: widget.token,
    //   channelId: widget.channnelName,
    //   options: options,
    //   uid: int.parse(widget.userid),
    // );
    await agoraEngine.joinChannel(
        widget.token, widget.channnelName, null, int.parse(widget.userid));
  }

  @override
  void dispose() async {
    await agoraEngine.leaveChannel();

    // agoraEngine.release();
    super.dispose();
  }

  void leave() async {
    setState(() {
      _isJoined = false;
      _remoteUid = null;
    });
    await agoraEngine.leaveChannel();
    showDialog(
        context: context,
        builder: (context) => ConfirmBackPress(orderid: "119"));
  }

  void muteAudio(bool value) async {
    print(mAudio);
    if (mAudio == false) {
      await agoraEngine.muteLocalAudioStream(true);
      setState(() {
        mAudio = true;
      });
    } else {
      await agoraEngine.muteLocalAudioStream(false);
      setState(() {
        mAudio = false;
      });
    }
  }

  void muteVideo(bool val) async {
    if (mVideo == false) {
      agoraEngine.muteLocalVideoStream(true);
      setState(() {
        mVideo = true;
      });
    } else {
      agoraEngine.muteLocalVideoStream(false);
      setState(() {
        mVideo = false;
      });
    }
  }

  Future<void> _switchCamera() {
    return agoraEngine.switchCamera();
  }

  Future<void> _shareScreen() async {
    // setState(() {
    //   shareScreen = !shareScreen;
    // });

    // if (shareScreen) {
    //   agoraEngine.startScreenCapture(const ScreenCaptureParameters2(
    //       captureAudio: true,
    //       audioParams: ScreenAudioParameters(
    //           sampleRate: 16000, channels: 2, captureSignalVolume: 100),
    //       captureVideo: true,
    //       videoParams: ScreenVideoParameters(
    //           dimensions: VideoDimensions(height: 1280, width: 720),
    //           frameRate: 15,
    //           bitrate: 600)));
    //   // Start screen sharing

    // } else {
    //   await agoraEngine.stopScreenCapture();
    // }
    // ChannelMediaOptions options = ChannelMediaOptions(
    //   publishCameraTrack: !shareScreen,
    //   publishMicrophoneTrack: !shareScreen,
    //   publishScreenTrack: shareScreen,
    //   publishScreenCaptureAudio: shareScreen,
    //   publishScreenCaptureVideo: shareScreen,
    // );

    // agoraEngine.updateChannelMediaOptions(options);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVIdeoCallWithVendor();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVIdeoCallWithVendor();
      } else {
        return MobileVIdeoCallWithVendor();
      }
    });
  }

  Widget DesktopVIdeoCallWithVendor() {
    return Scaffold(
        backgroundColor: bgColor,
        body: SizedBox(
          height: 800,
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                height: 800,
                width: MediaQuery.of(context).size.width * 0.7,
                margin: const EdgeInsets.only(right: 20, left: 35),
                child: Stack(children: [
                  Positioned(
                    top: 5,
                    child: Row(
                      children: [
                        const SizedBox(
                          height: 50,
                          width: 50,
                          child: CircleAvatar(
                            backgroundImage: AssetImage("assets/about_us.jpg"),
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Container(
                          decoration: const BoxDecoration(
                              color: Colors.redAccent,
                              borderRadius: BorderRadius.all(
                                Radius.circular(5),
                              )),
                          width: MediaQuery.of(context).size.width * 0.25,
                          height: MediaQuery.of(context).size.height * 0.06,
                          child: Center(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  "Name",
                                  style: GoogleFonts.merriweather(
                                    color: Colors.white,
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "UI/UX Design -------------",
                                  style: GoogleFonts.merriweather(
                                    fontSize: 15,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 30,
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 70,
                    child: Container(
                      height: 580,
                      width: MediaQuery.of(context).size.width * 0.7,
                      decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(30)),
                      child: Center(child: _remoteVideo()),
                    ),
                  ),
                  Positioned(
                      right: 5,
                      top: 75,
                      child: Container(
                        height: 180,
                        width: 130,
                        decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(10)),
                        child: Center(child: _localPreview()),
                      )),
                  Positioned(
                    bottom: 0,
                    child: Container(
                        height: 80,
                        width: MediaQuery.of(context).size.width * 0.7,
                        decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.75),
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10))),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            GestureDetector(
                              onTap: () {
                                leave();
                              },
                              child: Container(
                                height: 65,
                                width: 65,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Center(child: Icon(Icons.phone)),
                                    Center(
                                        child: Text(
                                      "End Call",
                                      style: GoogleFonts.merriweather(
                                        fontSize: 10,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ))
                                  ],
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                _switchCamera();
                              },
                              child: Container(
                                height: 65,
                                width: 65,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: themeColor,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Center(child: Icon(Icons.camera_alt)),
                                    Center(
                                        child: Text(
                                      "Cam",
                                      style: GoogleFonts.merriweather(
                                        fontSize: 10,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ))
                                  ],
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                print("pressed");
                                muteAudio(mAudio);
                              },
                              child: Container(
                                height: 65,
                                width: 65,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color:
                                      mAudio == false ? themeColor : darkBlue,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Center(
                                        child: Icon(
                                      Icons.volume_off,
                                      color: mAudio == false
                                          ? Colors.black
                                          : Colors.white,
                                    )),
                                    Center(
                                        child: Text(
                                      "Volume",
                                      style: GoogleFonts.merriweather(
                                        fontSize: 10,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ))
                                  ],
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                muteVideo(mVideo);
                              },
                              child: Container(
                                height: 65,
                                width: 65,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color:
                                      mVideo == false ? themeColor : darkBlue,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Center(
                                        child: Icon(
                                      Icons.volume_mute,
                                      color: mVideo == false
                                          ? Colors.black
                                          : Colors.white,
                                    )),
                                    Center(
                                        child: Text(
                                      "unmute",
                                      style: GoogleFonts.merriweather(
                                        fontSize: 10,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ))
                                  ],
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                _shareScreen();
                              },
                              child: Container(
                                height: 65,
                                width: 65,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: themeColor,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Center(child: Icon(Icons.share)),
                                    Center(
                                        child: Text(
                                      "Share",
                                      style: GoogleFonts.merriweather(
                                        fontSize: 10,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ))
                                  ],
                                ),
                              ),
                            )
                          ],
                        )),
                  ),
                ]),
              ),
              SizedBox(
                height: 730,
                width: MediaQuery.of(context).size.width * 0.25,
                child: Column(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border.all(color: Colors.red),
                            borderRadius: const BorderRadius.all(
                              Radius.circular(20),
                            )),
                        width: MediaQuery.of(context).size.width * 0.1,
                        height: MediaQuery.of(context).size.height * 0.06,
                        child: Center(
                          child: Text(
                            "End",
                            style: GoogleFonts.merriweather(
                                fontSize: 15, color: Colors.red),
                          ),
                        ),
                      ),
                    ),
                    const ChatWithVideoCall(
                      chatRoomId: "vh",
                    ),
                  ],
                ),
              )
            ],
          ),
        ));
  }

  Widget MobileVIdeoCallWithVendor() {
    return WillPopScope(
      onWillPop: () async {
        final shouldpop = await showDialog(
            context: context,
            builder: (context) => ConfirmBackPress(orderid: "119"));
        return shouldpop!;
      },
      child: Scaffold(
          body: Container(
        height: 800,
        width: double.infinity,
        child: Stack(children: [
          Container(
            height: 800,
            width: double.infinity,
            decoration: BoxDecoration(color: Colors.red),
            child: Center(child: _remoteVideo()),
          ),
          Positioned(
              right: 5,
              bottom: 90,
              child: Container(
                height: 180,
                width: 130,
                decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(child: _localPreview()),
              )),
          Positioned(
            bottom: 0,
            child: Container(
                height: 80,
                width: 360,
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.75),
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10))),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: () {
                        leave();
                      },
                      child: Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.red,
                        ),
                        child: Center(child: Icon(Icons.phone)),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _switchCamera();
                      },
                      child: Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: themeColor,
                        ),
                        child: Center(child: Icon(Icons.camera_alt)),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        print("pressed");
                        muteAudio(mAudio);
                      },
                      child: Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: mAudio == false ? themeColor : darkBlue,
                        ),
                        child: Center(
                            child: Icon(
                          Icons.volume_off,
                          color: mAudio == false ? Colors.black : Colors.white,
                        )),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        muteVideo(mVideo);
                      },
                      child: Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: mVideo == false ? themeColor : darkBlue,
                        ),
                        child: Center(
                            child: Icon(
                          Icons.volume_mute,
                          color: mVideo == false ? Colors.black : Colors.white,
                        )),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _shareScreen();
                      },
                      child: Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: themeColor,
                        ),
                        child: Center(child: Icon(Icons.share)),
                      ),
                    )
                  ],
                )),
          )
        ]),
      )),
    );
  }

  Widget _localPreview() {
    if (_isJoined) {
      if (shareScreen) {
        return Container();
        // );
      } else {
        return const RtcLocalView.SurfaceView();
      }
    } else {
      return const Text(
        'Join a channel',
        textAlign: TextAlign.center,
      );
    }
  }

// Display remote user's video
  Widget _remoteVideo() {
    if (_remoteUid != null) {
      return RtcRemoteView.SurfaceView(
        uid: _remoteUid!,
        channelId: widget.channnelName,
      );
    } else {
      String msg = '';
      if (_isJoined) msg = 'Waiting for a remote user to join';
      return Text(
        msg,
        textAlign: TextAlign.center,
      );
    }
  }
}
