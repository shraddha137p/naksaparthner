// class DynamicLinkProvider {

//   void createLink( String refCode) async {
//   final String url = "https://com.example.naksaa_services?ref=$refCode";




//   }
// }
