import 'dart:convert';

import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/AgoraConfig.dart';
import 'package:naksaa_services/API/FirebaseMethods.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/Service/VendorFollowerChekerService.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/LoginModel.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:agora_rtc_engine/rtc_local_view.dart' as RtcLocalView;
import 'package:agora_rtc_engine/rtc_remote_view.dart' as RtcRemoteView;
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:naksaa_services/model/VenodrFollowerCheck.dart';
import 'package:naksaa_services/model/livestreamfirebase.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../MainAsset/LoadingIndicator.dart';
import '../Utility/rechargeNowUtility.dart';
import 'AllLiveVendor.dart';
import 'ChatWithVideoCall.dart';

class LiveVendorScreen extends StatefulWidget {
  AsyncSnapshot<dynamic> edata;
  int index;
  // final String vid;
  final String token;
  final String channnelName;
  final bool isRole;
  final String channelId;
  final int uid;
  LiveVendorScreen(
      {super.key,
      // required this.vid,
      required this.edata,
      required this.isRole,
      required this.channelId,
      required this.channnelName,
      required this.token,
      required this.index,
      required this.uid});

  @override
  State<LiveVendorScreen> createState() => _LiveVendorScreenState();
}

class _LiveVendorScreenState extends State<LiveVendorScreen> {
  final TextEditingController _message = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  _LiveVendorScreenState();
  var networkProvider = NetworkHandler();

  bool mAudio = false;
  bool mVideo = false;
  bool shareScreen = false;
  // int uid = 0; // uid of the local user
  // final String channnelName = "naks";
  // final String token =
  //     "007eJxTYFjgN/PdQ6/63d7y/DOlLviv72J6Ks+XcJ/xQ/WJ2Q/nPbNWYEgyM0w2MzGwNDE0TjZJMUpLSjJPMzGysEg1MU9MtEgx+1l4PbkhkJHhSv5HBkYoBPFZGPISs4sZGACRqCFX";
  int? _remoteUid = 1; // uid of the remote user
  bool _isJoined = false; // Indicates if the local user has joined the channel
  late RtcEngine agoraEngine; // Agora engine instance

  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>(); // Global key to access the scaffold

  showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(message),
    ));
  }

  @override
  void initState() {
    GetVendorInfo();
    super.initState();
    // Set up an instance of Agora engine
    setupVideoSDKEngine();
  }

  final AllVendorService _vendorService = AllVendorService();
  List<Vdatum> vendordata = [];
  void GetVendorInfo() async {
    var response = await _vendorService.viewSingleVendor(widget.uid.toString());
    if (response != null) {
      setState(() {
        vendordata =
            VendorDetailsmodel.fromJson(jsonDecode(response)).vdata!.toList();
      });
    }
  }

  Future<void> setupVideoSDKEngine() async {
    // retrieve or request camera and microphone permissions
    // await [Permission.microphone, Permission.camera].request();
    // await window.navigator.getUserMedia(audio: true, video: true);
    // await window.navigator.getUserMedia(audio: true, video: true);

    //create an instance of the Agora engine
    // agoraEngine = createAgoraRtcEngine();
    // await agoraEngine
    //     .initialize(const RtcEngineContext(appId: AgoraChatConfig.appKey));
    agoraEngine = await RtcEngine.create(AgoraChatConfig.appKey);

    // await agoraEngine.enableVideo();

    // Register the event handler
    agoraEngine.setEventHandler(
      RtcEngineEventHandler(
        joinChannelSuccess: (String channel, int uid, int elapsed) {
          showMessage("Local user uid:$uid joined the channel");
          setState(() {
            _isJoined = true;
          });
        },
        userJoined: (int uid, int elapsed) {
          showMessage("Remote user uid:$uid joined the channel");
          setState(() {
            _remoteUid = 1;
          });
        },
        userOffline: (int uid, UserOfflineReason reason) {
          showMessage("Remote user uid:$uid left the channel");
          setState(() {
            _remoteUid = null;
          });
        },
      ),
    );
    join();
  }

  void join() async {
    await agoraEngine.startPreview();

    // // Set channel options including the client role and channel profile
    ChannelMediaOptions options =
        ChannelMediaOptions(autoSubscribeAudio: true, autoSubscribeVideo: true);

    // await agoraEngine.joinChannel(
    //   token: widget.token,
    //   channelId: widget.channnelName,
    //   options: options,
    //   uid: int.parse(widget.userid),
    // );
    await agoraEngine.joinChannelWithUserAccount(
        widget.token, widget.channnelName, widget.uid.toString(), options);
  }

  @override
  void dispose() async {
    await agoraEngine.leaveChannel();
    // agoraEngine.release();
    super.dispose();
  }

  void leave() async {
    setState(() {
      _isJoined = false;
      _remoteUid = null;
    });
    agoraEngine.leaveChannel();

    await updateViewCount("bj", false, widget.channelId);
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => BottomNavigationBarScreen(pageIndex: 0)));
  }

  void muteAudio(bool value) async {
    print(mAudio);
    if (mAudio == false) {
      await agoraEngine.muteLocalAudioStream(true);
      setState(() {
        mAudio = true;
      });
    } else {
      await agoraEngine.muteLocalAudioStream(false);
      setState(() {
        mAudio = false;
      });
    }
  }

  void muteVideo(bool val) async {
    if (mVideo == false) {
      agoraEngine.muteLocalVideoStream(true);
      setState(() {
        mVideo = true;
      });
    } else {
      agoraEngine.muteLocalVideoStream(false);
      setState(() {
        mVideo = false;
      });
    }
  }

  bool isfollowing = false;

  final List<FollowDatum> _vendorFollwer = [];
  var followerCheker = FollowerService();

  Future<void> _switchCamera() {
    return agoraEngine.switchCamera();
  }

  Future<void> _shareScreen() async {
    // setState(() {
    //   shareScreen = !shareScreen;
    // });

    // if (shareScreen) {
    //   agoraEngine.startScreenCapture(const ScreenCaptureParameters2(
    //       captureAudio: true,
    //       audioParams: ScreenAudioParameters(
    //           sampleRate: 16000, channels: 2, captureSignalVolume: 100),
    //       captureVideo: true,
    //       videoParams: ScreenVideoParameters(
    //           dimensions: VideoDimensions(height: 1280, width: 720),
    //           frameRate: 15,
    //           bitrate: 600)));
    //   // Start screen sharing

    // } else {
    //   await agoraEngine.stopScreenCapture();
    // }
    // ChannelMediaOptions options = ChannelMediaOptions(
    //   publishCameraTrack: !shareScreen,
    //   publishMicrophoneTrack: !shareScreen,
    //   publishScreenTrack: shareScreen,
    //   publishScreenCaptureAudio: shareScreen,
    //   publishScreenCaptureVideo: shareScreen,
    // );

    // agoraEngine.updateChannelMediaOptions(options);
  }
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopLiveVendorScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopLiveVendorScreen();
      } else {
        return MobileLiveVendorScreen();
      }
    });
  }

  Future<bool> showExitPopup() async {
    showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Center(child: Text('Leave Stream ?')),
            content: SingleChildScrollView(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text("Cancel"),
                  ),
                  TextButton(
                    onPressed: () async {
                      await updateViewCount(
                        "vh",
                        false,
                        widget.channelId,
                      );
                      Navigator.of(context).pushReplacement(
                        (MaterialPageRoute(
                            builder: (context) => const AllLiveVendor())),
                      );
                      Navigator.pop(context);
                      await updateViewCount("sdshdg", false, widget.channelId);
                    },
                    child: const Text("Yes"),
                  ),
                ],
              ),
            ),
          );
        });

    return false;
  }

  Widget DesktopLiveVendorScreen() {
    var screenSize = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: showExitPopup,
      child: Scaffold(
        body: Row(
          children: [
            Container(
              margin:  EdgeInsets.only(top: screenSize.height/48.05, bottom: screenSize.height/48.05, left: screenSize.width/96),
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width * 0.55,
              decoration: const BoxDecoration(
                color: Colors.red,
              ),
              child: Stack(children: [
                SizedBox(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width * 0.55,
                    child: _remoteVideo()),
                Positioned(
                  top: screenSize.height/38.4,
                  left: screenSize.width/174.5,
                  child: SizedBox(
                    height: screenSize.height/12.9,
                    child: Row(children: [
                      GestureDetector(
                        onTap: () {
                          showDialog<void>(
                              context: context,
                              builder: (BuildContext context) {
                                return BackPressLiveWidget("back");
                              });
                        },
                        child: Container(
                          height: screenSize.height/21.8,
                          width: screenSize.width/43.6,
                          decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.30),
                              shape: BoxShape.circle),
                          child:  Center(
                              child: Icon(
                            Icons.arrow_back_sharp,
                            size: screenSize.width/76.8,
                            color: Colors.white,
                          )),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/101,
                      ),
                      GestureDetector(
                        onTap: () {},
                        child: SizedBox(
                          height: screenSize.height/12.9,
                          width: screenSize.width/32.54,
                          child: Stack(
                            children: [
                              Container(
                                height: screenSize.height/16.2,
                                width: screenSize.width/32.54,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border:
                                      Border.all(width: screenSize.width/960, color: Colors.red),
                                  image: DecorationImage(
                                    image: NetworkImage(
                                      "${MainUrl}vendor-image/${vendordata[0].photo}",
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                  bottom: 0,
                                  child: Container(
                                    height: screenSize.height/41.7,
                                    width: screenSize.width/32.54,
                                    decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius:
                                            BorderRadius.circular(screenSize.width/128)),
                                    child:  Center(
                                        child: Text(
                                      "Live",
                                      style: TextStyle(
                                          fontSize: screenSize.width/112.9, color: Colors.white),
                                    )),
                                  ))
                            ],
                          ),
                        ),
                      ),
                       SizedBox(
                        width: screenSize.width/128,
                      ),
                      Text(
                        vendordata[0].name,
                        style:  TextStyle(
                            fontSize: screenSize.width/120,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                       SizedBox(
                        width: screenSize.width/384,
                      ),
                      Container(
                        height: screenSize.height/38.4,
                        width: screenSize.width/76.8,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/SVG/star2-2x.png"),
                                fit: BoxFit.fill)),
                        child:  Center(
                            child: Icon(
                          Icons.check,
                          size: screenSize.width/192,
                          color: Colors.white,
                        )),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.23,
                      ),
                      Container(
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              StreamBuilder<DocumentSnapshot>(
                                  stream: FirebaseFirestore.instance
                                      .collection('livestream')
                                      .doc(widget.channelId)
                                      .snapshots(),
                                  builder: (BuildContext context,
                                      AsyncSnapshot<DocumentSnapshot>
                                          snapshot) {
                                    if (snapshot.connectionState ==
                                        ConnectionState.waiting) {
                                      return const LoadingIndicator();
                                    }
                                    print("get data");
                                    print(snapshot.data);
                                    return Container(
                                      height: screenSize.height/41.7,
                                      padding:  EdgeInsets.symmetric(
                                          vertical: screenSize.height/480, horizontal: screenSize.width/274.2),
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(screenSize.width/128),
                                          color:
                                              Colors.black.withOpacity(0.25)),
                                      child: Center(
                                        child: Row(children: [
                                           Icon(
                                            Icons.remove_red_eye,
                                            color: Colors.white,
                                            size: screenSize.width/160,
                                          ),
                                           SizedBox(
                                            width: screenSize.width/640,
                                          ),
                                          Text(
                                            snapshot.data!['viewer'].toString(),
                                            style:  TextStyle(
                                                fontSize: screenSize.width/160,
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold),
                                          )
                                        ]),
                                      ),
                                    );
                                  }),
                               SizedBox(
                                height: screenSize.height/160.1,
                              ),
                              GestureDetector(
                                onTap: () async {
                                  SharedPreferences pref =
                                      await SharedPreferences.getInstance();
                                  String? uid = pref.getString("uid");
                                  followVendor(
                                    uid!,
                                    "11",
                                    !isfollowing,
                                  );
                                },
                                child: Container(
                                  height: screenSize.height/28.2,
                                  width: screenSize.width/15.86,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(screenSize.width/42.6),
                                      color:
                                          const Color.fromRGBO(17, 81, 115, 1)),
                                  child: Center(
                                    child: isfollowing != true
                                        ?  Text(
                                            "Follow",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: screenSize.width/128),
                                          )
                                        :  Text(
                                            "Following",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: screenSize.width/128),
                                          ),
                                  ),
                                ),
                              ),
                            ]),
                      )
                    ]),
                  ),
                ),
                Positioned(
                    bottom: screenSize.height/96.1,
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                             SizedBox(
                              width: screenSize.width/120,
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: Column(
                                children: [
                                  ListView.builder(
                                      shrinkWrap: true,
                                      physics:
                                          const AlwaysScrollableScrollPhysics(),
                                      itemCount: 5,
                                      itemBuilder: ((context, index) {
                                        return Container(
                                          margin:
                                               EdgeInsets.only(bottom: screenSize.height/96.1),
                                          child: Row(children: [
                                            Container(
                                              height: screenSize.height/24.64,
                                              width: screenSize.width/49.2,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  image: DecorationImage(
                                                      image: NetworkImage(
                                                          "https://rationcart.in/assets/img/Logo_rc.png"))),
                                            ),
                                          ]),
                                        );
                                      })),
                                ],
                              ),
                            ),
                             SizedBox(
                              width: screenSize.width/192,
                            ),
                            Container(
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        showDialog<void>(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return BackPressLiveWidget(
                                                  "noback");
                                            });
                                      },
                                      child: Container(
                                        height: screenSize.height/21.84,
                                        width: screenSize.width/43.63,
                                        decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: themeColor,
                                            border: Border.all(
                                                width: screenSize.width/960, color: Colors.white)),
                                        child:  Icon(
                                          Icons.call,
                                          color: blueColor,
                                          size: screenSize.width/76.8,
                                        ),
                                      ),
                                    ),
                                     SizedBox(
                                      height: screenSize.height/21.84,
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        SmartDialog.show(builder: (_) {
                                          return SendGift("2000");
                                        });
                                      },
                                      child: Container(
                                        height: screenSize.height/21.84,
                                        width: screenSize.width/43.6,
                                        decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: themeColor,
                                            border: Border.all(
                                                width: screenSize.width/960, color: Colors.white)),
                                        child:  Icon(
                                          Icons.diamond,
                                          color: blueColor,
                                          size: screenSize.width/76.8,
                                        ),
                                      ),
                                    ),
                                     SizedBox(
                                      height: screenSize.height/96.1,
                                    ),
                                    Container(
                                      height: screenSize.height/21.84,
                                      width: screenSize.width/43.63,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: themeColor,
                                          border: Border.all(
                                              width: screenSize.width/960, color: Colors.white)),
                                      child:  Icon(
                                        Icons.message,
                                        color: blueColor,
                                        size: screenSize.width/76.8,
                                      ),
                                    ),
                                     SizedBox(
                                      height: screenSize.height/96.1,
                                    ),
                                    Container(
                                      height: screenSize.height/21.84,
                                      width: screenSize.width/43.63,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: themeColor,
                                          border: Border.all(
                                              width: screenSize.width/960, color: Colors.white)),
                                      child:  Icon(
                                        Icons.thumb_up_alt_sharp,
                                        color: blueColor,
                                        size: screenSize.width/76.8,
                                      ),
                                    )
                                  ]),
                            )
                          ]),
                    ))
              ]),
            ),
             SizedBox(width: screenSize.width/96),
            SizedBox(
                height: screenSize.height/1.23,
                width: MediaQuery.of(context).size.width * 0.41,
                child: ChatWithVideoCall(
                  chatRoomId: widget.channelId,
                ))
          ],
        ),
      ),
    );
  }

  Widget BackPressLiveWidget(String name) {
    var screenSize = MediaQuery.of(context).size;
    return AlertDialog(
      title: Row(
        children: [
          const Center(
              child: Text(
            "Check Ohter Live session",
          )),
          const Spacer(),
          IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.close),
          )
        ],
      ),
      content: SizedBox(
        width: MediaQuery.of(context).size.width * 0.5,
        child: GridView.builder(
            itemCount: widget.edata.data.docs.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 4.0,
              childAspectRatio: 1.7,
              mainAxisSpacing: 10,
            ),
            itemBuilder: (BuildContext ctx, index) {
              LiveStreamFirebase livedata = LiveStreamFirebase.fromMap(
                  widget.edata.data.docs[index].data());
              return Column(
                children: [
                  Container(
                    height: 72,
                    width: 72,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                            image: NetworkImage(livedata.image),
                            fit: BoxFit.cover)),
                  ),
                  const SizedBox(
                    height: 4,
                  ),
                  Text(
                    livedata.name,
                    textAlign: TextAlign.end,
                    style: GoogleFonts.merriweather(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 15),
                  ),
                  Text(
                    "Architecture",
                    textAlign: TextAlign.end,
                    style: GoogleFonts.merriweather(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 12),
                  ),
                ],
              );
            }),
      ),
      actions: [
        name == "back"
            ? Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  InkWell(
                    onTap: leave,
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.1,
                      decoration: const BoxDecoration(
                          color: themeColor,
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: Padding(
                        padding: const EdgeInsets.all(
                          17,
                        ),
                        child: Center(
                          child: Text(
                            "Leave",
                            style: GoogleFonts.merriweather(
                                fontWeight: FontWeight.bold, color: darkBlue),
                          ),
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: leave,
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.1,
                      decoration: const BoxDecoration(
                          color: darkBlue,
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: Padding(
                        padding: const EdgeInsets.all(17),
                        child: Center(
                            child: Text(
                          "Follow & Leave",
                          style: GoogleFonts.merriweather(
                              fontWeight: FontWeight.bold, color: Colors.white),
                        )),
                      ),
                    ),
                  ),
                ],
              )
            : Container(),
      ],
    );
  }

  final FirebaseFirestore _fireStore = FirebaseFirestore.instance;

  Widget MobileLiveVendorScreen() {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        decoration: const BoxDecoration(),
        child: Stack(children: [
          Container(
            color: Colors.red,
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: _remoteVideo(),
          ),
          Positioned(
            top: 30,
            left: 5,
            child: SizedBox(
              height: 74,
              child: Row(children: [
                GestureDetector(
                  onTap: () {
                    leave();
                  },
                  child: Container(
                    height: 44,
                    width: 44,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.30),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: IconButton(
                        icon: const Icon(
                          Icons.arrow_back_sharp,
                          size: 25,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 7,
                ),
                GestureDetector(
                  onTap: () {},
                  child: SizedBox(
                    height: 65,
                    width: 50,
                    child: Stack(
                      children: [
                        Container(
                          height: 59,
                          width: 59,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(width: 2, color: Colors.red),
                              image: DecorationImage(
                                  image: NetworkImage(
                                      "${MainUrl}vendor-image/${vendordata[0].photo}"))),
                        ),
                        Positioned(
                            bottom: 0,
                            child: Container(
                              height: 23,
                              width: 50,
                              decoration: BoxDecoration(
                                  color: Colors.red,
                                  borderRadius: BorderRadius.circular(15)),
                              child: const Center(
                                  child: Text(
                                "Live",
                                style: TextStyle(
                                    fontSize: 17, color: Colors.white),
                              )),
                            ))
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  vendordata[0].name!,
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                const SizedBox(
                  width: 5,
                ),
                Container(
                  height: 25,
                  width: MediaQuery.of(context).size.width * 0.1,
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/SVG/star2-2x.png"),
                          fit: BoxFit.fill)),
                  child: const Center(
                      child: Icon(
                    Icons.check,
                    size: 10,
                    color: Colors.white,
                  )),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.2,
                ),
                Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      StreamBuilder<DocumentSnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('livestream')
                              .doc(widget.channelId)
                              .snapshots(),
                          builder: (BuildContext context,
                              AsyncSnapshot<DocumentSnapshot> snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return const LoadingIndicator();
                            }
                            print("get data");
                            print(snapshot.data);
                            return Container(
                              height: 23,
                              padding: const EdgeInsets.symmetric(
                                  vertical: 2, horizontal: 7),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Colors.black.withOpacity(0.25)),
                              child: Center(
                                child: Row(children: [
                                  const Icon(
                                    Icons.remove_red_eye,
                                    color: Colors.white,
                                    size: 12,
                                  ),
                                  const SizedBox(
                                    width: 3,
                                  ),
                                  Text(
                                    snapshot.data!['viewer'].toString(),
                                    style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  )
                                ]),
                              ),
                            );
                          }),
                      const SizedBox(
                        height: 6,
                      ),
                      GestureDetector(
                        onTap: () async {
                          SharedPreferences pref =
                              await SharedPreferences.getInstance();
                          String? uid = pref.getString("uid");
                          followVendor(
                            uid!,
                            "11",
                            !isfollowing,
                          );
                        },
                        child: Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(45),
                              color: const Color.fromRGBO(17, 81, 115, 1)),
                          child: Center(
                            child: isfollowing != true
                                ? const Text(
                                    "Follow",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15),
                                  )
                                : const Text(
                                    "Following",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15),
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ]),
            ),
          ),
          Positioned(
              bottom: 10,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                child:
                    Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  const SizedBox(
                    width: 16,
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.73,
                    child: Column(
                      children: [
                        StreamBuilder<dynamic>(
                            stream: _fireStore
                                .collection('livechat')
                                .doc(widget.channelId)
                                .collection('live')
                                .orderBy("createdAt", descending: false)
                                .snapshots(),
                            builder: (BuildContext context,
                                AsyncSnapshot<dynamic> snapshot) {
                              print(snapshot.data);
                              if (snapshot.data != null) {
                                return SizedBox(
                                  height: 250,
                                  child: ListView.builder(
                                      shrinkWrap: true,
                                      physics:
                                          const AlwaysScrollableScrollPhysics(),
                                      itemCount: snapshot.data.docs.length,
                                      itemBuilder: ((context, index) {
                                        Map map =
                                            snapshot.data!.docs[index].data();

                                        return Container(
                                          margin:
                                              const EdgeInsets.only(bottom: 10),
                                          child: Row(children: [
                                            Container(
                                              height: 39,
                                              width: 39,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: themeColor),
                                              child: Center(
                                                  child: Text(
                                                map['username'][0]
                                                    .toString()
                                                    .toUpperCase(),
                                                style: GoogleFonts.merriweather(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 18),
                                              )),
                                            ),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    map["username"],
                                                    style: const TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  const SizedBox(
                                                    height: 3,
                                                  ),
                                                  Text(
                                                    map["message"],
                                                    style: const TextStyle(
                                                        fontSize: 11,
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.normal),
                                                  )
                                                ]),
                                          ]),
                                        );
                                      })),
                                );
                              } else {
                                return Container();
                              }
                            }),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                          height: 35,
                          width: MediaQuery.of(context).size.width * 0.75,
                          padding: const EdgeInsets.symmetric(
                              vertical: 0, horizontal: 10),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(18)),
                          child: Center(
                            child: Row(
                              children: [
                                SizedBox(
                                  height: 35,
                                  width:
                                      MediaQuery.of(context).size.width * 0.6,
                                  child: Center(
                                    child: Form(
                                      key: _formKey,
                                      child: TextFormField(
                                        controller: _message,
                                        decoration: InputDecoration(
                                          border: InputBorder.none,
                                          hintText: 'Type your comment',
                                          hintStyle: GoogleFonts.merriweather(
                                              fontWeight: FontWeight.bold),
                                          contentPadding:
                                              const EdgeInsets.only(bottom: 10),
                                          focusedBorder: InputBorder.none,
                                          enabledBorder: InputBorder.none,
                                          errorBorder: InputBorder.none,
                                          disabledBorder: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  width: 0,
                                ),
                                // Transform.rotate(
                                // angle: -math.pi / 4,
                                InkWell(
                                  onTap: () async {
                                    if (_formKey.currentState!.validate()) {
                                      await chatFirebase(
                                        _message.text,
                                        "fdf",
                                        context,
                                        widget.channelId,
                                        "fdf",
                                        "text",
                                      );
                                      _message.clear();
                                    }
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: 3),
                                    height: 18,
                                    width: 18,
                                    decoration: const BoxDecoration(
                                      // shape: BoxShape.circle,
                                      image: DecorationImage(
                                        image:
                                            AssetImage("assets/SVG/Group.png"),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 35,
                  ),
                  Container(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            height: 44,
                            width: 44,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: themeColor,
                                border:
                                    Border.all(width: 2, color: Colors.white)),
                            child: const Icon(
                              Icons.call,
                              color: blueColor,
                              size: 25,
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          GestureDetector(
                            onTap: () {
                              SmartDialog.show(builder: (_) {
                                return SendGift("2000");
                              });
                            },
                            child: Container(
                              height: 44,
                              width: 44,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: themeColor,
                                border: Border.all(
                                  width: 2,
                                  color: Colors.white,
                                ),
                              ),
                              child: const Icon(
                                Icons.diamond,
                                color: blueColor,
                                size: 25,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Container(
                            height: 44,
                            width: 44,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: themeColor,
                                border:
                                    Border.all(width: 2, color: Colors.white)),
                            child: const Icon(
                              Icons.message,
                              color: blueColor,
                              size: 25,
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Container(
                            height: 44,
                            width: 44,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: themeColor,
                                border:
                                    Border.all(width: 2, color: Colors.white)),
                            child: const Icon(
                              Icons.thumb_up_alt_sharp,
                              color: blueColor,
                              size: 25,
                            ),
                          )
                        ]),
                  )
                ]),
              ))
        ]),
      ),
    );
  }

  Widget _localPreview() {
    if (_isJoined) {
      if (shareScreen) {
        return Container();
        // );
      } else {
        return const RtcLocalView.SurfaceView();
      }
    } else {
      return const Text(
        'Join a channel',
        textAlign: TextAlign.center,
      );
    }
  }

  Widget _remoteVideo() {
    if (_remoteUid != null) {
      return RtcRemoteView.SurfaceView(
        uid: _remoteUid!,
        channelId: widget.channnelName,
      );
    } else {
      String msg = '';
      if (_isJoined) msg = 'Waiting for a remote user to join';
      return Center(
        child: Text(
          msg,
          textAlign: TextAlign.center,
        ),
      );
    }
  }

  bool isFollwLoading = false;
  void followVendor(String cid, String vid, bool follow) async {
    Map<String, dynamic> data = {
      'customerid': cid,
      'vendorid': vid,
      'follow': follow,
    };
    setState(() {
      isFollwLoading = true;
    });
    var response = await networkProvider.post('vendor-follower', data);
    print(response.body);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse['data'] == 'inserted' ||
          jsonResponse['data'] == 'updated') {
        if (follow == false) {
          setState(() {
            isfollowing = false;
          });
          Fluttertoast.showToast(
              msg: "Sorry for inconvenience with User",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: darkBlue,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      }
      if (follow == true) {
        setState(() {
          isfollowing = true;
        });
        Fluttertoast.showToast(
            msg: "Thanks for following user",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: darkBlue,
            textColor: Colors.white,
            fontSize: 16.0);
      }
    }
  }

  Widget SendGift(String amount) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          20,
        ),
      ),
      height: 300,
      width: 300,
      child: Column(children: [
        Container(
          margin: const EdgeInsets.only(left: 20, right: 20, top: 10),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text(
              "Send Gift to Aditya",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.normal,
                  color: Colors.black),
            ),
            GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: const Icon(Icons.close))
          ]),
        ),
        Container(
          height: 210,
          margin: const EdgeInsets.only(
            top: 10,
          ),
          // color: Colors.black,
          child: GridView.count(
            crossAxisCount: 3,
            crossAxisSpacing: 4.0,
            // scrollDirection: Axis,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 3.0,
            children: List.generate(
              6,
              (index) => Container(
                child: Column(
                  children: [
                    Container(
                      height: 45,
                      width: 45,
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                              image: NetworkImage(
                                  "https://creazilla-store.fra1.digitaloceanspaces.com/cliparts/15331/red-rose-flower-clipart-xl.png"),
                              fit: BoxFit.fill)),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    const Text(
                      "₹ 501",
                      style: TextStyle(
                          fontSize: 11,
                          color: blueColor,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    const Text(
                      "Best Wishes",
                      style: TextStyle(
                          fontSize: 11,
                          color: blueColor,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
        const Divider(
          height: 2,
          color: blueColor,
        ),
        const SizedBox(
          height: 5,
        ),
        Container(
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            Container(
              child: Column(children: [
                const Text(
                  "Wallet Balance",
                  style: TextStyle(
                      fontSize: 12,
                      color: textColor,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  "₹ ${amount.toString()}",
                  style: const TextStyle(
                      fontSize: 12,
                      color: textColor,
                      fontWeight: FontWeight.bold),
                )
              ]),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
                showDialog<void>(
                  context: context,
                  barrierDismissible: false, // user must tap button!
                  builder: (BuildContext context) {
                    return AlertDialog(
                      elevation: 0.6,
                      contentPadding: const EdgeInsets.only(
                          left: 20, right: 10, top: 5, bottom: 5),
                      titlePadding: const EdgeInsets.only(
                          left: 20, right: 10, top: 5, bottom: 5),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Recharge Plan'),
                          IconButton(
                            icon: const Icon(
                              Icons.close,
                              color: Colors.red,
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )
                        ],
                      ),
                      content: const RechargeNow(),
                    );
                  },
                );
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: themeColor,
                ),
                child: const Center(
                    child: Text(
                  "Recharge",
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                )),
              ),
            ),
            InkWell(
              onTap: () async {
                SharedPreferences pref = await SharedPreferences.getInstance();
                if (pref.getString('uid') != null) {
                } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return const LoginModel();
                    },
                  );
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: themeColor,
                ),
                child: const Center(
                    child: Text(
                  "Send Giftsss",
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                )),
              ),
            )
          ]),
        )
      ]),
    );
  }
}
