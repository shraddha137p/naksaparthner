import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../API/FirebaseMethods.dart';
import '../../../MainAsset/LoadingIndicator.dart';
import '../../../model/livestreamfirebase.dart';
import 'LiveVendorScreen.dart';

class LivePeople extends StatefulWidget {
  const LivePeople({
    super.key,
  });

  @override
  State<LivePeople> createState() => _LivePeopleState();
}

class _LivePeopleState extends State<LivePeople> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopLivePeople();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopLivePeople();
      } else {
        return MobileLivePeople();
      }
    });
  }

  Widget MobileLivePeople() {
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
      height: screenSize.height / 5.4,
      child: StreamBuilder<dynamic>(
          stream: FirebaseFirestore.instance
              .collection('livestream')
              .where("islive", isEqualTo: "true")
              .snapshots(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const LoadingIndicator();
            }
            return ListView.builder(
              itemCount: snapshot.data.docs.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: ((context, index) {
                Object? mapdata = snapshot.data!.docs[index].data();

                LiveStreamFirebase liveData = LiveStreamFirebase.fromMap(
                    snapshot.data!.docs[index].data());
                return InkWell(
                  onTap: () async {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => LiveVendorScreen(
                                  edata: snapshot,
                                  isRole: false,
                                  channelId: "naksa1",
                                  uid: 2,
                                  channnelName: "naksa1",
                                  token:
                                      "006b61c6409413c4d2fbb7f4288e47aa8d6IABhZRmvK4gsR32qEnZqUbPDm7RyAxXoQ9rIebwl+bgRhqNtxrANvtUaEAAtSaF3NaeJZAEAAQDFY4hk",
                                  index: index,
                                )));
                    await updateViewCount("1", true, liveData.channelId);
                  },
                  child: Container(
                    margin: EdgeInsets.only(right: screenSize.width / 36),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          height: screenSize.height / 5.4,
                          width: screenSize.width / 3.6,
                          decoration: BoxDecoration(
                              color: Colors.yellow,
                              borderRadius: BorderRadius.circular(screenSize.width / 36),
                              image: const DecorationImage(
                                  image: NetworkImage(
                                      "https://www.tikli.in/wp-content/uploads/2022/02/rashmika-mandanna-10.jpg"),
                                  fit: BoxFit.fill)),
                        ),
                        Positioned(
                            top: screenSize.height / 7.2,
                            left: screenSize.width / 12,
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  vertical: screenSize.height / 378,
                                  horizontal: screenSize.width / 72),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                      screenSize.width / 72),
                                  color: const Color.fromRGBO(56, 56, 56, 1)
                                      .withOpacity(0.55)),
                              child: Row(
                                children: [
                                  Container(
                                    height: screenSize.height / 94.5,
                                    width: screenSize.width / 45,
                                    decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color.fromRGBO(36, 220, 55, 1)),
                                  ),
                                  SizedBox(
                                    width: screenSize.width / 72,
                                  ),
                                  Text(
                                    "Live",
                                    style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 36),
                                  ),
                                ],
                              ),
                            )),
                        Positioned(
                          top: screenSize.height / 6.04,
                          // left: 10,
                          child: Container(
                            child: Text(
                              liveData.name,
                              style: GoogleFonts.merriweather(
                                fontSize: screenSize.width / 36,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              }),
            );
          }),
    );
  }

  Widget DesktopLivePeople() {
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
        height: screenSize.height / 4.17,
        child: StreamBuilder<dynamic>(
            stream: FirebaseFirestore.instance
                .collection('livestream')
                .where("islive", isEqualTo: "true")
                .snapshots(),
            builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const LoadingIndicator();
              }
              return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  scrollDirection: Axis.horizontal,
                  physics: const AlwaysScrollableScrollPhysics(),
                  itemBuilder: ((context, index) {
                    Object? mapdata = snapshot.data!.docs[index].data();

                    LiveStreamFirebase liveData = LiveStreamFirebase.fromMap(
                        snapshot.data!.docs[index].data());
                    return InkWell(
                      onTap: () async {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LiveVendorScreen(
                                      edata: snapshot,
                                      isRole: false,
                                      channelId: "naksa1",
                                      uid: 2,
                                      channnelName: "naksa1",
                                      token:
                                          "006b61c6409413c4d2fbb7f4288e47aa8d6IABhZRmvK4gsR32qEnZqUbPDm7RyAxXoQ9rIebwl+bgRhqNtxrANvtUaEAAtSaF3NaeJZAEAAQDFY4hk",
                                      index: index,
                                    )));
                        await updateViewCount("1", true, liveData.channelId);
                      },
                      child: Container(
                        margin: EdgeInsets.only(right: screenSize.width / 192),
                        child: Stack(alignment: Alignment.center, children: [
                          Container(
                            height: screenSize.height / 4.36,
                            width: screenSize.width / 11.29,
                            decoration: BoxDecoration(
                                color: Colors.yellow,
                                borderRadius: BorderRadius.circular(
                                    screenSize.width / 192),
                                image: DecorationImage(
                                    image: NetworkImage(liveData.image),
                                    fit: BoxFit.fill)),
                          ),
                          Positioned(
                              top: screenSize.height / 5.49,
                              left: screenSize.width / 32,
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    vertical: screenSize.height / 480.5,
                                    horizontal: screenSize.width / 384),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                        screenSize.width / 384),
                                    color: Colors.white),
                                child: Row(
                                  children: [
                                    Container(
                                      height: screenSize.height / 240,
                                      width: screenSize.width / 240,
                                      decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                          color:
                                              Color.fromRGBO(36, 220, 55, 1)),
                                    ),
                                    SizedBox(
                                      width: screenSize.width / 384,
                                    ),
                                    Text(
                                      "Live",
                                      style: TextStyle(
                                          fontSize: screenSize.width / 192),
                                    ),
                                  ],
                                ),
                              )),
                          Positioned(
                              top: screenSize.height / 4.80,
                              // left: 10,
                              child: Container(
                                child: Text(
                                  liveData.name,
                                  style: TextStyle(
                                      fontSize: screenSize.width / 112.9,
                                      fontWeight: FontWeight.bold),
                                ),
                              ))
                        ]),
                      ),
                    );
                  }));
            }));
  }
}
