import 'dart:async';
import 'dart:io';

import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:custom_timer/custom_timer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:naksaa_services/API/FirebaseMethods.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/Langauage.dart';
import 'package:naksaa_services/UI/REgister/PhoneRegister.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:uuid/uuid.dart';

import '../../../MainAsset/URL.dart';

class ChatWithCustomer extends StatefulWidget {
  final String chatRoomId;
  List<CustomerP?> customer;
  List<Vdatum> vdetails;
  ChatWithCustomer(
      {super.key,
      required this.chatRoomId,
      required this.customer,
      required this.vdetails});

  @override
  State<ChatWithCustomer> createState() => _ChatWithCustomerState();
}

class _ChatWithCustomerState extends State<ChatWithCustomer>
    with SingleTickerProviderStateMixin {
  final TextEditingController _message = TextEditingController();

  late final CustomTimerController _controller = CustomTimerController(
      vsync: this,
      begin: const Duration(),
      end: const Duration(hours: 24),
      initialState: CustomTimerState.reset,
      interval: CustomTimerInterval.seconds);
  final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  void onSendMessage(Map<String, dynamic> messages) async {}

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _controller.start();
  }

  File? imageFIle;
  Future getImage() async {
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.gallery).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getImageByCamera() async {
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getDocumentForUpload() async {
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future uploadImage() async {
    String filename = const Uuid().v1();
    int status = 1;
    await _fireStore
        .collection('chatRoom')
        .doc(widget.chatRoomId)
        .collection('chats')
        .doc(filename)
        .set({
      "sendby": _auth.currentUser!.displayName,
      "message": "",
      "type": "img",
      "time": FieldValue.serverTimestamp()
    });
    var ref =
        FirebaseStorage.instance.ref().child('images').child('$filename.jpg');
    var uploadTask = await ref.putFile(imageFIle!).catchError((error) async {
      await _fireStore
          .collection('chatRoom')
          .doc(widget.chatRoomId)
          .collection('chats')
          .doc(filename)
          .delete();
      status = 0;
    });

    if (status == 1) {
      String imageurl = await uploadTask.ref.getDownloadURL();

      await _fireStore
          .collection('chatRoom')
          .doc(widget.chatRoomId)
          .collection('chats')
          .doc(filename)
          .update({"message": imageurl});
      print(imageurl);
    }

    // String imageUrl = await uploadTask.ref.getDownloadURL();
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(
        const Duration(
          minutes: 5,
        ), () {
      showAlert(context);
    });

    String strDigits(int n) => n.toString().padLeft(2, '0');
    final Size size = MediaQuery.of(context).size;
    print(size.height);
    print(size.width);
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopChatWithCustmer();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopChatWithCustmer();
      } else {
        return MobileChatWithCustmer();
      }
    });
  }

  Widget DesktopChatWithCustmer() {
    
    var screenSize = MediaQuery.of(context).size;
    String strDigits(int n) => n.toString().padLeft(2, '0');
    final Size size = MediaQuery.of(
      context,
    ).size;
    return Scaffold(
      backgroundColor: themeColor,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 120,
          automaticallyImplyLeading: false,
          foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: Container(
            margin:  EdgeInsets.only(
              top: screenSize.height/96.1,
              left: screenSize.width/192,
              right: screenSize.width/192,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon:  Icon(
                        Icons.arrow_back,
                        size: screenSize.width/18,
                      ),
                      onPressed: () {
                        Navigator.pop(
                          context,
                        );
                      },
                    ),
                    Container(
                      height: screenSize.height/16.0,
                      width: screenSize.width/32,
                      decoration: BoxDecoration(
                        border: Border.all(width: screenSize.width/1920, color: themeColor),
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: NetworkImage(
                            '${MainUrl}vendor-image/${widget.vdetails[0].photo}',
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Logout();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PhoneRegister(),
                          ),
                        );
                      },
                      child: Container(
                        height: screenSize.height/48.05,
                        width: screenSize.width/32,
                        decoration: BoxDecoration(
                          border: Border.all(
                            width: screenSize.width/1920,
                            color: const Color.fromRGBO(
                              47,
                              47,
                              47,
                              1,
                            ),
                          ),
                          borderRadius: BorderRadius.circular(
                            screenSize.width/384,
                          ),
                        ),
                        child:  Center(
                            child: Text(
                          "END",
                          style: TextStyle(
                            fontSize: screenSize.width/147.6,
                            color: Color.fromRGBO(
                              47,
                              47,
                              47,
                              1,
                            ),
                          ),
                        )),
                      ),
                    ),
                  ],
                ),
                Container(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(widget.vdetails[0].name!),
                         SizedBox(
                          width:  screenSize.width/192,
                        ),
                        // snapshot.data!['status'] == "Offline"
                        // ?
                        Container(
                          height: screenSize.height/96.1,
                          width: screenSize.width/192,
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle, color: Colors.red),
                        )
                        // : Container(
                        //     height: 10,
                        //     width: 10,
                        //     decoration: const BoxDecoration(
                        //         shape: BoxShape.circle,
                        //         color: Colors.green),
                        //   )
                      ]),
                ),
                 CircularCountDownTimer(
                  duration: 300,
                  isReverse: false,
                  initialDuration: 0,
                  width: screenSize.width/34.9,
                  height: screenSize.height/28.6,
                  textStyle: TextStyle(
                      fontSize: screenSize.width/213,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                  fillColor: Colors.transparent,
                  ringColor: Colors.transparent,
                )
              ],
            ),
          )),
      body: SizedBox(
        height: size.height / 1.12,
        child: Stack(
          children: [
            Positioned(
                bottom: 0,
                child: Container(
                  height: size.height / 2.88,
                  width: size.width,
                  decoration:  BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(screenSize.width/96),
                        topRight: Radius.circular(screenSize.width/96)),
                    color: blueColor,
                  ),
                )),
            Container(
              width: size.width,
              margin:  EdgeInsets.only(top: screenSize.height/48.05, left: screenSize.width/128, right: screenSize.width/137.1),
              child: SingleChildScrollView(
                child: Column(children: [
                  Container(
                    padding:  EdgeInsets.all( screenSize.width/192),
                    height: size.height / 1.30,
                    width: MediaQuery.of(context).size.width * 0.95,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/96),
                        color: Colors.white),
                    child: StreamBuilder<QuerySnapshot>(
                        stream: _fireStore
                            .collection('chatRoom')
                            .doc(widget.chatRoomId)
                            .collection('chats')
                            .orderBy("time", descending: false)
                            .snapshots(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          print(snapshot.data);
                          if (snapshot.data != null) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: snapshot.data!.docs.length,
                                itemBuilder: (context, index) {
                                  Object? map =
                                      snapshot.data!.docs[index].data();
                                  return messageScreen(size, map!);
                                },
                              ),
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                   SizedBox(
                    height: screenSize.height/48.05,
                  ),
                  SizedBox(
                    height: screenSize.height/19.2,
                    child: Row(children: [
                      GestureDetector(
                          onTap: () {
                            showDialog<void>(
                              barrierDismissible: true,
                              context: context,
                              builder: (BuildContext context) {
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    Padding(
                                      padding:  EdgeInsets.all(0),
                                      child: Container(
                                        height: screenSize.height/9.61,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        color: darkBlue,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: <Widget>[
                                            GestureDetector(
                                              onTap: () => getImageByCamera(),
                                              child: Container(
                                                height: screenSize.height/17.4,
                                                width: screenSize.width/21.3,
                                                decoration: BoxDecoration(
                                                    color: darkBlue,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            screenSize.width/38.4),
                                                    image: const DecorationImage(
                                                        image: AssetImage(
                                                            "assets/SVG/upload-2x.png"),
                                                        fit: BoxFit.fill)),
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () => getImage(),
                                              child: Container(
                                                height: screenSize.height/14.7,
                                                width: screenSize.width/29.5,
                                                decoration: BoxDecoration(
                                                  color: darkBlue,
                                                  borderRadius:
                                                      BorderRadius.circular(screenSize.width/38.4),
                                                  image: const DecorationImage(
                                                    image: AssetImage(
                                                        "assets/SVG/upload-2x.png"),
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: screenSize.height/14.7,
                                              width:  screenSize.width/29.5,
                                              decoration: BoxDecoration(
                                                color: darkBlue,
                                                borderRadius:
                                                    BorderRadius.circular(screenSize.width/38.4),
                                                image: const DecorationImage(
                                                  image: AssetImage(
                                                      "assets/SVG/upload-2x.png"),
                                                  fit: BoxFit.fill,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                );
                              },
                            );
                          },
                          child: Container(
                            height: screenSize.height/19.6,
                            width: screenSize.width/39.1,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image:
                                        AssetImage("assets/SVG/upload-2x.png"),
                                    fit: BoxFit.fill)),
                          )),
                       SizedBox(
                        width: screenSize.width/192,
                      ),
                      Container(
                        height: screenSize.height/19.6,
                        width: MediaQuery.of(context).size.width * 0.93,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(screenSize.width/96),
                            color: Colors.white),
                        child: Row(children: [
                          Form(
                            key: _formKey,
                            child: Container(
                              padding:
                                   EdgeInsets.only(left: screenSize.width/192, right: screenSize.width/192),
                              height: screenSize.width/27.6,
                              width: MediaQuery.of(context).size.width * 0.90,
                              child: TextFormField(
                                controller: _message,
                                decoration:  InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  contentPadding: EdgeInsets.only(
                                      left: screenSize.width/128, bottom: screenSize.height/87.3, top: screenSize.height/87.36, right: screenSize.width/128),
                                  hintText: "Type message here",
                                  hintStyle: TextStyle(
                                    fontSize: screenSize.width/137.1,
                                    color: Color.fromRGBO(
                                      196,
                                      196,
                                      196,
                                      1,
                                    ),
                                  ),
                                ),
                                style:  TextStyle(
                                  fontSize: screenSize.width/137.1,
                                  color: blueColor,
                                ),
                                keyboardType: TextInputType.multiline,
                                maxLines: null,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter message';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ),
                           SizedBox(
                            width: screenSize.width/192,
                          ),
                          GestureDetector(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                Map<String, dynamic> messages = {
                                  "sendby": widget.customer[0]!.name,
                                  "message": _message.text,
                                  "type": "text",
                                  "time": FieldValue.serverTimestamp()
                                };
                                await _fireStore
                                    .collection('chatRoom')
                                    .doc(widget.chatRoomId)
                                    .collection('chats')
                                    .add(messages);
                                _message.clear();
                              }
                            },
                            child: Container(
                              height: screenSize.height/45.7,
                              width: screenSize.width/76.8,
                              decoration: const BoxDecoration(
                                  // shape: BoxShape.circle,
                                  image: DecorationImage(
                                      image: AssetImage("assets/SVG/Group.png"),
                                      fit: BoxFit.fill)),
                            ),
                          ),
                        ]),
                      )
                    ]),
                  )
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget messageScreen(Size size, Object snapshot) {
    
    return (snapshot as Map)['type'] != "img"
        ? Container(
            width: size.width / 2.5,
            alignment: (snapshot)['sendby'] == widget.customer[0]!.name
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Container(
              decoration:  BoxDecoration(
                  color: darkBlue,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(size.width/96),
                      topRight: Radius.circular(size.width/96),
                      bottomLeft: Radius.circular(size.height/48.05))),
              padding:  EdgeInsets.symmetric(vertical: size.height/120.1, horizontal: 14),
              margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
              child: Text(
                snapshot['message'],
                style: const TextStyle(color: Colors.white, fontSize: 15),
              ),
            ))
        : Container(
            alignment: (snapshot)['sendby'] == widget.customer[0]!.name
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: snapshot['message'] != ""
                ? GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => broadImageView(
                                    image: snapshot['message'],
                                  )));
                    },
                    child: Container(
                      width: size.width / 2,
                      height: size.height / 3,
                      decoration: BoxDecoration(
                          color: darkBlue,
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                              bottomLeft: Radius.circular(20)),
                          image: DecorationImage(
                              image: NetworkImage(snapshot['message']),
                              fit: BoxFit.cover)),
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 14),
                      margin: const EdgeInsets.symmetric(
                          vertical: 5, horizontal: 8),
                      alignment: Alignment.center,
                    ),
                  )
                : Container(
                    width: size.width / 2,
                    height: size.height / 3,
                    decoration: const BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                          bottomLeft: Radius.circular(20)),
                    ),
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                    margin:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    alignment: Alignment.center,
                    child: const Center(child: LoadingIndicator()),
                  ),
          );
  }

  Widget MobileChatWithCustmer() {

    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: themeColor,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 120,
          automaticallyImplyLeading: false,
          foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: Container(
            margin:  EdgeInsets.only(top: size.height/17.1, left: size.width/36, right: size.width/36),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon:  Icon(
                        Icons.arrow_back,
                        size: size.width/18,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                    Container(
                      height: size.height/12.6,
                      width: size.width/6,
                      decoration: BoxDecoration(
                          border: Border.all(width: size.width/360, color: themeColor),
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: NetworkImage(
                                  '${MainUrl}vendor-image/${widget.vdetails[0].photo}'))),
                    ),
                    GestureDetector(
                      onTap: () {
                        Logout();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    BottomNavigationBarScreen(pageIndex: 0)));
                      },
                      child: Container(
                        height: size.height/31.5,
                        width: size.width/6,
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: size.width/360,
                                color: const Color.fromRGBO(47, 47, 47, 1)),
                            borderRadius: BorderRadius.circular(size.width/72)),
                        child:  Center(
                            child: Text(
                          "END",
                          style: TextStyle(
                              fontSize: size.width/27.6,
                              color: Color.fromRGBO(47, 47, 47, 1)),
                        )),
                      ),
                    ),
                  ],
                ),
                 SizedBox(
                  height: size.height/151.2,
                ),
                Container(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(widget.vdetails[0].name!),
                         SizedBox(
                          width: size.width/36,
                        ),
                        // snapshot.data!['status'] == "Offline"
                        // ?
                        Container(
                          height: size.height/75.6,
                          width: size.width/36,
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle, color: Colors.red),
                        )
                        // : Container(
                        //     height: 10,
                        //     width: 10,
                        //     decoration: const BoxDecoration(
                        //         shape: BoxShape.circle,
                        //         color: Colors.green),
                        //   )
                      ]),
                ),
                 SizedBox(
                  height: size.height/94.5,
                ),
                Center(
                    child: CustomTimer(
                        controller: _controller,
                        builder: (state, time) {
                          // Build the widget you want!🎉
                          return Text(
                              "${time.hours}:${time.minutes}:${time.seconds}.${time.milliseconds}",
                              style: const TextStyle(fontSize: 24.0));
                        })),
              ],
            ),
          )),
      body: SizedBox(
        height: size.height / 1.12,
        child: Stack(
          children: [
            Positioned(
                bottom: 0,
                child: Container(
                  height: size.height / 2.88,
                  width: size.width,
                  decoration:  BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(size.width/18),
                        topRight: Radius.circular(size.width/18)),
                    color: blueColor,
                  ),
                )),
            Container(
              width: size.width,
              margin:  EdgeInsets.only(top: size.height/75.6, left: size.width/24, right: size.width/25.7),
              child: SingleChildScrollView(
                child: Column(children: [
                  Container(
                    padding:  EdgeInsets.all(size.width/36),
                    height: size.height / 1.45,
                    width: size.width/1.09,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(size.width/18),
                        color: Colors.white),
                    child: StreamBuilder<QuerySnapshot>(
                        stream: _fireStore
                            .collection('chatRoom')
                            .doc(widget.chatRoomId)
                            .collection('chats')
                            .orderBy("time", descending: false)
                            .snapshots(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          print(snapshot.data);
                          if (snapshot.data != null) {
                            return ListView.builder(
                              shrinkWrap: true,
                              itemCount: snapshot.data!.docs.length,
                              itemBuilder: (context, index) {
                                Object? map = snapshot.data!.docs[index].data();
                                return messageScreenmobile(size, map!);
                              },
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                   SizedBox(
                    height: size.height/37.8,
                  ),
                  SizedBox(
                    height: size.height/15.12,
                    child: Row(children: [
                      GestureDetector(
                          onTap: () {
                            showDialog<void>(
                              barrierDismissible: true,
                              context: context,
                              builder: (BuildContext context) {
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(0),
                                      child: Container(
                                        height: size.height/7.56,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        color: darkBlue,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: <Widget>[
                                            GestureDetector(
                                              onTap: () => getImageByCamera(),
                                              child: Container(
                                                height: size.height/11.6,
                                                width: size.width/5.5,
                                                decoration: BoxDecoration(
                                                    color: darkBlue,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            size.width/7.2),
                                                    image: const DecorationImage(
                                                        image: AssetImage(
                                                            "assets/SVG/upload-2x.png"),
                                                        fit: BoxFit.fill)),
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () => getImage(),
                                              child: Container(
                                                height: size.height/11.6,
                                                width: size.width/5.53,
                                                decoration: BoxDecoration(
                                                    color: darkBlue,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            size.width/7.2),
                                                    image: const DecorationImage(
                                                        image: AssetImage(
                                                            "assets/SVG/upload-2x.png"),
                                                        fit: BoxFit.fill)),
                                              ),
                                            ),
                                            Container(
                                              height: size.height/11.6,
                                              width: size.width/5.53,
                                              decoration: BoxDecoration(
                                                  color: darkBlue,
                                                  borderRadius:
                                                      BorderRadius.circular(size.width/7.2),
                                                  image: const DecorationImage(
                                                      image: AssetImage(
                                                          "assets/SVG/upload-2x.png"),
                                                      fit: BoxFit.fill)),
                                            )
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                );
                              },
                            );
                          },
                          child: Container(
                            height: size.height/15.4,
                            width: size.width/7.3,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image:
                                        AssetImage("assets/SVG/upload-2x.png"),
                                    fit: BoxFit.fill)),
                          )),
                       SizedBox(
                        width: size.width/36,
                      ),
                      Container(
                        height: size.height/15.4,
                        width: size.width/1.32,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(size.width/18),
                            color: Colors.white),
                        child: Row(children: [
                          Form(
                            key: _formKey,
                            child: Container(
                              padding:
                                   EdgeInsets.only(left: size.width/36, right: size.width/36),
                              height: size.height/15.4,
                              width: size.width/1.55,
                              child: TextFormField(
                                controller: _message,
                                decoration:  InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    errorBorder: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    contentPadding: EdgeInsets.only(
                                        left: size.width/24,
                                        bottom: size.height/68.7,
                                        top: size.height/68.7,
                                        right: size.width/24),
                                    hintText: "Type message here",
                                    hintStyle: TextStyle(
                                        fontSize: size.width/25.7,
                                        color:
                                            Color.fromRGBO(196, 196, 196, 1))),
                                style:  TextStyle(
                                  fontSize: size.width/25.7,
                                  color: blueColor,
                                ),
                                keyboardType: TextInputType.multiline,
                                maxLines: null,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter message';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ),
                           SizedBox(
                            width: size.width/36,
                          ),
                          GestureDetector(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                Map<String, dynamic> messages = {
                                  "sendby": widget.customer[0]!.name,
                                  "message": _message.text,
                                  "type": "text",
                                  "time": FieldValue.serverTimestamp()
                                };
                                await _fireStore
                                    .collection('chatRoom')
                                    .doc(widget.chatRoomId)
                                    .collection('chats')
                                    .add(messages);
                                _message.clear();
                              }
                            },
                            child: Container(
                              height: size.height/36,
                              width: size.width/14.4,
                              decoration: const BoxDecoration(
                                  // shape: BoxShape.circle,
                                  image: DecorationImage(
                                      image: AssetImage("assets/SVG/Group.png"),
                                      fit: BoxFit.fill)),
                            ),
                          ),
                        ]),
                      )
                    ]),
                  )
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget messageScreenmobile(Size size, Object snapshot) {
     var screenSize = MediaQuery.of(context).size;
    return (snapshot as Map)['type'] != "img"
        ? Container(
            width: size.width / 2.5,
            alignment: (snapshot)['sendby'] == widget.customer[0]!.name
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Container(
              decoration:  BoxDecoration(
                  color: darkBlue,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(screenSize.width/18),
                      topRight: Radius.circular(screenSize.width/18),
                      bottomLeft: Radius.circular(screenSize.width/18))),
              padding:  EdgeInsets.symmetric(vertical: screenSize.height/94.5, horizontal: screenSize.width/137.1),
              margin:  EdgeInsets.symmetric(vertical: screenSize.height/151.2, horizontal: screenSize.width/45),
              child: Text(
                snapshot['message'],
                style:  TextStyle(color: Colors.white, fontSize: screenSize.width/24),
              ),
            ))
        : Container(
            alignment: (snapshot)['sendby'] == widget.customer[0]!.name
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: snapshot['message'] != ""
                ? GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => broadImageView(
                                    image: snapshot['message'],
                                  )));
                    },
                    child: Container(
                      width: size.width / 2,
                      height: size.height / 3,
                      decoration: BoxDecoration(
                          color: darkBlue,
                          borderRadius:  BorderRadius.only(
                              topLeft: Radius.circular(screenSize.width/18),
                              topRight: Radius.circular(screenSize.width/18),
                              bottomLeft: Radius.circular(screenSize.width/18)),
                          image: DecorationImage(
                              image: NetworkImage(snapshot['message']),
                              fit: BoxFit.cover)),
                      padding:  EdgeInsets.symmetric(
                          vertical: screenSize.height/94.5, horizontal: screenSize.width/25.71),
                      margin:  EdgeInsets.symmetric(
                          vertical: screenSize.height/151.2, horizontal: screenSize.width/45),
                      alignment: Alignment.center,
                    ),
                  )
                : Container(
                    width: size.width / 2,
                    height: size.height / 3,
                    decoration:  BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(screenSize.width/18),
                          topRight: Radius.circular(screenSize.width/18),
                          bottomLeft: Radius.circular(screenSize.width/18)),
                    ),
                    padding:
                         EdgeInsets.symmetric(vertical: screenSize.height/94.5, horizontal: screenSize.width/25.7),
                    margin:
                         EdgeInsets.symmetric(vertical: screenSize.height/151.2, horizontal: screenSize.width/45),
                    alignment: Alignment.center,
                    child: const Center(child: LoadingIndicator()),
                  ),
          );
  }

  showAlert(BuildContext context) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Future.delayed(
            const Duration(
              minutes: 50,
            ),
            () {
              Navigator.of(context).pop(true);
            },
          );
          return AlertDialog(
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20))),
            content: SizedBox(
              height: 202,
              width: 310,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        "Free chat is are avialable for 5 minute",
                        style: GoogleFonts.merriweather(
                            fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      const Spacer(),
                      IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(
                            Icons.close,
                            size: 22,
                          ))
                    ],
                  ),
                  const SizedBox(
                    height: 7.5,
                  ),
                  const Divider(
                    color: Colors.grey,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Continue to chat with",
                    style: GoogleFonts.merriweather(
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    height: 70,
                    width: 70,
                    child: CircleAvatar(
                      backgroundImage: NetworkImage(
                          '${MainUrl}vendor-image/${widget.vdetails[0].photo}'),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    widget.vdetails[0].name!,
                    style: GoogleFonts.merriweather(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 130,
                    height: 40,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 9, 68, 117),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(
                        "Recharge",
                        style: GoogleFonts.merriweather(
                            fontSize: 12, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              )
            ],
          );
        });
  }
}

class broadImageView extends StatelessWidget {
  String image;
  broadImageView({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          foregroundColor: darkBlue,
          elevation: 0,
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.share)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert))
          ],
        ),
        body: Container(
          height: size.height / 1.2,
          width: size.width,
          decoration: BoxDecoration(
            image: DecorationImage(image: NetworkImage(image)),
          ),
        ));
  }
}
