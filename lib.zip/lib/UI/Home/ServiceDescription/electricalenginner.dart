import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lecle_bubble_timeline/lecle_bubble_timeline.dart';
import 'package:lecle_bubble_timeline/models/timeline_item.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/Utility/maislider1.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/MainSlider.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/desktopNavbar.dart';

import '../Partner/ClientTestimonials.dart';
import '../Partner/ConnectWithPeople.dart';

class ElectricalEngineer extends StatefulWidget {
  const ElectricalEngineer({super.key});

  @override
  State<ElectricalEngineer> createState() => _ElectricalEngineerState();
}

class _ElectricalEngineerState extends State<ElectricalEngineer> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopInteriorDesign();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopInteriorDesign();
      } else {
        return MobileInteriorDesign();
      }
    });
  }

  Widget DesktopInteriorDesign() {

    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
        body: SingleChildScrollView(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
             SizedBox(
              height: screenSize.height/48.05,
            ),
            const NavBar(),
            Container(
              height: MediaQuery.of(context).size.height * 0.1,
              width: MediaQuery.of(context).size.width,
              color: Colors.yellow,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Home",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/112.9,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                   SizedBox(
                    width: screenSize.width/384,
                  ),
                  Text(
                    ">",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/112.9,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                   SizedBox(
                    width: screenSize.width/384,
                  ),
                  Text(
                    "Electrical Engineer",
                    style: GoogleFonts.merriweather(
                        fontSize: screenSize.width/112.9,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  )
                ],
              ),
            ),
             SizedBox(
              height: screenSize.height/19.22,
            ),
            const MainSlider(),
            Container(
              margin:  EdgeInsets.only(left: screenSize.width/128, right: screenSize.width/128),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                     SizedBox(
                      height: screenSize.height/48.05,
                    ),
                    Container(
                      alignment: Alignment.center,
                      margin:
                           EdgeInsets.only(left: screenSize.width/192, top: screenSize.height/24.02, bottom: screenSize.height/24.02),
                      child:  BigText(
                        name: "How We Works?",
                        size: screenSize.width/112.9,
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(
                        left: screenSize.width/27.42,
                        right: screenSize.width/27.42,
                      ),
                      child: Row(
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.4,
                            height: MediaQuery.of(context).size.height * 0.7,
                            child: Text(
                              "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).Dummy Content is a Joomla! system plugin (and editor button) that helps you automatically place random dummy text into your Articles - or in any other content item that has an editor, such as Custom HTML Modules, Category descriptions, 3rd party content, etc.",
                              textAlign: TextAlign.justify,
                              style: GoogleFonts.merriweather(fontSize: screenSize.width/106.6),
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.4,
                            height: MediaQuery.of(context).size.height * 0.7,
                            child: HowWeWork(),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                     Center(
                      child: BigText(
                        name: "Feeling Lost?",
                        size: screenSize.height/112.9,
                      ),
                    ),
                     Center(
                      child: BigText(
                        name:
                            "when trying to explain your interior design needs?",
                        size: screenSize.height/112.9,
                      ),
                    ),
                    Container(
                      margin:  EdgeInsets.only(
                        left: screenSize.width/27.42,
                        top: screenSize.height/19.22,
                        bottom:  screenSize.height/19.22,
                        right: screenSize.width/27.42,
                      ),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width *
                                        0.27,
                                    child: InteriorCard(
                                       Icon(
                                        Icons.account_circle_outlined,
                                        size: screenSize.width/48,
                                      ),
                                      "Not able to convey your style?",
                                      "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you",
                                    ),
                                  ),
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width *
                                        0.27,
                                    child: InteriorCard(
                                         Icon(
                                          Icons.account_circle_outlined,
                                          size: screenSize.width/48,
                                        ),
                                        "Not able to convey your style?",
                                        "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                                  ),
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width *
                                        0.27,
                                    child: InteriorCard(
                                         Icon(
                                          Icons.account_circle_outlined,
                                          size:  screenSize.width/48,
                                        ),
                                        "Not able to convey your style?",
                                        "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin:  EdgeInsets.only(
                                  left: 0, top: screenSize.height/19.22, bottom: screenSize.height/19.22),
                            ),
                            BigText(
                              name: "What you get on web call",
                              size: screenSize.width/24,
                              color: Colors.black.withOpacity(0.80),
                            ),
                             SizedBox(
                              height: screenSize.height/24.02,
                            ),
                            SizedBox(
                                width: MediaQuery.of(context).size.width,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.4,
                                        child: WhatYouGet()),
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.4,
                                      height: screenSize.height/2.402,
                                      decoration: const BoxDecoration(
                                          image: DecorationImage(
                                              image: NetworkImage(
                                                  "https://www.freeconference.com/wp-content/uploads/2021/07/FC-video-call-file-sharing-min-768x554.png"),
                                              fit: BoxFit.cover)),
                                    )
                                  ],
                                )),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.1,
                            ),
                            Center(
                              child: BigText(
                                name: "Our Expert's Portfolio",
                                size:  screenSize.width/106.6,
                                color: Colors.black.withOpacity(0.80),
                              ),
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.1,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height,
                                child: OurExpertsPortfolio()),
                             SizedBox(
                              height: screenSize.height/96.1,
                            ),
                            Container(
                              margin:  EdgeInsets.only(bottom: screenSize.height/48.05),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Client Testimonials",
                                        style: GoogleFonts.merriweather(
                                            fontSize:  screenSize.width/137.14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        "View All >",
                                        style: GoogleFonts.merriweather(
                                            fontSize: screenSize.width/137.14,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                   SizedBox(
                                    height: screenSize.height/48.05,
                                  ),
                                  const ClientTestimonials(),
                                   SizedBox(
                                    height: screenSize.height/48.05,
                                  ),
                                  Container(
                                    margin:  EdgeInsets.only(bottom: screenSize.height/12.01),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Connect with Naksian",
                                              style: GoogleFonts.merriweather(
                                                fontSize: screenSize.width/160,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            Text(
                                              "View All >",
                                              style: GoogleFonts.merriweather(
                                                fontSize: screenSize.width/160,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            )
                                          ],
                                        ),
                                         SizedBox(
                                          height: screenSize.height/48.05,
                                        ),
                                        const ConnectWithPeople(),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                  ]),
            ),
            const BottomFooter()
          ],
        )),
        bottomNavigationBar: bottomNavigationBar());
  }

  Widget MobileInteriorDesign() {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            "ElectricalEngineer Desginer",
            style: GoogleFonts.merriweather(
              fontSize: 14,
              color: blueColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          elevation: 0,
          backgroundColor: themeColor,
        ),
        body: SingleChildScrollView(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const MainSlider(),
            Container(
              margin: const EdgeInsets.only(left: 15, right: 15),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      margin: const EdgeInsets.only(
                        left: 10,
                        top: 40,
                      ),
                      child: const BigText(
                        name: "How We Works?",
                        size: 17,
                      ),
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.9,
                          height: MediaQuery.of(context).size.height * 0.6,
                          child: HowWeWork(),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const BigText(
                      name: "Feeling Lost?",
                      size: 20,
                    ),
                    const BigText(
                      name:
                          "when trying to explain your interior design needs?",
                      size: 17,
                    ),
                    Container(
                      margin:
                          const EdgeInsets.only(left: 0, top: 30, bottom: 30),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  InteriorCard(
                                    const Icon(
                                      Icons.account_circle_outlined,
                                      size: 40,
                                    ),
                                    "Not able to convey your style?",
                                    "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you",
                                  ),
                                  InteriorCard(
                                      const Icon(
                                        Icons.account_circle_outlined,
                                        size: 40,
                                      ),
                                      "Not able to convey your style?",
                                      "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                                  InteriorCard(
                                      const Icon(
                                        Icons.account_circle_outlined,
                                        size: 40,
                                      ),
                                      "Not able to convey your style?",
                                      "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                                ],
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(
                                  left: 0, top: 50, bottom: 20),
                            ),
                            BigText(
                              name: "What you get on web call",
                              size: 18,
                              color: Colors.black.withOpacity(0.80),
                            ),
                            const SizedBox(
                              height: 40,
                            ),
                            WhatYouGet(),
                            const SizedBox(
                              height: 20,
                            ),
                            Center(
                              child: BigText(
                                name: "Our Expert's Portfolio",
                                size: 18,
                                color: Colors.black.withOpacity(0.80),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.2,
                                width: MediaQuery.of(context).size.width,
                                child: OurExpertsPortfolioMobile()),
                            const SizedBox(
                              height: 20,
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 10),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Client Testimonials",
                                        style: GoogleFonts.merriweather(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        "View All >",
                                        style: GoogleFonts.merriweather(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const ClientTestimonials(),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(bottom: 80),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Connect with Naksian",
                                              style: GoogleFonts.merriweather(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            Text(
                                              "View All >",
                                              style: GoogleFonts.merriweather(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            )
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        const ConnectWithPeople(),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                  ]),
            ),
          ],
        )),
        bottomNavigationBar: bottomNavigationBar());
  }

  Widget bottomNavigationBar() {
    return Container(
        alignment: Alignment.center,
        height: 50,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(10), topRight: Radius.circular(10)),
          border: Border.all(
            width: 1,
            color: Colors.transparent,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.only(left: 10, right: 5),
              width: 160,
              height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: themeColor,
              ),
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    const Icon(
                      Icons.phone,
                      color: blueColor,
                      size: 20,
                    ),
                    Text(
                      "Call",
                      style: GoogleFonts.merriweather(
                        fontSize: 14,
                        color: blueColor,
                        fontWeight: FontWeight.bold,
                      ),
                      // style: TextStyle(
                      //     fontFamily: "Merriweather-LightItalic",
                      //     fontSize: 14,
                      //     color: blueColor,
                      //     fontWeight: FontWeight.bold),
                    )
                  ]),
            ),
            Container(
              margin: const EdgeInsets.only(left: 5, right: 10),
              width: 160,
              height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: themeColor,
              ),
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    const Icon(
                      Icons.message,
                      color: blueColor,
                      size: 20,
                    ),
                    Text(
                      "Chat",
                      style: GoogleFonts.merriweather(
                        fontSize: 14,
                        color: blueColor,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ]),
            )
          ],
        ));
  }

  Widget WhatYouGet() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        const SizedBox(
          height: 15,
        ),
        ListTile(
          leading: const Icon(
            Icons.check_circle_rounded,
            color: blueColor,
          ),
          title: Text(
            "One-to-One live webcall with our expert Interior consultant.",
            textAlign: TextAlign.justify,
            style: GoogleFonts.merriweather(
              color: Colors.black,
              fontSize: 17,
            ),
          ),
        ),
        ListTile(
          leading: const Icon(
            Icons.check_circle_rounded,
            color: blueColor,
          ),
          title: Text(
            "Detailed list of rooms to figure your requirements",
            textAlign: TextAlign.justify,
            style: GoogleFonts.merriweather(
              color: Colors.black,
              fontSize: 17,
            ),
          ),
        ),
        ListTile(
          leading: const Icon(
            Icons.check_circle_rounded,
            color: blueColor,
          ),
          title: Text(
            "Clarity on the design of your every room individually",
            textAlign: TextAlign.justify,
            style: GoogleFonts.merriweather(
              color: Colors.black,
              fontSize: 17,
            ),
          ),
        ),
        ListTile(
          leading: const Icon(
            Icons.check_circle_rounded,
            color: blueColor,
          ),
          title: Text(
            "Budget approximation to save lacs of rupees",
            textAlign: TextAlign.justify,
            style: GoogleFonts.merriweather(
              color: Colors.black,
              fontSize: 17,
            ),
          ),
        ),
        ListTile(
          leading: const Icon(
            Icons.check_circle_rounded,
            color: blueColor,
          ),
          title: Text(
            "Gain a Functional understanding of Interior Design!",
            textAlign: TextAlign.justify,
            style: GoogleFonts.merriweather(
              color: Colors.black,
              fontSize: 17,
            ),
          ),
        ),
        ListTile(
          leading: const Icon(
            Icons.check_circle_rounded,
            color: blueColor,
          ),
          title: Text(
            "Theme development according to your Style and Taste",
            textAlign: TextAlign.justify,
            style: GoogleFonts.merriweather(
              color: Colors.black,
              fontSize: 17,
            ),
          ),
        ),
      ],
    );
  }

  Widget InteriorCard(Icon icon, String title, String desc) {
    return MediaQuery.removePadding(
      context: context,
      removeTop: true,
      child: Card(
        elevation: 2,
        child: ClipPath(
          clipper: ShapeBorderClipper(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4))),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(color: themeColor, width: 5),
              ),
            ),
            width: 322,
            child: Column(children: [
              SizedBox(
                height: 35,
                width: 35,
                child: icon,
              ),
              BigText(
                name: title,
                size: 17,
                color: Colors.black.withOpacity(0.83),
              ),
              const SizedBox(
                height: 8,
              ),
              BigText(
                name: desc,
                size: 17,
                color: Colors.black.withOpacity(0.63),
              )
            ]),
          ),
        ),
      ),
    );
  }

  Widget HowWeWork() {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.3,
      child: BubbleTimeline(
        bubbleSize: 60,
        // List of Timeline Bubble Items
        items: [
          TimelineItem(
            title: 'View Electrical Engineer',
            subtitle: 'Step 1',
            icon: const Icon(
              Icons.directions_boat,
              color: Colors.white,
            ),
            bubbleColor: themeColor,
            // description: 'Description for boat',
            titleStyle: GoogleFonts.merriweather(
              color: blueColor,
              fontSize: 15.0,
              fontWeight: FontWeight.w700,
            ),
            subtitleStyle:
                const TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500),
          ),
          TimelineItem(
            title: 'Choose Electrical Engineer',
            subtitle: 'Step 2',
            icon: const Icon(
              Icons.directions_bike,
              color: Colors.white,
            ),
            bubbleColor: Colors.yellow,
            titleStyle: GoogleFonts.merriweather(
              color: blueColor,
              fontSize: 15.0,
              fontWeight: FontWeight.w700,
            ),
            subtitleStyle: GoogleFonts.merriweather(
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
          TimelineItem(
            title: 'Choose Room & Style',
            subtitle: 'Step 3',
            icon: const Icon(
              Icons.directions_bus,
              color: Colors.white,
            ),
            bubbleColor: Colors.green,
            // description: 'Description for bus',
            titleStyle: GoogleFonts.merriweather(
              color: blueColor,
              fontSize: 15.0,
              fontWeight: FontWeight.w700,
            ),
            subtitleStyle: GoogleFonts.merriweather(
              color: blueColor,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
          TimelineItem(
            title: 'Get Your Package',
            subtitle: 'Step 4',
            icon: const Icon(
              Icons.directions_bus,
              color: Colors.white,
            ),
            bubbleColor: Colors.red,
            // description: 'Description for bus',
            titleStyle: GoogleFonts.merriweather(
              color: blueColor,
              fontSize: 15.0,
              fontWeight: FontWeight.w700,
            ),
            subtitleStyle: GoogleFonts.merriweather(
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
        stripColor: blueColor,
        dividerCircleColor: Colors.white,
      ),
    );
  }

  Widget OurExpertsPortfolio() {
    return Column(children: const [
      MainSlider1(
        ep: "electrical",
      ),
    ]);
  }

  Widget OurExpertsPortfolioMobile() {
    return Column(children: const [
      MainSlider1(
        ep: "electrical",
      ),
    ]);
  }
}
