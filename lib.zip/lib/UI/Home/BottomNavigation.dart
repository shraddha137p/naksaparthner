import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/CallScreen.dart';
import 'package:naksaa_services/UI/Home/ChatScreen.dart';
import 'package:naksaa_services/UI/Home/HistoryScreen.dart';
import 'package:naksaa_services/UI/Home/HomeScreen.dart';
import 'package:naksaa_services/UI/Home/Partner/AllLiveVendor.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class BottomNavigationBarScreen extends StatefulWidget {
  int pageIndex;
  BottomNavigationBarScreen({super.key, required this.pageIndex});

  @override
  State<BottomNavigationBarScreen> createState() =>
      _BottomNavigationBarScreenState(pageIndex);
}

class _BottomNavigationBarScreenState extends State<BottomNavigationBarScreen> {
  int pageIndex;
  _BottomNavigationBarScreenState(this.pageIndex);
  bool isSelected = false;

  final pages = [
    const HomeScreen(),
    const ChatMainScreen(),
    const AllLiveVendor(),
    const CallMainScreen(),
    const HistoryScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      body: pages[pageIndex],
      bottomNavigationBar: buildMyNavBar(
        context,
      ),
      bottomSheet: const Padding(
        padding: EdgeInsets.only(
          bottom: 85.0,
        ),
      ),
    );
  }

  Container buildMyNavBar(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;
    Color themeColor = const Color.fromRGBO(
      255,
      215,
      0,
      1,
    );
    Color secondColor = const Color.fromRGBO(
      2,
      44,
      67,
      1,
    ).withOpacity(
      0.59,
    );
    return Container(
      height: 75,
      decoration: const BoxDecoration(
        color: Color.fromRGBO(255, 255, 255, 1),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(18),
          topRight: Radius.circular(
            18,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          GestureDetector(
            onTap: () {                             
              setState(() {
                pageIndex = 0;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: pageIndex == 0 ? blueColor : themeColor,
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                    height: screenHeight / 23.31,
                    child: pageIndex == 0
                        ? Container(
                            child: SvgPicture.asset(
                              "assets/SVG/home.svg",
                              color: themeColor,
                            ),
                          )
                        : Container(
                            child: SvgPicture.asset(
                              "assets/SVG/home.svg",
                              color: blueColor,
                            ),
                          )),
                InkWell(
                  onTap: () {
                    setState(() {
                      pageIndex = 0;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.only(left: 3),
                    child: const BigText(
                      name: "Home",
                    ),
                  ),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 1;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: pageIndex == 1 ? blueColor : themeColor,
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                    height: screenHeight / 23.31,
                    child: pageIndex == 1
                        ? Container(
                            child: SvgPicture.asset(
                              "assets/SVG/chat.svg",
                              color: themeColor,
                            ),
                          )
                        : Container(
                            child: SvgPicture.asset(
                              "assets/SVG/chat-yellow.svg",
                              color: blueColor,
                            ),
                          )),
                InkWell(
                  onTap: () {
                    setState(() {
                      pageIndex = 1;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.only(
                      left: 3,
                    ),
                    child: const BigText(
                      name: "Chat",
                    ),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 2;
              });
            },
            child: Container(
              // height: 55,
              // width: 55,
              // decoration: BoxDecoration(
              //     color: pageIndex == 2 ? themeColor : Colors.white,
              //     shape: BoxShape.circle,
              //     border: Border.all(width: 1, color: blueColor)),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      child: pageIndex == 2
                          ? Icon(
                              Icons.play_arrow,
                              color: themeColor,
                              size: screenHeight / 27.2,
                            )
                          : Icon(
                              Icons.play_arrow,
                              color: blueColor,
                              size: screenHeight / 27.2,
                            ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          pageIndex = 2;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.only(left: 3),
                        child: const BigText(
                          name: "Live",
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 3;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: pageIndex == 3 ? blueColor : themeColor,
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                    height: screenHeight / 23.31,
                    child: pageIndex == 3
                        ? Container(
                            child: SvgPicture.asset(
                              "assets/SVG/phone.svg",
                              color: themeColor,
                            ),
                          )
                        : Container(
                            child: SvgPicture.asset(
                              "assets/SVG/phone.svg",
                              color: blueColor,
                            ),
                          )),
                InkWell(
                  onTap: () {
                    setState(() {
                      pageIndex = 3;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.only(left: 3),
                    child: const BigText(
                      name: "Call",
                    ),
                  ),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(
                () {
                  pageIndex = 4;
                },
              );
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: pageIndex == 4 ? blueColor : themeColor,
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                    height: screenHeight / 23.31,
                    child: pageIndex == 4
                        ? Container(
                            child: SvgPicture.asset(
                              "assets/SVG/history.svg",
                              color: themeColor,
                            ),
                          )
                        : Container(
                            child: SvgPicture.asset(
                              "assets/SVG/history.svg",
                              color: blueColor,
                            ),
                          )),
                InkWell(
                  onTap: () {
                    setState(() {
                      pageIndex = 4;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.only(left: 3),
                    child: const BigText(
                      name: "History",
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BigText extends StatelessWidget {
  final String name;
  final Color color;
  final double size;

  const BigText(
      {Key? key,
      required this.name,
      this.color = Colors.black,
      this.size = 11.0})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        name,
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        style: GoogleFonts.merriweather(
          fontSize: size,
          fontWeight: FontWeight.bold,
          color: color,
        ),
        textAlign: TextAlign.justify,
      ),
    );
  }
}
