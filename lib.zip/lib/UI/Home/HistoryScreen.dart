import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/CustomerOrderScreenChat.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/Navigationdrawer.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/Wallet.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../REgister/project Assets/AppBar.dart';
import '../REgister/project Assets/CustomerOrderScreen.dart';
import '../REgister/project Assets/LoginModel.dart';
import '../REgister/project Assets/desktopNavbar.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with TickerProviderStateMixin {
  late TabController _controller;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkLogin();
    _controller = TabController(
      vsync: this,
      length: 3,
      initialIndex: 0,
    );
  }

  void checkLogin() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    if (pref.getString('uid') != null) {
    } else {
      showModalBottomSheet(
        isDismissible: false,
        context: context,
        isScrollControlled: true,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        builder: (BuildContext context) {
          return const LoginModel();
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopHistoryScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopHistoryScreen();
      } else {
        return MobileHistoryScreen();
      }
    });
  }

  Widget DesktopHistoryScreen() {
    return Scaffold(
      backgroundColor: bgColor,
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      // drawer:
      //     Drawer(backgroundColor: darkBlue, child: const NavigationDrawer()),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.all(20),
                height: 44,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    color: Colors.white),
                child: TabBar(
                  labelColor: themeColor,
                  // labelStyle: theme.textTheme.headline1,
                  indicatorColor: themeColor,
                  indicatorSize: TabBarIndicatorSize.label,
                  // indicatorPadding: tab,

                  unselectedLabelColor: Colors.grey,
                  controller: _controller,
                  tabs: const [
                    Tab(
                      child: Text("Wallet"),
                    ),
                    Tab(
                      child: Text("Calls"),
                    ),
                    Tab(
                      child: Text("Chats"),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height,
                child: TabBarView(
                  controller: _controller,
                  children: const [
                    WalletSection(),
                    CustomerOrderScreen(),
                    CustomerOrderScreenForChat()
                  ],
                ),
              ),
              const BottomFooter()
            ],
          ),
        ),
      ),
    );
  }

  Widget MobileHistoryScreen() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.0,
        toolbarHeight: 155,
        automaticallyImplyLeading: false,
        foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
        flexibleSpace: const AppBarScreen(),
      ),
      drawer: const Drawer(
        backgroundColor: darkBlue,
        child: NavigationDrawers(),
      ),

      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(20),
            height: 44,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22), color: Colors.white),
            child: TabBar(
              labelColor: themeColor,
              // labelStyle: theme.textTheme.headline1,
              indicatorColor: themeColor,
              indicatorSize: TabBarIndicatorSize.label,
              // indicatorPadding: tab,

              unselectedLabelColor: Colors.grey,
              controller: _controller,
              tabs: const [
                Tab(
                  child: Text("Wallet"),
                ),
                Tab(
                  child: Text("Calls"),
                ),
                Tab(
                  child: Text("Chats"),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _controller,
              children: const [
                WalletSection(),
                CustomerOrderScreen(),
                CustomerOrderScreenForChat()
              ],
            ),
          ),
        ],
      ),
    );
  }
}
