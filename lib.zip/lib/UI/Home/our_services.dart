import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/InteriorDesgin.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/Structureengineer.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../aboutus/aboutnavigation.dart';
import '../REgister/project Assets/desktopNavbar.dart';
import 'BottomFooter.dart';
import 'ServiceDescription/Architect.dart';
import 'ServiceDescription/civilenginner.dart';
import 'ServiceDescription/electricalenginner.dart';
import 'ServiceDescription/lightningDesigner.dart';
import 'ServiceDescription/plumingengineer.dart';
import 'ServiceDescription/vastu.dart';

class OurServices extends StatefulWidget {
  const OurServices({Key? key}) : super(key: key);

  @override
  State<OurServices> createState() => _OurServicesState();
}

bool isHover1 = false;
bool isHover2 = false;
bool isHover3 = false;
bool isHover4 = false;
bool isHover5 = false;
bool isHover6 = false;
bool isHover7 = false;
bool isHover8 = false;

class _OurServicesState extends State<OurServices> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServices(context);
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServices(context);
      } else {
        return MobileServices(context);
      }
    });
  }

  Widget DesktopServices(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    print(width);

    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          Container(
            color: Colors.white,
            child: const Aboutnavigation(
              MainContent: "Home",
              SubContent: "Our Services",
            ),
          ),
          SizedBox(
            height: height * 0.03,
          ),
          Text(
            "What We Do",
            style: GoogleFonts.merriweather(
              fontSize: 20,
              fontWeight: FontWeight.w500,
              color: const Color(0xffFE5D14),
            ),
          ),
          SizedBox(
            height: height * 0.02,
          ),
          Text("Our Services Areas",
              style: GoogleFonts.merriweather(
                fontSize: 38,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
              textAlign: TextAlign.justify,
              maxLines: 3),
          SizedBox(
            height: height * 0.1,
          ),

          Container(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Architect(),
                          ),
                        );
                      },
                      onHover: (val) {
                        setState(() {
                          isHover1 = val;
                        });
                      },
                      child: isHover1 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.0208,
                                          child: Icon(
                                            Icons.architecture_outlined,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "01",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text(
                                      "Architect",
                                      style: GoogleFonts.merriweather(
                                        fontSize: width * 0.01921,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1.0,
                                      ),
                                      textAlign: TextAlign.justify,
                                      maxLines: 3,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/archtiet.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: width * 0.0156,
                                          top: 50,
                                          right: width * 0.0208),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("Architect",
                                              style: GoogleFonts.merriweather(
                                                fontSize: width * 0.01921,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                                letterSpacing: 1.0,
                                              ),
                                              textAlign: TextAlign.justify,
                                              maxLines: 3),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: width * 0.0201,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const InteriorDesginDescription()));
                      },
                      onHover: (val) {
                        setState(() {
                          isHover2 = val;
                        });
                      },
                      child: isHover2 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.0208,
                                          child: Icon(
                                            Icons.architecture_outlined,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "02",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0416,
                                            letterSpacing: 1.0,
                                            fontWeight: FontWeight.bold,
                                            color: darkBlue,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text(
                                      "Interior Designer",
                                      style: GoogleFonts.merriweather(
                                        fontSize: width * 0.01921,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1.0,
                                      ),
                                      textAlign: TextAlign.justify,
                                      maxLines: 3,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/interior.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(
                                  10,
                                ),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                        10,
                                      ),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(
                                            0xffFE5D14,
                                          ).withOpacity(
                                            0.5,
                                          ),
                                          const Color.fromARGB(
                                            255,
                                            238,
                                            130,
                                            81,
                                          ).withOpacity(
                                            0.5,
                                          )
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: width * 0.0156,
                                          top: 50,
                                          right: width * 0.0208),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("Interior Designer",
                                              style: GoogleFonts.merriweather(
                                                fontSize: width * 0.01921,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                                letterSpacing: 1.0,
                                              ),
                                              textAlign: TextAlign.justify,
                                              maxLines: 3),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: width * 0.0201,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Vastu(),
                          ),
                        );
                      },
                      onHover: (val) {
                        setState(() {
                          isHover3 = val;
                        });
                      },
                      child: isHover3 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: width * 0.0208,
                                          child: Icon(
                                            Icons.ac_unit_outlined,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "03",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text("Vastu",
                                        style: GoogleFonts.merriweather(
                                          fontSize: width * 0.01921,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                        textAlign: TextAlign.justify,
                                        maxLines: 3),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/vastu.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: width * 0.0156,
                                          top: 50,
                                          right: width * 0.0208),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("Vastu",
                                              style: GoogleFonts.merriweather(
                                                fontSize: width * 0.01921,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                                letterSpacing: 1.0,
                                              ),
                                              textAlign: TextAlign.justify,
                                              maxLines: 3),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: width * 0.0201,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const ElectricalEngineer()));
                      },
                      onHover: (val) {
                        setState(() {
                          isHover4 = val;
                        });
                      },
                      child: isHover4 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: width * 0.0208,
                                          child: Icon(
                                            Icons.person,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "04",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text(
                                      "Electrical Engineer",
                                      style: GoogleFonts.merriweather(
                                        fontSize: width * 0.01921,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1.0,
                                      ),
                                      textAlign: TextAlign.justify,
                                      maxLines: 5,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/electric.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 30, top: 50, right: 40),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("Electrical Engineer",
                                              style: GoogleFonts.merriweather(
                                                fontSize: width * 0.01921,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                                letterSpacing: 1.0,
                                              ),
                                              textAlign: TextAlign.justify,
                                              maxLines: 5),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const LightingDesginer()));
                      },
                      onHover: (val) {
                        setState(() {
                          isHover5 = val;
                        });
                      },
                      child: isHover5 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.0208,
                                          child: Icon(
                                            Icons.architecture_outlined,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "05",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text(
                                      "Lighting Desgineer",
                                      style: GoogleFonts.merriweather(
                                        fontSize: width * 0.01921,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1.0,
                                      ),
                                      textAlign: TextAlign.justify,
                                      maxLines: 3,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/light.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: width * 0.0156,
                                          top: 50,
                                          right: width * 0.0208),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("Lighting Desgineer",
                                              style: GoogleFonts.merriweather(
                                                fontSize: width * 0.01921,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                                letterSpacing: 1.0,
                                              ),
                                              textAlign: TextAlign.justify,
                                              maxLines: 3),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: width * 0.0201,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const CivilEngineer(),
                          ),
                        );
                      },
                      onHover: (val) {
                        setState(() {
                          isHover6 = val;
                        });
                      },
                      child: isHover6 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: width * 0.0208,
                                          child: Icon(
                                            Icons.chat_bubble,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "06",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text(
                                      "Civil Engineer",
                                      style: GoogleFonts.merriweather(
                                        fontSize: width * 0.01921,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1.0,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/civil.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: width * 0.0156,
                                          top: 50,
                                          right: width * 0.0208),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Civil Engineer",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.01921,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                          ),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: width * 0.0201,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const StructureEngineer(),
                          ),
                        );
                      },
                      onHover: (val) {
                        setState(() {
                          isHover7 = val;
                        });
                      },
                      child: isHover7 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: width * 0.0208,
                                          child: Icon(
                                            Icons.auto_awesome_mosaic_rounded,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "07",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text("Structure Engineer",
                                        style: GoogleFonts.merriweather(
                                          fontSize: width * 0.01921,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                        textAlign: TextAlign.justify,
                                        maxLines: 3),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/structural.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left:
                                            MediaQuery.of(context).size.width *
                                                0.0156,
                                        top: 50,
                                        right:
                                            MediaQuery.of(context).size.width *
                                                0.0156,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Structure Engineer",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.01921,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                          ),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          SizedBox(
                                            height: height * 0.035,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: width * 0.0201,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const PlumbingEngineer(),
                          ),
                        );
                      },
                      onHover: (val) {
                        setState(() {
                          isHover8 = val;
                        });
                      },
                      child: isHover8 != true
                          ? Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffFE5D14),
                                          radius: width * 0.0208,
                                          child: Icon(
                                            Icons.person,
                                            color: Colors.white,
                                            size: width * 0.0208,
                                          ),
                                        ),
                                        Text(
                                          "08",
                                          style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0416,
                                              letterSpacing: 1.0,
                                              fontWeight: FontWeight.bold,
                                              color: darkBlue),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: height * 0.07,
                                    ),
                                    Text(
                                      "Plumbing Engineer",
                                      style: GoogleFonts.merriweather(
                                        fontSize: width * 0.01921,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1.0,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : Container(
                              width: width * 0.23,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                    image: AssetImage(
                                      "assets/plumbing.png",
                                    ),
                                    fit: BoxFit.fill),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    width: width * 0.23,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xffFE5D14)
                                              .withOpacity(0.5),
                                          const Color.fromARGB(
                                                  255, 238, 130, 81)
                                              .withOpacity(0.5)
                                        ],
                                        begin: Alignment.bottomLeft,
                                        end: Alignment.topRight,
                                        stops: const [0.4, 0.7],
                                        tileMode: TileMode.repeated,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: width * 0.0156,
                                          top: 50,
                                          right: width * 0.0208),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Plumbing Engineer",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.01921,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                          ),
                                          SizedBox(
                                            height: height * 0.020,
                                          ),
                                          Text(
                                            "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.0099,
                                              color: Colors.white,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5,
                                          ),
                                          const SizedBox(
                                            height: 35,
                                          ),
                                          Container(
                                            height: height * 0.0291,
                                            width: width * 0.073,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "Read More",
                                                  style:
                                                      GoogleFonts.merriweather(
                                                    fontSize: width * 0.0093,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward,
                                                  size: width * 0.0083,
                                                  color: Colors.white,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 80,
          ),
          Padding(
            padding:
                EdgeInsets.symmetric(horizontal: width * 0.0175, vertical: 30),
            child: Container(
              height: height * 0.1499,
              width: width * 1,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 4,
                    )
                  ]),
              child: Padding(
                padding: EdgeInsets.only(
                    left: width * 0.0104, right: width * 0.0104),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: height * 0.0977,
                        width: width * 0.161,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(
                            20,
                          ),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(
                                0xffFE5D14,
                              ),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(
                              width: width * 0.0104,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("1500",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0156,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text("Project Complete",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0083,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3)
                              ],
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.0977,
                        width: width * 0.161,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(0xffFE5D14),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(
                              width: width * 0.0104,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("1500",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0156,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text("Project Complete",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0083,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3)
                              ],
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.0977,
                        width: width * 0.161,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(0xffFE5D14),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(
                              width: width * 0.0104,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("1500",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0156,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text("Project Complete",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0083,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3)
                              ],
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.0977,
                        width: width * 0.161,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(0xffFE5D14),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(
                              width: width * 0.0104,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("1500",
                                    style: GoogleFonts.merriweather(
                                        fontSize: width * 0.0156,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.justify,
                                    maxLines: 3),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Project Complete",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0083,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                )
                              ],
                            )
                          ],
                        ),
                      )
                    ]),
              ),
            ),
          ),

          const SizedBox(
            height: 80,
          ),
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: width * 0.0104,
              vertical: 30,
            ),
            child: Container(
              height: height * 0.1499,
              width: width * 1,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: EdgeInsets.only(
                    left: width * 0.0104, right: width * 0.0104),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: height * 0.1099,
                        width: width * 0.213,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(0xffFE5D14),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(width: width * 0.0104),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Quick Response",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.013,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  maxLines: 3,
                                  textAlign: TextAlign.justify,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "There are many variations of passages",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0067,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  maxLines: 3,
                                  textAlign: TextAlign.justify,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Ipsum available but the",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0067,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  maxLines: 3,
                                  textAlign: TextAlign.justify,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.1099,
                        width: width * 0.213,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(0xffFE5D14),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(width: width * 0.0104),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Quick Response",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.013,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "There are many variations of passages",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0067,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Ipsum available but the",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0067,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.1099,
                        width: width * 0.213,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.0208,
                              backgroundColor: const Color(0xffFE5D14),
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: width * 0.0208,
                              ),
                            ),
                            SizedBox(width: width * 0.0104),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Quick Response",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.013,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                ),
                                SizedBox(
                                  height: height * 0.0052,
                                ),
                                Text(
                                  "There are many variations of passages",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0067,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                ),
                                SizedBox(
                                  height: height * 0.0052,
                                ),
                                Text(
                                  "Ipsum available but the",
                                  style: GoogleFonts.merriweather(
                                      fontSize: width * 0.0067,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3,
                                ),
                                SizedBox(
                                  height: height * 0.0052,
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ]),
              ),
            ),
          ),
          const SizedBox(
            height: 50,
          ),

          // PrivacyPolicy(),
          const BottomFooter(),
        ],
      )),
    );
  }

  Widget MobileServices(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        automaticallyImplyLeading: false,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back,
              color: Colors.black,
            )),
        title: Text(
          "Our Services",
          style: GoogleFonts.merriweather(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: ListView(children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Divider(),
            // Container(
            //   color: Colors.white,
            //   child: const Aboutnavigation(
            //     MainContent: "Home",
            //     SubContent: "Our Services",
            //   ),
            // ),
            // SizedBox(
            //   height: height * 0.03,
            // ),
            // Text(
            //   "What We Do",
            //   style: GoogleFonts.merriweather(
            //     fontSize: 20,
            //     fontWeight: FontWeight.w500,
            //     color: const Color(0xffFE5D14),
            //   ),
            // ),
            // SizedBox(
            //   height: height * 0.02,
            // ),
            // Text("Our Services Areas",
            //     style: GoogleFonts.merriweather(
            //       fontSize: 38,
            //       fontWeight: FontWeight.bold,
            //       color: Colors.black,
            //     ),
            //     textAlign: TextAlign.justify,
            //     maxLines: 3),
            // SizedBox(
            //   height: height * 0.1,
            // ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 110,
                  width: 110,
                  // color: Colors.red,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 65,
                        width: 65,
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                            color: darkBlue,
                            borderRadius: BorderRadius.circular(10)),
                        child: CircleAvatar(
                          backgroundColor: darkBlue,
                          child: SvgPicture.asset(
                            "assets/Architect.svg",
                            color: themeColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 110,
                  width: 110,
                  // color: Colors.red,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 65,
                        width: 65,
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                            color: darkBlue,
                            borderRadius: BorderRadius.circular(10)),
                        child: CircleAvatar(
                          backgroundColor: darkBlue,
                          child: SvgPicture.asset(
                            "assets/Architect.svg",
                            color: themeColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 110,
                  width: 110,
                  // color: Colors.red,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 65,
                        width: 65,
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                            color: darkBlue,
                            borderRadius: BorderRadius.circular(10)),
                        child: CircleAvatar(
                          backgroundColor: darkBlue,
                          child: SvgPicture.asset(
                            "assets/Architect.svg",
                            color: themeColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 110,
                  width: 110,
                  // color: Colors.red,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 65,
                        width: 65,
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                            color: darkBlue,
                            borderRadius: BorderRadius.circular(10)),
                        child: CircleAvatar(
                          backgroundColor: darkBlue,
                          child: SvgPicture.asset(
                            "assets/Architect.svg",
                            color: themeColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 110,
                  width: 110,
                  // color: Colors.red,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 65,
                        width: 65,
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                            color: darkBlue,
                            borderRadius: BorderRadius.circular(10)),
                        child: CircleAvatar(
                          backgroundColor: darkBlue,
                          child: SvgPicture.asset(
                            "assets/Architect.svg",
                            color: themeColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 110,
                  width: 110,
                  // color: Colors.red,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 65,
                        width: 65,
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                            color: darkBlue,
                            borderRadius: BorderRadius.circular(10)),
                        child: CircleAvatar(
                          backgroundColor: darkBlue,
                          child: SvgPicture.asset(
                            "assets/Architect.svg",
                            color: themeColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),

            Container(
              child: Column(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Architect(),
                        ),
                      );
                    },
                    onHover: (val) {
                      setState(() {
                        isHover1 = val;
                      });
                    },
                    child: isHover1 != true
                        ? Padding(
                            padding: const EdgeInsets.only(
                              left: 20,
                              right: 20,
                            ),
                            child: Container(
                              width: width,
                              height: height * 0.17,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8, right: 8),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.architecture_outlined,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "01",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text(
                                        "Architect Designer",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                        textAlign: TextAlign.justify,
                                        maxLines: 3,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: AssetImage(
                                    "assets/archtiect.png",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(
                                          0xffFE5D14,
                                        ).withOpacity(
                                          0.5,
                                        ),
                                        const Color.fromARGB(
                                          255,
                                          238,
                                          130,
                                          81,
                                        ).withOpacity(
                                          0.5,
                                        )
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [
                                        0.4,
                                        0.7,
                                      ],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: width * 0.0156,
                                        top: 50,
                                        right: width * 0.0208),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Architect Designer",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.01921,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 3),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        SizedBox(
                                          height: height * 0.035,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                  ),
                  SizedBox(
                    width: width * 0.0201,
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Vastu(),
                        ),
                      );
                    },
                    onHover: (val) {
                      setState(() {
                        isHover2 = val;
                      });
                    },
                    child: isHover2 != true
                        ? Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        right: 8,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.ac_unit_outlined,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "02",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text("Vastu Consultant",
                                          style: GoogleFonts.merriweather(
                                            fontSize: 25,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            letterSpacing: 1.0,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 3),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: width * 0.0156,
                                        top: 50,
                                        right: width * 0.0208),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Vastu Consultant",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.01921,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 3),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        SizedBox(
                                          height: height * 0.035,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  ),
                  SizedBox(
                    width: width * 0.0201,
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const InteriorDesginDescription()));
                    },
                    onHover: (val) {
                      setState(() {
                        isHover3 = val;
                      });
                    },
                    child: isHover3 != true
                        ? Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        right: 8,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.person,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "03",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text(
                                        "Interior Designer",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                        textAlign: TextAlign.justify,
                                        maxLines: 5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 30, top: 50, right: 40),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Interior Designer",
                                            style: GoogleFonts.merriweather(
                                              fontSize: width * 0.01921,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                            textAlign: TextAlign.justify,
                                            maxLines: 5),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        SizedBox(
                                          height: height * 0.035,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const ElectricalEngineer()));
                    },
                    onHover: (val) {
                      setState(() {
                        isHover4 = val;
                      });
                    },
                    child: isHover4 != true
                        ? Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        right: 8,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.chat_bubble,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "04",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text(
                                        "Electrical Engineer",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: width * 0.0156,
                                        top: 50,
                                        right: width * 0.0208),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Electrical Enginer",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.01921,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        SizedBox(
                                          height: height * 0.035,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                  ),
                  SizedBox(
                    width: width * 0.0201,
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LightingDesginer(),
                        ),
                      );
                    },
                    onHover: (val) {
                      setState(() {
                        isHover5 = val;
                      });
                    },
                    child: isHover5 != true
                        ? Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        right: 8,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.auto_awesome_mosaic_rounded,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "05",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text("Lightning Engineering",
                                          style: GoogleFonts.merriweather(
                                            fontSize: 25,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            letterSpacing: 1.0,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 3),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width *
                                          0.0156,
                                      top: 50,
                                      right: MediaQuery.of(context).size.width *
                                          0.0156,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Lightning Engineering",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.01921,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        SizedBox(
                                          height: height * 0.035,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  ),
                  SizedBox(
                    width: width * 0.0201,
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {},
                    onHover: (val) {
                      setState(() {
                        isHover6 = val;
                      });
                    },
                    child: isHover6 != true
                        ? Padding(
                            padding: const EdgeInsets.only(
                              left: 20,
                              right: 20,
                            ),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8, right: 8),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.person,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "06",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text(
                                        "Civil Engineering",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: width * 0.0156,
                                        top: 50,
                                        right: width * 0.0208),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Siding Corner",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.01921,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        const SizedBox(
                                          height: 35,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const StructureEngineer(),
                        ),
                      );
                    },
                    onHover: (val) {
                      setState(() {
                        isHover6 = val;
                      });
                    },
                    child: isHover6 != true
                        ? Padding(
                            padding: const EdgeInsets.only(
                              left: 20,
                              right: 20,
                            ),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8, right: 8),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.person,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "07",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text(
                                        "Structure Engineer",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: width * 0.0156,
                                        top: 50,
                                        right: width * 0.0208),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Siding Corner",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.01921,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        const SizedBox(
                                          height: 35,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  ),
                  SizedBox(height: 20),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const PlumbingEngineer(),
                        ),
                      );
                    },
                    onHover: (val) {
                      setState(() {
                        isHover6 = val;
                      });
                    },
                    child: isHover6 != true
                        ? Padding(
                            padding: const EdgeInsets.only(
                              left: 20,
                              right: 20,
                            ),
                            child: Container(
                              width: width,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 2,
                                    )
                                  ]),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 0.0104, vertical: 30),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8, right: 8),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircleAvatar(
                                            backgroundColor:
                                                const Color(0xffFE5D14),
                                            radius: width * 0.05,
                                            child: const Icon(
                                              Icons.person,
                                              color: Colors.white,
                                              size: 25,
                                            ),
                                          ),
                                          Text(
                                            "08",
                                            style: GoogleFonts.merriweather(
                                                fontSize: 25,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                                color: darkBlue),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Center(
                                      child: Text(
                                        "Plumbing Engineering",
                                        style: GoogleFonts.merriweather(
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          letterSpacing: 1.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : Container(
                            width: width * 0.23,
                            decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
                                  ),
                                  fit: BoxFit.fill),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  width: width * 0.23,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xffFE5D14)
                                            .withOpacity(0.5),
                                        const Color.fromARGB(255, 238, 130, 81)
                                            .withOpacity(0.5)
                                      ],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                      stops: const [0.4, 0.7],
                                      tileMode: TileMode.repeated,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: width * 0.0156,
                                        top: 50,
                                        right: width * 0.0208),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Siding Corner",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.01921,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                        SizedBox(
                                          height: height * 0.020,
                                        ),
                                        Text(
                                          "There are many variations of passages of Lorem a Ipsum available, but the majority have suffered ali teration in some form",
                                          style: GoogleFonts.merriweather(
                                            fontSize: width * 0.0099,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.justify,
                                          maxLines: 5,
                                        ),
                                        const SizedBox(
                                          height: 35,
                                        ),
                                        Container(
                                          height: height * 0.0291,
                                          width: width * 0.073,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "Read More",
                                                style: GoogleFonts.merriweather(
                                                  fontSize: width * 0.0093,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Icon(
                                                Icons.arrow_forward,
                                                size: width * 0.0083,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 50,
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
              ),
              child: Container(
                height: height * 0.18,
                width: width,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                      )
                    ]),
                child: Padding(
                  padding: EdgeInsets.only(
                      left: width * 0.0104, right: width * 0.0104),
                  child: Column(children: [
                    Container(
                      height: height * 0.0977,
                      width: width * 0.45,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8, right: 8),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: width * 0.05,
                              backgroundColor: const Color(0xffFE5D14),
                              child: const Icon(
                                Icons.person,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("1500",
                                    style: GoogleFonts.merriweather(
                                        fontSize: 15,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.justify,
                                    maxLines: 2),
                                Text(
                                  "Project Complete",
                                  style: GoogleFonts.merriweather(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.justify,
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // height: height * 0.0977,
                      height: 30,
                      width: width * 0.37,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: width * 0.05,
                            backgroundColor: const Color(0xffFE5D14),
                            child: const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 25,
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("1500",
                                  style: GoogleFonts.merriweather(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3),
                              Text(
                                "Project Complete",
                                style: GoogleFonts.merriweather(
                                    fontSize: 15,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w500),
                                textAlign: TextAlign.justify,
                                maxLines: 3,
                              )
                            ],
                          )
                        ],
                      ),
                    )
                  ]),
                ),
              ),
            ),

            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20),
              child: Container(
                  height: 250,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                      )
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 30),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: width * 0.05,
                            backgroundColor: const Color(0xffFE5D14),
                            child: const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 25,
                            ),
                          ),
                          SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Quick Response",
                                  style: GoogleFonts.merriweather(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3),
                              Text(
                                "There are many variations \nof passage Ispum available",
                                style: GoogleFonts.merriweather(
                                  fontSize: 15,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                                textAlign: TextAlign.justify,
                                maxLines: 3,
                              )
                            ],
                          )
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: width * 0.05,
                            backgroundColor: const Color(0xffFE5D14),
                            child: const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 25,
                            ),
                          ),
                          SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Quick Response",
                                  style: GoogleFonts.merriweather(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3),
                              Text(
                                "There are many variations \nof passage Ispum available",
                                style: GoogleFonts.merriweather(
                                  fontSize: 15,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                                textAlign: TextAlign.justify,
                                maxLines: 3,
                              )
                            ],
                          )
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: width * 0.05,
                            backgroundColor: const Color(0xffFE5D14),
                            child: const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 25,
                            ),
                          ),
                          SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Quick Response",
                                  style: GoogleFonts.merriweather(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.justify,
                                  maxLines: 3),
                              Text(
                                "There are many variations \nof passage Ispum available",
                                style: GoogleFonts.merriweather(
                                  fontSize: 15,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                                textAlign: TextAlign.justify,
                                maxLines: 3,
                              )
                            ],
                          )
                        ],
                      ),
                    ],
                  )),
            ),
            SizedBox(height: 20),

            // PrivacyPolicy(),
          ],
        ),
      ]),
    );
  }
}
