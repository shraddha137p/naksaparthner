// ignore_for_file: use_build_context_synchronously

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfile.dart';
import 'package:naksaa_services/UI/Home/SearchScreen.dart';
import 'package:naksaa_services/UI/Home/Utility/rechargeNowUtility.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/ChatScreenOptions.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/Navigationdrawer.dart';
import 'package:naksaa_services/model/AllVendorModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Service/WalletService.dart';
import '../../model/CustomerWalletModel.dart';
import '../REgister/project Assets/AppBar.dart';
import '../REgister/project Assets/LoginModel.dart';
import '../REgister/project Assets/constants.dart';
import '../REgister/project Assets/desktopNavbar.dart';
import 'BottomFooter.dart';
import 'Partner/VideoCall/OrderSuccessModel.dart';
import 'Partner/VideoCall/VideoCallandAudioCallModal.dart';

class ChatMainScreen extends StatefulWidget {
  const ChatMainScreen({super.key});

  @override
  State<ChatMainScreen> createState() => _ChatMainScreenState();
}

class _ChatMainScreenState extends State<ChatMainScreen> {
  List<Datum> results = [];
  var vendorService = AllVendorService();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata("stype", "sname");
    getWalletAmount();
    // allVendor = vendorService.viewallVendor();
  }

  bool isloading = false;
  List<Walletdatum> _walletList = [];
  var walletService = CustomerWalletService();
  Future<void> getWalletAmount() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await walletService.viewCustomerWallet(uid!);
    if (response != null) {
      setState(() {
        isloading = true;
      });
      _walletList = response;
    }
  }

  var ismainloading = false;

  var networkHandler = NetworkHandler();
  Future<List<Datum>> getdata(String sname, String stype) async {
    var response = await vendorService.viewallVendor(sname, stype);
    if (results != null) {
      setState(() {
        ismainloading = true;
        results = response!;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    Color themeColor = const Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = const Color.fromRGBO(56, 56, 56, 1);
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopChatScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopChatScreen();
      } else {
        return MobileChatScreen();
      }
    });
  }

  Widget MobileChatScreen() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        toolbarHeight: 140,
        automaticallyImplyLeading: false,
        foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
        flexibleSpace: const AppBarScreen(),
      ),
      drawer: const Drawer(
        backgroundColor: darkBlue,
        child: NavigationDrawers(),
      ),
      body: SingleChildScrollView(
        child: Container(
          // height: 600,
          color: const Color.fromRGBO(242, 244, 243, 1),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.all(screenSize.width / 45),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Messaging"),
                        Container(
                          child: Row(children: const [
                            Text("Sort By Date"),
                            Icon(Icons.keyboard_arrow_down_outlined)
                          ]),
                        ),
                      ]),
                ),
                Container(
                    // height: 482,
                    child: RefreshIndicator(
                        onRefresh: () {
                          return getdata("stype", "sname");
                        },
                        child: MobileFutureBuilder())),
                ChatAndCallScreenOptions(
                  sname: (value) {
                    List maindata = value.split(',');
                    setState(() {
                      getdata(maindata[0], maindata[1]);
                    });
                    MobileFutureBuilder();
                  },
                ),
                SizedBox(
                  height: screenSize.height / 12.81,
                ),
                kIsWeb ? BottomFooter() : Container(),
              ]),
        ),
      ),
    );
  }

  Widget MobileFutureBuilder() {
    var screenSize = MediaQuery.of(context).size;
    return ismainloading != false
        ? results.length >= 1
            ? ListView.builder(
                itemCount: results.length,
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: ((context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VendorProfileScreen(
                            vid: results[index].id.toString(),
                          ),
                        ),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(screenSize.width / 36),
                      height: screenSize.height / 5.6,
                      margin: EdgeInsets.only(
                          bottom: screenSize.height / 50.4,
                          left: screenSize.width / 25.7,
                          right: screenSize.width / 25.7),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          screenSize.width / 36,
                        ),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(
                              0,
                              0,
                              0,
                              0.16,
                            ),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ),
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: screenSize.width / 5.53,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: screenSize.height / 12.6,
                                  width: screenSize.width / 6,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      width: screenSize.width / 360,
                                      color: themeColor,
                                    ),
                                    image: DecorationImage(
                                      image: NetworkImage(
                                        '${MainUrl}vendor-image/${results[index].photo}',
                                      ),
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 63,
                                ),
                                Container(
                                  child: RatingBarIndicator(
                                    rating: 4.5,
                                    itemBuilder: (context, index) => const Icon(
                                      Icons.star,
                                      color: Colors.amber,
                                    ),
                                    itemCount: 5,
                                    itemSize: 13.0,
                                    direction: Axis.horizontal,
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 75.6,
                                ),
                                Container(
                                  child: Center(
                                    child: Text(
                                      "734 Votes",
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 40,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            width: screenSize.width / 36,
                          ),
                          Container(
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                            Text(results[index].name,
                                      // overflow: TextOverflow.ellipsis,
                                      // maxLines: 1,
                                      style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width / 27.6,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black)),
                                  SizedBox(
                                    height: screenSize.height / 75.6,
                                  ),
                                  SizedBox(
                                    width: screenSize.width / 2.4,
                                    child: Text(
                                      results[index].primaryskills,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width / 27.6,
                                          fontWeight: FontWeight.normal,
                                          color: Colors.black),
                                    ),
                                  ),
                                  SizedBox(
                                    height: screenSize.height / 151.2,
                                  ),
                                  SizedBox(
                                    width: screenSize.width / 2.4,
                                    child: Text(
                                      results[index].language,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 27.6,
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black.withOpacity(
                                          0.53,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: screenSize.height / 151.2,
                                  ),
                                  Text(
                                    "${(results[index].enddate.difference(results[index].startdate).inDays)} Days",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 27.6,
                                      fontWeight: FontWeight.normal,
                                      color: Colors.black.withOpacity(
                                        0.53,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: screenSize.height / 126,
                                  ),
                                  Text(
                                    "₹ ${results[index].audicallprice}/min",
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 25.71,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black.withOpacity(
                                        1,
                                      ),
                                    ),
                                  )
                                ]),
                          ),
                          Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  height: screenSize.height / 18.9,
                                  width: screenSize.width / 9,
                                  decoration: const BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(
                                        "assets/SVG/star2-2x.png",
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                      child: Padding(
                                    padding: EdgeInsets.only(
                                      bottom: screenSize.height / 151.2,
                                    ),
                                    child: Icon(
                                      Icons.check,
                                      color: Colors.white,
                                      size: screenSize.width / 22.5,
                                    ),
                                  )),
                                ),
                                GestureDetector(
                                  onTap: () async {
                                    SharedPreferences pref =
                                        await SharedPreferences.getInstance();
                                    if (pref.getString('uid') != null) {
                                      if (_walletList.length >= 1) {
                                        if (double.parse(
                                                _walletList[0].walletamount) >=
                                            100.0) {
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) =>
                                                VideoCallAndAudioCallModal(
                                              name: results[index].name,
                                              image: results[index].photo,
                                              vid: results[index].id.toString(),
                                              audioCallPrice:
                                                  results[index].audicallprice,
                                              videoCallPrice:
                                                  results[index].audicallprice,
                                            ),
                                          );
                                        } else {
                                          showDialog<void>(
                                            context: context,
                                            barrierDismissible:
                                                false, // user must tap button!
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                elevation: 0.6,
                                                contentPadding: EdgeInsets.only(
                                                  left: screenSize.width / 18,
                                                  right: screenSize.width / 36,
                                                  top:
                                                      screenSize.height / 151.2,
                                                  bottom:
                                                      screenSize.height / 151.2,
                                                ),
                                                titlePadding: EdgeInsets.only(
                                                  left: screenSize.width / 18,
                                                  right: screenSize.width / 36,
                                                  top:
                                                      screenSize.height / 151.2,
                                                  bottom:
                                                      screenSize.height / 151.2,
                                                ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    screenSize.width / 24,
                                                  ),
                                                ),
                                                title: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    const Text('Recharge Plan'),
                                                    IconButton(
                                                      icon: const Icon(
                                                        Icons.close,
                                                        color: Colors.red,
                                                      ),
                                                      onPressed: () {
                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                    )
                                                  ],
                                                ),
                                                content: const RechargeNow(),
                                              );
                                            },
                                          );
                                        }
                                      } else {
                                        showDialog<void>(
                                          context: context,
                                          barrierDismissible:
                                              false, // user must tap button!
                                          builder: (BuildContext context) {
                                            return AlertDialog(
                                              elevation: 0.6,
                                              contentPadding: EdgeInsets.only(
                                                left: screenSize.width / 18,
                                                right: screenSize.width / 36,
                                                top: screenSize.height / 151.2,
                                                bottom:
                                                    screenSize.height / 151.2,
                                              ),
                                              titlePadding: EdgeInsets.only(
                                                left: screenSize.width / 18,
                                                right: screenSize.width / 36,
                                                top: screenSize.height / 151.2,
                                                bottom:
                                                    screenSize.height / 151.2,
                                              ),
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  screenSize.width / 24,
                                                ),
                                              ),
                                              title: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  const Text('Recharge Plan'),
                                                  IconButton(
                                                    icon: const Icon(
                                                      Icons.close,
                                                      color: Colors.red,
                                                    ),
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                  )
                                                ],
                                              ),
                                              content: const RechargeNow(),
                                            );
                                          },
                                        );
                                      }
                                    } else {
                                      showModalBottomSheet(
                                        isDismissible: false,
                                        context: context,
                                        isScrollControlled: true,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                screenSize.width / 36)),
                                        builder: (BuildContext context) {
                                          return const LoginModel();
                                        },
                                      );
                                    }
                                  },
                                  child: Container(
                                    height: screenSize.height / 30.2,
                                    width: screenSize.width / 5.53,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                        screenSize.width / 36,
                                      ),
                                      color: themeColor,
                                    ),
                                    child: Center(
                                      child: Text(
                                        "Chat",
                                        style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width / 30,
                                          fontWeight: FontWeight.bold,
                                          color: Color.fromRGBO(
                                            2,
                                            44,
                                            67,
                                            1,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              )
            : const Center(
                child: Text(
                  "No Data Found",
                ),
              )
        : const Center(
            child: CircularProgressIndicator(),
          );
  }

  Widget DesktopChatScreen() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: const PreferredSize(
        preferredSize: Size(
          1000,
          1000,
        ),
        child: NavBar(),
      ),
      body: SingleChildScrollView(
        child: Container(
          color: const Color.fromRGBO(
            242,
            244,
            243,
            1,
          ),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      alignment: Alignment.topRight,
                      width: MediaQuery.of(
                            context,
                          ).size.width *
                          0.2,
                      margin: EdgeInsets.all(
                        screenSize.width / 128,
                      ),
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const SearchScreen(),
                            ),
                          );
                        },
                        child: Container(
                          margin: EdgeInsets.only(
                            left: screenSize.width / 96,
                            right: screenSize.width / 96,
                          ),
                          padding: EdgeInsets.only(
                            left: screenSize.width / 240,
                            right: screenSize.width / 240,
                          ),
                          height: screenSize.height / 21.3,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              screenSize.width / 192,
                            ),
                            color: Colors.white,
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.search,
                                color: Color.fromRGBO(
                                  183,
                                  190,
                                  198,
                                  1,
                                ),
                                size: screenSize.width / 64,
                              ),
                              SizedBox(
                                width: screenSize.width / 128,
                              ),
                              Text(
                                "Search Service",
                                style: GoogleFonts.merriweather(
                                  fontSize: screenSize.width / 137.1,
                                  color: Color.fromRGBO(
                                    183,
                                    190,
                                    198,
                                    1,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenSize.height / 1.99,
                  child: RefreshIndicator(
                      onRefresh: () {
                        print("refreshed");
                        return getdata("stype", "sname");
                      },
                      child: DesktopFutureBuilder()),
                ),
                ChatAndCallScreenOptions(
                  sname: (value) {
                    List maindata = value.split(',');
                    setState(() {
                      ismainloading = false;
                      getdata(maindata[0], maindata[1]);
                    });
                    DesktopFutureBuilder();
                  },
                ),
                const BottomFooter()
              ]),
        ),
      ),
    );
  }

  Widget DesktopFutureBuilder() {
    var screenSize = MediaQuery.of(context).size;
    return ismainloading != false
        ? results.length >= 1
            ? GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  crossAxisSpacing: 4.0,
                  childAspectRatio: 2.2,
                  mainAxisSpacing: 4.0,
                ),
                itemCount: results.length,
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: ((context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VendorProfileScreen(
                            vid: results[index].id.toString(),
                          ),
                        ),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(
                        screenSize.width / 192,
                      ),
                      height: screenSize.height / 7.11,
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.only(
                        bottom: screenSize.height / 64.06,
                        left: screenSize.width / 137.1,
                        right: screenSize.width / 137.1,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          screenSize.width / 192,
                        ),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(
                              0,
                              0,
                              0,
                              0.16,
                            ),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ),
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: screenSize.width / 29.5,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: screenSize.height / 16.01,
                                  width: screenSize.width / 32,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        width: screenSize.width / 1920,
                                        color: themeColor),
                                    image: DecorationImage(
                                      image: NetworkImage(
                                          '${MainUrl}vendor-image/${results[index].photo}'),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 80.0,
                                ),
                                Container(
                                  child: RatingBarIndicator(
                                    rating: 4.5,
                                    itemBuilder: (
                                      context,
                                      index,
                                    ) =>
                                        const Icon(
                                      Icons.star,
                                      color: Colors.amber,
                                    ),
                                    itemCount: 5,
                                    itemSize: 13.0,
                                    direction: Axis.horizontal,
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 96.1,
                                ),
                                Container(
                                  child: Center(
                                    child: Text(
                                      "734 Votes",
                                      style: GoogleFonts.merriweather(
                                        fontSize: screenSize.width / 213.3,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  results[index].name,
                                  style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 120,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                                SizedBox(
                                  height: screenSize.height / 96.1,
                                ),
                                SizedBox(
                                  width: screenSize.width / 12.8,
                                  child: Text(
                                    results[index].primaryskills,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 147.6,
                                      fontWeight: FontWeight.normal,
                                      color: Colors.black.withOpacity(
                                        0.53,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 192.2,
                                ),
                                SizedBox(
                                  width: screenSize.width / 12.8,
                                  child: Text(
                                    results[index].language,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.merriweather(
                                      fontSize: screenSize.width / 147.6,
                                      fontWeight: FontWeight.normal,
                                      color: Colors.black.withOpacity(
                                        0.53,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 192.2,
                                ),
                                Text(
                                  "${(results[index].enddate.difference(results[index].startdate).inDays)} Days",
                                  style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width / 147.6,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black.withOpacity(
                                      0.53,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height / 160.1,
                                ),
                                Text(
                                  "₹ ${results[index].audicallprice}/min",
                                  style: GoogleFonts.merriweather(
                                    fontSize: screenSize.width / 137.1,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black.withOpacity(
                                      1,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  height: screenSize.height / 24.02,
                                  width: screenSize.width / 48,
                                  decoration: const BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(
                                        "assets/SVG/star2-2x.png",
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        bottom: screenSize.height / 192.2,
                                      ),
                                      child: Icon(
                                        Icons.check,
                                        color: Colors.white,
                                        size: screenSize.width / 120,
                                      ),
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () async {
                                    SharedPreferences pref =
                                        await SharedPreferences.getInstance();
                                    if (pref.getString('uid') != null) {
                                      if (double.parse(
                                              _walletList[0].walletamount) >=
                                          100.0) {
                                        setState(() {
                                          isloading = true;
                                        });
                                        SharedPreferences pref =
                                            await SharedPreferences
                                                .getInstance();

                                        Map<String, String> data = {
                                          "userid":
                                              pref.getString("uid").toString(),
                                          "vid": results[index].id.toString(),
                                          "orderfor": "chat",
                                          "orderstatus": "created",
                                          "createdat": DateTime.now().toString()
                                        };
                                        _createOrderForChat(
                                          data,
                                          results[index].photo,
                                          results[index].name,
                                        );
                                      } else {
                                        showDialog<void>(
                                          context: context,
                                          barrierDismissible: false,
                                          builder: (
                                            BuildContext context,
                                          ) {
                                            return AlertDialog(
                                              elevation: 0.6,
                                              contentPadding: EdgeInsets.only(
                                                left: screenSize.width / 96,
                                                right: screenSize.width / 192,
                                                top: screenSize.height / 192.2,
                                                bottom:
                                                    screenSize.height / 192.2,
                                              ),
                                              titlePadding: EdgeInsets.only(
                                                left: screenSize.width / 96,
                                                right: screenSize.width / 192,
                                                top: screenSize.height / 192.2,
                                                bottom:
                                                    screenSize.height / 192.2,
                                              ),
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  screenSize.width / 128,
                                                ),
                                              ),
                                              title: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  const Text(
                                                    'Recharge Plan',
                                                  ),
                                                  IconButton(
                                                    icon: const Icon(
                                                      Icons.close,
                                                      color: Colors.red,
                                                    ),
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                  )
                                                ],
                                              ),
                                              content: const RechargeNow(),
                                            );
                                          },
                                        );
                                      }
                                    } else {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return const LoginModel();
                                        },
                                      );
                                    }
                                  },
                                  child: Container(
                                    height: screenSize.height / 38.44,
                                    width: screenSize.width / 29.53,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            screenSize.width / 192),
                                        color: themeColor),
                                    child: Center(
                                      child: Text(
                                        "Chat",
                                        style: GoogleFonts.merriweather(
                                          fontSize: screenSize.width / 160,
                                          fontWeight: FontWeight.bold,
                                          color: Color.fromRGBO(
                                            2,
                                            44,
                                            67,
                                            1,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                }),
              )
            : const Center(
                child: Text(
                  "No Data Found",
                ),
              )
        : const Center(
            child: CircularProgressIndicator(),
          );
  }

  void _createOrderForChat(
      Map<String, String> data, String image, String name) async {
    var response = await networkHandler.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "success",
          ),
        );
        print("Order created succesflly");
      } else {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "failed",
          ),
        );
        print("Something went wrong");
      }
    }
  }
}
