import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/model/BannerModel.dart';
import 'package:naksaa_services/model/experportfilo.dart';

class BannerService {
  Future<List<BDatum>?> viewallBanner() async {
    var client = http.Client();
    var uri = Uri.parse('${BaseUrl}banner');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      print(json);
      // print(json);
      return BannerModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }

  Future<List<ExpertData>> viewallBanner2() async {
    var client = http.Client();
    var uri = Uri.parse('${BaseUrl}expert_portfolio/1');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      print(json);
      // print(json);
      return ExpertPortfolioModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}
