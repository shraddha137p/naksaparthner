import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/Architect.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/InteriorDesgin.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/Structureengineer.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/civilenginner.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/lightningDesigner.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/plumingengineer.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/vastu.dart';

import '../../REgister/project Assets/constants.dart';
import '../ServiceDescription/electricalenginner.dart';

class ServiceMainScreen extends StatefulWidget {
  const ServiceMainScreen({super.key});

  @override
  State<ServiceMainScreen> createState() => _ServiceMainScreenState();
}

class _ServiceMainScreenState extends State<ServiceMainScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
          // margin: const EdgeInsets.only(right: 10),
          child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            width: screenSize.width / 72,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const Architect(),
                ),
              );
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Architect.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Architect Engineer",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const InteriorDesginDescription()));
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Interior Design.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Interior Desginer",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const Vastu(),
                ),
              );
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Vastu.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Vastu  Consultant",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ElectricalEngineer()));
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Electrical Engineer.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Electrical Engineer",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const LightingDesginer()));
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Lighting Design.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Lighting Desginer",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const CivilEngineer(),
                ),
              );
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Civil Engineer.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Civil Engineer",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const StructureEngineer(),
                ),
              );
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: screenSize.height / 15.12,
                  width: screenSize.width / 6,
                  padding: EdgeInsets.all(screenSize.width / 72),
                  child: SvgPicture.asset(
                    "assets/Structure.svg",
                    color: themeColor,
                  ),
                ),
                SizedBox(
                  height: screenSize.height / 189,
                ),
                Container(
                  child: Center(
                    child: SizedBox(
                      height: screenSize.height / 30.24,
                      width: screenSize.width / 6,
                      child: Text(
                        "Structure Engineer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 36,
                          color: const Color.fromRGBO(
                            2,
                            44,
                            67,
                            1,
                          ),
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.fade,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: screenSize.width / 30,
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const PlumbingEngineer(),
                ),
              );
            },
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: screenSize.height / 15.12,
                    width: screenSize.width / 6,
                    padding: EdgeInsets.all(screenSize.width / 72),
                    child: SvgPicture.asset(
                      "assets/Plumbing Engineer.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 94.5,
                  ),
                  Container(
                    child: Center(
                      child: SizedBox(
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 6,
                        child: Text(
                          "Plumbing Engineer",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: const Color.fromRGBO(
                              2,
                              44,
                              67,
                              1,
                            ),
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                    ),
                  )
                ]),
          ),
          SizedBox(
            width: screenSize.width / 72,
          ),
        ],
      )),
    );
  }

  Widget DesktopServiceMain() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      padding: EdgeInsets.only(
        left: screenSize.width / 192,
        right: screenSize.width / 192,
        top: screenSize.height / 160.1,
      ),
      // height: 200,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const Architect(),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Architect.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    height: screenSize.height / 24.02,
                    child: Center(
                      child: Text(
                        "Architect Engineer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const InteriorDesginDescription(),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Interior Design.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    height: screenSize.height / 24.02,
                    child: Center(
                      child: Text(
                        "Interior Designer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Vastu()));
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Vastu.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    height: screenSize.height / 24.02,
                    child: Center(
                      child: Text(
                        "Vastu Consultant",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ElectricalEngineer()));
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Electrical Engineer.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    child: Center(
                      child: Text(
                        "Electrical Engineer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const LightingDesginer(),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Lighting Design.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    child: Center(
                      child: Text(
                        "Lighting Desginer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const CivilEngineer(),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Civil Engineer.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 27.42,
                    child: Center(
                      child: Text(
                        "Civil Engineer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const StructureEngineer(),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Structure.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    child: Center(
                      child: Text(
                        "Structure Engineer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const PlumbingEngineer()));
            },
            child: Container(
              margin: EdgeInsets.only(right: screenSize.width / 48),
              child: Column(
                children: [
                  Container(
                    height: screenSize.height / 9.61,
                    width: screenSize.width / 19.2,
                    child: SvgPicture.asset(
                      "assets/Plumbing Engineer.svg",
                      color: themeColor,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 96.1,
                  ),
                  SizedBox(
                    width: screenSize.width / 19.2,
                    child: Center(
                      child: Text(
                        "Plumbing Engineer",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
