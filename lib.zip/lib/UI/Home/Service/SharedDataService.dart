import 'package:flutter/cupertino.dart';

class AppState {
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
  static String updateNotification = "";

  static GlobalKey<NavigatorState> getNavigator() {
    return navigatorKey;
  }
}
