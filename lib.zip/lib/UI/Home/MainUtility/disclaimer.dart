import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../../aboutus/aboutnavigation.dart';
import '../../REgister/project Assets/desktopNavbar.dart';
import '../BottomFooter.dart';

class OurDisclaimer extends StatefulWidget {
  const OurDisclaimer({Key? key}) : super(key: key);

  @override
  State<OurDisclaimer> createState() => _OurDisclaimerState();
}

class _OurDisclaimerState extends State<OurDisclaimer> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopDisclaimer();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopDisclaimer();
      } else {
        return MobileDisclaimer();
      }
    });
  }

  Widget DesktopDisclaimer() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          Container(
            color: Colors.white,
            child: const Aboutnavigation(
              MainContent: "Home",
              SubContent: "Our Disclaimer",
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          HeadingContent(),
          const SizedBox(
            height: 15,
          ),
          OurDisclaimer(),
          const BottomFooter()
        ],
      )),
    );
  }

  Widget MobileDisclaimer() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        title: Text(
          "Disclaimer",
          style: GoogleFonts.merriweather(
              fontWeight: FontWeight.bold, color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          const SizedBox(
            height: 15,
          ),
          HeadingContent(),
          const SizedBox(
            height: 15,
          ),
          OurDisclaimer(),
          const BottomFooter()
        ],
      )),
    );
  }

  Widget HeadingContent() {
    return Text(
      "Our Disclaimer",
      style: GoogleFonts.merriweather(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: darkBlue,
      ),
    );
  }

  Widget OurDisclaimer() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.85,
      child: Text(
        "The information and data contained on astrotalk website is to be treated purely for your entertainment purposes only. Any prediction or other message that you receive is not a substitute for advice, programs, or treatment that you would normally receive from a licensed professional such as a lawyer, doctor, psychiatrist, or financial advisor. Accordingly, astrotalk.com provides no guarantees, implied warranties, or assurances of any kind, and will not be responsible for any interpretation made or use by the recipient of the information and data mentioned above.Moreover, astrotalk.com is not a registered firm. It is a product of Codeyeti Software Solutions Pvt Ltd. All the transaction and gathered data is / will be accessed by CodeYeti.",
        textAlign: TextAlign.justify,
        style: GoogleFonts.merriweather(fontSize: 16),
      ),
    );
  }
}
