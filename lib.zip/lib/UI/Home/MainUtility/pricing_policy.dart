import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/MainUtility/Terms_and_conditions.dart';

import '../../../aboutus/aboutnavigation.dart';
import '../../REgister/project Assets/MainTextContent.dart';
import '../../REgister/project Assets/MainTextHead.dart';
import '../../REgister/project Assets/constants.dart';
import '../../REgister/project Assets/desktopNavbar.dart';
import '../BottomFooter.dart';

class PricingPolicy extends StatefulWidget {
  const PricingPolicy({Key? key}) : super(key: key);

  @override
  State<PricingPolicy> createState() => _PricingPolicyState();
}

class _PricingPolicyState extends State<PricingPolicy> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopPricingPolicy();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopPricingPolicy();
      } else {
        return MobilePricingPolicy();
      }
    });
  }

  Widget DesktopPricingPolicy() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          Container(
            color: Colors.white,
            child: const Aboutnavigation(
              MainContent: "Home",
              SubContent: "Pricing Policy",
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          HeadingContent(),
          const SizedBox(
            height: 15,
          ),
          PricingPolicy(),
          const BottomFooter()
        ],
      )),
    );
  }

  Widget MobilePricingPolicy() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          "Pricing Policy",
          style: GoogleFonts.merriweather(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
          child: Column(
        children: [
          const SizedBox(
            height: 15,
          ),
          HeadingContent(),
          const SizedBox(
            height: 15,
          ),
          PricingPolicy(),
          const BottomFooter()
        ],
      )),
    );
  }

  Widget HeadingContent() {
    return InkWell(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const TermsAndConditions()));
        },
        child: Text(
          "PRICING POLICY",
          style: GoogleFonts.merriweather(
              fontSize: 20, fontWeight: FontWeight.bold, color: darkBlue),
        ));
  }

  Widget PricingPolicy() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.85,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MainTextHead(
            txt1: "Price Range",
          ),
          const SizedBox(
            height: 15,
          ),
          const MainTextContent(
              txt2:
                  "At AstroTalk.com we have customised pricing according to the services rendered by us. The details are provided to you beforehand according to the effort, efficiency and the output of the service. Typically, the range of transactions on our Android and iOS applications varies from INR 500 to 1500 per user per session."),
          const SizedBox(
            height: 20,
          ),
          MainTextHead(
            txt1: "Schedule of payment",
          ),
          const SizedBox(
            height: 15,
          ),
          const MainTextContent(
              txt2:
                  "Some of our services can be utilised for fixed durations. In such cases, it is clearly mentioned within the description of these services. The period of usage in these cases vary from 1 month to 6 months."),
          const SizedBox(
            height: 20,
          ),
          MainTextHead(
            txt1: "Price Matching",
          ),
          const SizedBox(
            height: 15,
          ),
          const MainTextContent(
              txt2:
                  "At AstroTalk.com we are committed to offering you the best possible prices. We will be glad to meet our competitor's pricing if you ever find a service that we offer, in the similar interest and providing same professionalism and features, available from a similar service provider.\n\nOur prices do not vary according to the market needs, competitor pricing etc."),
          const SizedBox(
            height: 20,
          ),
          MainTextHead(
            txt1: "Sale Adjustment",
          ),
          const SizedBox(
            height: 15,
          ),
          const MainTextContent(
              txt2:
                  "If a service that you have purchased is reduced in price within one weeks of your booking date, we will not be able to adjust the sale price for you. Please note that we cannot make sale adjustment. If you have booked a slot for a date, generally, we cannot reschedule the slot to another date. This will result in the cancellation of the booking/order(s). Please refer cancellation policies for more details."),
          const SizedBox(
            height: 20,
          ),
          MainTextHead(
            txt1: "Pricing Errors",
          ),
          const SizedBox(
            height: 15,
          ),
          const MainTextContent(
              txt2:
                  "We work hard to ensure the accuracy of pricing. Despite our efforts, pricing errors may still occur. If a service’s price is higher than the price displayed, we will cancel your booking and notify you of the cancellation.\n\nOur service is offered for sale by CodeYeti Software Solutions Pvt’ Ltd’ for your personal needs. Therefore, we reserve the right to refuse to sell to any person whom we believe may be misusing the service.\n\nPlease feel free to reach us at support@codeyeti.in"),
          const SizedBox(
            height: 20,
          ),
        ],
      ),
    );
  }
}
