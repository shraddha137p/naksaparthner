import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';

import '../../../aboutus/aboutnavigation.dart';
import '../../REgister/project Assets/MainTextContent.dart';
import '../../REgister/project Assets/MainTextHead.dart';
import '../../REgister/project Assets/constants.dart';
import '../../REgister/project Assets/desktopNavbar.dart';

class PrivacyPolicy extends StatefulWidget {
  const PrivacyPolicy({Key? key}) : super(key: key);

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopPrivacyPolicy();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopPrivacyPolicy();
      } else {
        return MobilePrivacyPolicy();
      }
    });
  }

  Widget DesktopPrivacyPolicy() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          Container(
            color: Colors.white,
            child: const Aboutnavigation(
              MainContent: "Home",
              SubContent: "PRIVACY POLICY",
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          HeadingContent(),
          const SizedBox(
            height: 15,
          ),
          PrivacyPolicy(),
          const BottomFooter(),
        ],
      )),
    );
  }

  Widget MobilePrivacyPolicy() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: Text(
          "Privacy policy",
          style: GoogleFonts.merriweather(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          // Container(
          //   color: Colors.white,
          //   child: const Aboutnavigation(
          //     MainContent: "Home",
          //     SubContent: "PRIVACY POLICY",
          //   ),
          // ),
          const SizedBox(
            height: 15,
          ),
          HeadingContent(),
          const SizedBox(
            height: 15,
          ),
          PrivacyPolicy(),
          const BottomFooter(),
        ],
      )),
    );
  }

  Widget HeadingContent() {
    return InkWell(
        onTap: () {
          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) => const RefundAndCancellationPolicy()));
        },
        child: Text(
          "PRIVACY POLICY",
          style: GoogleFonts.merriweather(
              fontSize: 20, fontWeight: FontWeight.bold, color: darkBlue),
        ));
  }

  Widget PrivacyPolicy() {
    return SizedBox(
        width: MediaQuery.of(context).size.width * 0.85,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const MainTextContent(
                txt2:
                    "www.astrotalk.com (“we”, “Codeyeti software solutions pvt. Ltd”, “Astrotalk” (web and application) hereinafter referred as “website”) is committed to protect the privacy of the users of the website (including astrologers and buyers/customers whether registered or not registered). Please read this privacy policy carefully to understand how the website is going to use your information supplied by you to the Website."),
            const SizedBox(
              height: 10,
            ),
            const MainTextContent(
                txt2:
                    "This Privacy Policy is published in accordance with Rule 3(1) of the Information Technology (Intermediaries Guidelines) Rules, 2011 and Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011 which requires publishing of the Privacy policy for collection, use, storage and transfer of sensitive personal data or information."),

            const SizedBox(
              height: 20,
            ),

            //USER’S CONSENT

            MainTextHead(txt1: "USER’S CONSENT"),
            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "This Privacy Policy, which may be updated/amended from time to time, deals with the information collected from its users in the form of personal identification, contact details, birth details and any forecast made using the supplied information and how such information is further used for the purposes of the Website. By accessing the website and using it, you indicate that you understand the terms and expressly consent to the privacy policy of this website. If you do not agree with the terms of this privacy policy, please do not use this website."),

            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "Your continued use of this website shall confirm that you have provided your unconditional consent and confirm to the terms of this privacy policy as regards collecting, maintaining, using, processing and disclosing your personal and other information in accordance with this Privacy Policy."),

            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "This Privacy Policy is to be read alongwith the respective Terms of Use or other terms and conditions as provided on the Website."),

            const SizedBox(
              height: 20,
            ),

            //COMMITMENT

            MainTextHead(txt1: "COMMITMENT"),
            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "The Website intends to protect the privacy of all kinds of users visiting the platform irrespective whether the user is a registered user or merely a visitor. It is recommended to every user to understand what types of personally identifiable information is collected. The Website employs the personally identifiable information for certain predictions however it is guaranteed that no direct or indirect use of such information which is revealed in the prediction for a member will be done except for the explicit purpose of communicating the horoscope charts and predictions to the member itself disclosing such information. It is further clarified that the Website does not in any manner deal in selling or renting the information supplied to the Website."),
            const SizedBox(
              height: 10,
            ),
            const MainTextContent(
                txt2:
                    "The Website does not commit to treat or provide solutions for users with weak mental health which is inclusive of any user who have thoughts related to committing suicide, self-destruction etc. Such users are advised to stop the use of the present website with immediate effect and any continued use of the website by such person would be considered solely at the user’s risk and the Website shall have no liability for any untoward event in such scenario. The Website declares that the information provided by such kind of user can be shared, if required, with law enforcement authorities. Such information is not protected from any kind of non-disclosure or confidential agreements either with the Website or with any third-party involved herein."),

            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "The Website does not commit in any manner whatsoever for the accuracy of the predictions made by the astrologers to any user. The Website does not take any guarantee/responsibility/liability regarding the reliability or reality of the gems and other related items represented and sold on the website. It is further declared by the Website that no warranty on such service is provided by the Website in any manner."),

            const SizedBox(
              height: 20,
            ),

            //INFORMATION COLLECTED BY WEBSITE

            MainTextHead(txt1: "INFORMATION COLLECTED BY WEBSITE"),
            const SizedBox(
              height: 10,
            ),
            UnderLineText1mobile("PERSONAL IDENTIFIABLE INFORMATION:",
                " The information qualifies as personal in nature when the information collected identifies a specific end user. Such information would be collected by the website during the following actions:-"),
            const SizedBox(
              height: 10,
            ),
            UnderLineText2mobile(
                "a.",
                "Creating an account / Registration data:",
                "While accessing the Website, the User of the Website may be required to create an account. The personal information which may be sought while creating an account shall include, but not limited to the Full name, Address, Telephone Number, Email-address, Date of Birth, Gender, Location, Photograph, any other items of ‘sensitive personal data or information” as such term is defined under the Information Technology (Reasonable Security Practices And Procedures And Sensitive Personal Data Of Information) Rules, 2011 enacted under the Information Technology Act, 2000, and any other detail required on the website during registration. It is hereby informed to all the Users that the e-mail address or phone number together with a password or OTP is used for the purpose of securing User’s profile and for effective implementation of the personalized E-mail and SMS Services provided by the Website to the User. In the event that no registration is made by the User, the Website may not be able to provide any services due to non-availability of the personal identifiable information of the User."),
            const SizedBox(
              height: 10,
            ),
            UnderLineText2mobile("b.", "Booking a paid service",
                "While accessing the Website, the User of the Website may be required to create an account. The personal information which may be sought while creating an\naccount shall include, but not limited to the Full name, Address, Telephone Number, Email-address, Date of Birth, Gender, Location, Photograph, any other items of ‘sensitive personal data or\ninformation” as such term is defined under the Information Technology (Reasonable Security Practices And Procedures And Sensitive Personal Data Of Information) Rules, 2011 enacted under the\nInformation Technology Act, 2000, and any other detail required on the website during registration.\nIt is hereby informed to all the Users that the e-mail address or phone number together with a password or OTP is used for the purpose of\nsecuring User’s profile and for effective implementation of the personalized E-mail and SMS Services provided by the Website to the User. In the event that no registration is made by the User, the Website may not be able to provide any services due to non-\navailability of the personal identifiable information of the User."),
            const SizedBox(
              height: 10,
            ),
            UnderLineText2mobile("c.", "Log Files, IP Address and Cookies:",
                "The website collects information that is stored by your browser on your computer’s hard drive i.e. through cookies. It further automatically log generic information about the user’s computer connection to the Internet i.e. Session Data. The website may store temporary or permanent ‘cookies’ on the user’s computer. Cookies would allow the web server to recognize the user computer each time the user returns to the website including the time and date of the visit, viewing of page, length of time, verify registration or password information etc. Such cookies are usually only read by the server placed and the user may choose to block these cookies on their computers. Please note that if the cookies are turned off, the user may be prevented from using certain features of the website. The website uses the cookies to personalize the user’s experience on the website and to display an advertisement according to the user’s preferences.Some of the services provided by the Website may direct the User to platform of third parties. Any Information provided by the User on such platforms may be dealt by them in the manner provided by the privacy policy formulated by such third-party platforms. The Website in this regard fully disclaims any liability(ies) or claim(s) which may arise by use/misuse of such information shared by the User, to any third party or any party not known to the Website. The website would not liable for the mis-use of such information shared by the User or by any third party.We also collect details including but not limited to User feedback, comments, etc. that may be disclosed/informed/mentioned on any article/blog or groups/forums or other pages which the User may have access to while visiting the Website. For such information which is in public domain and accessible to all the Users and visitors of the Website, the User is advised to exercise its discretion before disclosing it as this information is susceptible to misuse."),
            const SizedBox(
              height: 10,
            ),
            UnderLineText2mobile("d.", "Miscellaneous Activities:",
                " The Website may collect any other information which may be mandatory to be disclosed and further may receive any other information via email or other method inclusive of contract with regard to specific services availed from the Website or any products bought from the Website, such information may not be made part of the User-Member’s Profile but shall be used only for addressing the specific need or concern of the User."),
            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("NON - PERSONAL IDENTIFIABLE INFORMATION:",
                "The information qualifies as non-personal in nature when the information collected does not identify a specific end user. Such information is collected when the user visits the Website, cookies, etc. and would include but not limited to the following:"),
            const SizedBox(
              height: 10,
            ),
            UrlTextmobile("a.",
                "URL (Uniform Resource Locator) of the previous website visited by the User before visiting this website or the URL of the website the User visits after visiting this Website."),
            const SizedBox(
              height: 10,
            ),
            UrlTextmobile(
              "b.",
              "Internet service provider / IP Address / Telecom service provider.",
            ),

            const SizedBox(
              height: 10,
            ),
            UrlTextmobile(
              "c.",
              "Type of Browser used for accessing the website.",
            ),
            const SizedBox(
              height: 10,
            ),
            UrlTextmobile(
              "d.",
              "Geographical Location",
            ),

            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "Such non-personal identifiable information is used by the Website for the purposes including but not limited to troubleshoot connection problems, administer the website, analyze trends, gather demographic information, frequency of visits to the website, average length of visits, pages viewed during a visit, compliance with applicable law, and cooperate with law enforcement activities, etc."),

            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "The information is used for improving the site content and performance and the website may share this information with Third Party Service Providers and Third Party Advertisers to measure the overall effectiveness of the website’s online advertising, content, programming and for other bonafide purpose as required."),

            const SizedBox(
              height: 10,
            ),

            const MainTextContent(
                txt2:
                    "THE USER HEREBY REPRESENT AND CONFIRMS THAT THE INFORMATION PROVIDED TO THE WEBSITE IS AUTHENTIC, CORRECT, CURRENT AND UPDATED. THE WEBSITE AND ITS ENTITES SHALL NOT BE RESPONSIBLE FOR THE AUTHENTICITY OF THE INFORMATION THAT THE USER MAY PROVIDE. THE USER SHALL BE PERSONALLY LIABLE AND INDEMNIFY THE WEBSITE FOR THE BREACH OF ANY PROVISION."),

            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("SECURITY MEASURES:",
                "The security of the personal information supplied by the User is very important to the Website and the website for the purpose of securing the information takes various measures inclusive of taking reasonable steps such as physical and electronic security measures to guard against the unauthorized access to the information. The personal information of a user is collected on a secured server. The payment details are entered on the Payment Gateway’s or Bank’s page on a secured SSL. The data is transferred between Bank’s page and payment’s gateways in an encrypted manner. However please note that no data transmission can be guaranteed to be completely secure. Hence the user is advised to take precaution and care against any sharing of the details submitted on the website included the log-in details as generated after registration. The website is not responsible for the security or confidentiality of communications the user may send through the internet using email messages, etc."),
            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("USAGE OF THE INFORMATION:",
                " The information collected by the Website may be used for any purpose as may be permissible under the applicable law and shall include but not limited to the following: -"),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("a.",
                "For providing a personalised browsing experience. While guaranteeing the anonymity of the user, the personal information collected in Clause “Personal Identifiable Information” may be used for research purposes, for improving the marketing and promotional efforts, to analyse usage, improve the content of the Website, product offering and for customising the Website’s layout for suiting the needs of its Users."),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("b.",
                "With IP tracking details and Cookies data, the Website will use it only for facilitating the usage of the website and provide personalised experience and any information which is sensitive in nature will not be provided to any third party without the consent of the User."),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("c.",
                "All information (and copies thereof) collected by Website, including without limitation Personal Information, User Data, and other information related to your access and use of the services offered by Website, may be retained by Website for such period as necessary, including but not limited to, for purposes such as compliance with statutory or legal obligations, tax laws and potential evidentiary purposes and for other reasonable purposes such as to implement, administer, and manage your access and use of our services, or resolution of any disputes."),
            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("d.",
                "To ensure a seamless experience at the Website for you and to ensure your maximum benefit and comfort, the Website may use the data collected through cookies, log file, device identifiers, location data and clear gifs information to: (a) remember information so that you will not have to re-enter it during your visit or the next time you visit the site; (b) provide custom, personalized content and information, including advertising; (c) provide and monitor the effectiveness of Services offered by Website; (d) monitor aggregate metrics such as total number of visitors, traffic, usage, and demographic patterns on the Website and its Services; (e) diagnose or fix technology problems; and (f) otherwise to plan for and enhance the service."),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("e.",
                "Website uses certain third-party analytics tools to measure traffic and usage trends for the Services. These tools collect information, which is not personal or sensitive in nature sent by the User’s device, including the web pages visited, add-ons, and other information that assists the Website in improving the Services. Such information is collected from Users in the form of anonymized logs, so that it cannot reasonably be used to identify any particular individual User."),

            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("CONFIDENTIAL:",
                "The website aspires to takes care of all the information provided to it by its Users which may be termed as confidential. Such confidential information which is not required to be disclosed to the website, is specifically excluded from the definition of Personal Information and shall not be collected/used. The confidential information of the User shall not be disclosed or shared by the Websites, its employees, its agents or any third-party contractors including the experts either orally or in writing except for the following circumstances:"),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("a.",
                "If Website believes that there is a significant/ real/ imminent threat or risk to User’s health, safety or life or to the health, safety or life of any other person or the public."),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("b.",
                "If such confidential information must be shared in accordance with the law inclusive of any investigation, Court summons, judicial proceedings etc."),

            const SizedBox(
              height: 10,
            ),

            UrlTextmobile("c.",
                "To protect and defend the rights or property of the Website"),

            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("CHILDREN PRIVACY POLICY:",
                "The Website requires that the User visiting and using the services are above 18 years of age however some service information is accessible to children under the age of 18 as well. However, it is stressed upon that website is not designed or intended to be attractive to be used by children under the age of 13 and no personal identifiable information of children below the age of 13 is collected knowingly. IF YOU ARE UNDER 13 YEARS OF AGE, PLEASE DO NOT USE ANY OF THE SERVICE PROVIDED BY THE WEBSITE AT ANY TIME OR IN ANY MANNER. If it comes to the knowledge of the concerned parent regarding sharing of any information of a child under the age of 13, contact the Website immediately. We will take appropriate steps and delete the data from the Website’s systems."),

            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("Safety and Security:",
                " Astrotalk.com honors users' privacy and employs the best practice to secure the user's personal details, such as birth details, address, etc., and also financial details such as credit card or debit card transaction details. Astrotalk.com uses the best encryption methodologies to ensure secure transactions from our side and thus encourages our clients to use their credit/debit cards on Astrotalk.com with full confidence. By doing so, we strive for the safety and security of our users, thus making their experience with Astrotalk.com absolutely safe and secure."),

            const SizedBox(
              height: 20,
            ),

            //DISCLAIMER

            MainTextHead(txt1: "DISCLAIMER"),
            const SizedBox(
              height: 10,
            ),
            const MainTextContent(
                txt2:
                    "THE WEBSITE IS NOT RESPONSIBLE FOR ANY COMMUNICATION BETWEEN THE USER AND THE THIRD-PARTY WEBSITE. THE USER IS ADVISED TO READ THE PRIVACY POLICY AND OTHER POLICIES OF THE THIRD PARTY ON THEIR WEBSITES AND THIS WEBSITE SHALL NOT BE HELD LIABLE FOR SUCH USAGE MADE ONLY BECAUSE A LINK TO THE THIRD-PARTY WEBSITE WAS PROVIDED ON THE PAGE OF THIS WEBSITE."),

            const SizedBox(
              height: 20,
            ),

            //GRIEVANCE OFFICER

            const MainTextContent(txt2: "GRIEVANCE OFFICER"),

            const SizedBox(
              height: 10,
            ),

            UnderLineText1mobile("Grievance Officer Name:", "Ankush Mohan"),
            const SizedBox(
              height: 5,
            ),
            const Text(
              "Email: support@naksa.com",
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            ),

            const SizedBox(
              height: 5,
            ),

            const MainTextContent(
                txt2:
                    "The above Officer is appointed in accordance with the Information Technology Act 2000 and rules made there under. The Officer can be contacted if there are any discrepancies found on the website or there is any breach of Terms of Use, Privacy Policy or other policies or any other complaints or concerns."),

            const SizedBox(
              height: 30,
            ),
          ],
        ));
  }

  Widget UnderLineText1mobile(String txtU, String txtN) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      // height: MediaQuery.of(context).size.height * 0.5,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Text(
              txtU,
              overflow: TextOverflow.fade,
              style: GoogleFonts.merriweather(
                decoration: TextDecoration.underline,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Text(
              txtN,
              textAlign: TextAlign.justify,
              maxLines: 7,
              style: GoogleFonts.merriweather(fontSize: 15),
            ),
          ),
        ],
      ),
    );
  }

  Widget UnderLineText1(String txtU, String txtN) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.85,
      // height: MediaQuery.of(context).size.height * 0.5,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.15,
            child: Text(
              txtU,
              overflow: TextOverflow.fade,
              style: const TextStyle(
                decoration: TextDecoration.underline,
              ),
            ),
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.67,
            child: Text(
              txtN,
              textAlign: TextAlign.justify,
              maxLines: 7,
              style: GoogleFonts.merriweather(fontSize: 15),
            ),
          ),
        ],
      ),
    );
  }

  Widget UnderLineText2(String txta, String txtcreat, String txtMain) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.9,
        // height: 0.5,
        child: Row(
          // mainAxisAlignment:MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              txta,
              textAlign: TextAlign.justify,
              style: GoogleFonts.merriweather(),
            ),
            Flexible(
              child: Text(
                txtcreat,
                maxLines: 10,
                style: const TextStyle(
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
            const SizedBox(
              width: 4,
            ),
            SizedBox(
                width: MediaQuery.of(context).size.width * 0.70,
                child: MainTextContent(
                  txt2: txtMain,
                )),
          ],
        ),
      ),
    );
  }

  Widget UnderLineText2mobile(String txta, String txtcreat, String txtMain) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.9,
        // height: 0.5,
        child: Column(
          // mainAxisAlignment:MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  txta,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.merriweather(),
                ),
                const SizedBox(
                  width: 5,
                ),
                Text(
                  txtcreat,
                  maxLines: 10,
                  style: GoogleFonts.merriweather(
                    fontWeight: FontWeight.bold,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ],
            ),
            const SizedBox(
              width: 4,
            ),
            SizedBox(
                width: MediaQuery.of(context).size.width,
                child: MainTextContent(
                  txt2: txtMain,
                )),
          ],
        ),
      ),
    );
  }

  Widget UrlText(String txtAUrl, String txtUrl) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.8266,
        // height: 0.8,
        child: Row(
          // mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Flexible(child: Text(txtAUrl, maxLines: 10)),
            const SizedBox(
              width: 6,
            ),
            Flexible(child: MainTextContent(txt2: txtUrl)),
          ],
        ),
      ),
    );
  }

  Widget UrlTextmobile(String txtAUrl, String txtUrl) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.8266,
        // height: 0.8,
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Flexible(
                  child: Text(
                    txtAUrl + txtUrl,
                    maxLines: 10,
                    textAlign: TextAlign.justify,
                    style: GoogleFonts.merriweather(),
                  ),
                ),
              ],
            ),
            const SizedBox(
              width: 6,
            ),
          ],
        ),
      ),
    );
  }
}
