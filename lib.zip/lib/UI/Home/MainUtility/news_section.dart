import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class NewsSection extends StatefulWidget {
  const NewsSection({super.key});

  @override
  State<NewsSection> createState() => _NewsSectionState();
}

class _NewsSectionState extends State<NewsSection> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopNewSection();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopNewSection();
      } else {
        return MobileNewSection();
      }
    });
  }

  Widget DesktopNewSection() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      width: double.infinity,
      color: themeColor,
      child: Column(
        children: [
          HeadingContent(),
          SizedBox(
            height: screenSize.height / 64.06,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
            ],
          ),
          SizedBox(
            height: screenSize.height / 48.05,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
            ],
          ),
          SizedBox(
            height: screenSize.height / 48.05,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
            ],
          ),
          SizedBox(
            height: screenSize.height / 48.05,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
              newSectionWidget(),
              SizedBox(
                width: screenSize.width / 96,
              ),
            ],
          ),
          SizedBox(
            height: screenSize.height / 48.05,
          ),
        ],
      ),
    );
  }

  Widget MobileNewSection() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: screenSize.width / 72),
            margin: EdgeInsets.symmetric(vertical: screenSize.height / 75.6),
            height: screenSize.height / 9.45,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                Container(
                  width: screenSize.width / 1.89,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  child: Column(
                    children: [
                      Image.network(
                        "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 2.57,
                      ),
                      SizedBox(
                        height: screenSize.height / 151.2,
                      ),
                      Text(
                        "May 01, 2023",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: screenSize.width / 36,
                ),
                Container(
                  width: screenSize.width / 1.89,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  child: Column(
                    children: [
                      Image.network(
                        "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 2.57,
                      ),
                      SizedBox(
                        height: screenSize.height / 151.2,
                      ),
                      Text(
                        "May 01, 2023",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: screenSize.width / 36,
                ),
                Container(
                  width: screenSize.width / 1.89,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  child: Column(
                    children: [
                      Image.network(
                        "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 2.57,
                      ),
                      SizedBox(
                        height: screenSize.height / 151.2,
                      ),
                      Text(
                        "May 01, 2023",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: screenSize.width / 36,
                ),
                Container(
                  width: screenSize.width / 1.89,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  child: Column(
                    children: [
                      Image.network(
                        "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 2.57,
                      ),
                      SizedBox(
                        height: screenSize.height / 151.2,
                      ),
                      Text(
                        "May 01, 2023",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: screenSize.width / 36,
                ),
                Container(
                  height: screenSize.height / 9.45,
                  width: screenSize.width / 1.89,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  child: Column(
                    children: [
                      Image.network(
                        "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 2.57,
                      ),
                      SizedBox(
                        height: screenSize.height / 151.2,
                      ),
                      Text(
                        "May 01, 2023",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: screenSize.width / 36,
                ),
                Container(
                  height: screenSize.height / 9.45,
                  width: screenSize.width / 1.89,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(screenSize.width / 36),
                  ),
                  child: Column(
                    children: [
                      Image.network(
                        "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
                        height: screenSize.height / 15.12,
                        width: screenSize.width / 2.57,
                      ),
                      SizedBox(
                        height: screenSize.height / 151.2,
                      ),
                      Text(
                        "May 01, 2023",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget HeadingContent() {
    
    var screenSize = MediaQuery.of(context).size;
    return Text(
      "News Section",
      style: GoogleFonts.merriweather(
          fontSize: screenSize.width/64, fontWeight: FontWeight.bold, color: darkBlue),
    );
  }
}

// ignore: camel_case_types
class newSectionWidget extends StatelessWidget {
  const newSectionWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    return Container(
      height: screenSize.height/10.64,
      width: screenSize.width/10.1,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(screenSize.width/384),
      ),
      child: Padding(
        padding:  EdgeInsets.all(screenSize.width/240),
        child: Column(children: [
           SizedBox(
            height:screenSize.height/106.7,
          ),
          Image.network(
            "https://tse2.mm.bing.net/th?id=OIP.CgkTIis_Vujk03bJs06aBQHaB5&pid=Api&P=0",
            height: screenSize.height/24.02,
            width: screenSize.width/3.84,
          ),
           SizedBox(
            height: screenSize.height/192.2,
          ),
          Text(
            "May 01, 2023",
            style: GoogleFonts.merriweather(
                fontSize: screenSize.width/192, color: Colors.black, fontWeight: FontWeight.bold),
          )
        ]),
      ),
    );
  }
}
