import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';
import 'package:naksaa_services/UI/Home/MainUtility/disclaimer.dart';
import 'package:naksaa_services/UI/Home/MainUtility/pricing_policy.dart';
import 'package:naksaa_services/UI/Home/MainUtility/privacy_policy.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:webviewx/webviewx.dart';

import '../../REgister/project Assets/AppBar.dart';
import '../../REgister/project Assets/Navigationdrawer.dart';
import '../../REgister/project Assets/desktopNavbar.dart';
import 'Terms_and_conditions.dart';
import 'blog_details.dart';

class BlogPage extends StatefulWidget {
  const BlogPage({
    super.key,
  });

  @override
  State<BlogPage> createState() => _BlogPageState();
}

bool isdrop = false;
bool isloaded = false;
int selection = 0;
int? totallength;

class _BlogPageState extends State<BlogPage> {
  late WebViewXController webviewController;

  Size get screenSize => MediaQuery.of(context).size;

  @override
  void dispose() {
    webviewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopBlogPage();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopBlogPage();
      } else {
        return MobileBlogPage();
      }
    });
  }

  bool isloading = false;

  bool isloading1 = false;

  Widget MobileBlogPage() {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
        appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0.0,
            toolbarHeight: 140,
            automaticallyImplyLeading: false,
            foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
            flexibleSpace: const AppBarScreen()),
        drawer: const Drawer(
          backgroundColor: darkBlue,
          child: NavigationDrawers(),
        ),
        body: Container(
            padding: EdgeInsets.only(bottom: 10),
            child: WebViewX(
              key: const ValueKey('webviewx'),
              initialContent: 'https://naksa.kesarwanisangh.com/',
              initialSourceType: SourceType.url,
              height: screenSize.height,
              width: screenSize.width,
              onWebViewCreated: (controller) => webviewController = controller,
              onPageStarted: (src) {
                debugPrint('A new page has started loading: $src\n');
              },
              onPageFinished: (src) {
                debugPrint('The page has finished loading: $src\n');
                setState(() {
                  isloading = false;
                });
              },
              jsContent: const {
                EmbeddedJsContent(
                  js: "function testPlatformIndependentMethod() { console.log('Hi from JS') }",
                ),
                EmbeddedJsContent(
                  webJs:
                      "function testPlatformSpecificMethod(msg) { TestDartCallback('Web callback says: ' + msg) }",
                  mobileJs:
                      "function testPlatformSpecificMethod(msg) { TestDartCallback.postMessage('Mobile callback says: ' + msg) }",
                ),
              },
              dartCallBacks: {},
              webSpecificParams: const WebSpecificParams(
                printDebugInfo: true,
              ),
              mobileSpecificParams: const MobileSpecificParams(
                androidEnableHybridComposition: true,
              ),
              navigationDelegate: (navigation) {
                debugPrint(navigation.content.sourceType.toString());
                return NavigationDecision.navigate;
              },
            )));
  }

  Widget DesktopBlogPage() {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
        appBar: const PreferredSize(
          preferredSize: Size(1000, 1000),
          child: NavBar(),
        ),
        body: SingleChildScrollView(
            child: Container(
                height: height,
                child: WebViewX(
                  key: const ValueKey('webviewx'),
                  initialContent: 'https://naksa.kesarwanisangh.com/',
                  initialSourceType: SourceType.url,
                  height: screenSize.height,
                  width: screenSize.width,
                  onWebViewCreated: (controller) =>
                      webviewController = controller,
                  onPageStarted: (src) {
                    debugPrint('A new page has started loading: $src\n');
                  },
                  onPageFinished: (src) {
                    debugPrint('The page has finished loading: $src\n');
                    setState(() {
                      isloading = false;
                    });
                  },
                  jsContent: const {
                    EmbeddedJsContent(
                      js: "function testPlatformIndependentMethod() { console.log('Hi from JS') }",
                    ),
                    EmbeddedJsContent(
                      webJs:
                          "function testPlatformSpecificMethod(msg) { TestDartCallback('Web callback says: ' + msg) }",
                      mobileJs:
                          "function testPlatformSpecificMethod(msg) { TestDartCallback.postMessage('Mobile callback says: ' + msg) }",
                    ),
                  },
                  dartCallBacks: {},
                  webSpecificParams: const WebSpecificParams(
                    printDebugInfo: true,
                  ),
                  mobileSpecificParams: const MobileSpecificParams(
                    androidEnableHybridComposition: true,
                  ),
                  navigationDelegate: (navigation) {
                    debugPrint(navigation.content.sourceType.toString());
                    return NavigationDecision.navigate;
                  },
                ))));
  }

  Widget Googleplaybutton() {
    return Column(
      children: [
        Text(
          "Download app from",
          style: GoogleFonts.merriweather(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            Container(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    20,
                  ),
                ),
              ),
              child: Image.asset(
                "assets/transparentapp.png",
                height: 40,
                width: 130,
                fit: BoxFit.cover,
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(20),
                ),
              ),
              child: Image.asset(
                "assets/googletransparent.png",
                height: 50,
                width: 130,
                fit: BoxFit.cover,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget Footerconnectwithus() {
    return Column(
      children: [
        Text("Connect With us",
            style: GoogleFonts.merriweather(
                fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.facebook,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.twitter,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.instagram,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.youtube,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget headerfotter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Link',
          style: GoogleFonts.merriweather(
              fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 20,
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(
              context,
              "/home",
            );
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const bullet(),
                  Text(
                    ' Home',
                    style: GoogleFonts.merriweather(
                        fontSize: 16,
                        fontWeight: _isHovering[0] != true
                            ? FontWeight.w500
                            : FontWeight.bold,
                        color: _isHovering[0] != true
                            ? Colors.black.withOpacity(0.7)
                            : darkBlue),
                  ),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(
              context,
              "/about_us",
            );
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' About Us',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(context, "/our_Services");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Services',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          hoverColor: Colors.transparent,
          onTap: () {
            Navigator.pushNamed(context, "/chat_with_us");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Chat With US',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          hoverColor: Colors.transparent,
          onTap: () {
            Navigator.pushNamed(context, "/call_with_us");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Call With Us',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(context, "/our_live_vendor");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Live Naksian',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)
                      // style: TextStyle(
                      //   fontSize: 16,
                      //   fontWeight: FontWeight.bold,
                      //   color: _isHovering[4] ? active : disable,
                      // ),
                      ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  final List _isHovering = [false, false, false, false, false];
  Widget FooterColumn() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Corporate Info",
          style: GoogleFonts.merriweather(
              fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const PrivacyPolicy(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[0] = true : _isHovering[0] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Privacy Policy",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TermsAndConditions(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[1] = true : _isHovering[1] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Terms & Conditions",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[1] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[1] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  // Navigator.pushNamed(
                  //     context, "/home/Refund&cancellationPolicy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[2] = true : _isHovering[2] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Refund & Cancellation Policy",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[2] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[2] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const PricingPolicy(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[3] = true : _isHovering[3] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Pricing Policy",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[3] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[3] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const OurDisclaimer(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[4] = true : _isHovering[4] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Our Disclaimer",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[4] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[4] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget footerhead() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Corporate Info",
          style: GoogleFonts.merriweather(
              fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/privacy_policy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[0] = true : _isHovering[0] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Home",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/terms_and_conditions");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[1] = true : _isHovering[1] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "About Us",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  // Navigator.pushNamed(
                  //     context, "/home/Refund&cancellationPolicy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[2] = true : _isHovering[2] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Services",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/pricing_policy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[3] = true : _isHovering[3] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Call with Us",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[3] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[3] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/our_disclaimer");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[4] = true : _isHovering[4] = false;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      const bullet(),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Live Naksian",
                        style: GoogleFonts.merriweather(
                            fontSize: 16,
                            fontWeight: _isHovering[4] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[4] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}
