import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/OrderNotificationModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Service/NotificationService.dart';
import 'Partner/CallRequest.dart';
import 'Partner/ChatRequest.dart';
import 'Partner/VideoCall/IncomingVideoCallScreen.dart';

class NaksaNotifictaion extends StatefulWidget {
  const NaksaNotifictaion({super.key});

  @override
  State<NaksaNotifictaion> createState() => _NaksaNotifictaionState();
}

class _NaksaNotifictaionState extends State<NaksaNotifictaion> {
  List<OrderNotification> _ordernotification = [];
  var notificationService = NotificationService();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getData();
  }

  bool isloading = false;
  Future<List<OrderNotification>> _getData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var reponse = await notificationService.orderNotifications(uid!);
    if (reponse != null) {
      setState(() {
        isloading = true;
        _ordernotification = reponse;
      });
    } else {
      setState(() {
        _ordernotification = [];
      });
    }
    return reponse!;
  }

  @override
  Widget build(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Notifications"),
        backgroundColor: themeColor,
      ),
      body: Container(
        margin:  EdgeInsets.all(screenSize.width/24),
        child: isloading != false
            ? _ordernotification.length >= 1
                ? ListView.builder(
                    itemCount: _ordernotification.length,
                    itemBuilder: (context, index) {
                      return _ordernotification[index].orderstatus == "accepted"
                          ? GestureDetector(
                              onTap: () async {
                                if (_ordernotification[index].orderfor ==
                                    "chat") {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              IncomingChatRequest(
                                                vendorid:
                                                    _ordernotification[index]
                                                        .id
                                                        .toString(),
                                                orderid:
                                                    _ordernotification[index]
                                                        .orderid
                                                        .toString(),
                                              )));
                                }
                                if (_ordernotification[index].orderfor ==
                                    "call") {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              IncomingCallRequest(
                                                  channelname:
                                                      _ordernotification[index]
                                                          .channelname
                                                          .toString(),
                                                  token:
                                                      _ordernotification[index]
                                                          .channelname
                                                          .toString(),
                                                  vendorid:
                                                      _ordernotification[index]
                                                          .id
                                                          .toString())));
                                }
                                if (_ordernotification[index].orderfor ==
                                    "video-call") {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              IncomingVideoCallRequest(
                                                  channelname:
                                                      _ordernotification[index]
                                                          .channelname
                                                          .toString(),
                                                  token:
                                                      _ordernotification[index]
                                                          .channelname
                                                          .toString(),
                                                  vendorid:
                                                      "1")));
                                }
                              },
                              child: Container(    
                                width: screenSize.width/1.07,
                                margin:  EdgeInsets.only(bottom: screenSize.height/75.6),
                                padding:  EdgeInsets.symmetric(
                                    vertical: screenSize.width/24, horizontal: screenSize.width/36),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(screenSize.width/36),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color.fromRGBO(0, 0, 0, 0.16),
                                      offset: Offset(
                                        3.0,
                                        3.0,
                                      ),
                                      blurRadius: 6.0,
                                      spreadRadius: 2.0,
                                    ), //BoxShadow
                                    BoxShadow(
                                      color: Colors.white,
                                      offset: Offset(0.0, 0.0),
                                      blurRadius: 0.0,
                                      spreadRadius: 0.0,
                                    ), //BoxShadow
                                  ],
                                ),
                                child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      SizedBox(
                                        width: screenSize.width/9,
                                        child: CircleAvatar(
                                          backgroundImage: NetworkImage(
                                              MainUrl +
                                                  "vendor-image/" +
                                                  _ordernotification[index]
                                                      .photo
                                                      .toString()),
                                        ),
                                      ),
                                       SizedBox(
                                        width: screenSize.width/36,
                                      ),
                                      SizedBox(
                                        width: screenSize.width/1.56,
                                        child: Text(
                                          "${_ordernotification[index].name} Accepted Your Order, To Connect Now Click Here ",
                                          style: TextStyle(
                                              fontSize: screenSize.width/24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      Icon(Icons.arrow_forward_ios_sharp)
                                    ]),
                              ),
                            )
                          : Container();
                    })
                : const Center(
                    child: Text("No Notification Found"),
                  )
            : const LoadingIndicator(),
      ),
    );
  }
}
