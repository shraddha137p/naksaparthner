import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/BannerService.dart';
import 'package:naksaa_services/model/experportfilo.dart';

class MainSlider1 extends StatefulWidget {
  final String ep;
  const MainSlider1({super.key, required this.ep});

  @override
  State<MainSlider1> createState() => _MainSlider1State();
}

class _MainSlider1State extends State<MainSlider1> {
  List<ExpertData> results = [];
  var vendorService = BannerService();
  bool isloading = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    // allVendor = vendorService.viewallVendor();
  }

  Future<List<ExpertData>> getdata() async {
    setState(() {
      isloading = true;
    });
    results = (await vendorService.viewallBanner2(widget.ep));
    if (results != null) {
      setState(() {
        isloading = false;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopBanner();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopBanner();
      } else {
        return Mobilebanner();
      }
    });
  }

  Widget DesktopBanner() {
    return isloading != true
        ? Container(
            margin: const EdgeInsets.only(left: 10, right: 10),
            height: 350,
            color: Colors.transparent,
            child: SizedBox(
                height: MediaQuery.of(context).size.height,
                child: GridView.builder(
                    itemCount: results.length,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      mainAxisExtent: 170,
                      mainAxisSpacing: 20,
                      crossAxisSpacing: 20,
                      childAspectRatio: 5,
                    ),
                    itemBuilder: (BuildContext context, int index) {
                      return ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.network(
                          "${MainUrl}portfolio-image/${results[index].eimage}",
                          fit: BoxFit.fill,
                        ),
                      );
                    })))
        : const SizedBox(
            height: 120,
            child: LoadingIndicator(),
          );
  }

  Widget Mobilebanner() {
    return isloading != true
        ? SizedBox(
            height: 120,
            child: ListView(
              children: [
                CarouselSlider(
                  items: results
                      .map((e) => Container(
                            margin: const EdgeInsets.all(6.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              image: DecorationImage(
                                image: NetworkImage(
                                    '${MainUrl}portfolio-image/${e.eimage}'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ))
                      .toList(),

                  // //Slider Container properties
                  options: CarouselOptions(
                    height: 120.0,
                    enlargeCenterPage: true,
                    autoPlay: true,
                    aspectRatio: 16 / 9,
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enableInfiniteScroll: true,
                    autoPlayAnimationDuration:
                        const Duration(milliseconds: 800),
                    viewportFraction: 0.9,
                  ),
                ),
              ],
            ),
          )
        : const SizedBox(
            height: 120,
            child: LoadingIndicator(),
          );
  }
}
