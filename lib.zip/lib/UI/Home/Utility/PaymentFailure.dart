import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';

import '../../REgister/project Assets/constants.dart';

class PaymentFailure extends StatefulWidget {
  const PaymentFailure({super.key});

  @override
  State<PaymentFailure> createState() => _PaymentFailureState();
}

class _PaymentFailureState extends State<PaymentFailure> {
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(const Duration(seconds: 5), () {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (conetxt) => BottomNavigationBarScreen(pageIndex: 0)));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopPaymentFailure();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopPaymentFailure();
      } else {
        return MobilePaymentFailure();
      }
    });
  }

  Widget DesktopPaymentFailure() {
    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 100,
              width: 100,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/SVG/p_success.png"),
                      fit: BoxFit.cover)),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              "Some Thing Went Wrong!",
              style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(231, 95, 101, 1)),
            ),
            const SizedBox(
              height: 8,
            ),
            Text(
              "Payment Failed!",
              style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.black.withOpacity(0.7)),
            ),
            const SizedBox(
              height: 18,
            ),
            Container(
              margin: const EdgeInsets.only(left: 30, right: 30),
              child: Text(
                "You will be redirected to Home Page Shortly or click here to return to Home Page",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Colors.black.withOpacity(0.5)),
              ),
            ),
            const SizedBox(
              height: 35,
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (conetxt) =>
                            BottomNavigationBarScreen(pageIndex: 0)));
              },
              child: Container(
                height: 45,
                width: 300,
                decoration: BoxDecoration(
                    color: darkBlue, borderRadius: BorderRadius.circular(10)),
                child: const Center(
                    child: Text(
                  "Go To Home",
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget MobilePaymentFailure() {
    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 100,
              width: 100,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/SVG/p_success.png"),
                      fit: BoxFit.cover)),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              "Some Thing Went Wrong!",
              style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(231, 95, 101, 1)),
            ),
            const SizedBox(
              height: 8,
            ),
            Text(
              "Payment Failed!",
              style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.black.withOpacity(0.7)),
            ),
            const SizedBox(
              height: 18,
            ),
            Container(
              margin: const EdgeInsets.only(left: 30, right: 30),
              child: Text(
                "You will be redirected to Home Page Shortly or click here to return to Home Page",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Colors.black.withOpacity(0.5)),
              ),
            ),
            const SizedBox(
              height: 35,
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (conetxt) =>
                            BottomNavigationBarScreen(pageIndex: 0)));
              },
              child: Container(
                height: 45,
                width: 300,
                decoration: BoxDecoration(
                    color: darkBlue, borderRadius: BorderRadius.circular(10)),
                child: const Center(
                    child: Text(
                  "Go To Home",
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
