import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/Service/PaymentandWalletService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../model/RechargeNowModel.dart';
import '../../REgister/project Assets/LoginModel.dart';
import 'PaymentDetails.dart';

class RechargeNow extends StatefulWidget {
  const RechargeNow({super.key});

  @override
  State<RechargeNow> createState() => _RechargeNowState();
}

class _RechargeNowState extends State<RechargeNow> {
  List<Datum> recharge = [];

  var rechargeService = PaymentandWalletService();

  Future<List<Datum>> getdata() async {
    recharge = await rechargeService.viewRechargePlan();
    if (recharge != null) {
      return recharge;
    } else {
      throw Exception('Failed to load');
    }
  }

  final _navKey = GlobalKey<NavigatorState>();

  void gotoPaymentScreen(BuildContext context, String amount) {
    _navKey.currentState!.push(
      MaterialPageRoute(
          builder: (context) => PaymentDetails(
                amount: amount,
              )),
    );
  }

  @override
  Widget build(BuildContext context) {
    
    var screenSize = MediaQuery.of(context).size;
    return Container(
        height: screenSize.height / 3.6,
        width: screenSize.width / 1.12,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(screenSize.width / 36),
        ),
        alignment: Alignment.center,
        child: Column(
          children: [
            RefreshIndicator(
              onRefresh: () {
                return getdata();
              },
              child: FutureBuilder(
                future: getdata(),
                builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                        .hasData
                    ? item.data!.isNotEmpty
                        ? Container(
                            height: screenSize.height / 3.78,
                            margin:  EdgeInsets.only(top: screenSize.height / 75.6),
                            // color: Colors.black,
                            child: MediaQuery.removePadding(
                              context: context,
                              removeTop: true,
                              child: GridView.count(
                                  childAspectRatio: (1 / .6),
                                  crossAxisCount: 3,
                                  padding:  EdgeInsets.all(screenSize.width / 36),
                                  crossAxisSpacing: 4.0,
                                  // scrollDirection: Axis,
                                  // physics: NeverScrollableScrollPhysics(),
                                  mainAxisSpacing: 3.0,
                                  children: List.generate(
                                      recharge.length,
                                      (index) => GestureDetector(
                                            onTap: () async {
                                              SharedPreferences pref =
                                                  await SharedPreferences
                                                      .getInstance();
                                              if (pref.getString('uid') !=
                                                  null) {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        PaymentDetails(
                                                      amount: recharge[index]
                                                          .amount,
                                                    ),
                                                  ),
                                                );
                                              } else {
                                                showModalBottomSheet(
                                                  isDismissible: false,
                                                  context: context,
                                                  isScrollControlled: true,
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              screenSize.width / 36)),
                                                  builder:
                                                      (BuildContext context) {
                                                    return const LoginModel();
                                                  },
                                                );
                                              }
                                            },
                                            child: Container(
                                              height: screenSize.height / 16.8,
                                              width: screenSize.width / 4.61,
                                              margin:  EdgeInsets.only(
                                                bottom: screenSize.width / 36,
                                                right: screenSize.width / 36,
                                              ),
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(screenSize.width / 72),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Color.fromRGBO(
                                                      0,
                                                      0,
                                                      0,
                                                      0.16,
                                                    ),
                                                    offset: Offset(
                                                      3.0,
                                                      3.0,
                                                    ),
                                                    blurRadius: 6.0,
                                                    spreadRadius: 2.0,
                                                  ),
                                                  BoxShadow(
                                                    color: Colors.white,
                                                    offset: Offset(
                                                      0.0,
                                                      0.0,
                                                    ),
                                                    blurRadius: 0.0,
                                                    spreadRadius: 0.0,
                                                  ),
                                                ],
                                                color: themeColor,
                                              ),
                                              child: Center(
                                                child: Text(
                                                  "₹ ${recharge[index].amount}",
                                                  style:  GoogleFonts.merriweather(
                                                      fontSize: screenSize.width / 32.72,
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                            ),
                                          ))),
                            ),
                          )
                        : const Center(
                            child: Text("No Data Found"),
                          )
                    :  SizedBox(
                        height: screenSize.height / 3.78,
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      ),
              ),
            )
          ],
        ));
  }
}
