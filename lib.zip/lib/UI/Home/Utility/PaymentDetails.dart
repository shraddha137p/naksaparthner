import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/Home/Utility/PaymentFailure.dart';
import 'package:naksaa_services/UI/Home/Utility/PaymentSuccess.dart';
import 'package:razorpay_web/razorpay_web.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../API/NetworkProvider.dart';
import '../../REgister/project Assets/constants.dart';

class PaymentDetails extends StatefulWidget {
  String amount;
  PaymentDetails({super.key, required this.amount});

  @override
  State<PaymentDetails> createState() => _PaymentDetailsState(amount);
}

class _PaymentDetailsState extends State<PaymentDetails> {
  bool isloading = false;
  String amount;
  _PaymentDetailsState(this.amount);
  int selectedRadio = 0;
  late Razorpay _razorpay;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

// Changes the selected value on 'onChanged' click on each radio button
  setSelectedRadio(int val) {
    setState(() {
      selectedRadio = val;
    });
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopPaymentDetail();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopPaymentDetail();
      } else {
        return MobilePaymentDetail();
      }
    });
  }

  Widget DesktopPaymentDetail() {
    return isloading != true
        ? Scaffold(
            appBar: AppBar(
              title: const Text("Payment Details"),
              backgroundColor: themeColor,
              elevation: 0,
            ),
            body: SingleChildScrollView(
              child: Container(
                margin: const EdgeInsets.only(
                    left: 150, right: 150, top: 10, bottom: 70),
                child: Column(children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Payment Details",
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Total Amount",
                              style: TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w400),
                            ),
                            Text(
                              "₹ ${widget.amount}",
                              style: const TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "GST (18%)",
                              style: TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w400),
                            ),
                            Text(
                              "₹ ${((int.parse(widget.amount)) * 18) ~/ 100}",
                              style: const TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Total Payable Amount",
                              style: TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w600),
                            ),
                            Text(
                              "₹ ${(int.parse(widget.amount)) + (((int.parse(
                                    widget.amount,
                                  )) * 18) ~/ 100)}",
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.only(
                        left: 10, right: 10, top: 2, bottom: 2),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            height: 45,
                            width: 250,
                            child: TextFormField(
                              cursorColor: Colors.black,
                              decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  contentPadding:
                                      EdgeInsets.only(left: 15, right: 15),
                                  hintText: "Hint here"),
                            ),
                          ),
                          const Text(
                            "Apply",
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: darkBlue),
                          )
                        ]),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Recommended Methods",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(children: [
                                Container(
                                  height: 30,
                                  width: 60,
                                  decoration: const BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage(
                                              "assets/SVG/Paytm Logo.png"))),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Paytm UPI",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: darkBlue),
                                )
                              ]),
                            ),
                            Radio(
                              value: 1,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Payment Methods",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Paytm Logo.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Paytm UPI",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 1,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(children: [
                                Container(
                                  height: 30,
                                  width: 60,
                                  decoration: const BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage(
                                              "assets/SVG/Upi Logo.png"))),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    Text(
                                      "UPI",
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: darkBlue),
                                    ),
                                    Text(
                                      "Google Pay, Paytm, Phone Pay",
                                      style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.normal,
                                          color: darkBlue),
                                    ),
                                  ],
                                )
                              ]),
                            ),
                            Radio(
                              value: 3,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Debit Credit Card.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Debit Card",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 4,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Debit Credit Card.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Credit Card",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 5,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Net Banking.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Net Banking",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 6,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Wallet.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Wallet",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 7,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ]),
              ),
            ),
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerFloat,
            floatingActionButton: selectedRadio != 0
                ? isloaded != true
                    ? GestureDetector(
                        onTap: () async {
                          SharedPreferences pref =
                              await SharedPreferences.getInstance();
                          String? uid = pref.getString("uid");
                          setState(() {
                            isloaded = true;
                          });
                          String amt =
                              "${(int.parse(widget.amount)) + (((int.parse(widget.amount)) * 18) ~/ 100)}";
                          // _makePayment(
                          //     amt.toString(), '1', 'INR', DateTime.now().toString());
                          Map<String, String> data = {
                            'amount': amt,
                            'gst': (((int.parse(widget.amount)) * 18) ~/ 100)
                                .toString(),
                            'userid': uid!,
                            'currency': 'INR',
                            'created_at': DateTime.now().toString()
                          };
                          var response =
                              await networkProvider.post('create/order', data);
                          if (response.statusCode == 200) {
                            Map jsonResponse = jsonDecode(response.body);
                            if (jsonResponse["sts"] == true) {
                              Map resResponse = jsonResponse["order"];

                              _makePayment(amt.toString(),
                                  resResponse["currency"], resResponse["id"]);
                            }
                          }
                        },
                        child: Container(
                          height: 45,
                          width: 300,
                          decoration: BoxDecoration(
                              color: darkBlue,
                              borderRadius: BorderRadius.circular(10)),
                          child: const Center(
                              child: Text(
                            "Pay Now",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          )),
                        ),
                      )
                    : Container(
                        height: 45,
                        width: 300,
                        decoration: BoxDecoration(
                            color: themeColor.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(10)),
                        child: const Center(
                            child: CircularProgressIndicator(
                          color: darkBlue,
                        )),
                      )
                : Container(
                    height: 45,
                    width: 300,
                    decoration: BoxDecoration(
                        color: themeColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Center(
                        child: Text(
                      "Pay Now",
                      style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    )),
                  ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }

  Widget MobilePaymentDetail() {
    return isloading != true
        ? Scaffold(
            appBar: AppBar(
              title: const Text("Payment Details"),
              backgroundColor: themeColor,
              elevation: 0,
            ),
            body: SingleChildScrollView(
              child: Container(
                margin: const EdgeInsets.only(
                    left: 10, right: 10, top: 10, bottom: 70),
                child: Column(children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Payment Details",
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "Total Amount",
                                style: TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.w400),
                              ),
                              Text(
                                "₹ ${widget.amount}",
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "GST (18%)",
                                style: TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.w400),
                              ),
                              Text(
                                "₹ ${((int.parse(widget.amount)) * 18) ~/ 100}",
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "Total Payable Amount",
                                style: TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.w600),
                              ),
                              Text(
                                "₹ ${(int.parse(widget.amount)) + (((int.parse(widget.amount)) * 18) ~/ 100)}",
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                              )
                            ],
                          )
                        ]),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.only(
                        left: 10, right: 10, top: 2, bottom: 2),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            height: 45,
                            width: 250,
                            child: TextFormField(
                              cursorColor: Colors.black,
                              decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  contentPadding:
                                      EdgeInsets.only(left: 15, right: 15),
                                  hintText: "Hint here"),
                            ),
                          ),
                          const Text(
                            "Apply",
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: darkBlue),
                          )
                        ]),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Recommended Methods",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(children: [
                                Container(
                                  height: 30,
                                  width: 60,
                                  decoration: const BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage(
                                              "assets/SVG/Paytm Logo.png"))),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Paytm UPI",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: darkBlue),
                                )
                              ]),
                            ),
                            Radio(
                              value: 1,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.16),
                            offset: Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 6.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Payment Methods",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Paytm Logo.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Paytm UPI",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 1,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(children: [
                                Container(
                                  height: 30,
                                  width: 60,
                                  decoration: const BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage(
                                              "assets/SVG/Upi Logo.png"))),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    Text(
                                      "UPI",
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: darkBlue),
                                    ),
                                    Text(
                                      "Google Pay, Paytm, Phone Pay",
                                      style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.normal,
                                          color: darkBlue),
                                    ),
                                  ],
                                )
                              ]),
                            ),
                            Radio(
                              value: 3,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Debit Credit Card.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Debit Card",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 4,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Debit Credit Card.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Credit Card",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 5,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Net Banking.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Net Banking",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 6,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                height: 30,
                                width: 60,
                                decoration: const BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/Wallet.png"))),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Wallet",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: darkBlue),
                              )
                            ]),
                            Radio(
                              value: 7,
                              groupValue: selectedRadio,
                              activeColor: themeColor,
                              onChanged: (val) {
                                setSelectedRadio(val!);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ]),
              ),
            ),
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerFloat,
            floatingActionButton: selectedRadio != 0
                ? isloaded != true
                    ? GestureDetector(
                        onTap: () async {
                          SharedPreferences pref =
                              await SharedPreferences.getInstance();
                          String? uid = pref.getString("uid");
                          setState(() {
                            isloaded = true;
                          });
                          String amt =
                              "${(int.parse(widget.amount)) + (((int.parse(widget.amount)) * 18) ~/ 100)}";
                          // _makePayment(
                          //     amt.toString(), '1', 'INR', DateTime.now().toString());
                          Map<String, String> data = {
                            'amount': amt,
                            'gst': (((int.parse(widget.amount)) * 18) ~/ 100)
                                .toString(),
                            'userid': uid!,
                            'currency': 'INR',
                            'created_at': DateTime.now().toString()
                          };
                          var response =
                              await networkProvider.post('create/order', data);
                          if (response.statusCode == 200) {
                            Map jsonResponse = jsonDecode(response.body);
                            if (jsonResponse["sts"] == true) {
                              Map resResponse = jsonResponse["order"];

                              _makePayment(amt.toString(),
                                  resResponse["currency"], resResponse["id"]);
                            }
                          }
                        },
                        child: Container(
                          height: 45,
                          width: 300,
                          decoration: BoxDecoration(
                              color: darkBlue,
                              borderRadius: BorderRadius.circular(10)),
                          child: const Center(
                              child: Text(
                            "Pay Now",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          )),
                        ),
                      )
                    : Container(
                        height: 45,
                        width: 300,
                        decoration: BoxDecoration(
                            color: themeColor.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(10)),
                        child: const Center(
                            child: CircularProgressIndicator(
                          color: darkBlue,
                        )),
                      )
                : Container(
                    height: 45,
                    width: 300,
                    decoration: BoxDecoration(
                      color: themeColor.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(
                        10,
                      ),
                    ),
                    child: const Center(
                      child: Text(
                        "Pay Now",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(
              child: LoadingIndicator(),
            ),
          );
  }

  bool isloaded = false;
  var networkProvider = NetworkHandler();
  void _makePayment(String mainamount, String currency, String orderid) {
    setState(() {
      isloaded = false;
    });
    var options = {
      'key': 'rzp_test_33SOqt1CkQpnYu',
      'amount': mainamount,
      'currency': currency,
      'order_id': orderid,
      'image':
          'https://naksa.kesarwanisangh.com/wp-content/uploads/2023/03/WhatsApp_Image_2023-03-25_at_16.12.29-removebg-preview-removebg-preview-1.png',
      'name': 'Naksa Info Hub',
      'description': 'A Place For Success',
      'prefill': {'contact': '1234567890', 'email': 'test@razorpay.com'},
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      print(e);
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response1) async {
    setState(() {
      isloading = true;
    });
    Fluttertoast.showToast(
      msg: "SUCCESS: ${response1.paymentId!}",
    );
    _verifyPayment(
        response1.paymentId!, response1.signature!, response1.orderId!);
    print(response1.paymentId!);
    print(response1.orderId!);
    print(response1.signature);
    // isloaded = true;
    // Map<String, String> newdata = {
    //   "userid": data["userid"].toString(),
    //   "address": data["caddress"].toString(),
    //   "mobile": data["mobile"].toString(),
    //   "name": data["name"].toString(),
    //   "amt": data["totalprice"].toString(),
    //   "lat": data["lat"].toString(),
    //   "lon": data["long"].toString(),
    //   "transno": response1.paymentId!
    // };
    // var response =
    //     await networkHandler.postdata("saveorderonline.php", newdata);
    // Map mapResponse = json.decode(response.body);
    // if (response.statusCode == 200) {
    //   isloaded = false;
    //   List jsonResponse = mapResponse["res"];
    //   Map resp = jsonResponse[0];
    //   if (resp["status1"] == "Done") {
    //     Navigator.push(
    //         context, MaterialPageRoute(builder: (context) => OrderStatus()));
    //   } else if (resp["status1"] == "Not Available") {
    //     Fluttertoast.showToast(
    //         msg: "We're not deliver in this area!",
    //         toastLength: Toast.LENGTH_SHORT,
    //         gravity: ToastGravity.BOTTOM,
    //         timeInSecForIosWeb: 1,
    //         backgroundColor: Colors.red,
    //         textColor: Colors.white,
    //         fontSize: 16.0);
    //   }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
      msg: "Some thing went wrong, Please try again..",
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
      msg: "EXTERNAL_WALLET: ${response.walletName!}",
    );
  }

  void _verifyPayment(
      String paymentid, String signature, String orderid) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");

    Map<String, String> data = {
      "userid": uid!,
      "walletamount": widget.amount,
      "transdate": DateTime.now().toString(),
      'payment_id': paymentid,
      'signature': signature,
      'order_id': orderid,
      'updatedat': DateTime.now().toString()
    };
    var response = await networkProvider.post('payment/verify', data);
    Map jsonResponse = jsonDecode(response.body);
    print(response.body);
    print("aryaman srivastava");
    if (jsonResponse["orderstatus"] == "success") {
      print("Payment Successfull");
      setState(() {
        isloading = false;
      });
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const PaymentSuccess()));
    } else {
      setState(() {
        isloading = false;
      });
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const PaymentFailure()));
    }
  }
}
