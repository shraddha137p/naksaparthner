import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class FAQQ extends StatefulWidget {
  final String Faqqq;
  const FAQQ({super.key, required this.Faqqq});

  @override
  State<FAQQ> createState() => _FAQQState();
}

class _FAQQState extends State<FAQQ> {
  bool isExpanded = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: themeColor,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        title: Text(
          widget.Faqqq,
          style: GoogleFonts.merriweather(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.grey.withOpacity(0.3),
        ),
        child: ListView.builder(
            itemCount: 5,
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.only(
                  left: 13,
                  right: 13,
                  top: 10,
                  // bottom: 10,
                ),
                child: Card(
                  elevation: 12,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: ExpansionTile(
                    iconColor: Colors.white,
                    collapsedBackgroundColor: darkBlue,
                    backgroundColor: bgColor,
                    title: Text(
                      "Who we are",
                      style: GoogleFonts.merriweather(
                        color: isExpanded ? Colors.black : Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 15),
                            child: Text(
                              "We are devlopers",
                              style: GoogleFonts.merriweather(
                                color: Colors.black,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            }),
      ),
    );
  }
}
