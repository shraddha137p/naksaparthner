import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/CallScreen.dart';
import 'package:naksaa_services/UI/Home/MainUtility/disclaimer.dart';
import 'package:naksaa_services/UI/Home/Partner/AllLiveVendor.dart';
import 'package:naksaa_services/UI/Home/our_services.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/aboutus/aboutus.dart';

import 'MainUtility/Terms_and_conditions.dart';
import 'MainUtility/pricing_policy.dart';
import 'MainUtility/privacy_policy.dart';

class BottomFooter extends StatefulWidget {
  const BottomFooter({Key? key}) : super(key: key);

  @override
  State<BottomFooter> createState() => _BottomFooterState();
}

class _BottomFooterState extends State<BottomFooter> {
  final List<String> lst1 = [
    "Web Application Development",
    "E-commerce",
    "Content Management System",
    "B2B Platforms",
    "ERP /CRM",
    "Backend Solutions",
    "Mobile App Development",
  ];

  final List<String> lst2 = [
    "UI Designing",
    "Search Engine Optimization",
    "Responsive Web Designing",
    "Corporate Websites",
    "Interactive Web Designing",
    "Templates, Blogs",
  ];

  final List<String> lst3 = [
    "Logo Designing",
    "Overall Branding",
    "Business Presentations",
    "2D & 3D Modeling",
    "2D Animations",
    "Whiteboard Animation",
    "3D Animations",
  ];

  final List lst4 = [
    {
      "name": "Privacy Policy",
      "onclick": "PrivacyPolicy",
    },
    {
      "name": "Terms & Conditions",
      "onclick": "PrivacyPolicy",
    },
    {
      "name": "Refund & Cancellation Policy",
      "onclick": "PrivacyPolicy",
    },
    {
      "name": "Pricing Policy",
      "onclick": "PrivacyPolicy",
    },
    {
      "name": "Our Disclaimer",
      "onclick": "PrivacyPolicy",
    }
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopHomeScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopHomeScreen();
      } else {
        return MobileHomeScreen();
      }
    });
  }

  @override
  Widget DesktopHomeScreen() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(
          left: screenSize.width / 38.4, right: screenSize.width / 38.4),
      child: Column(children: [
        SizedBox(
          height: screenSize.height / 48.05,
        ),
        Container(
          height: screenSize.height / 3.20,
          width: double.infinity,
          color: Colors.transparent,
          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                FooterColumn(),
                FooterColumn(),
                FooterColumn(),
                FooterColumn()
              ]),
        ),
        SizedBox(
          height: screenSize.height / 48.05,
        ),
        Container(
          height: screenSize.height / 3.20,
          width: double.infinity,
          color: Colors.transparent,
          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                FooterColumn(),
                headerfotter(),
                Footerconnectwithus(),
                Googleplaybutton()
              ]),
        ),
        Container(
          height: screenSize.height / 6.406,
          width: double.infinity,
          color: Colors.transparent,
          child: Row(children: [
            Text(
              "Copyright © 2023 Naksa Info Hub.All right reserved",
              style: GoogleFonts.merriweather(),
            ),
            const Spacer(),
            Image.asset(
              "assets/logo.png",
              height: screenSize.height / 12.81,
              width: screenSize.width / 25.6,
            )
          ]),
        ),
      ]),
    );
  }

  Widget MobileHomeScreen() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(
        left: screenSize.width / 18,
        right: screenSize.width / 18,
        top: screenSize.height / 37.8,
        bottom: screenSize.height / 37.8,
      ),
      child: Column(children: [
        Container(
          // height: 300,
          // width: 300,
          color: Colors.transparent,
          child: FooterColumn(),
        ),
        SizedBox(
          height: screenSize.height/18.9,
        ),
        Container(
          // height: 300,
          // width: 300,
          color: Colors.transparent,
          child: footerheadmobile(),
        ),
        SizedBox(
          height: screenSize.height/37.8,
        ),
        Container(
          // height: 150,
          width: double.infinity,
          color: Colors.transparent,
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Flexible(
              child: Column(
                children: [
                  Text(
                    "Copyright © 2023 Naksa ",
                    textAlign: TextAlign.justify,
                    style: GoogleFonts.merriweather(),
                  ),
                   SizedBox(
                    height: screenSize.height/151.2,
                  ),
                  Text(
                    "All right reserved",
                    textAlign: TextAlign.justify,
                    style: GoogleFonts.merriweather(),
                  ),
                ],
              ),
            ),
            // const Spacer(),
            Image.asset(
              "assets/logo.png",
              height: screenSize.height/16.8,
              width:  screenSize.width/8,
            )
          ]),
        ),
      ]),
    );
  }

  Widget Googleplaybutton() {
    return Column(
      children: [
        Text(
          "Download app from",
          style: GoogleFonts.merriweather(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            Container(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
              child: Image.asset(
                "assets/transparentapp.png",
                height: 40,
                width: 130,
                fit: BoxFit.cover,
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    20,
                  ),
                ),
              ),
              child: Image.asset(
                "assets/googletransparent.png",
                height: 50,
                width: 130,
                fit: BoxFit.cover,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget Footerconnectwithus() {
    return Column(
      children: [
        Text("Connect With us",
            style: GoogleFonts.merriweather(
                fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.facebook,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.twitter,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.instagram,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                FontAwesomeIcons.youtube,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget headerfotter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Link',
          style: GoogleFonts.merriweather(
              fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 20,
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(
              context,
              "/home",
            );
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const bullet(),
                  Text(
                    ' Home',
                    style: GoogleFonts.merriweather(
                        fontSize: 16,
                        fontWeight: _isHovering[0] != true
                            ? FontWeight.w500
                            : FontWeight.bold,
                        color: _isHovering[0] != true
                            ? Colors.black.withOpacity(0.7)
                            : darkBlue),
                  ),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(
              context,
              "/about_us",
            );
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' About Us',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(context, "/our_Services");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Services',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          hoverColor: Colors.transparent,
          onTap: () {
            Navigator.pushNamed(context, "/chat_with_us");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Chat With US',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          hoverColor: Colors.transparent,
          onTap: () {
            Navigator.pushNamed(context, "/call_with_us");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Call With Us',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(context, "/our_live_vendor");
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  const bullet(),
                  Text(' Live Naksian',
                      style: GoogleFonts.merriweather(
                          fontSize: 16,
                          fontWeight: _isHovering[0] != true
                              ? FontWeight.w500
                              : FontWeight.bold,
                          color: _isHovering[0] != true
                              ? Colors.black.withOpacity(0.7)
                              : darkBlue)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  final List _isHovering = [false, false, false, false, false];
  Widget FooterColumn() {
    var screenSize = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Corporate Info",
          style: GoogleFonts.merriweather(
              fontSize: screenSize.width / 96, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: screenSize.height / 48.05,
        ),
        Padding(
          padding: EdgeInsets.only(left: screenSize.width / 96),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const PrivacyPolicy(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[0] = true : _isHovering[0] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Privacy Policy",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TermsAndConditions(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[1] = true : _isHovering[1] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Terms & Conditions",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[1] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[1] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  // Navigator.pushNamed(
                  //     context, "/home/Refund&cancellationPolicy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[2] = true : _isHovering[2] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Refund & Cancellation Policy",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[2] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[2] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const PricingPolicy(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[3] = true : _isHovering[3] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Pricing Policy",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[3] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[3] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const OurDisclaimer(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[4] = true : _isHovering[4] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Our Disclaimer",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[4] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[4] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget footerhead() {
    var screenSize = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Corporate Info",
          style: GoogleFonts.merriweather(
              fontSize: screenSize.width / 96, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: screenSize.height / 48.05,
        ),
        Padding(
          padding: EdgeInsets.only(left: screenSize.width / 96),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/privacy_policy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[0] = true : _isHovering[0] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Home",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/terms_and_conditions");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[1] = true : _isHovering[1] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "About Us",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  // Navigator.pushNamed(
                  //     context, "/home/Refund&cancellationPolicy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[2] = true : _isHovering[2] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Services",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/pricing_policy");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[3] = true : _isHovering[3] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Call with Us",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[3] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[3] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, "/our_disclaimer");
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[4] = true : _isHovering[4] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Live Naksian",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[4] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[4] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget footerheadmobile() {
    var screenSize = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Quick link",
          style: GoogleFonts.merriweather(
              fontSize: screenSize.width / 96, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: screenSize.height / 48.05,
        ),
        Padding(
          padding: EdgeInsets.only(left: screenSize.width / 96),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BottomNavigationBarScreen(
                        pageIndex: 0,
                      ),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[0] = true : _isHovering[0] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Home",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[0] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[0] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const Aboutus(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[1] = true : _isHovering[1] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "About Us",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[1] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[1] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const OurServices(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[2] = true : _isHovering[2] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Services",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[2] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[2] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CallMainScreen()));
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[3] = true : _isHovering[3] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Call with Us",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[3] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[3] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AllLiveVendor(),
                    ),
                  );
                },
                onHover: (val) {
                  setState(() {
                    val ? _isHovering[4] = true : _isHovering[4] = false;
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: screenSize.height / 137.2),
                  child: Row(
                    children: [
                      const bullet(),
                      SizedBox(
                        width: screenSize.width / 192,
                      ),
                      Text(
                        "Live Naksian",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 120,
                            fontWeight: _isHovering[4] != true
                                ? FontWeight.w500
                                : FontWeight.bold,
                            color: _isHovering[4] != true
                                ? Colors.black.withOpacity(0.7)
                                : darkBlue),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  final bool _isHover = false;
}

class bullet extends StatelessWidget {
  const bullet({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      height: screenSize.height / 192.2,
      width: screenSize.width / 384,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(screenSize.width / 192),
      ),
    );
  }
}
