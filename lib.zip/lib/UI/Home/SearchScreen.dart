import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/AllVendorModel.dart';

import '../../MainAsset/URL.dart';
import '../../Service/SearchVendorService.dart';
import 'Partner/VendorProfile.dart';
import 'Service/ServiceMain.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool isSearch = true;
  List<Datum> services = [];
  bool isloading = false;
  String query = '';
  Timer? debouncer;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    debouncer?.cancel();
    super.dispose();
    WidgetsBinding.instance.addPostFrameCallback((_) => init());
  }

  void debounce(
    VoidCallback callback, {
    Duration duration = const Duration(milliseconds: 1000),
  }) {
    if (debouncer != null) {
      debouncer!.cancel();
    }

    debouncer = Timer(duration, callback);
  }

  Future init() async {
    services = await SearchService.searchProducts(query);

    setState(() => services = services);
  }

  Future searchServiceDetails(String query) async => debounce(() async {
        setState(() {
          isloading = true;
        });
        final services = await SearchService.searchProducts(query);

        if (!mounted) return;

        setState(() {
          this.query = query;
          this.services = services;
          isloading = false;
        });
      });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopSearchScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopSearchScreen();
      } else {
        return MobileSearchScreen();
      }
    });
  }

  Widget DesktopSearchScreen() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2.0),
          child: Container(
            color: blueColor,
            height: screenSize.height/961,
          ),
        ),
        elevation: 0,
        foregroundColor: Colors.black,
        backgroundColor: Colors.white,
        title: TextFormField(
            controller: _searchController,
            decoration:  InputDecoration(
              hintText: 'Search Interior desginer, Architecture....',
              hintStyle: TextStyle(
                color: textColor,
                fontSize: screenSize.width/128,
                fontStyle: FontStyle.italic,
              ),
              border: InputBorder.none,
            ),
            style: const TextStyle(
              color: Colors.black,
            ),
            onChanged: (text) {
              if (text.trim().isEmpty) {
                setState(() {
                  isSearch = true;
                });
              } else {
                searchServiceDetails(text);
                setState(() {
                  isSearch = false;
                });
              }
            }),
      ),
      body: SingleChildScrollView(
        child: isSearch != false
            ? Column(children: [
                 SizedBox(
                  height: screenSize.height/64.06,
                ),
                Container(
                    margin:  EdgeInsets.only(left: screenSize.width/76.8, right: screenSize.width/76.8),
                    padding:  EdgeInsets.all(screenSize.width/240),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/91.42),
                        color: Colors.white),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: 5,
                        itemBuilder: ((context, index) {
                          return Container(
                            padding:  EdgeInsets.all(screenSize.width/274.2),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children:  [
                                      Icon(
                                        Icons.access_time_outlined,
                                        color: Color.fromRGBO(159, 152, 152, 1),
                                      ),
                                      SizedBox(
                                        width: screenSize.width/128,
                                      ),
                                      Text("Aditya roy"),
                                    ]),
                                  ),
                                 Icon(
                                    Icons.arrow_forward,
                                    size: screenSize.width/128,
                                  )
                                ]),
                          );
                        }))),
                SizedBox(
                  height: screenSize.height/48.05,
                ),
                Container(
                  height: screenSize.height/13.72,
                  padding:  EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/96),
                  margin:  EdgeInsets.only(left: screenSize.width/76.8, right: screenSize.width/6.8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(screenSize.width/91.4),
                    color: darkBlue,
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:  [
                            Text(
                              "Explore & Search For",
                              style:
                                  TextStyle(fontSize: screenSize.width/137.1, color: Colors.white),
                            ),
                            Text(
                              "More on Naksa Services",
                              style:
                                  TextStyle(fontSize: screenSize.width/147.6, color: Colors.white),
                            )
                          ],
                        ),
                        Container(
                          height: screenSize.height/38.44,
                          width: screenSize.height/38.44,
                          decoration: const BoxDecoration(
                              color: themeColor, shape: BoxShape.circle),
                          child: const Center(
                            child: Icon(
                              Icons.arrow_right_rounded,
                            ),
                          ),
                        )
                      ]),
                ),
                 SizedBox(
                  height: screenSize.height/48.05,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        margin:  EdgeInsets.only(left: screenSize.width/96),
                        child:  Text(
                          "Quick Links",
                          style: TextStyle(
                              fontSize: screenSize.width/128, fontWeight: FontWeight.w500),
                        )),
                    const ServiceMainScreen(),
                  ],
                ),
              ])
            : Container(
                margin:  EdgeInsets.only(top: screenSize.height/64.06),
                child: isloading != true
                    ? services.isNotEmpty
                        ? SizedBox(
                            width: screenSize.width/4.26,
                            child: ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: services.length,
                              itemBuilder: (context, index) {
                                final service = services[index];

                                return buildService(
                                  service,
                                );
                              },
                            ),
                          )
                        : Container(
                            height: screenSize.height/13.7,
                            padding:  EdgeInsets.only(left: screenSize.width/96, right: screenSize.width/96),
                            margin:  EdgeInsets.only(left: screenSize.width/76.8, right: screenSize.width/76.8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(21),
                              color: darkBlue,
                            ),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children:  [
                                      Text(
                                        "No Results Founds!....",
                                        style: TextStyle(
                                            fontSize: screenSize.width/137.1, color: Colors.white),
                                      ),
                                      Text(
                                        "Please try again....",
                                        style: TextStyle(
                                            fontSize: screenSize.width/14.6, color: Colors.white),
                                      )
                                    ],
                                  ),
                                  Container(
                                    height: screenSize.height/38.44,
                                    width: screenSize.width/76.8,
                                    decoration: const BoxDecoration(
                                        color: themeColor,
                                        shape: BoxShape.circle),
                                    child: const Center(
                                      child: Icon(
                                        Icons.arrow_right_rounded,
                                      ),
                                    ),
                                  )
                                ]),
                          )
                    : const Center(
                        child: LoadingIndicator(),
                      ),
              ),
      ),
    );
  }

  Widget MobileSearchScreen() {
    
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        bottom: PreferredSize(
            preferredSize: const Size.fromHeight(2.0),
            child: Container(
              color: blueColor,
              height: screenSize.height/756,
            )),
        elevation: 0,
        foregroundColor: Colors.black,
        backgroundColor: Colors.white,
        title: TextFormField(
            controller: _searchController,
            decoration:  InputDecoration(
                hintText: 'Search Interior desginer, Architecture....',
                hintStyle: TextStyle(
                  color: textColor,
                  fontSize: screenSize.width/24,
                  fontStyle: FontStyle.italic,
                ),
                border: InputBorder.none),
            style: const TextStyle(
              color: Colors.black,
            ),
            onChanged: (text) {
              if (text.trim().isEmpty) {
                setState(() {
                  isSearch = true;
                });
              } else {
                searchServiceDetails(text);
                setState(() {
                  isSearch = false;
                });
              }
            }),
      ),
      body: SingleChildScrollView(
        child: isSearch != false
            ? Column(children: [
               SizedBox(
                  height: screenSize.height/50.4,
                ),
                Container(
                    margin:  EdgeInsets.only(left: screenSize.width/14.4, right: screenSize.width/14.4),
                    padding:  EdgeInsets.all(screenSize.width/45),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(screenSize.width/17.14),
                        color: Colors.white),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: 5,
                        itemBuilder: ((context, index) {
                          return Container(
                            padding:  EdgeInsets.all(screenSize.width/51.42),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children:  [
                                      Icon(
                                        Icons.access_time_outlined,
                                        color: Color.fromRGBO(159, 152, 152, 1),
                                      ),
                                      SizedBox(
                                        width: screenSize.width/24,
                                      ),
                                      Text("Aditya roy"),
                                    ]),
                                  ),
                                 Icon(
                                    Icons.arrow_forward,
                                    size: screenSize.width/24,
                                  )
                                ]),
                          );
                        }))),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                Container(
                  height: screenSize.height/10.8,
                  padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/18),
                  margin:  EdgeInsets.only(left: screenSize.width/14.4, right: screenSize.width/14.4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(screenSize.width/17.14),
                    color: darkBlue,
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:  [
                            Text(
                              "Explore & Search For",
                              style:
                                  TextStyle(fontSize: screenSize.width/25.71, color: Colors.white),
                            ),
                            Text(
                              "More on Naksa Services",
                              style:
                                  TextStyle(fontSize: screenSize.width/27.69, color: Colors.white),
                            )
                          ],
                        ),
                        Container(
                          height: screenSize.height/30.24,
                          width: screenSize.width/14.4,
                          decoration: const BoxDecoration(
                              color: themeColor, shape: BoxShape.circle),
                          child: const Center(
                            child: Icon(
                              Icons.arrow_right_rounded,
                            ),
                          ),
                        )
                      ]),
                ),
                 SizedBox(
                  height: screenSize.height/37.8,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        margin:  EdgeInsets.only(left: screenSize.width/18),
                        child:  Text(
                          "Quick Links",
                          style: TextStyle(
                              fontSize: screenSize.width/24, fontWeight: FontWeight.w500),
                        )),
                    const ServiceMainScreen(),
                  ],
                ),
              ])
            : Container(
                margin:  EdgeInsets.only(top: screenSize.height/50.4),
                child: isloading != true
                    ? services.isNotEmpty
                        ? SizedBox(
                            width: screenSize.width/9,
                            child: ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: services.length,
                              itemBuilder: (context, index) {
                                final service = services[index];

                                return buildService(service);
                              },
                            ),
                          )
                        : Container(
                            height: screenSize.height/10.8,
                            padding:  EdgeInsets.only(left: screenSize.width/18, right: screenSize.width/18),
                            margin:  EdgeInsets.only(left: screenSize.width/14.4, right: screenSize.width/14.4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(screenSize.width/17.14),
                              color: darkBlue,
                            ),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children:  [
                                      Text(
                                        "No Results Founds!....",
                                        style: TextStyle(
                                            fontSize: screenSize.width/25.71, color: Colors.white),
                                      ),
                                      Text(
                                        "Please try again....",
                                        style: TextStyle(
                                            fontSize: screenSize.width/27.6, color: Colors.white),
                                      )
                                    ],
                                  ),
                                  Container(
                                    height: screenSize.height/30.24,
                                    width: screenSize.width/14.4,
                                    decoration: const BoxDecoration(
                                        color: themeColor,
                                        shape: BoxShape.circle),
                                    child: const Center(
                                      child: Icon(
                                        Icons.arrow_right_rounded,
                                      ),
                                    ),
                                  )
                                ]),
                          )
                    : const Center(
                        child: LoadingIndicator(),
                      ),
              ),
      ),
    );
  }

  Widget buildService(Datum service) => GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => VendorProfileScreen(
                vid: service.id.toString(),
              ),
            ),
          );
        },
        child: Container(
          padding: const EdgeInsets.all(10),
          height: 134,
          // width: 200,
          margin: const EdgeInsets.only(
            bottom: 15,
            left: 14,
            right: 14,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: const [
              BoxShadow(
                color: Color.fromRGBO(0, 0, 0, 0.16),
                offset: Offset(
                  3.0,
                  3.0,
                ),
                blurRadius: 6.0,
                spreadRadius: 2.0,
              ), //BoxShadow
              BoxShadow(
                color: Colors.white,
                offset: Offset(
                  0.0,
                  0.0,
                ),
                blurRadius: 0.0,
                spreadRadius: 0.0,
              ), //BoxShadow
            ],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
            SizedBox(
              width: 65,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(width: 1, color: themeColor),
                        image: DecorationImage(
                            image: NetworkImage(
                                '${MainUrl}vendor-image/${service.photo}'),
                            fit: BoxFit.cover)),
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  Container(
                    child: RatingBarIndicator(
                      rating: 4.5,
                      itemBuilder: (context, index) => const Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                      itemCount: 5,
                      itemSize: 13.0,
                      direction: Axis.horizontal,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    child: const Center(
                      child: Text(
                        "734 Votes",
                        style:
                            TextStyle(fontSize: 9, fontWeight: FontWeight.w600),
                      ),
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(
              width: 24,
            ),
            Container(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      service.name,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: 150,
                      child: Text(
                        service.primaryskills,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black.withOpacity(0.53)),
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    SizedBox(
                      width: 150,
                      child: Text(
                        service.language,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black.withOpacity(0.53)),
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      "${(service.enddate.difference(service.startdate).inDays)} Days",
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.normal,
                          color: Colors.black.withOpacity(0.53)),
                    ),
                    const SizedBox(
                      height: 6,
                    ),
                    Text(
                      "₹ ${service.audicallprice}/min",
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black.withOpacity(1)),
                    )
                  ]),
            ),
            Container(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/SVG/star2-2x.png"))),
                      child: const Center(
                          child: Padding(
                        padding: EdgeInsets.only(bottom: 5),
                        child: Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 16,
                        ),
                      )),
                    ),
                  ]),
            )
          ]),
        ),
      );
}
