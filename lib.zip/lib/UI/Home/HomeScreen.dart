import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';
import 'package:naksaa_services/UI/Home/MainUtility/blog_page.dart';
import 'package:naksaa_services/UI/Home/Partner/AllLiveVendor.dart';
import 'package:naksaa_services/UI/Home/Partner/ClientTestimonials.dart';
import 'package:naksaa_services/UI/Home/Partner/ConnectWithPeople.dart';
import 'package:naksaa_services/UI/Home/Partner/LivePeople.dart';
import 'package:naksaa_services/UI/Home/Partner/NaksaBlog.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/MainSlider.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/desktopNavbar.dart';

import '../REgister/project Assets/AppBar.dart';
import '../REgister/project Assets/MainServiceOptions.dart';
import '../REgister/project Assets/Navigationdrawer.dart';
import 'BottomNavigation.dart';
import 'MainUtility/news_section.dart';
import 'Service/ServiceMain.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopHomeScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopHomeScreen();
      } else {
        return MobileHomeScreen();
      }
    });
  }

  Widget DesktopHomeScreen() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      // drawer:
      //     const Drawer(backgroundColor: darkBlue, child: NavigationDrawer()),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const MainSlider(),
            SizedBox(
              height: screenSize.height / 48.05,
            ),
            const MainServiceOptions(),
            SizedBox(
              height: screenSize.height / 48.05,
            ),
            Container(
              color: backgroundColor,
              margin: EdgeInsets.only(top: screenSize.height / 96.1),
              child: const ServiceMainScreen(),
            ),
            SizedBox(
              height: screenSize.height / 38.4,
            ),
            Container(
              margin: EdgeInsets.only(
                  left: screenSize.width / 32, right: screenSize.width / 32),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Live Naksian",
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 137.1,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const AllLiveVendor()));
                        },
                        child: Text(
                          "View All >",
                          style: GoogleFonts.merriweather(
                              fontWeight: FontWeight.bold,
                              fontSize: screenSize.width / 137.1),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: screenSize.height / 38.44,
                  ),
                  const LivePeople(),
                ],
              ),
            ),
            SizedBox(
              height: screenSize.height / 38.44,
            ),
            Container(
              margin: EdgeInsets.only(
                  left: screenSize.width / 32, right: screenSize.width / 32),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Connect with Naksian",
                          style: GoogleFonts.merriweather(
                              fontSize: screenSize.width / 137.1,
                              fontWeight: FontWeight.bold)),
                      Text(
                        "View All >",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 137.1,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  SizedBox(
                    height: screenSize.height / 38.44,
                  ),
                  const ConnectWithPeople(),
                ],
              ),
            ),
            SizedBox(
              height: screenSize.height / 24.02,
            ),
            Container(
              margin: EdgeInsets.only(
                left: screenSize.width / 32,
                right: screenSize.width / 32,
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Client Testimonials",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 137.1,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "View All >",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 137.1,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  SizedBox(
                    height: screenSize.height / 24.02,
                  ),
                  const ClientTestimonials(),
                ],
              ),
            ),
            SizedBox(
              height: screenSize.height / 38.44,
            ),
            Container(
              padding: EdgeInsets.only(
                left: screenSize.width / 32,
                right: screenSize.width / 32,
              ),
              color: themeColor,
              child: Column(
                children: const [
                  NewsSection(),
                ],
              ),
            ),
            SizedBox(
              height: screenSize.height / 38.44,
            ),
            Container(
              // margin: EdgeInsets.only(left: 10, right: 10),
              color: Colors.white,
              padding: EdgeInsets.all(screenSize.height / 128),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Latest News",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 112.9,
                            fontWeight: FontWeight.bold),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const BlogPage()));
                        },
                        child: Text(
                          "View All >",
                          style: GoogleFonts.merriweather(
                              fontSize: screenSize.width / 112.9,
                              fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: screenSize.height / 120.1,
                  ),
                  const NaksaBlog(),
                ],
              ),
            ),
            const BottomFooter()
          ],
        ),
      ),
    );
  }

  Widget MobileHomeScreen() {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        toolbarHeight: 160,
        automaticallyImplyLeading: false,
        foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
        flexibleSpace: const AppBarScreen(),
      ),
     
      drawer: const Drawer(
        backgroundColor: darkBlue,
        child: NavigationDrawers(),
      ),
      body: ListView(
        // physics: NeverScrollableScrollPhysics(),
               shrinkWrap: false,
        children: [
        Column(children: [
          Container(
            color: Colors.white,
            padding: EdgeInsets.only(
              top: screenSize.height / 75.6,
            ),
            child: const ServiceMainScreen(),
          ),
          SizedBox(
            height: screenSize.height / 37.8,
          ),
          const MainSlider(),
          SizedBox(
            height: screenSize.height / 37.8,
          ),
          CallWithUs(),
          SizedBox(
            width: screenSize.width / 30,
          ),
          Container(
            margin: EdgeInsets.only(
                left: screenSize.width / 30,
                right: screenSize.width / 30,
                top: screenSize.width / 24),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Live Naksian",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width / 25.71,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const AllLiveVendor(),
                          ),
                        );
                      },
                      child: Text(
                        "View All >",
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 25.71,
                            fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: screenSize.height / 75.6,
                ),
                const LivePeople(),
              ],
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          Container(
            margin: EdgeInsets.only(
              left: screenSize.width / 30,
              right: screenSize.width / 30,
              top: screenSize.height / 75.6,
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Connect with Naksian",
                      style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 25.71,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "View All >",
                      style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 25.71,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                SizedBox(
                  height: screenSize.height / 75.6,
                ),
                const ConnectWithPeople(),
              ],
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          Container(
            margin: EdgeInsets.only(
                left: screenSize.width / 30,
                right: screenSize.width / 30,
                bottom: screenSize.height / 37.8),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Naksa In News",
                      style: GoogleFonts.merriweather(
                          fontWeight: FontWeight.bold,
                          fontSize: screenSize.width / 25.71),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenSize.height / 94.5,
                ),
                const NewsSection(),
              ],
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          Container(
            margin: EdgeInsets.only(
                left: screenSize.width / 30,
                right: screenSize.width / 30,
                bottom: screenSize.height / 37.8),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Client Testimonials",
                      style: GoogleFonts.merriweather(
                          fontWeight: FontWeight.bold,
                          fontSize: screenSize.width / 25.71),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenSize.height / 94.5,
                ),
                const ClientTestimonials(),
              ],
            ),
          ),
          SizedBox(
            height: screenSize.height / 75.6,
          ),
          Container(
            // margin: EdgeInsets.only(left: 10, right: 10),
            color: Colors.white,
            padding: EdgeInsets.all(screenSize.width / 24),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Latest News",
                      style: GoogleFonts.merriweather(
                        fontSize: screenSize.width / 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const BlogPage()));
                      },
                      child: Text(
                        "View All >",
                        style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: screenSize.height / 94.5,
                ),
                const NaksaBlog(),
              ],
            ),
          ),
          SizedBox(
            height: screenSize.height / 37.8,
          ),
        ]),
        kIsWeb ? BottomFooter() : Container()
      ]),
    );
  }

  Widget CallWithUs() {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => BottomNavigationBarScreen(
                            pageIndex: 1,
                          )));
            },
            child: Container(
              height: screenSize.height / 8.4,
              width: screenSize.width / 4.23,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width / 72),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(
                      0.0,
                      0.0,
                    ),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                        backgroundColor: Colors.red,
                        radius: screenSize.width / 14.4,
                        child: Icon(
                          Icons.chat,
                          color: Colors.white,
                        )),
                    SizedBox(
                      height: screenSize.height / 151.2,
                    ),
                    SizedBox(
                      width: screenSize.width / 5.14,
                      child: Text(
                        "Chat With us",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                        maxLines: 2,
                      ),
                    )
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BottomNavigationBarScreen(
                    pageIndex: 3,
                  ),
                ),
              );
            },
            child: Container(
              height: screenSize.height / 8.4,
              width: screenSize.width / 4.23,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width / 72),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(
                      0.0,
                      0.0,
                    ),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.red,
                    radius: screenSize.width / 14.4,
                    child: Icon(
                      Icons.call_sharp,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 151.2,
                  ),
                  SizedBox(
                    width: screenSize.width / 5.14,
                    child: Text(
                      "Call With Us ",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 36,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                      maxLines: 2,
                    ),
                  )
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BottomNavigationBarScreen(
                    pageIndex: 2,
                  ),
                ),
              );
            },
            child: Container(
              height: screenSize.height / 8.4,
              width: screenSize.width / 4.23,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width / 72),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(
                      0.0,
                      0.0,
                    ),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                        backgroundColor: Colors.red,
                        radius: screenSize.width / 14.4,
                        child: Icon(
                          Icons.video_call,
                          color: Colors.white,
                        )),
                    SizedBox(
                      height: screenSize.height / 151.2,
                    ),
                    SizedBox(
                      width: screenSize.width / 5.14,
                      child: Text(
                        "Live Vendor",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.merriweather(
                            fontSize: screenSize.width / 36,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                        maxLines: 2,
                      ),
                    )
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const BlogPage(),
                ),
              );
            },
            child: Container(
              height: screenSize.height / 8.4,
              width: screenSize.width / 4.23,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(screenSize.width / 72),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(
                      0.0,
                      0.0,
                    ),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.red,
                    radius: screenSize.width / 14.4,
                    child: Icon(
                      Icons.cast_for_education,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: screenSize.height / 151.2,
                  ),
                  SizedBox(
                    width: screenSize.width / 5.14,
                    child: Text(
                      "Naksa Blog",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.merriweather(
                          fontSize: screenSize.width / 36,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                      maxLines: 2,
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
