import 'dart:convert';
import 'package:http/http.dart' as http;
import '../MainAsset/URL.dart';
import '../model/RechargeNowModel.dart';

class PaymentandWalletService {
  Future<List<Datum>> viewRechargePlan() async {
    var client = http.Client();
    var uri = Uri.parse('${BaseUrl}recharge');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return RechargeNowModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}
