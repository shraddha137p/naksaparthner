import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:naksaa_services/model/customerFollowingModel.dart';
import '../MainAsset/URL.dart';

class CustomerFollowingService {
  Future<List<CustomerFollowingData>?> viewVendorFollower(String cid) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'customer-following-vendor/${cid}/true');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return CustomerFollowing.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}
