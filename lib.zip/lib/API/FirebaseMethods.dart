import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:uuid/uuid.dart';

Future<User?> createAcountFirebase(
    String name, String email, String password) async {
  FirebaseAuth auth = FirebaseAuth.instance;
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  try {
    User? user = (await auth.createUserWithEmailAndPassword(
            email: email, password: password))
        .user;
    if (user != null) {
      print("Accounted Created Succesfully");
      user.updateProfile(displayName: name);
      await firebaseFirestore
          .collection("users")
          .doc(auth.currentUser!.uid)
          .set({
        "name": name,
        "email": email,
        "status": "unavailable",
        "role": "customer",
        "uid": auth.currentUser!.uid
      });

      return user;
    } else {
      print("Account Creattion Failed");
      return user!;
    }
  } catch (e) {
    print(e);
    return null;
  }
}

Future<User?> loginFirebase(String email, String password) async {
  FirebaseAuth auth = FirebaseAuth.instance;
  try {
    User? user = (await auth.signInWithEmailAndPassword(
            email: email, password: password))
        .user;
    if (user != null) {
      print("Login successsfull");
      return user;
    } else {
      print("Login Failed");
      return user;
    }
  } catch (e) {
    print(e);
    return null;
  }
}

Future Logout() async {
  FirebaseAuth auth = FirebaseAuth.instance;
  try {
    await auth.signOut();
    print("logout");
  } catch (e) {
    print(e);
  }
}

Future<void> updateViewCount(
    String id, bool isIncrease, String channelId) async {
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  print("inside update function");
  print(channelId);
  try {
    await firebaseFirestore
        .collection('livestream')
        .doc(channelId)
        .update({'viewer': FieldValue.increment(isIncrease ? 1 : -1)});
  } catch (e) {
    print(e.toString());
  }
}

Future<void> chatFirebase(String text, String id, BuildContext context,
    String ChannelId, String username, String uid) async {
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  try {
    String commentId = const Uuid().v1();
    firebaseFirestore.collection('livechat').doc(ChannelId)
      ..collection('live').add({
        'username': username,
        'message': text,
        'uid': uid,
        'createdAt': DateTime.now(),
        'commentId': ChannelId
      });
  } on FirebaseException catch (e) {
    print(e.toString());
  }
}
