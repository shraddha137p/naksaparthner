import 'dart:convert';

import 'package:http/http.dart' as http;

class AllService {
  Future getAllPost() async {
    var response = await http
        .get(Uri.parse("https://naksa.kesarwanisangh.com/wp-json/wp/v2/posts"));
    if ((response.statusCode == 200) || (response.statusCode == 201)) {
      // log.i(response.body);
      return json.decode(response.body);
    }
    print(response.body);
  }

  Future getPostByID(String id) async {
    var response = await http.get(
        Uri.parse("https://naksa.kesarwanisangh.com/wp-json/wp/v2/posts/$id"));
    if ((response.statusCode == 200) || (response.statusCode == 201)) {
      // log.i(response.body);
      return json.decode(response.body);
    }
    print(response.body);
  }

  Future getCategories() async {
    var response = await http.get(
        Uri.parse("https://naksa.kesarwanisangh.com/wp-json/wp/v2/categories"));
    if ((response.statusCode == 200) || (response.statusCode == 201)) {
      // log.i(response.body);
      return json.decode(response.body);
    }
    print(response.body);
  }
  //  Future<List<PostModel?>> getPost() async {
  //   // SharedPreferences prefs = await SharedPreferences.getInstance();
  //   // String? vid = prefs.getString("vid");
  //   var client = http.Client();
  // var uri = Uri.parse("https://naksa.kesarwanisangh.com/wp-json/wp/v2/posts");
  //   var response = await client.get(uri);
  //   if (response.statusCode == 200) {
  //     final  parsed = json.decode(response.body).cast<Map<String, dynamic>>();
  //   var result = parsed.map<PostModel>((json)=>PostModel.fromJson(json)).toList();
  //     // print(json);
  //     print(result);
  //     return result;
  //   } else {
  //     throw Exception('failed to load data');
  //   }
  // }
}
