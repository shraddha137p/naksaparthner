import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:logger/logger.dart';
import 'dart:convert';

import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class NetworkHandler {
  var log = Logger();

  Future get(String url) async {
    url = formater(url);
    var uri = Uri.parse(url);
    var response = await http.get(uri);
    if ((response.statusCode == 200) || (response.statusCode == 201)) {
      log.i(response.body);
      return json.decode(response.body);
    }
    log.i(response.body);
    log.i(response.statusCode);
  }

  Future<http.Response> post(String url, Map<String, dynamic> body) async {
    url = formater(url);
    log.d(body);
    var response = await http.post(
      Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body: json.encode(body),
    );
    print(response.body);
    return response;
  }

  String formater(String url) {
    return BaseUrl + url;
  }
}
