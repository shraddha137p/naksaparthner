import 'package:flutter/material.dart';

// Replaces <#Your app key#>, <#Your created user#>, and <#User Token#> and with your own App Key, user ID, and user token generated in Agora Console.
class AgoraChatConfig {
  static const String appKey = "b61c6409413c4d2fbb7f4288e47aa8d6";
  static const String userId = "123456";
  static const String agoraToken =
      "007eJxTYLgesoOlU2zew2UWTCt1/nasOCUxa5ris8e8h3hsTKLjgyYpMCSZGSabmRhYmhgaJ5ukGKUlJZmnmRhZWKSamCcmWqSYMdSWJzcEMjIUXHNhYmRgZWBkYGIA8RkYAE1mHGI=";
}
