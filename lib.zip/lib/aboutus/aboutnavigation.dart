import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Aboutnavigation extends StatefulWidget {
  final String MainContent;
  final String SubContent;
  const Aboutnavigation(
      {super.key, required this.MainContent, required this.SubContent});

  @override
  State<Aboutnavigation> createState() => _ServiceMainScreenState();
}

class _ServiceMainScreenState extends State<Aboutnavigation> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    return Container(
        color: Colors.amber,
        height: 100,
        width: MediaQuery.of(context).size.width,
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                widget.MainContent,
                style: GoogleFonts.merriweather(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15),
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                ">",
                style: GoogleFonts.merriweather(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15),
              ),
              const SizedBox(
                width: 10,
              ),
              InkWell(
                onTap: () {
                  Navigator.pushReplacementNamed(context, "/Pricing_Policy");
                },
                child: Text(
                  widget.SubContent,
                  style: GoogleFonts.merriweather(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15),
                ),
              ),
            ],
          ),
        ));
  }

  Widget DesktopServiceMain() {
    return Container(
        color: Colors.amber,
        margin: const EdgeInsets.only(left: 10, right: 10, top: 6),
        height: 100,
        width: MediaQuery.of(context).size.width,
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                widget.MainContent,
                style: GoogleFonts.merriweather(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15),
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                ">",
                style: GoogleFonts.merriweather(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15),
              ),
              const SizedBox(
                width: 10,
              ),
              InkWell(
                onTap: () {
                  Navigator.pushReplacementNamed(context, "/Pricing_Policy");
                },
                child: Text(
                  widget.SubContent,
                  style: GoogleFonts.merriweather(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15),
                ),
              ),
            ],
          ),
        ));
  }
}
