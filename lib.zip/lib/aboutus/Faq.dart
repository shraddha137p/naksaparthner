import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class Faq extends StatefulWidget {
  const Faq({super.key});

  @override
  State<Faq> createState() => _ServiceMainScreenState();
}

class _ServiceMainScreenState extends State<Faq> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  final List faq = ["Who we are "];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    return Center(
      child: Container(
          margin: const EdgeInsets.only(left: 10, right: 10, top: 6),
          height: 280,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.2,
                width: MediaQuery.of(context).size.width * 0.4,
                child: Text(
                  "Our Specialization",
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.merriweather(
                    fontSize: 20,
                  ),
                ),
              ),
              const SizedBox(
                width: 150,
              ),
              SizedBox(
                  height: MediaQuery.of(context).size.height * 0.2,
                  width: MediaQuery.of(context).size.width * 0.25,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      "assets/about_us.jpg",
                      height: MediaQuery.of(context).size.height * 0.2,
                      width: MediaQuery.of(context).size.width * 0.25,
                      fit: BoxFit.fill,
                    ),
                  )),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.2,
                width: MediaQuery.of(context).size.width * 0.4,
                child: Text(
                  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.merriweather(),
                ),
              ),
            ],
          )),
    );
  }

  Widget DesktopServiceMain() {
    return Container(
        margin: const EdgeInsets.only(left: 70, right: 70, top: 6),
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.5,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Frequently Asked Questions",
                    style: GoogleFonts.merriweather(
                      color: Colors.black,
                      decorationThickness: 1.5,
                      fontSize: 27,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ExpansionTile(
                    iconColor: Colors.white,
                    collapsedBackgroundColor: darkBlue,
                    backgroundColor: bgColor,
                    title: Padding(
                      padding: const EdgeInsets.only(left: 15),
                      child: Text(
                        "Who we are",
                        style: GoogleFonts.merriweather(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Text(
                            "We are devlopers",
                            style: GoogleFonts.merriweather(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ExpansionTile(
                    iconColor: Colors.white,
                    collapsedBackgroundColor: darkBlue,
                    backgroundColor: bgColor,
                    title: Padding(
                      padding: const EdgeInsets.only(left: 15),
                      child: Text(
                        "Who we are",
                        style: GoogleFonts.merriweather(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Text(
                            "We are devlopers",
                            style: GoogleFonts.merriweather(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ExpansionTile(
                    iconColor: Colors.white,
                    collapsedBackgroundColor: darkBlue,
                    backgroundColor: bgColor,
                    title: Padding(
                      padding: const EdgeInsets.only(left: 15),
                      child: Text(
                        "Who we are",
                        style: GoogleFonts.merriweather(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Text(
                            "We are devlopers",
                            style: GoogleFonts.merriweather(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ExpansionTile(
                    iconColor: Colors.white,
                    collapsedBackgroundColor: darkBlue,
                    backgroundColor: bgColor,
                    title: Padding(
                      padding: const EdgeInsets.only(left: 15),
                      child: Text(
                        "Who we are",
                        style: GoogleFonts.merriweather(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Text(
                            "We are devlopers",
                            style: GoogleFonts.merriweather(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ExpansionTile(
                    iconColor: Colors.white,
                    collapsedBackgroundColor: darkBlue,
                    backgroundColor: bgColor,
                    title: Padding(
                      padding: const EdgeInsets.only(left: 15),
                      child: Text(
                        "Who we are",
                        style: GoogleFonts.merriweather(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Text(
                            "We are devlopers",
                            style: GoogleFonts.merriweather(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            )
          ],
        ));
  }
}
