import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/BottomFooter.dart';
import 'package:naksaa_services/UI/Home/Partner/AllLiveVendor.dart';
import 'package:naksaa_services/UI/Home/Partner/ClientTestimonials.dart';
import 'package:naksaa_services/UI/Home/Partner/ConnectWithPeople.dart';
import 'package:naksaa_services/UI/Home/Partner/LivePeople.dart';
import 'package:naksaa_services/UI/Home/Partner/NaksaBlog.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/MainSlider.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/desktopNavbar.dart';
import 'package:naksaa_services/aboutus/Faq.dart';
import 'package:naksaa_services/aboutus/our_specialization.dart';

import '../UI/Home/Service/ServiceMain.dart';
import '../UI/REgister/project Assets/AppBar.dart';
import 'aboutnavigation.dart';
import 'headeraboutus.dart';
import 'our_core_team.dart';

// import '../REgister/project Assets/AppBar.dart';
// import '../REgister/project Assets/Navigationdrawer.dart';
// import 'Service/ServiceMain.dart';

class Aboutus extends StatefulWidget {
  const Aboutus({super.key});

  @override
  State<Aboutus> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<Aboutus> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopHomeScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopHomeScreen();
      } else {
        return MobileHomeScreen();
      }
    });
  }

  Widget DesktopHomeScreen() {
    var screenSize;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: const PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      // drawer:
      //     const Drawer(backgroundColor: darkBlue, child: NavigationDrawer()),
      body: ListView(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                color: Colors.white,
                child: const Aboutnavigation(
                  MainContent: "Home",
                  SubContent: "About Us",
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              // Padding(
              //   padding: const EdgeInsets.only(left: 100),
              //   child: Text(
              //     "Bussiness related quires ",
              //     style: GoogleFonts.merriweather(
              //       fontWeight: FontWeight.bold,
              //       fontSize: 26,
              //       color: Colors.black,
              //     ),
              //   ),
              // ),
              Container(
                color: bgColor,
                child: const HeaderAboutus(),
              ),
              Container(
                color: bgColor,
                child: const OurSpecialization(),
              ),
              Container(
                color: bgColor,
                child: const OurCoreTeam(),
              ),
              const SizedBox(
                height: 60,
              ),
              Container(
                color: bgColor,
                child: const Faq(),
              ),
              const SizedBox(
                height: 60,
              ),
              const BottomFooter()
            ],
          ),
        ],
      ),
    );
  }

  Widget MobileHomeScreen() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 140,
          automaticallyImplyLeading: false,
          foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: const AppBarScreen()),
      // drawer:
      //     const Drawer(backgroundColor: darkBlue, child: NavigationDrawer()),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
              color: Colors.white,
              margin: const EdgeInsets.only(top: 10),
              child: const ServiceMainScreen()),
          const MainSlider(),
          Container(
            margin: const EdgeInsets.only(left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Live Naksian",
                      style: TextStyle(fontSize: 12),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const AllLiveVendor()));
                      },
                      child: const Text(
                        "View All >",
                        style: TextStyle(fontSize: 12),
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 8,
                ),
                const LivePeople(),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            margin: const EdgeInsets.only(left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Connect with Naksian",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                const SizedBox(
                  height: 8,
                ),
                const ConnectWithPeople(),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            margin: const EdgeInsets.only(left: 10, right: 10, bottom: 20),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Client Testimonials",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                const SizedBox(
                  height: 8,
                ),
                const ClientTestimonials(),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            // margin: EdgeInsets.only(left: 10, right: 10),
            color: Colors.white,
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Latest News",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                const SizedBox(
                  height: 8,
                ),
                const NaksaBlog(),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
