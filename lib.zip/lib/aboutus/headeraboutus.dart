import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HeaderAboutus extends StatefulWidget {
  const HeaderAboutus({super.key});

  @override
  State<HeaderAboutus> createState() => _ServiceMainScreenState();
}

class _ServiceMainScreenState extends State<HeaderAboutus> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  final List design = [
    "Interiror Designer",
    "Architecture",
    "Vastu Consultant",
    "Strucutre Engineer",
    "Civil Engineer",
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    return Center(
      child: Container(
          margin: const EdgeInsets.only(left: 70, right: 70, top: 6),
          // height: 280,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                      width: MediaQuery.of(context).size.width / 2.4,
                      child: Text(
                        "Grow Your Business With Us",
                        textAlign: TextAlign.start,
                        maxLines: 2,
                        style: GoogleFonts.merriweather(
                            fontSize: 60, fontWeight: FontWeight.bold),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 10),
                    width: MediaQuery.of(context).size.width * 0.4,
                    child: Text(
                      "Welcome to Naksa, your one-stop shop for services in 3D design, architecture, interior design, and vastu consulting. In addition to being aesthetically beautiful, rooms you design with the assistance of our team of talented architects, interior designers, and vastu experts will also be practical and harmonious.",
                      textAlign: TextAlign.justify,
                      style: GoogleFonts.merriweather(fontSize: 18),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 10),
                    width: MediaQuery.of(context).size.width * 0.4,
                    child: Text(
                      "At Naksa, we are dedicated to offering our customers unmatched quality, imaginative ideas, and great service. To find out more about our offerings and how we can assist you in realising your vision, get in touch with us right now.",
                      textAlign: TextAlign.justify,
                      style: GoogleFonts.merriweather(fontSize: 18),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                width: 50,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                      child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      "assets/about_us.jpg",
                      height: MediaQuery.of(context).size.height * 0.55,
                      width: MediaQuery.of(context).size.width * 0.40,
                      fit: BoxFit.fill,
                    ),
                  )),
                ],
              )
            ],
          )),
    );
  }

  Widget DesktopServiceMain() {
    return Center(
      child: Container(
          margin: const EdgeInsets.only(left: 70, right: 70, top: 6),
          // height: 280,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                      width: MediaQuery.of(context).size.width / 2.4,
                      child: Text(
                        "Grow Your Business With Us",
                        textAlign: TextAlign.start,
                        maxLines: 2,
                        style: GoogleFonts.merriweather(
                            fontSize: 60, fontWeight: FontWeight.bold),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 10),
                    width: MediaQuery.of(context).size.width * 0.4,
                    child: Text(
                      "Welcome to Naksa, your one-stop shop for services in 3D design, architecture, interior design, and vastu consulting. In addition to being aesthetically beautiful, rooms you design with the assistance of our team of talented architects, interior designers, and vastu experts will also be practical and harmonious.",
                      textAlign: TextAlign.justify,
                      style: GoogleFonts.merriweather(fontSize: 18),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 10),
                    width: MediaQuery.of(context).size.width * 0.4,
                    child: Text(
                      "At Naksa, we are dedicated to offering our customers unmatched quality, imaginative ideas, and great service. To find out more about our offerings and how we can assist you in realising your vision, get in touch with us right now.",
                      textAlign: TextAlign.justify,
                      style: GoogleFonts.merriweather(fontSize: 18),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                width: 50,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                      child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      "assets/about_us.jpg",
                      height: MediaQuery.of(context).size.height * 0.55,
                      width: MediaQuery.of(context).size.width * 0.40,
                      fit: BoxFit.fill,
                    ),
                  )),
                ],
              )
            ],
          )),
    );
  }
}
