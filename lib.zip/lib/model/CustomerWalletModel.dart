// To parse this JSON data, do
//
//     final customerWalletModel = customerWalletModelFromJson(jsonString);

import 'dart:convert';

CustomerWalletModel customerWalletModelFromJson(String str) =>
    CustomerWalletModel.fromJson(json.decode(str));

String customerWalletModelToJson(CustomerWalletModel data) =>
    json.encode(data.toJson());

class CustomerWalletModel {
  CustomerWalletModel({
    required this.walletdata,
    required this.status,
  });

  List<Walletdatum> walletdata;
  bool status;

  factory CustomerWalletModel.fromJson(Map<String, dynamic> json) =>
      CustomerWalletModel(
        walletdata: List<Walletdatum>.from(
            json["walletdata"].map((x) => Walletdatum.fromJson(x))),
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "walletdata": List<dynamic>.from(walletdata.map((x) => x.toJson())),
        "status": status,
      };
}

class Walletdatum {
  Walletdatum({
    required this.walletid,
    required this.walletamount,
    required this.transdate,
    required this.updatedat,
    required this.userid,
  });

  int walletid;
  String walletamount;
  String transdate;
  dynamic updatedat;
  int userid;

  factory Walletdatum.fromJson(Map<String, dynamic> json) => Walletdatum(
        walletid: json["walletid"],
        walletamount: json["walletamount"],
        transdate: json["transdate"],
        updatedat: json["updatedat"],
        userid: json["userid"],
      );

  Map<String, dynamic> toJson() => {
        "walletid": walletid,
        "walletamount": walletamount,
        "transdate": transdate,
        "updatedat": updatedat,
        "userid": userid,
      };
}
