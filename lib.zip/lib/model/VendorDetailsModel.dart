// To parse this JSON data, do
//
//     final VendorDetailsmodel = VendorDetailsmodelFromJson(jsonString);

import 'dart:convert';

VendorDetailsmodel VendorDetailsmodelFromJson(String str) =>
    VendorDetailsmodel.fromJson(json.decode(str));

String VendorDetailsmodelToJson(VendorDetailsmodel data) =>
    json.encode(data.toJson());

class VendorDetailsmodel {
  VendorDetailsmodel({
    required this.vendorCount,
    required this.status,
    required this.vdata,
    
  });

  int vendorCount;
  bool status;
  List<Vdatum> vdata;

  factory VendorDetailsmodel.fromJson(Map<String, dynamic> json) =>
      VendorDetailsmodel(
        vendorCount: json["vendorCount"],
        status: json["status"],
        vdata: List<Vdatum>.from(json["vdata"].map((x) => Vdatum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "vendorCount": vendorCount,
        "status": status,
        "data": List<dynamic>.from(vdata.map((x) => x.toJson())),
      };
}

class Vdatum {
  Vdatum({
    required this.name,
    required this.email,
    required this.id,
    required this.photo,
    required this.language,
    required this.primaryskills,
    required this.startdate,
    required this.enddate,
    required this.audicallprice,
    required this.videocallprice,
    required this.aboutus,
  });

  String name;
  String email;
  int id;
  String photo;
  String language;
  String primaryskills;
  DateTime startdate;
  DateTime enddate;
  String audicallprice;
  String videocallprice;
  String aboutus;

  factory Vdatum.fromJson(Map<String, dynamic> json) => Vdatum(
        name: json["name"],
        email: json["email"],
        id: json["id"],
        photo: json["photo"],
        language: json["language"],
        primaryskills: json["primaryskills"],
        startdate: DateTime.parse(json["startdate"]),
        enddate: DateTime.parse(json["enddate"]),
        audicallprice: json["audicallprice"],
        videocallprice: json["videocallprice"],
        aboutus: json["aboutus"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "email": email,
        "id": id,
        "photo": photo,
        "language": language,
        "primaryskills": primaryskills,
        "startdate":
            "${startdate.year.toString().padLeft(4, '0')}-${startdate.month.toString().padLeft(2, '0')}-${startdate.day.toString().padLeft(2, '0')}",
        "enddate":
            "${enddate.year.toString().padLeft(4, '0')}-${enddate.month.toString().padLeft(2, '0')}-${enddate.day.toString().padLeft(2, '0')}",
        "audicallprice": audicallprice,
        "videocallprice": videocallprice,
        "aboutus": aboutus,
      };
}
