// To parse this JSON data, do
//
//     final orderNotificationModel = orderNotificationModelFromJson(jsonString);

import 'dart:convert';

CustomerProfileModel orderNotificationModelFromJson(String str) =>
    CustomerProfileModel.fromJson(json.decode(str));

String orderNotificationModelToJson(CustomerProfileModel data) =>
    json.encode(data.toJson());

class CustomerProfileModel {
  int? rowsCount;
  List<CustomerP>? data;

  CustomerProfileModel({
    this.rowsCount,
    this.data,
  });

  factory CustomerProfileModel.fromJson(Map<String, dynamic> json) =>
      CustomerProfileModel(
        rowsCount: json["rowsCount"],
        data: List<CustomerP>.from(
            json["data"].map((x) => CustomerP.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class CustomerP {
  int? id;
  String? phone;
  String? name;
  String? otp;
  String? email;
  String? dob;
  String? gender;
  String? photo;
  String? mobNotification;
  String? transdate;

  CustomerP({
    this.id,
    this.phone,
    this.name,
    this.otp,
    this.email,
    this.dob,
    this.gender,
    this.photo,
    this.mobNotification,
    this.transdate,
  });

  factory CustomerP.fromJson(Map<String, dynamic> json) => CustomerP(
        id: json["id"],
        phone: json["phone"],
        name: json["name"],
        otp: json["otp"],
        email: json["email"],
        dob: json["dob"],
        gender: json["gender"],
        photo: json["photo"],
        mobNotification: json["mob_notification"],
        transdate: json["transdate"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "phone": phone,
        "name": name,
        "otp": otp,
        "email": email,
        "dob": dob,
        "gender": gender,
        "photo": photo,
        "mob_notification": mobNotification,
        "transdate": transdate,
      };
}
