// To parse this JSON data, do
//
//     final gifts = giftsFromJson(jsonString);

import 'dart:convert';

Gifts giftsFromJson(String str) => Gifts.fromJson(json.decode(str));

String giftsToJson(Gifts data) => json.encode(data.toJson());

class Gifts {
    int rowsCount;
    bool status;
    List<gifft> data;

    Gifts({
        required this.rowsCount,
        required this.status,
        required this.data,
    });

    factory Gifts.fromJson(Map<String, dynamic> json) => Gifts(
        rowsCount: json["rowsCount"],
        status: json["status"],
        data: List<gifft>.from(json["data"].map((x) => gifft.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class gifft {
    int id;
    String? name;
    String icon;
    String amount;

    gifft({
        required this.id,
        this.name,
        required this.icon,
        required this.amount,
    });

    factory gifft.fromJson(Map<String, dynamic> json) => gifft(
        id: json["id"],
        name: json["name"],
        icon: json["icon"],
        amount: json["amount"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "icon": icon,
        "amount": amount,
    };
}
