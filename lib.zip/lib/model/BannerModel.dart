// To parse this JSON data, do
//
//     final bannerModel = bannerModelFromJson(jsonString);

import 'dart:convert';

BannerModel bannerModelFromJson(String str) =>
    BannerModel.fromJson(json.decode(str));

String bannerModelToJson(BannerModel data) => json.encode(data.toJson());

class BannerModel {
  BannerModel({
    required this.rowsCount,
    required this.data,
  });

  int rowsCount;
  List<BDatum> data;

  factory BannerModel.fromJson(Map<String, dynamic> json) => BannerModel(
        rowsCount: json["rowsCount"],
        data: List<BDatum>.from(json["data"].map((x) => BDatum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class BDatum {
  BDatum({
    required this.id,
    required this.banimage,
  });

  int id;
  String banimage;

  factory BDatum.fromJson(Map<String, dynamic> json) => BDatum(
        id: json["id"],
        banimage: json["banimage"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "banimage": banimage,
      };
}
