// To parse this JSON data, do
//
//     final orderNotificationModel = orderNotificationModelFromJson(jsonString);

import 'dart:convert';

OrderNotificationModel orderNotificationModelFromJson(String str) =>
    OrderNotificationModel.fromJson(json.decode(str));

String orderNotificationModelToJson(OrderNotificationModel data) =>
    json.encode(data.toJson());

class OrderNotificationModel {
  int? rowsCount;
  List<OrderNotification>? data;

  OrderNotificationModel({
    this.rowsCount,
    this.data,
  });

  factory OrderNotificationModel.fromJson(Map<String, dynamic> json) =>
      OrderNotificationModel(
        rowsCount: json["rowsCount"],
        data: List<OrderNotification>.from(
            json["data"].map((x) => OrderNotification.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class OrderNotification {
  String? name;
  int? id;
  String? photo;
  int? orderid;
  String? channelname;
  String? notificationTitle;
  String? orderfor;
  String? orderstatus;

  OrderNotification({
    this.name,
    this.id,
    this.photo,
    this.orderid,
    this.channelname,
    this.notificationTitle,
    this.orderfor,
    this.orderstatus,
  });

  factory OrderNotification.fromJson(Map<String, dynamic> json) =>
      OrderNotification(
        name: json["name"],
        id: json["id"],
        photo: json["photo"],
        orderid: json["orderid"],
        channelname: json["channelname"],
        notificationTitle: json["notification_title"],
        orderfor: json["orderfor"],
        orderstatus: json["orderstatus"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "id": id,
        "photo": photo,
        "orderid": orderid,
        "channelname": channelname,
        "notification_title": notificationTitle,
        "orderfor": orderfor,
        "orderstatus": orderstatus,
      };
}
