// To parse this JSON data, do
//
//     final ExpertPortfolioModel = ExpertPortfolioModelFromJson(jsonString);

import 'dart:convert';

ExpertPortfolioModel ExpertPortfolioModelFromJson(String str) => ExpertPortfolioModel.fromJson(json.decode(str));

String ExpertPortfolioModelToJson(ExpertPortfolioModel data) => json.encode(data.toJson());

class ExpertPortfolioModel {
    ExpertPortfolioModel({
        required this.rowsCount,
        required this.data,
    });

    int rowsCount;
    List<ExpertData> data;

    factory ExpertPortfolioModel.fromJson(Map<String, dynamic> json) => ExpertPortfolioModel(
        rowsCount: json["rowsCount"],
        data: List<ExpertData>.from(json["data"].map((x) => ExpertData.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class ExpertData {
    ExpertData({
        required this.id,
        required this.ecategory,
        required this.eimage,
    });

    int id;
    String ecategory;
    String eimage;

    factory ExpertData.fromJson(Map<String, dynamic> json) => ExpertData(
        id: json["id"],
        ecategory: json["ecategory"],
        eimage: json["eimage"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "ecategory": ecategory,
        "eimage": eimage,
    };
}
