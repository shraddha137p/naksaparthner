// To parse this JSON data, do
//
//     final vendorModel = vendorModelFromJson(jsonString);

import 'dart:convert';

VendorModel vendorModelFromJson(String str) =>
    VendorModel.fromJson(json.decode(str));

String vendorModelToJson(VendorModel data) => json.encode(data.toJson());

class VendorModel {
  VendorModel({
    required this.rowsCount,
    required this.status,
    required this.data,
  });

  int rowsCount;
  bool status;
  List<Datum> data;

  factory VendorModel.fromJson(Map<String, dynamic> json) => VendorModel(
        rowsCount: json["rowsCount"],
        status: json["status"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    required this.name,
    required this.id,
    required this.photo,
    required this.language,
    required this.primaryskills,
    required this.startdate,
    required this.enddate,
    required this.audicallprice,
  });

  String name;
  int id;
  String photo;
  String language;
  String primaryskills;
  DateTime startdate;
  DateTime enddate;
  String audicallprice;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        name: json["name"],
        id: json["id"],
        photo: json["photo"],
        language: json["language"],
        primaryskills: json["primaryskills"],
        startdate: DateTime.parse(json["startdate"]),
        enddate: DateTime.parse(json["enddate"]),
        audicallprice: json["audicallprice"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "id": id,
        "photo": photo,
        "language": language,
        "primaryskills": primaryskills,
        "startdate":
            "${startdate.year.toString().padLeft(4, '0')}-${startdate.month.toString().padLeft(2, '0')}-${startdate.day.toString().padLeft(2, '0')}",
        "enddate":
            "${enddate.year.toString().padLeft(4, '0')}-${enddate.month.toString().padLeft(2, '0')}-${enddate.day.toString().padLeft(2, '0')}",
        "audicallprice": audicallprice,
      };
}
