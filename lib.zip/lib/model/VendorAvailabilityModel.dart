// To parse this JSON data, do
//
//     final vendorAvailabilityModel = vendorAvailabilityModelFromJson(jsonString);

import 'dart:convert';

VendorAvailabilityModel vendorAvailabilityModelFromJson(String str) =>
    VendorAvailabilityModel.fromJson(json.decode(str));

String vendorAvailabilityModelToJson(VendorAvailabilityModel data) =>
    json.encode(data.toJson());

class VendorAvailabilityModel {
  VendorAvailabilityModel({
    required this.rowsCount,
    required this.status,
    required this.data,
  });

  int rowsCount;
  bool status;
  List<VendorAData> data;

  factory VendorAvailabilityModel.fromJson(Map<String, dynamic> json) =>
      VendorAvailabilityModel(
        rowsCount: json["rowsCount"],
        status: json["status"],
        data: List<VendorAData>.from(
            json["data"].map((x) => VendorAData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class VendorAData {
  VendorAData({
    required this.id,
    required this.day,
    required this.slotnumber,
    required this.slotrange,
    required this.createdat,
    required this.updatedat,
    required this.vid,
  });

  int id;
  String day;
  String slotnumber;
  String slotrange;
  String createdat;
  String updatedat;
  int vid;

  factory VendorAData.fromJson(Map<String, dynamic> json) => VendorAData(
        id: json["id"],
        day: json["day"],
        slotnumber: json["slotnumber"],
        slotrange: json["slotrange"],
        createdat: json["createdat"],
        updatedat: json["updatedat"],
        vid: json["vid"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "day": day,
        "slotnumber": slotnumber,
        "slotrange": slotrange,
        "createdat": createdat,
        "updatedat": updatedat,
        "vid": vid,
      };
}
