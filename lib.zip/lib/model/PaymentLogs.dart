// To parse this JSON data, do
//
//     final customerPaymentLogsModel = customerPaymentLogsModelFromJson(jsonString);

import 'dart:convert';

CustomerPaymentLogsModel customerPaymentLogsModelFromJson(String str) => CustomerPaymentLogsModel.fromJson(json.decode(str));

String customerPaymentLogsModelToJson(CustomerPaymentLogsModel data) => json.encode(data.toJson());

class CustomerPaymentLogsModel {
    List<Paymentlog>? paymentlog;
    int? rowsCount;

    CustomerPaymentLogsModel({
        this.paymentlog,
        this.rowsCount,
    });

    factory CustomerPaymentLogsModel.fromJson(Map<String, dynamic> json) => CustomerPaymentLogsModel(
        paymentlog: List<Paymentlog>.from(json["paymentlog"].map((x) => Paymentlog.fromJson(x))),
        rowsCount: json["rowsCount"],
    );

    Map<String, dynamic> toJson() => {
        "paymentlog": List<dynamic>.from(paymentlog!.map((x) => x.toJson())),
        "rowsCount": rowsCount,
    };
}

class Paymentlog {
    int? id;
    String? amount;
    String? gst;
    String? userid;
    String? createdAt;
    String? updatedAt;
    String? currency;
    String? paymentId;
    String? orderid;
    String? signature;
    String?status;

    Paymentlog({
        this.id,
        this.amount,
        this.gst,
        this.userid,
        this.createdAt,
        this.updatedAt,
        this.currency,
        this.paymentId,
        this.orderid,
        this.signature,
        this.status,
    });

    factory Paymentlog.fromJson(Map<String, dynamic> json) => Paymentlog(
        id: json["id"],
        amount: json["amount"],
        gst: json["gst"],
        userid: json["userid"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
        currency: json["currency"],
        paymentId: json["payment_id"],
        orderid: json["orderid"],
        signature: json["signature"],
        status: json["status"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "amount": amount,
        "gst": gst,
        "userid": userid,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "currency": currency,
        "payment_id": paymentId,
        "orderid": orderid,
        "signature": signature,
        "status": status,
    };
}
