class LiveStreamFirebase {
  final String name;
  final String image;
  final String uid;
  final startedAt;
  final int viewer;
  final String channelId;
  final String tempToken;
  final String Channelname;
  final String islive;

  LiveStreamFirebase(
      {required this.name,
      required this.image,
      required this.uid,
      required this.startedAt,
      required this.viewer,
      required this.channelId,
      required this.Channelname,
      required this.tempToken,
      required this.islive});

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'image': image,
      'uid': uid,
      'viewer': viewer,
      'channelid': channelId,
      'startedAt': startedAt,
      "tempToken": tempToken,
      "Channelname": Channelname,
      'islive': islive
    };
  }

  factory LiveStreamFirebase.fromMap(Map<String, dynamic> map) {
    return LiveStreamFirebase(
        name: map['name'] ?? '',
        image: map['image'] ?? '',
        uid: map['uid'] ?? '',
        startedAt: map['startedAt'] ?? '',
        viewer: map['viewer']?.toInt() ?? 0,
        channelId: map['channelid'] ?? '',
        Channelname: map['Channelname'] ?? '',
        tempToken: map['tempToken'] ?? '',
        islive: map['islive'] ?? '');
  }
}
